@echo off
cd /d "%~dp0"
start "" "FIND_YOURSELF_v9.exe" --rendering-method gl_compatibility
