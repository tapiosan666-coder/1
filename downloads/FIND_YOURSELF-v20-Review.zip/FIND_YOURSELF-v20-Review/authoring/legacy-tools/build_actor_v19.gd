extends SceneTree
const JOINTS=["Pelvis","UpperArm_L","Forearm_L","UpperArm_R","Forearm_R","Thigh_L","Shin_L","Thigh_R","Shin_R","Head","Foot_L","Foot_R"]
const PARENTS=[-1,0,1,0,3,0,5,0,7,0,6,8]
func _initialize()->void:call_deferred("run")
func own(node:Node,root:Node)->void:
 for ch in node.get_children():ch.owner=root;own(ch,root)
func collect(n:Node,out:Array)->void:
 if n is MeshInstance3D:out.append(n)
 for ch in n.get_children():collect(ch,out)
func material_for(name:String)->StandardMaterial3D:
 var m=StandardMaterial3D.new();m.resource_name=name;m.roughness=.78
 m.albedo_color={"overshirt":Color(.17,.27,.32),"trousers":Color(.10,.13,.16),"neck":Color(.65,.43,.30),"details":Color(.25,.27,.27),"shoes":Color(.07,.06,.05),"sole":Color(.22,.21,.20),"tee":Color(.82,.79,.70)}.get(name,Color(.3,.3,.3));return m
func run()->void:
 var root=Node3D.new();root.name="ShopperAsset";var sk=Skeleton3D.new();sk.name="Skeleton3D";root.add_child(sk)
 var locations:Array[Vector3]=[Vector3(0,.97,0),Vector3(-.215,1.46,.008),Vector3(-.302,1.16,.008),Vector3(.215,1.46,.008),Vector3(.302,1.16,.008),Vector3(-.105,.97,0),Vector3(-.105,.52,0),Vector3(.105,.97,0),Vector3(.105,.52,0),Vector3(0,1.50,0),Vector3(-.105,.08,-.035),Vector3(.105,.08,-.035)]
 var skin=Skin.new()
 for i in range(12):
  sk.add_bone(JOINTS[i]);sk.set_bone_parent(i,PARENTS[i]);var rest=locations[i]-(locations[PARENTS[i]]if PARENTS[i]>=0 else Vector3.ZERO);sk.set_bone_rest(i,Transform3D(Basis.IDENTITY,rest));skin.add_bind(i,Transform3D(Basis.IDENTITY,-locations[i]))
 sk.reset_bone_poses()
 var source:Mesh=load("res://assets/v18/people/civilian_body.res");var mesh=ArrayMesh.new();var count:int=0
 for index in source.get_surface_count():
  var a=source.surface_get_arrays(index);var v:PackedVector3Array=a[Mesh.ARRAY_VERTEX];var packed:PackedVector2Array=a[Mesh.ARRAY_TEX_UV2];var bones=PackedInt32Array();var weights=PackedFloat32Array();bones.resize(v.size()*4);weights.resize(v.size()*4)
  for j in v.size():
   var first:int=floori(packed[j].x);var weight:float=clampf((packed[j].x-first)*2.,0.,1.);bones[j*4]=first;bones[j*4+1]=roundi(packed[j].y);weights[j*4]=weight;weights[j*4+1]=1.-weight
  for j in v.size():
   if v[j].y<.18:
    var foot:int=10 if v[j].x<0 else 11;var shin:int=6 if v[j].x<0 else 8;var blend:float=1.-smoothstep(.12,.18,v[j].y);bones[j*4]=foot;bones[j*4+1]=shin;weights[j*4]=blend;weights[j*4+1]=1.-blend
  a[Mesh.ARRAY_BONES]=bones;a[Mesh.ARRAY_WEIGHTS]=weights;mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,a);mesh.surface_set_material(index,material_for(source.surface_get_material(index).resource_name));count+=v.size()
 var body=MeshInstance3D.new();body.name="ContinuousClothing";body.mesh=load("res://skin_palette_v19.gd").body_mesh(0,mesh);body.skin=skin;root.add_child(body);body.skeleton=NodePath("../Skeleton3D")
 var head=load("res://assets/v18/people/civilian.glb").instantiate();var parts:Array=[];collect(head,parts)
 var detail_names:Array=[]
 for part:MeshInstance3D in parts:
  var label:String=str(part.name).to_lower();var node=MeshInstance3D.new();node.mesh=part.mesh.duplicate();node.name=part.name
  var attachment=BoneAttachment3D.new();var bone:String="Head";var offset=Vector3(0,.20,0)
  if label.contains("hair"):offset=Vector3(0,.31,0)
  elif label.contains("eye_l"):offset=Vector3(-.036924,.20,-.0835)
  elif label.contains("eye_r"):offset=Vector3(.036924,.20,-.0835)
  elif label.contains("hand"):
   var left:bool=label.contains("_l");bone="Forearm_L"if left else"Forearm_R";var bound: AABB=part.mesh.get_aabb();offset=Vector3(-.082 if left else .082,.875-bound.end.y-1.16,0.)
  attachment.bone_name=bone;attachment.name="Attach_"+part.name;sk.add_child(attachment);attachment.add_child(node);node.position=offset
  for j in node.mesh.get_surface_count():
   var old=node.mesh.surface_get_material(j);var mat=old.duplicate()if old!=null else StandardMaterial3D.new()
   if mat is StandardMaterial3D:
    mat.roughness=.65 if label.contains("head")or label.contains("hand")else .76;mat.vertex_color_use_as_albedo=true;mat.cull_mode=BaseMaterial3D.CULL_DISABLED
   node.mesh.surface_set_material(j,mat)
  detail_names.append(label)
 head.free();own(root,root);var scene=PackedScene.new();var status=scene.pack(root);if status!=OK:quit(2);return
 var err=ResourceSaver.save(scene,"res://assets/v19/character/shopper-motion.scn",ResourceSaver.FLAG_COMPRESS);print("V18_SKINNED_SHOPPER ",err," clothing_vertices ",count," details ",detail_names)
 var f=FileAccess.open("res://source/v19/legacy-person-asset.json",FileAccess.WRITE);f.store_string(JSON.stringify({"source":"Existing MakeHuman-derived CC0 head/hands + original continuous clothed body; no gameplay NPC code copied","native_skeleton_bones":12,"clothing_vertices":count,"details":detail_names,"prototype_quality":true,"AAA_quality_claim":false},"  "));root.free();quit(err)
