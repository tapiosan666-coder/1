# 編集・再生成用データ

`v20-source/FY-F-01.blend`は編集可能なBlender4.3原稿（画像パック済み）、`base.vrm`は許諾付き原型です。商用・改変・再配布の条件は`../licenses/v20`を参照してください。原型はCC0ではありません。

Godotの通常起動にはこれらの原稿もBlenderも不要です。Godot ZIPだけでF5起動できます。

再生成する場合は、Godotプロジェクトの`authoring`へこのフォルダの`v20-source`をコピーしてください。Godot ZIPに収録した`authoring/v20_character.py`をBlender4.3で実行し、その後Python+Pillowで`authoring/v20_lossless_images.py`を実行します。後者はPNGの復号RGBA一致を検査しながら可逆WebP外部画像へ整理します。元・派生ライセンス設定もGLBへ埋め込みます。Godotで再インポート後に実画面と動作を再検査してください。

フォント再サブセット処理は通常不要です。再実行する場合は、フル版Noto Sans CJK JPのパスを環境変数`FY_FULL_NOTO_FONT`で指定します。配布版のUI用フォントは既に必要な文字を含みます。

`legacy-tools`は以前のオフライン制作ツールです。現行ランタイムの依存物ではありません。過去の入力・環境に依存するツールもあり、そのまま全世代を再生成できることまでは保証していません。以前の設計原本やゲーム本体へ自動反映しないでください。
