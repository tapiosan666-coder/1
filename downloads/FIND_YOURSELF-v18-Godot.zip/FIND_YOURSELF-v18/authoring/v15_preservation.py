from pathlib import Path
import sys,hashlib,collections,json
P=Path(__file__).resolve().parents[1];O=P.parent/'FIND_YOURSELF-Site-v14';sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
checks=[]
for r in read(O/'source/v13/pack-manifest.json'):
 path=r['path'];checks.append({'path':path,'unchanged':sha(P/path)==sha(O/path),'sha256':sha(P/path)})
for path in['player.gd','escalator_v2.gd','staff_doors.gd','elevators_v11.gd','settings_v7.gd','source/site-v11.json.zst','source/v12/floors-updated-patch.json','source/v14/roof-planting.json','source/v14/roof-bed-support.json','roof_finish_v14.gd']:
 checks.append({'path':path,'unchanged':sha(P/path)==sha(O/path),'sha256':sha(P/path)})
F=read(P/'source/v11/floors-updated.json');old=read(O/'source/v11/floors-updated.json');ids=[s['id']for f in F for s in f['stores']];oids=[s['id']for f in old for s in f['stores']];assert sorted(ids)==sorted(oids)and len(ids)==480 and len(F)==15
oldstores={s['id']:s for f in old for s in f['stores']}
assert all(s['polygon'].equals(oldstores[s['id']]['polygon'])and s['entry']==oldstores[s['id']]['entry']for f in F for s in f['stores'])
assert all(r['unchanged']for r in checks)
cp=read(P/'source/v15/C-outlet-proposal.json');es=read(P/'source/v15/ES-site-proposal.json');bound=read(P/'source/v15/boundary-audit.json');inventory=read(P/'source/v15/store-inventory.json');flag=collections.Counter(t for r in inventory for t in r['flags'])
result={'normal_building_and_control_checks':checks,'all_normal_packs_unchanged':True,'floors_retained':len(F),'IDs_retained':len(ids),'normal_floor_geometry_unchanged':all(f['floor_plate'].equals(q['floor_plate'])for f,q in zip(F,old)),'canonical_shop_plots_unchanged':True,'C_proposal_store_area_lost_m2':sum(r['retail_area_lost_m2']for r in cp['floors']),'C_proposal':'UNAPPROVED','ES_site_proposal':'UNAPPROVED','ES_site_flights':len(es['escalators']),'ES_site_levels':['1F','2F','3F','RF'],'ES_basement':'NOT INSTALLED / parking conflict','RF_SUPPORT_16':'UNAPPROVED','BRF_GARDEN_2_BED_4':'NOT INSTALLED / relocation proposal only','boundary_non_RF_stores':sum(r['floor']!='RF'for r in bound['stores']),'boundary_non_RF_uncovered_stores':sum(bool(r['issue_samples'])and r['floor']!='RF'for r in bound['stores']),'boundary_open_RF_plots_review':sum(r['floor']=='RF'for r in bound['stores']),'boundary_samples':sum(r['boundary_samples']for r in bound['stores']),'shape_candidates':dict(flag),'candidates_are_not_automatically_defects':True,'human_playtest':False,'Windows_GPU_FPS':None,'FF16_quality_reached':False,'main_game_integrated':False}
write(P/'source/v15/preservation-audit.json',result);print('V15_PRESERVATION',len(checks),'unchanged checks',len(ids),'IDs',len(F),'floors')
