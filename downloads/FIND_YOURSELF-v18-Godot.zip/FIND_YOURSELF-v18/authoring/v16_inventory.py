from pathlib import Path
import sys,collections,hashlib
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
F=read(P/'source/v11/floors-updated.json');rows=[]
for f in F:
 row={'wing':f['wing'],'floor':f['label'],'y':f['height'],'store_count':len(f['stores']),'categories':dict(collections.Counter(s['category']for s in f['stores'])),'world_public_bounds':[f['public'].bounds[i]+(429 if i%2==0 else-46)for i in range(4)],'public_area_m2':f['public'].area,'public_center_world':[f['public'].centroid.x+429,f['public'].centroid.y-46],'keys':list(f),'zones':[]}
 for key in ['courts','gardens','program','plazas','hubs','outdoor_ground','indoor_public']:
  values=f.get(key,[])
  if hasattr(values,'area'):row['zones'].append({'type':key,'area_m2':values.area});continue
  for x in values:
   g=x.get('polygon',x.get('geometry'))
   row['zones'].append({'type':key,'id':x.get('id'),'name':x.get('name',x.get('use',x.get('role'))),'area_m2':g.area if g is not None and not g.is_empty else None,'center_world':[g.centroid.x+429,g.centroid.y-46]if g is not None and not g.is_empty else None})
 rows.append(row)
write(P/'source/v16/existing-floor-inventory.json',rows)
for r in rows:print(r['wing'],r['floor'],r['store_count'],r['categories'],'zones',[(z.get('id'),z.get('name'),z.get('center_world'))for z in r['zones']][:10])
hubs=read(P/'source/v13/arrival-hubs.json');print('EXISTING_HUBS',[(r.get('id'),r.get('kind'),r.get('point'))for r in hubs][:18])
a=read(P/'source/v13/amenities-public.json');print('PUBLIC_ASSETS',collections.Counter(i['asset']for i in a['instances']if str(i['group']).startswith(('V13-HUB','V13-BRF'))))
print('B1/RF canon keys',[(r['wing'],r['floor'],r['keys'])for r in rows if r['floor']in['B1','RF']][:4])
