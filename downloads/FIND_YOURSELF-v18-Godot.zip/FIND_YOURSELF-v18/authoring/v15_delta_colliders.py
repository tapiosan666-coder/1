"""Lossless sparse replacement layers. Store only changed material collider groups, never re-quantize geometry."""
from pathlib import Path
import sys,numpy as np,hashlib
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
paths=[r['path']for r in read(P/'source/v13/pack-manifest.json')if r['path']not in['assets/v12/C-outlet.pack.zst','assets/v12/C-supported-finish.pack.zst','assets/v12/es-transfer-study.pack.zst']];cols={};rows=[]
for path in paths:
 for k,v in load_pack(P/path)['colliders'].items():cols.setdefault(k,[]).append(v)
cols={k:np.concatenate(v).astype('<f4')for k,v in cols.items()}
def signature(a):return hashlib.sha256(np.sort(np.asarray(a,dtype='<f4').reshape(-1,9).view('V36').ravel()).tobytes()).hexdigest()
sig={k:signature(v)for k,v in cols.items()}
for path in(['assets/v15/C-finish-replacement.pack.zst']if'--c-only'in sys.argv else['assets/v15/ES-site-replacement.pack.zst']if'--es-only'in sys.argv else['assets/v15/C-finish-replacement.pack.zst','assets/v15/ES-site-replacement.pack.zst']):
 g=load_pack(P/path);before={k:signature(v)for k,v in g['colliders'].items()};omitted=[]
 for k in list(g['colliders']):
  if before[k]==sig.get(k):g['colliders'].pop(k);omitted.append(k)
 expanded=dict(cols);expanded.update(g['colliders']);assert all(signature(expanded[k])==v for k,v in before.items())
 print(save_zst(P/path,g));rows.append({'path':path,'unchanged_layers_omitted':omitted,'replacement_layers':list(g['colliders']),'all_effective_collider_triangle_multisets_unchanged':True,'geometry_not_simplified':True})
target=P/'source/v15/lossless-collider-deltas.json'
if ('--es-only'in sys.argv or '--c-only'in sys.argv) and target.exists():rows=[r for r in read(target)if r['path']not in[q['path']for q in rows]]+rows
write(target,rows)
