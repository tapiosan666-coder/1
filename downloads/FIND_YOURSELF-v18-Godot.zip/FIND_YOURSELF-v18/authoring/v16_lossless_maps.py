from pathlib import Path
import json,struct,hashlib,sys
sys.path.append('/workspace/.venvs/find-yourself/lib/python3.12/site-packages');import zstandard
P=Path(__file__).resolve().parents[1];rows=[]
for name in['v12/map-data.json','v12/map-data-C-option.json','v13/map-data.json','v13/map-data-C-option.json','v15/map-data-C-option.json','v15/map-data-ES-option.json']:
 p=P/'source'/name
 if not p.exists():continue
 b=p.read_bytes();packed=b'FYZ1'+struct.pack('<I',len(b))+zstandard.ZstdCompressor(level=19,threads=2).compress(b);assert zstandard.ZstdDecompressor().decompress(packed[8:])==b
 Path(str(p)+'.zst').write_bytes(packed);p.unlink();rows.append({'path':'source/'+name,'decoded_sha256':hashlib.sha256(b).hexdigest(),'decoded_bytes':len(b),'packed_bytes':len(packed),'unchanged_bytes_after_decoding':True})
(P/'source/v16/lossless-map-packaging.json').write_text(json.dumps(rows,indent=2));print('V16_LOSSLESS_MAPS',len(rows))
