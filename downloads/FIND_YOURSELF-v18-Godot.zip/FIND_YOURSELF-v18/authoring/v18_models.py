"""Original category-specific retail fixtures. Fixed metric origins, no reference photo pixels."""
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parents[1];exec((P/'authoring/v17_models.py').read_text().split('# Original campaign products;')[0]);OUT=P/'assets/v18/models';OUT.mkdir(exist_ok=True)
# Original packaging artwork is projected on product fronts, never wrapped as a generic shelf colour.
from PIL import Image,ImageDraw,ImageFont
for label,title,col in [('dairy','SORA MILK','#284d68'),('pantry','まいにちの穀物','#80613b'),('book','旅と暮らし','#39534b'),('magazine','ROOM & LIFE','#6c5267'),('beauty','LUMINA CARE','#6d7973'),('tech','音と、暮らす。','#293c4f')]:
 im=Image.new('RGB',(512,640),'#f0e9da');dr=ImageDraw.Draw(im);dr.rectangle((0,0,512,65),fill=col);dr.ellipse((100,135,410,435),fill=col);dr.arc((145,180,365,400),15,320,fill='#e7ca8d',width=14);font=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',34);dr.text((256,490),title,font=font,fill=col,anchor='mt');dr.text((256,555),'ORIGINAL COLLECTION',font=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',20),fill=col,anchor='mt');im.save(P/'assets/v18/signs'/(label+'.png'),optimize=True)
labels={k:material('Original_label_'+k,(1,1,1),.68,texture='assets/v18/signs/'+k+'.png')for k in['dairy','pantry','book','magazine','beauty','tech']}
def label_face(x,y,z,w,h,mat):
 return mesh('Printed_product_front',[(x-w/2,y,z-h/2),(x+w/2,y,z-h/2),(x+w/2,y,z+h/2),(x-w/2,y,z+h/2)],[(0,1,2,3)],mat,[(0,0),(1,0),(1,1),(0,1)])
# Apparel: folded merchandise, distinct heights, real hems and a customer display deck.
for x in[-1.15,1.15]:box('Retail_table_trestle',(x,0,.39),(.09,.87,.78),brass,.014)
box('Folded_merchandise_deck',(0,0,.81),(2.7,1.05,.10),wood,.025)
for j in range(6):
 x=-.93+(j%3)*.93;y=-.27+(j//3)*.52
 for k in range(2+j%3):
  box('Folded_knit_body',(x,y,.90+k*.065),(.66,.44,.058),fabrics[(j+k)%5],.02)
  tube('Folded_sleeve_seam',[(x-.25,y-.16,.932+k*.065),(x-.18,y+.12,.932+k*.065)],.002,linen)
done('apparel_fold_table')
# Fitting booth as shop fit-out: three walls, open access curtain, mirror and actual customer opening.
for x in[-.90,.90]:box('Fitting_partition',(x,.0,1.15),(.065,1.75,2.3),cream,.012)
box('Fitting_back',(0,.85,1.15),(1.8,.065,2.3),cream,.012);rail((-.90,-.83,2.25),(.90,-.83,2.25),.02,brass)
for j in range(7):
 x=.34+j*.075;verts=[]
 for z in[.10,2.19]:
  for t in range(5):verts.append((x+t*.02,-.82+math.sin(t*math.pi*.5)*.035,z))
 mesh('Gathered_fitting_curtain',verts,[(i,i+1,i+6,i+5)for i in range(4)],linen)
box('Wall_mirror',(0,.805,1.30),(.75,.012,1.55),steel,.015);box('Fitting_stool',(0,.35,.42),(.55,.5,.12),wood,.02)
for x in[-.2,.2]:box('Stool_leg',(x,.35,.21),(.045,.4,.42),metal,.005)
done('fitting_room_open')
# Apparel / general cash wrap with distinct staff-side recess and payment equipment.
box('Cash_wrap_carcass',(0,0,.46),(2.7,.85,.92),walnut,.035);box('Accessible_low_counter',(-1.15,-.02,.76),(.45,.9,.08),stone,.014);box('Checkout_countertop',(.25,0,.98),(2.35,.95,.09),stone,.02)
box('Terminal_stalk',(.6,.08,1.1),(.07,.09,.25),metal,.008);o=box('Payment_display',(.6,.03,1.29),(.4,.07,.25),metal,.015);o.rotation_euler.x=-.14;label_face(.6,-.012,1.29,.34,.19,labels['tech']);box('Paper_bag_stack',(-.55,0,1.08),(.60,.38,.15),paper,.01);done('retail_cash_wrap')
# Magazine rack: staggered inclined ledges and overlapping face-out publications.
for x in[-.75,.75]:box('Magazine_gable',(x,.05,.85),(.055,.62,1.7),wood,.012)
for row in range(4):
 z=.30+row*.39;box('Magazine_ledge',(0,-.13,z),(1.5,.53,.045),wood,.008)
 for j in range(4):
  x=-.57+j*.38;box('Magazine_stack',(x,.0,z+.18),(.34,.07,.33),paper,.004);label_face(x,-.039,z+.18,.33,.32,labels['magazine']if row%2 else labels['book'])
done('magazine_faceout')
# Fresh produce: angled crates and recognisable departments (citrus, aubergine, greens, roots).
box('Produce_display_body',(0,0,.40),(3.4,1.65,.80),wood,.035)
for j in range(6):
 x=-1.12+(j%3)*1.12;y=-.40+(j//3)*.82;box('Produce_crate',(x,y,.83),(1.03,.75,.10),walnut,.012)
 for k in range(9):
  xx=x-.35+(k%3)*.34;yy=y-.25+(k//3)*.24
  if j%3==0:
   sphere('Citrus',(xx,yy,.96),(.12,.11,.11),pastry);sphere('Citrus_leaf',(xx+.05,yy,1.07),(.065,.02,.012),leafm[1])
  elif j%3==1:
   o=sphere('Aubergine',(xx,yy,1.0),(.075,.15,.075),indigo);o.rotation_euler.z=.5;sphere('Green_calyx',(xx,yy-.12,1.02),(.055,.045,.025),leafm[0])
  else:
   sphere('Cabbage_core',(xx,yy,.98),(.13,.13,.13),leafm[2])
   for a in range(6):
    az=a*math.tau/6;sphere('Folded_cabbage_leaf',(xx+.07*math.cos(az),yy+.07*math.sin(az),1.0),(.10,.065,.12),leafm[a%3])
done('fresh_produce_department')
# Refrigeration: functional depth, opaque insulated back, mullions, product fronts, condenser plinth.
box('Refrigerator_insulation',(0,.29,1.12),(3.4,.22,2.24),cream,.035);box('Refrigerator_plinth',(0,0,.12),(3.5,1.0,.24),metal,.025)
for x in[-1.7,1.7]:box('Refrigerator_side',(x,0,1.15),(.10,.97,2.3),cream,.02)
box('Case_header',(0,0,2.27),(3.5,1.0,.14),sage,.02)
for z in[.30,.76,1.22,1.68]:
 box('Coldcase_shelf',(0,-.02,z),(3.3,.79,.04),steel,.006)
 for j in range(14):
  x=-1.48+j*.225;box('Dairy_carton',(x,-.12,z+.17),(.17,.22,.30),cream,.009);label_face(x,-.235,z+.17,.16,.28,labels['dairy'])
for x in[-1.1,0,1.1]:box('Refrigerator_glass',(x,-.48,1.30),(1.08,.015,1.82),glass,.004);rail((x+.45,-.51,.99),(x+.45,-.51,1.47),.014,steel)
done('dairy_refrigerator')
# Pantry gondola with different package sizes, cartons and labelled bags rather than repeated bottles.
box('Pantry_base',(0,0,.12),(2.2,1.05,.24),walnut,.018);box('Pantry_spine',(0,0,1.02),(2.2,.055,1.8),wood,.012)
for side in[-1,1]:
 for row,z in enumerate([.30,.68,1.06,1.44]):
  box('Pantry_shelf',(0,side*.26,z),(2.2,.47,.045),wood,.007)
  for j in range(9):
   x=-.94+j*.23;h=.22+.04*((j+row)%3);box('Pantry_package',(x,side*.25,z+h/2+.03),(.17,.19,h),cream,.012)
   if side<0:label_face(x,-.35,z+h/2+.03,.16,h-.02,labels['pantry'])
done('pantry_gondola')
# Grocery checkout lane and conveyor, customer bagging surface, scanner and card terminal.
box('Conveyor_carcass',(-.8,0,.48),(2.15,1.0,.96),metal,.04);box('Conveyor_belt',(-.8,0,.985),(1.95,.82,.035),rubber,.008);box('Cash_station',(.78,0,.52),(1.1,.95,1.04),wood,.04);box('Bagging_tray',(1.6,0,.88),(.75,1.05,.08),steel,.02)
box('Barcode_scanner',(.58,-.18,1.06),(.32,.45,.045),metal,.01);box('POS_stand',(.8,.22,1.23),(.07,.09,.36),metal,.009);box('POS_screen',(.8,.16,1.44),(.43,.065,.30),metal,.018)
label_face(.8,.121,1.44,.38,.25,labels['tech']);done('grocery_checkout')
# Electronics specialist wall: original content, separate screens, stands and cables.
box('Electronics_wall',(0,.28,1.3),(3.3,.09,2.6),indigo,.018)
for j in range(3):
 x=-1.04+j*1.04;box('Screen_panel',(x,.16,1.5),(.94,.065,.65),metal,.02);label_face(x,.122,1.5,.87,.57,labels['tech']);rail((x,.15,1.15),(x,.22,.75),.008,metal)
box('Device_service_bench',(0,-.03,.66),(3.2,.68,.12),wood,.015)
for j in range(5):box('Smart_home_device',(-1.25+j*.62,-.08,.89),(.32,.24,.34),cream,.045)
done('electronics_wall_demo')
# Cosmetics perimeter tester bay, integrated vertical light rails and distinct product grouping.
box('Beauty_wall',(0,.30,1.25),(2.7,.07,2.5),cream,.018)
for z in[.50,1.1,1.7]:
 box('Tester_shelf',(0,.03,z),(2.65,.5,.05),stone,.012)
 for j in range(9):
  x=-1.10+j*.275;lathe('Skincare_jar',[(0,0),(.065,0),(.065,.10),(.055,.12),(0,.12)],clay,(x,-.02,z+.03),24);box('Skincare_package',(x,.15,z+.16),(.16,.12,.26),cream,.012);label_face(x,.083,z+.16,.14,.23,labels['beauty'])
for x in[-1.28,1.28]:box('Integrated_diffuser',(x,.21,1.30),(.035,.04,2.2),white,.008)
done('beauty_wall_testers')
# Cafe preparation zone: opaque cabinetry, sink/tap, oven and food-safe worktop.
box('Kitchen_cabinet',(0,.04,.46),(3.4,.78,.92),sage,.03);box('Kitchen_worktop',(0,0,.96),(3.5,.91,.07),steel,.02);box('Oven',(.83,-.015,.55),(.80,.84,.70),metal,.02);box('Oven_glass',(.83,-.45,.53),(.63,.015,.40),glass,.006)
box('Sink_rim',(-.8,0,1.01),(.78,.60,.035),steel,.01);box('Sink_recess',(-.8,0,1.02),(.62,.44,.009),metal,.01);tube('Kitchen_tap',[(-.8,.20,1.02),(-.8,.20,1.34),(-.8,-.07,1.35),(-.8,-.14,1.22)],.018,steel)
box('Kitchen_splashback',(0,.44,1.36),(3.5,.045,.72),cream,.01);done('cafe_kitchen_line')
# Homeware categories: open crockery cupboard and an asymmetric feature island.
for x in[-1.3,1.3]:box('Homeware_gable',(x,.10,1.08),(.07,.59,2.16),wood,.012)
box('Homeware_back',(0,.38,1.08),(2.6,.055,2.16),cream,.01)
for row,z in enumerate([.15,.65,1.15,1.65]):
 box('Homeware_shelf',(0,.10,z),(2.6,.60,.05),wood,.01)
 for j in range(7):
  x=-1.05+j*.35;lathe('Glazed_bowl',[(0,0),(.07,0),(.13,.11),(.12,.12),(.105,.11),(.065,.025),(0,.025)],ceramics[(j+row)%3],(x,.04,z+.03),28)
done('homeware_category_wall')
# Public lounge joinery: integrated planted seat, not a repeated free-standing prop grid.
lathe('Lounge_planter',[(0,0),(.65,0),(.75,.12),(.75,.62),(.64,.67),(.55,.67),(.55,.58),(0,.58)],stone,(-1.25,0,0),40)
box('Lounge_seat_base',(.75,0,.22),(2.8,.82,.44),wood,.04);box('Lounge_seat_cushion',(.75,-.03,.47),(2.75,.78,.14),linen,.05);box('Lounge_back',(.75,.34,.79),(2.75,.13,.65),wood,.025)
for j in range(16):
 a=j*2.4;h=.60+(j%4)*.16;tube('Planter_stem',[(-1.25,0,.59),(-1.25+.25*math.cos(a),.25*math.sin(a),h+1)],.007,leafm[0]);sphere('Planter_leaf',(-1.25+.25*math.cos(a),.25*math.sin(a),h+1),(.18,.08,.04),leafm[j%3])
done('integrated_lounge')
print('V18_CATEGORY_MODELS_DONE',flush=True)
