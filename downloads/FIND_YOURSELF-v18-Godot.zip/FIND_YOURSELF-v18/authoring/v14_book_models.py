from pathlib import Path
P=Path(__file__).resolve().parents[1];src=(P/'authoring/retail_models_v10.py').read_text();exec(src[:src.index('for var in range(3):bookcase')]);OUT=P/'assets/v14/models';OUT.mkdir(exist_ok=True)
poster=material('Original_book_editorial',(1,1,1),.78,texture='assets/v14/materials/book-editorial.png')
for variant in range(2):
 before=set(bpy.context.scene.objects);bookcase(variant,short=True)
 for o in set(bpy.context.scene.objects)-before:o.location.y-=.20
 before=set(bpy.context.scene.objects);bookcase(variant+2,short=True)
 for o in set(bpy.context.scene.objects)-before:o.rotation_euler.z+=math.pi;o.location.y+=.20
 # Printed gable editorial mounted inside the old 2.045m silhouette.
 for side in [-1,1]:
  x=side*1.022;vv=[(x,-.26,.55),(x,.26,.55),(x,.26,1.11),(x,-.26,1.11)];mesh('Book_end_editorial',vv,[(0,1,2,3)],poster,[(0,0),(1,0),(1,1),(0,1)])
 finish('book_double_gondola_'+str(variant))
