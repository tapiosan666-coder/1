from pathlib import Path
import sys,json,collections,csv,hashlib,shutil
P=Path(__file__).resolve().parents[1];R=Path('/workspace/v16-review');(R/'source').mkdir(exist_ok=True);sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
R=Path('/workspace/v16-review');(R/'source').mkdir(parents=True,exist_ok=True)
D=read(P/'source/v16/commons.json');F=read(P/'source/v11/floors-updated.json')
rows=[]
for z in D['zones']:
 items=[q for q in D['instances']if q['zone']==z['id']];foot=unary_union([q['footprint']for q in items if not q['host']]);rows.append({'zone':z['id'],'館':z['wing'],'階':z['floor'],'名称':z['title'],'既存店舗ID':z['store_id'],'状態':('通常版で実装'if z['activation']=='always'else'催事ON時のみ'if z['activation']=='aichi_fair'else'F6未承認別案のみ')if z['implemented']else'追加配置を見送り・v15維持','モデル配置':len(items),'掲示面':z['display_surfaces'],'什器の投影面積㎡':round(foot.area,3),'中心X':z['preferred'][0],'中心Z':z['preferred'][1],'床高m':z['height']})
csvwrite(R/'source/v16-施設と実装範囲.csv',list(rows[0]),[list(r.values())for r in rows])
rows=[{'ID':d['id'],'館':d['wing'],'階level':d['level'],'用途':d['zone'],'モデル':d['model'],'X':d['p'][0],'Y':d['p'][1],'Z':d['p'][2],'向きX':d['n'][0],'向きZ':d['n'][1],'衝突':d['collision'],'表示条件':d['activation'],'既存店舗ID':d['store_id'],'親':d['host']}for d in D['instances']]
csvwrite(R/'source/v16-什器配置台帳.csv',list(rows[0]),[list(r.values())for r in rows])
rows=[{'館':f['wing'],'階':f['label'],'床高m':f['height'],'既存店舗数':len(f['stores']),'v16配置数':sum(d['wing']==f['wing']and d['level']==f['level']for d in D['instances']),'注記':'既存床・店舗IDを維持。追加配置がない箇所はv15のまま。'}for f in F]
csvwrite(R/'source/15層-現状と追加範囲.csv',list(rows[0]),[list(r.values())for r in rows])
for name in ['commons','geometry-check','layout-rejections','preservation','model-bounds','existing-floor-inventory','lossless-model-packaging','lossless-image-aliases','lossless-map-packaging','font-extension']:
 f=P/'source/v16'/(name+'.json')
 if f.exists():shutil.copy2(f,R/'source'/f.name)
shutil.copy2(P/'licenses/v16-original-assets.txt',R/'使用素材とライセンス.txt')
refs=Path('/workspace/FIND_YOURSELF-v16-reference/FIND_YOURSELF-v16-Instruction-and-Images');(R/'references').mkdir(exist_ok=True)
for name in ['01_Codex_v16_統合指示書.md','04_画像資料一覧.md','05_施設別_確認済み情報と観察メモ.md']:shutil.copy2(refs/name,R/'references'/name)
write(R/'source/参照資料の扱い.json',{'directly_viewed_attached_images':12,'concept_boards':3,'v15_Viewport_references':9,'linked_sites_newly_browsed':False,'notes':'添付の3コンセプト画像・9実画面を目視参照。記載された外部施設の観察メモは受領資料であり、今回こちらで現地・公式写真を再検証したものではない。実在ロゴ・写真のゲーム内転用はしていない。'})
write(R/'source/C-RF-water-garden-design-only.json',{'status':'UNAPPROVED_DESIGN_ONLY_NOT_IN_ANY_SCENE','coordinate_system':'proposal-local; world placement not assigned','concept_water_area_m2':240,'concept_water_depth_m':.08,'water_only_mass_tonnes':19.2,'water_only_load_kPa':.7848,'structural_capacity_verified':False,'drainage_verified':False,'evacuation_verified':False,'RF_SUPPORT_16':'UNAPPROVED','normal_and_F4_unchanged':True})
(R/'B館F6-検討結果.md').write_text('''# B館F6の乗り継ぎ検討\n\n配置はv15の未承認別案を保持。通常版へ移設していません。1F→2F→3F→RFは同じ西広場の設備で移動し、2F・3Fの次の上りまで各8.4mです。今回は逆方向の下りも実W入力で検査し、各8.4mの経路を確認しています。橋の既存手すりに別案専用の案内を追加しました。\n\n同じ側へ降り口・次便の乗り口を寄せる案も考えられますが、機械の重なり、床開口、乗降ロビー、店舗・広場との干渉を別に再設計する必要があり、今回の優先課題に対して配置変更の根拠は不足しています。短縮効果を実測した案とは扱わず、現配置の維持と案内を選びました。\n\nB1への同一設備の延伸候補は車路と4台分の駐車に干渉します。地下の既存階段・EV・ESを保持し、無断で開口を増やしていません。建築・構造安全や営業運用の承認は未取得です。図面の局所経路とW入力検査は、人間による実操作とは区別します。\n''')
print('V16_REVIEW_DATA',len(D['instances']),'placements',len(F),'floors')
