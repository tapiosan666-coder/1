from pathlib import Path
from fontTools import subset
from fontTools.ttLib import TTFont
import os
P=Path(__file__).resolve().parents[1];full=Path(os.environ.get('FIND_YOURSELF_NOTO_ORIGINAL',str(P.parent/'FIND_YOURSELF-Site-v10/assets/NotoSansCJKjp-Regular.otf')));target=P/'assets/NotoSansCJKjp-Regular.otf';old=TTFont(target);codes=set(old.getBestCmap());text=''
for pat in ['*.gd','*.md','authoring/v12*.py','source/brands-v12.json','source/v12/map-data.json','source/v12/*.csv','source/v12/REQUEST.md','authoring/v13*.py','source/v13/*.json','authoring/v14*.py','source/v14/*.json']:
 for p in P.glob(pat):
  if p.is_file():text+=p.read_text(errors='replace')
codes.update(map(ord,text));font=TTFont(full);opt=subset.Options();opt.layout_features=['*'];ss=subset.Subsetter(options=opt);ss.populate(unicodes=codes);ss.subset(font)
for r in font['name'].names:
 if r.nameID in [1,4,6,16,17]:
  value='FYValidationUIv14'if r.nameID==6 else'FY Validation UI v14'if r.nameID in[1,4,16]else'Regular';r.string=value.encode(r.getEncoding())
font.save(target);print('FONT_SUBSET',target.stat().st_size,'glyphs',len(font.getBestCmap()))
