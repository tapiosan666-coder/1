"""Original specialist service fixtures. Curved, detailed models; no third-party or real-brand assets."""
from pathlib import Path
P=Path(__file__).resolve().parents[1];src=(P/'authoring/retail_models_v10.py').read_text();exec(src[:src.index('for var in range(3):bookcase')]);OUT=P/'assets/v15/models';OUT.mkdir(exist_ok=True)
# Apparel: opaque fitting enclosure with real open doorway, curved hanging curtain, mirror and stool.
for x in[-.96,.96]:box('Fitting_room_side',(x,0,1.18),(.065,1.65,2.36),white,.016)
box('Fitting_room_rear',(0,.80,1.18),(1.96,.06,2.36),wood,.013);box('Overdoor_lintel',(0,-.80,2.27),(1.96,.10,.18),wood,.013)
tube('Curtain_track',[(-.90,-.79,2.20),(0,-.79,2.20),(.90,-.79,2.20)],.018,brass)
v=[];faces=[]
for j,z in enumerate([.12,1.12,2.17]):
 for i in range(25):x=-.88+i*.025;v.append((x,-.78+.055*math.sin(i*math.pi/2),z))
for j in range(2):
 for i in range(24):a=j*25+i;faces.append((a,a+1,a+26,a+25))
mesh('Pleated_curtain_parked_open',v,faces,fabrics[1]);box('Mirror_frame',(.90,.18,1.31),(.03,.69,1.65),brass,.008);box('Mirror_glass',(.88,.18,1.31),(.008,.65,1.61),steel,.002)
lathe('Fitting_stool',[(0,0),(.24,0),(.24,.06),(.13,.10),(.13,.42),(.29,.43),(.29,.49),(0,.49)],wood,(.10,.45,0));finish('apparel_fitting_room')
# Books: three sloped face-out magazine tiers, layered covers rather than generic boxes.
for x in[-.73,.73]:box('Magazine_side_standard',(x,0,.69),(.04,.60,1.38),wood,.01)
box('Magazine_base',(0,0,.05),(1.52,.64,.10),walnut,.015)
for j,z in enumerate([.30,.68,1.06]):
 o=box('Angled_magazine_back',(0,.07,z),(1.48,.035,.40),white,.004);o.rotation_euler.x=math.radians(-17)
 box('Clear_magazine_lip',(0,-.13,z-.17),(1.48,.035,.075),glass,.005)
 for i in range(5):
  x=-.58+i*.29;o=box('Magazine_pages',(x,-.04,z),(.265,.035,.33),paper,.002);o.rotation_euler.x=math.radians(-17)
  o=box('Printed_magazine_cover',(x,-.060,z),(.269,.003,.334),bookmats[(j*5+i)%6],.002);o.rotation_euler.x=math.radians(-17)
  box('Cover_title_band',(x,-.064,z+.10),(.21,.002,.028),white,.001)
finish('book_magazine_display')
# Beauty: consultation/tester counter with elliptical ends, mirrors, bottles and lights.
lathe('Rounded_tester_pedestal',[(0,0),(.36,0),(.38,.08),(.30,.12),(.30,.84),(.42,.86),(.42,.92),(0,.92)],white,(-.73,0,0))
lathe('Rounded_tester_pedestal',[(0,0),(.36,0),(.38,.08),(.30,.12),(.30,.84),(.42,.86),(.42,.92),(0,.92)],white,(.73,0,0));box('Tester_counter',(0,0,.89),(1.46,.84,.07),stone,.018)
for x in[-.62,.62]:
 lathe('Mirror_stand',[(0,0),(.09,0),(.09,.04),(.018,.05),(.018,.36),(0,.36)],brass,(x,.19,.93));o=lathe('Circular_consultation_mirror',[(0,0),(.23,0),(.23,.025),(0,.025)],steel,(x,.19,1.51));o.matrix_world=Matrix.Translation(Vector((x,.19,1.51)))@Matrix.Rotation(math.pi/2,4,'X')@Matrix.Translation(Vector((-x,-.19,-1.51)))
 for i in range(4):lathe('Tester_bottle',[(0,0),(.027,0),(.027,.09),(.018,.10),(.018,.14),(0,.14)],ceramics[i%3],(x-.20+i*.12,-.20,.94),16)
finish('beauty_tester_bar')
# Electronics: TV demonstration wall, integrated cable cabinet and soundbar.
box('Media_wall_base',(0,0,.26),(2.8,.62,.52),walnut,.025)
for x in[-.94,0,.94]:box('Recessed_cabinet_door',(x,-.318,.28),(.90,.022,.44),wood,.009)
box('Slatted_back_panel',(0,.23,1.43),(2.8,.08,1.83),wood,.012)
for i in range(29):box('Acoustic_batten',(-1.36+i*.097,.17,1.43),(.038,.04,1.78),walnut,.006)
box('OLED_bezel',(0,.10,1.58),(1.92,.052,1.10),metal,.018);screen=material('Original_ocean_demo',(.07,.25,.31),.25);box('OLED_display',(0,.070,1.58),(1.86,.004,1.04),screen,.005)
box('Soundbar',(0,-.15,.62),(1.12,.11,.10),metal,.025)
for x in[-1.10,1.10]:lathe('Demo_speaker',[(0,0),(.10,0),(.10,.27),(0,.27)],metal,(x,-.13,.52),24)
finish('electronics_media_demo')
# Cafe: real service island with espresso machine, sink and undercounter chilled storage.
box('Cafe_joinery',(0,0,.48),(2.3,.76,.96),walnut,.025);box('Stone_worktop',(0,0,.985),(2.38,.84,.055),stone,.015)
for x in[-.79,0,.79]:box('Service_cabinet_door',(x,-.39,.46),(.72,.028,.82),wood,.008);tube('Cabinet_pull',[(x-.14,-.42,.70),(x+.14,-.42,.70)],.009,brass)
box('Espresso_machine',(0,.08,1.19),(.82,.48,.36),steel,.045)
for x in[-.23,.23]:tube('Group_handle',[(x,-.18,1.15),(x,-.40,1.15)],.025,rubber);lathe('Coffee_cup',[(0,0),(.035,0),(.042,.07),(.037,.075),(.031,.012),(0,.012)],ceramics[0],(x,-.13,1.02),24)
box('Drip_tray',(0,-.14,1.035),(.72,.25,.035),metal,.005)
for x in[-.86,.86]:lathe('Coffee_grinder_hopper',[(0,0),(.09,0),(.07,.05),(.12,.20),(.12,.24),(0,.24)],glass,(x,.10,1.19),20);box('Coffee_grinder_base',(x,.10,1.10),(.23,.24,.20),metal,.025)
finish('cafe_barista_station')
# Grocery: checkout conveyor and operator workstation, product queue independent of generic shelves.
box('Checkout_plinth',(0,0,.41),(2.9,.75,.82),metal,.035);box('Belt_frame',(-.55,0,.84),(1.68,.79,.08),steel,.015);box('Conveyor_belt',(-.55,0,.891),(1.50,.65,.015),rubber,.006)
for i in range(17):box('Belt_seam',(-1.23+i*.086,0,.901),(.002,.64,.002),metal,.001)
box('Scanner_bed',(.52,0,.88),(.45,.75,.05),white,.01);box('Barcode_scanner',(.52,0,1.04),(.18,.18,.30),metal,.02);box('Bagging_area',(1.10,0,.85),(.70,.77,.08),steel,.012)
box('Terminal_stalk',(.72,.19,1.17),(.05,.06,.39),metal,.007);o=box('Till_touchscreen',(.72,.16,1.39),(.39,.07,.26),metal,.015);o.rotation_euler.x=math.radians(15)
finish('grocery_checkout_lane')
print('V15_MODELS_DONE',flush=True)
# Apparel entrance mannequin: sculpted display form, articulated tapered limbs, fabric torso.
lathe('Display_plinth',[(0,0),(.36,0),(.36,.035),(0,.035)],stone)
for side in[-1,1]:
 tube('Sculpted_leg',[(side*.10,0,.12),(side*.11,.01,.48),(side*.12,0,.88)],.065,skin)
 o=lathe('Display_foot',[(0,0),(.055,0),(.065,.12),(0,.12)],skin,(side*.10,-.055,.045),20);o.scale.y=1.8
lathe('Woven_tunic',[(0,.80),(.19,.80),(.19,.90),(.14,1.10),(.19,1.32),(.18,1.43),(.085,1.47),(0,1.47)],fabrics[2],steps=40)
for side in[-1,1]:tube('Display_arm',[(side*.16,0,1.38),(side*.26,-.015,1.14),(side*.27,-.08,.96)],.047,skin)
lathe('Display_neck',[(0,0),(.045,0),(.045,.11),(0,.11)],skin,(0,0,1.43),24)
bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=16,location=(0,0,1.66));o=bpy.context.object;o.name='Sculpted_porcelain_head';o.scale=(.087,.092,.125);o.data.materials.append(skin)
for f in o.data.polygons:f.use_smooth=True
finish('apparel_window_mannequin')
# Cafe customer-facing ordering fixture, deliberately no duplicated espresso machine.
box('Order_counter_carcass',(0,0,.48),(2.4,.80,.96),wood,.025);box('Stone_counter_top',(0,0,.985),(2.48,.87,.05),stone,.02)
box('Pastry_case_base',(-.46,-.01,1.035),(1.26,.63,.05),metal,.01)
for x in[-1.07,.15]:box('Pastry_case_end',(x,0,1.25),(.012,.60,.40),glass,.003)
box('Case_front',(-.46,-.30,1.25),(1.24,.012,.40),glass,.003);box('Case_top',(-.46,0,1.46),(1.26,.62,.012),glass,.003)
for i in range(5):
 x=-.92+i*.23;lathe('Pastry_plate',[(0,0),(.10,0),(.11,.015),(.09,.025),(0,.025)],ceramics[0],(x,0,1.065),20)
 for j in range(4):lathe('Layered_brioche',[(0,0),(.057,0),(.070,.035),(.056,.08),(.025,.105),(0,.11)],pastry,(x,-.02+j*.012,1.09),20)
box('POS_pedestal',(.77,.12,1.13),(.055,.07,.26),metal,.008);box('Ordering_terminal',(.77,.09,1.32),(.36,.06,.25),metal,.014)
finish('cafe_order_counter')
