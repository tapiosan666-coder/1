from pathlib import Path
import json,zipfile,hashlib,struct,posixpath,sys
P=Path(__file__).resolve().parents[1];D=Path('/workspace/1/downloads');D.mkdir(exist_ok=True)
base=(P/'authoring/v15_package.py').read_text();base=base[:base.index("\nmanifest={'version'")];ns={'__file__':str(P/'authoring/v15_package.py')};exec(base,ns);out=ns['out']
out=[(f,r)for f,r in out if not(r.startswith('assets/v16/models/')and f.suffix!='.glb')and not(r.startswith('assets/v15/gi-')and f.suffix=='.res')]
refs=set()
for f,r in out:
 if f.suffix!='.glb':continue
 b=f.read_bytes();n=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+n])
 for row in g.get('images',[])+g.get('buffers',[]):
  uri=row.get('uri','')
  if uri and not uri.startswith('data:'):refs.add(posixpath.normpath(posixpath.join(posixpath.dirname(r),uri)))
# Only byte-identical images are shared; no resolution/colour/mesh reduction.
normal_aliases={'assets/v8/brick-normal.png':'assets/v8/plaster-normal.png','assets/v8/slate-normal.png':'assets/v8/plaster-normal.png','assets/v10/materials/limestone-normal.png':'assets/v10/materials/plaster-normal.png','assets/v10/materials/terrazzo-normal.png':'assets/v10/materials/plaster-normal.png','assets/v10/materials/basalt-normal.png':'assets/v10/materials/plaster-normal.png','assets/v14/materials/plaster-normal.png':'assets/v14/materials/ceramic-normal.png','assets/v14/materials/paving-normal.png':'assets/v14/materials/ceramic-normal.png'}
for a,b in normal_aliases.items():assert (P/a).read_bytes()==(P/b).read_bytes()
out=[(f,r)for f,r in out if r not in normal_aliases and not(f.suffix.lower()in['.png','.jpg','.jpeg']and ('/textures/'in r and len(f.stem)==64 or '/models/'in r)and r not in refs)]
assert not refs-{r for f,r in out},refs-{r for f,r in out}
m={'version':'v16 independent spatial-density validation','single_archive':True,'main_game_integrated':False,'human_playtest':False,'C_option':'UNAPPROVED','ES_option':'UNAPPROVED','RF_SUPPORT_16':'UNAPPROVED','roof_water_garden':'DESIGN_ONLY_NOT_IMPLEMENTED','files':[{'path':r,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f,r in out]}
f=P/'release-manifest-v16.json';f.write_text(json.dumps(m,ensure_ascii=False,indent=2));out.append((f,f.name))
path=D/('FIND_YOURSELF-v16-TRIAL.zip'if'--trial'in sys.argv else'FIND_YOURSELF-v16-Godot.zip')
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f,r in out:z.write(f,'FIND_YOURSELF-v16/'+r)
print('V16_SINGLE_ZIP',path.stat().st_size,'files',len(out),'refs',len(refs),'under_Git_blob_limit',path.stat().st_size<104857600,flush=True)
with zipfile.ZipFile(path)as z:assert z.testzip()is None
