from pathlib import Path
import json
P=Path(__file__).resolve().parents[1];old=json.load(open(P/'source/v15/menu-cameras.json'))
new=[]
def add(id,title,eye,look):new.append(dict(id=id,title=title,eye=eye,look=look,fov=75,ui=''))
add('V16-A-visitor','A館 西広場の案内と休憩',[339,1.65,-47],[355,1.4,-40])
add('V16-B-aichi','B館 時の広場・あいち催事',[-3.527,1.6502,32.1],[10.473,5.0002,2.1])
add('V16-B-fair-close','B館 食と手しごとの屋台',[7,1.65,11],[20,1.65,9])
add('V16-C-kids','C館 こもれび遊び場',[-104,1.65,-296],[-111,1.7,-311])
add('V16-C-dog','C館 二重ゲート・ドッグラン',[-116,1.65,-280],[-118,1.2,-265])
add('V16-C-melon','C館 焼きたてメロンパン',[-86,1.65,-317],[-88,1.5,-324])
add('V16-C-courtyard','C館 中庭・屋外動線',[-68.5434,1.65,-289.5022],[-161,16,-289.5])
for s in old:
 if any(x in s['id'].lower()for x in ['b1','rf']):new.append(dict(s))
combined=list({r['id']:r for r in reversed(new+old)}.values())[::-1]
json.dump(combined,open(P/'source/v16/menu-cameras.json','w'),ensure_ascii=False,indent=2)
json.dump(new,open(P/'source/v16/compare-cameras.json','w'),ensure_ascii=False,indent=2)
