from pathlib import Path
P=Path(__file__).resolve().parents[1];src=(P/'authoring/v16_models.py').read_text().split("bench();finish('outdoor_bench')")[0];exec(src)
# An original ficus-like atrium tree: tapering trunk, branching crowns and curved leaves.
clear();trunk=material('Original_tree_bark',(.20,.14,.08),.95)
leafm=[material('Ficus_leaf_'+str(i),c,.74)for i,c in enumerate([(.045,.12,.035),(.09,.20,.05),(.14,.24,.075)])]
tube('Tapered_main_trunk',[(0,0,0),(.02,.03,1.6),(.13,-.08,3.1),(.03,.10,4.7)],.09,trunk)
for j in range(16):
 a=j*2.39996;rad=1.25 if j<9 else.95;z=3.2+(j%5)*.39;tip=(rad*math.cos(a),rad*math.sin(a),z+.43)
 tube('Natural_branch',[(.05,0,2.15+j*.09),(.50*tip[0],.50*tip[1],z-.18),tip],.026,trunk)
 for k in range(30):
  az=rng.uniform(0,math.tau);rr=rng.uniform(.1,.62);cx=tip[0]+rr*math.cos(az);cy=tip[1]+rr*math.sin(az);cz=tip[2]+rng.uniform(-.43,.47);length=rng.uniform(.18,.31);wide=length*.34;angle=rng.uniform(0,math.tau)
  q=[]
  for xx,yy,zz in[(0,0,0),(-wide,length*.45,.016),(0,length,.025),(wide,length*.45,.016),(0,length*.48,.04)]:q.append((cx+xx*math.cos(angle)-yy*math.sin(angle),cy+xx*math.sin(angle)+yy*math.cos(angle),cz+zz))
  mesh('Curved_ficus_leaf',q,[(0,1,4),(1,2,4),(2,3,4),(3,0,4)],leafm[(j+k)%3])
finish('atrium_ficus_tree')
