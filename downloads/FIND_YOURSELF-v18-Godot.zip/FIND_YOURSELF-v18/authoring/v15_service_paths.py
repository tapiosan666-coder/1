from pathlib import Path
import sys,numpy as np,heapq,math
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
F=read(P/'source/v11/floors-updated.json');lookup={s['id']:(f,s)for f in F for s in f['stores']};art=read(P/'source/v12/scene-art.json')['instances'];new=read(P/'source/v15/retail-services.json')['instances'];rows=[]
for item in new:
 sid=item['group'];f,s=lookup[sid];occupied=[rect((i['p'][0]-429,i['p'][2]+46),i['u'],*i['max_xz']).buffer(.36,join_style=2)for i in art+new if i['group']==sid and i.get('max_xz')];space=s['sales'].buffer(-.34,join_style=2).difference(unary_union(occupied));e=np.asarray(s['entry']);n=np.asarray(s['n']);u=np.asarray(item['u']);front=np.asarray(item['front']);c=np.array([item['p'][0]-429,item['p'][2]+46]);target=c+front*(float(item['max_xz'][1])/2+.8);start=e+n*1.0;step=.35;origin=np.array(space.bounds[:2]);node=lambda a:tuple(np.round((a-origin)/step).astype(int));point=lambda a:origin+np.array(a)*step;valid={}
 def okay(q):
  if q not in valid:valid[q]=space.covers(Point(point(q)))
  return valid[q]
 def nearest(a):
  q=node(a);ns=[(q[0]+i,q[1]+j)for i in range(-4,5)for j in range(-4,5)if okay((q[0]+i,q[1]+j))];return min(ns,key=lambda x:np.linalg.norm(point(x)-a))if ns else None
 a=nearest(start);b=nearest(target)
 if a is None or b is None:rows.append({'id':sid+'-'+item['asset'].split('/')[-1],'pass_geometry':False,'reason':'No clear entry or service approach'});continue
 queue=[(0.,0.,a)];cost={a:0};parent={};found=False
 while queue:
  _,g,q=heapq.heappop(queue)
  if g>cost[q]+1e-8:continue
  if q==b:found=True;break
  for dx,dz in[(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]:
   r=(q[0]+dx,q[1]+dz)
   if not okay(r)or not space.covers(LineString([point(q),point(r)])):continue
   ng=g+math.hypot(dx,dz)
   if ng<cost.get(r,1e20):cost[r]=ng;parent[r]=q;heapq.heappush(queue,(ng+math.dist(r,b),ng,r))
 if not found:rows.append({'id':sid+'-'+item['asset'].split('/')[-1],'pass_geometry':False,'reason':'Service approach disconnected'});continue
 path=[point(b)];q=b
 while q!=a:q=parent[q];path.append(point(q))
 path=path[::-1];simple=[path[0]];i=0
 while i<len(path)-1:
  j=len(path)-1
  while j>i+1 and not space.covers(LineString([path[i],path[j]])):j-=1
  simple.append(path[j]);i=j
 rows.append({'id':sid+'-'+item['asset'].split('/')[-1],'pass_geometry':True,'points':[[v[0]+429,f['height'],v[1]-46]for v in simple],'method':'Sales polygon eroded by 0.34m; real fixture occupancy expanded by 0.36m; A* 0.35m, then collision test required','human_playtest':False})
write(P/'source/v15/service-paths.json',rows);print('SERVICE_PATHS',sum(r['pass_geometry']for r in rows),'/',len(rows));print([(r['id'],r['pass_geometry'])for r in rows])
