from pathlib import Path
import json,struct,hashlib,zstandard
P=Path(__file__).resolve().parents[1];rows=json.loads((P/'source/v13/pack-manifest.json').read_text());rows=[r for r in rows if r['path']not in['assets/v12/C-outlet.pack.zst','assets/v12/C-supported-finish.pack.zst']]
for path in['assets/v15/C-finish-replacement.pack.zst','assets/v15/ES-site-replacement.pack.zst','assets/v15/retail-services.pack.zst']:rows.append({'path':path})
for r in rows:
 b=(P/r['path']).read_bytes();raw=zstandard.ZstdDecompressor().decompress(b[8:]);r.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),decoded_bytes=len(raw),decoded_sha256=hashlib.sha256(raw).hexdigest())
(P/'source/v15/pack-manifest.json').write_text(json.dumps(rows,indent=2))
print('V15_PACKS',len(rows),'all decoded hashes recorded')
