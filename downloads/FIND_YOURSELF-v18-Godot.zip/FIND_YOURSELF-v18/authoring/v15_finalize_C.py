"""Purpose/route annotations for the independent C option; never modifies normal floor data."""
from pathlib import Path
import sys,numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
F=read(P/'source/v11/floors-updated.json');C=[f for f in F if f['wing']=='C'];cp=read(P/'source/v15/C-outlet-proposal.json');f3=next(f for f in C if f['level']==2);r3=next(r for r in cp['floors']if r['level']==2);access=next(r for r in cp['gallery_connections']if r['id']=='C-ES-CN23-TOP-ACCESS');devices={e['id']:e for f in C for e in f['escalators']};arrivals=[ee for ee in devices.values()if ee['levels'][-1]==2];mean=np.mean([np.asarray(e['c'])+np.asarray(e['u'])*(e['run_m']/2+2.2)for e in arrivals],axis=0);lobby=rect(mean,arrivals[0]['u'],4.8,7.0);extra=LineString(access['points']).buffer(2.1,cap_style=2,join_style=2).union(lobby).intersection(r3['proposed_floor']);shopscores=unary_union([s['polygon']for s in f3['stores']]+[c['outline']for c in f3['cores']]);r3['proposed_public']=r3['proposed_public'].union(extra.difference(shopscores));r3['CN23_lobby']=lobby.intersection(r3['proposed_floor']);cp['third_floor_inter_pavilion_direct_links_removed']=True;cp['third_floor_strategy']='Each pavilion retains its own gallery and stair/EV; inter-pavilion circulation uses 2F or ground. Existing CN23 has one dedicated 3F access bridge, not a continuous 3F ring.';write(P/'source/v15/C-outlet-proposal.json',cp)
cases=[]
for conn in cp['gallery_connections']:
 ln=LineString(conn['points']);d=ln.length*.5;p0=np.array(ln.interpolate(d).coords[0]);t=np.array(ln.interpolate(d+.1).coords[0])-np.array(ln.interpolate(d-.1).coords[0]);t/=np.linalg.norm(t);n=np.array([-t[1],t[0]])
 for lev in conn['levels']:
  ff=next(r for r in cp['floors']if r['level']==lev)
  for side in[-1,1]:
   a=p0+n*side*.5;b=p0+n*side*4.5
   if ff['proposed_floor'].covers(Point(a))and not ff['proposed_floor'].covers(Point(b)):cases.append({'id':conn['id']+'-'+ff['floor']+'-'+str(side),'a':[a[0]+429,ff['height'],a[1]-46],'b':[b[0]+429,ff['height'],b[1]-46]})
centre=np.mean([np.array(p['footprint'].centroid.coords[0])for p in f3['pavilions']],axis=0)
for pav in f3['pavilions']:
 gallery=pav['front_corridor'].intersection(r3['proposed_public']).buffer(-.50,join_style=2)
 if gallery.is_empty:continue
 a=np.array(max(polys(gallery),key=lambda g:g.area).representative_point().coords[0]);n=centre-a;n/=np.linalg.norm(n);b=a+n*7
 if r3['proposed_floor'].covers(Point(a))and not r3['proposed_floor'].covers(Point(b)):cases.append({'id':'C-PAV-'+pav['id']+'-3F-OUTER','a':[a[0]+429,10.875,a[1]-46],'b':[b[0]+429,10.875,b[1]-46]})
# Start one metre inside the first real slab edge, rather than in the middle
# of a wide gallery. Otherwise travel >2.5m is not evidence of a missing rail.
for case in cases:
 lev=min(cp['floors'],key=lambda f:abs(f['height']-case['a'][1]));a=np.array([case['a'][0]-429,case['a'][2]+46]);b=np.array([case['b'][0]-429,case['b'][2]+46]);direction=(b-a)/np.linalg.norm(b-a);line_length=np.linalg.norm(b-a);lo=0.;hi=line_length
 for d in np.linspace(0,line_length,141):
  if not lev['proposed_floor'].covers(Point(a+direction*d)):hi=float(d);break
  lo=float(d)
 for _ in range(35):
  mid=(lo+hi)/2
  if lev['proposed_floor'].covers(Point(a+direction*mid)):lo=mid
  else:hi=mid
 edge=a+direction*lo
 # Approach the actual boundary normal; diagonal steering can correctly slide
 # along a guard for metres and must not be mistaken for passing through it.
 segments=[]
 for po in polys(lev['proposed_floor']):
  for ring in[po.exterior,*po.interiors]:
   coords=list(ring.coords)
   for aa,bb in zip(coords,coords[1:]):
    seg=LineString([aa,bb]);segments.append((seg.distance(Point(edge)),np.array(aa),np.array(bb)))
 _,aa,bb=min(segments,key=lambda v:v[0]);tangent=(bb-aa)/np.linalg.norm(bb-aa);normal=np.array([-tangent[1],tangent[0]])
 if lev['proposed_floor'].covers(Point(edge+normal*.15)):normal=-normal
 direction=normal;start=edge-direction*1.;outside=edge+direction*2.5;case['original_start_world']=case['a'];case['edge_world']=[edge[0]+429,lev['height'],edge[1]-46];case['a']=[start[0]+429,lev['height'],start[1]-46];case['b']=[outside[0]+429,lev['height'],outside[1]-46];case['start_inset_m']=1.
write(P/'source/v15/C-edge-cases.json',cases);print('C_FINAL',[(r['floor'],round(r['proposed_floor'].area,2),r['floor_components'])for r in cp['floors']],'connections',[(r['id'],r['levels'],round(r['length_m'],2))for r in cp['gallery_connections']],'edge cases',len(cases))
