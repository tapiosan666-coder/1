from pathlib import Path
import json,shutil
P=Path(__file__).resolve().parents[1];R=Path('/workspace/v16-review');T=[]
def read(p):return json.loads(Path(p).read_text())
def rows(name,path,key,field='pass',method=''):
 d=read(path);a=d[key];good=sum(bool(q[field])for q in a);bad=len(a)-good;assert not bad,(name,[q for q in a if not q[field]])
 T.append({'name':name,'passed':good,'failed':bad,'method':method,'source':str(Path(path).relative_to(R))})
for src,dst in [(P/'evidence/v16/physics-ES.json',R/'tests/ES-site-input.json'),(P/'evidence/v16/physics-C.json',R/'tests/C-gallery-input.json'),(P/'evidence/v16/edges-ES.json',R/'tests/ES-edge-input.json'),(P/'evidence/v16/edges-C.json',R/'tests/C-edge-input.json'),(P/'evidence/v16/controls/controls-amenities.json',R/'tests/controls-amenities.json'),(P/'evidence/settings-save-restore-v7.json',R/'tests/settings.json'),(P/'evidence/v16/cache-normal.json',R/'tests/cache-normal.json'),(P/'evidence/v16/cache-C-option.json',R/'tests/cache-C-option.json')]:shutil.copy2(src,dst)
rows('建築原本・主要処理の保護',R/'source/preservation.json','checks','same','19パック＋主要7インターフェースの原本比較')
rows('配置・設計データ',R/'source/geometry-check.json','checks','passed','床/既存地面の被覆、ID、処理保護。設計上の検査')
rows('通常版の指定歩行',R/'tests/core/physics-all.json','checks',method='実衝突カプセルの自動経路追従。人間ではない')
rows('ESと既存アクセス',R/'tests/core/physics-ES.json','checks',method='実ES40機＋ES指定で抽出されたアクセス123経路')
rows('EV乗降・各階移動',R/'tests/core/physics-EV.json','checks',method='実開口・連続キャリアで移動。ワープではない')
rows('C館別案の指定歩行',R/'tests/C/physics-all.json','checks',method='別案で全経路。C館186経路と館間接続を含む')
rows('C館別案の回廊',R/'tests/C-gallery-input.json','checks',method='実W入力＋自動操舵。人間の実操作ではない')
d=read(R/'tests/ES-site-input.json');a=d['checks']+d['transfers'];assert all(c['pass']for c in a);T.append({'name':'F6 乗降・上下乗継・接続','passed':len(a),'failed':0,'method':'実W入力。6機械＋4乗継＋8接続','source':'tests/ES-site-input.json'})
rows('C館別案のガード',R/'tests/C-edge-input.json','cases',method='代表22地点へ160tick進み、落下・通過を確認')
rows('F6別案のガード',R/'tests/ES-edge-input.json','cases',method='2F/3F/RFの代表4方向。全境界の保証ではない')
rows('C館別案のES',R/'tests/C-es/es-approach-input.json','checks',method='実W入力で4機の乗降。移動処理は保持')
rows('新施設への歩行',R/'tests/facilities/v16-facility-walk.json','checks',method='案内・催事・遊び場・車・二重ゲート。実W入力')
rows('支持・催事切替・ゲート',R/'tests/commons/v16-commons-physics.json','checks',method='実衝突の支持線、切替、再開時重複、インターロック')
rows('F9・M・催事操作',R/'tests/controls-amenities.json','checks',method='キー注入、移動先接地、マップ・HUD非重複')
rows('基本操作と初期設定',R/'tests/controls/controls.json','checks',method='向き、W、M停止、144上限/VSync/60Hzなど')
rows('設定の保存・復元',R/'tests/settings.json','checks',method='3解像度×5上限×VSync。人間の全解像度目視ではない')
rows('F4/F6の独立切替',R/'tests/navigation.json','checks',method='実current_sceneへのキー注入。通常版へ戻るまで')
for name in ['normal','C-option']:rows('間接光キャッシュ '+name,R/('tests/cache-'+name+'.json'),'checks',method='最終ソースとの指紋一致。全館GI完成ではない')
for name in ['normal','C','ES']:rows('新規展開 '+name,R/('tests/fresh/'+name+'.json'),'checks',method='全展開・インポート後、独立シーンを起動')
rows('実UIのViewport確認',R/'ui/checks.json','checks',method='1920×1080、M/F9/F10をキー注入。人間ではない')
for name in ['package-integrity','fresh/native-main']:
 d=read(R/('tests/'+name+'.json'));assert d['pass'];T.append({'name':'ZIP整合性'if name=='package-integrity'else'新規展開・描画起動','passed':1,'failed':0,'method':'CRC・全ファイルSHA・外部画像参照'if name=='package-integrity'else'実描画でmain起動（F5相当）。Windowsではない','source':'tests/'+name+'.json'})
D={'version':'v16','all_listed_tests_pass':True,'tests':T,'human_playtest':False,'Windows_GPU_FPS':None,'144FPS_achieved':None,'software_renderer':'llvmpipe (LLVM 19.1.7, 256 bits)','not_architectural_or_product_safety_approval':True,'notes':['経路・入力・描画を別に評価。数の多さだけで品質を合格としない。','新規利用区画の旧装飾4197三角形を除去、衝突変更0。','Windows GPU、人間の操作、製品安全、建築構造・排水・車両軌跡は未検証。']}
(R/'検査結果.json').write_text(json.dumps(D,ensure_ascii=False,indent=2));print('V16_TEST_SUMMARY',len(T),'categories, all individually passed')
