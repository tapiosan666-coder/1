"""Separate B-west site proposal; original controller untouched. Exact deletion of old ES triangles and coordinated slab opening."""
from pathlib import Path
import sys,copy,numpy as np,hashlib
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely.ops import transform
from shapely import intersects_xy,constrained_delaunay_triangles
F=read(P/'source/v11/floors-updated.json');normal=[r['path']for r in read(P/'source/v13/pack-manifest.json')if r['path']not in['assets/v12/C-outlet.pack.zst','assets/v12/C-supported-finish.pack.zst','assets/v12/es-transfer-study.pack.zst']];S={};cols={};deleted=[];erase=[];changed={};old_tri=set()
def fingerprint(t):return np.asarray(sorted(map(tuple,np.round(t,4))),dtype='<f4').tobytes()
for path in normal:
 g=load_pack(P/path)
 for k,d in g['surfaces'].items():
  if any(tag in k for tag in ['@@ESC-E1-','@@V12-ES-E1-','@@V12-LANDING-E1-']):
   for t in triangles(d):old_tri.add(fingerprint(t))
   deleted.append(k);erase.append(k)
  S[k]=d
 for k,v in g['colliders'].items():cols.setdefault(k,[]).append(v)
# B1 has no hole; cut 1F new atrium slot to allow B1->1F. Existing WEST void already contains the upper slot.
centre=np.array([-192.,-15.5]);hole=box(-204.,-26.5,-180.,-4.5);huge=box(-2000,-2000,2000,2000);levels=[(0.,huge,huge.difference(hole))];protected_by_y={0.:huge}
clip_source=(P/'authoring/v15_c_finish.py').read_text();exec(clip_source[clip_source.index('def clip('):clip_source.index('for path in paths:')])
for k,d in S.items():
 if k in erase:continue
 nd,count=clip(d,k)
 if count:
  if len(nd['v']):changed[k]=nd
  else:erase.append(k)
newcols={};counts={}
for k,items in cols.items():
 a=np.concatenate(items).reshape(-1,3,3);keep=np.array([fingerprint(t)not in old_tri for t in a]);counts[k]=int((~keep).sum());a=a[keep];d={'v':a.ravel(),'n':np.tile([0.,1.,0.],(len(a)*3,1)).ravel(),'uv':np.zeros(len(a)*6),'c':np.ones(len(a)*12)};nd,_=clip(d,k);newcols[k]=nd['v']
module=load_pack(P/'assets/v15/ES-upper-module.pack.zst');study=read(P/'source/v15/ES-upper-module.json')
for k,d in module['surfaces'].items():
 d['v']=d['v'].reshape(-1,3)+np.array([-192,0,-15.5]);d['v']=d['v'].astype(np.float32).ravel();changed[k.replace('V12-TRANSFER-STUDY','V15-B-WEST-TRANSFER')]=d
for k,v in module['colliders'].items():newcols[k]=np.concatenate([newcols.get(k,np.array([])),(v.reshape(-1,3)+np.array([-192,0,-15.5])).ravel()])
M={};coll={};render_group='V15-B-WEST-CONNECTORS'
def pos(x,y,z):return[float(x),float(y),float(z)]
exec((P/'authoring/mesh_primitives.py').read_text())
# Doorless 4.2m clear bridges from both sides of the site module into the existing West public promenade.
connectors=[]
for lev in [1,2,3]:
 y=HEIGHT[lev]
 for xa,xb in [(-219.,-204.),(-180.,-165.)]:
  g=box(xa,-17.6,xb,-13.4);extrude(g,y-.38,.38,'stone',True);surf(g,y+.005,'v10_floor_B');surf(g,y-.385,'plaster',False)
  for z in[-17.6,-13.4]:
   edge=LineString([(xa,z),(xb,z)]);extrude(edge.buffer(.035,cap_style=2),y,.15,'v10_darkstone',True);extrude(edge.buffer(.025,cap_style=2),y+.15,1.0,'v10_guard_glass',True)
  connectors.append({'level':lev,'height':y,'geometry':g,'purpose':'West atrium transfer lobby to existing public promenade','clear_width_m':4.2})
# Remove the module outer railing at actual connector mouths. Its original floor remains unchanged.
for k,d in list(changed.items()):
 if 'V15-B-WEST-TRANSFER'not in k or not('glass'in k or'v10_chalk'in k or'v10_metal'in k):continue
 a=triangles(d);ct=a.mean(1);drop=(abs(abs(ct[:,0]+192)-12)<.12)&(abs(ct[:,2]+15.5)<2.12)&(ct[:,1]>-5.4)&(ct[:,1]<17.7)
 if drop.any():changed[k]=retain(d,~drop)
# Collider rails are thin verticals at x boundaries; remove with same geometric criterion.
for k,v in list(newcols.items()):
 if not('glass'in k or'v10_chalk'in k or'v10_metal'in k):continue
 a=v.reshape(-1,3,3);ct=a.mean(1);drop=(abs(abs(ct[:,0]+192)-12)<.12)&(abs(ct[:,2]+15.5)<2.12)&(ct[:,1]>-5.4)&(ct[:,1]<17.7)&(np.ptp(a[:,:,1],axis=1)>.1);newcols[k]=a[~drop].ravel()
# The obsolete flights were outside the main atrium; restore their actual floor slots without covering the atrium.
old=[e for e in read(P/'source/scene-manifest.json')['escalators']if e['id'].startswith('E1-')]
for lev in [0,1,2]:
 f=next(f for f in F if f['wing']=='B'and f['level']==lev);void=transform(lambda x,z,zz=None:(np.asarray(x)+429,np.asarray(z)-46),f['void']);parts=[]
 for e in old:
  if lev not in e['levels']:continue
  parts.append(rect((e['c'][0],e['c'][2]),e['u'],e['run_m']+3.6,2.65))
 g=unary_union(parts).difference(void).difference(hole if lev==0 else Polygon());extrude(g,HEIGHT[lev]-.38,.38,'stone',True);surf(g,HEIGHT[lev]+.005,'v10_floor_B')
changed.update(M)
for k,v in coll.items():newcols[k]=np.concatenate([newcols.get(k,np.array([])),np.asarray(v)])
# Coordinated clear mouths through both the old atrium guards and module guards.
from triangle_cut_v15 import cut
mouths=[(x-.45,-17.52,x+.45,-13.48)for x in[-218.,-204.,-180.,-166.]];rail_mats=['glass','v10_guard_glass','v10_darkstone','dark_stone','v10_metal','metal','v10_chalk'];railcuts=[]
all_surfaces={k:v for k,v in S.items()if k not in erase};all_surfaces.update(changed)
for k,d in all_surfaces.items():
 if k.split('@@')[0]not in rail_mats:continue
 nd,count=cut(d,mouths,list(HEIGHT.values()))
 if count:
  if len(nd['v']):changed[k]=nd
  else:erase.append(k);changed.pop(k,None)
  railcuts.append({'surface':k,'triangles_split':count})
for k,v in list(newcols.items()):
 if k not in rail_mats:continue
 a=v.reshape(-1,3,3);d={'v':a.ravel(),'n':np.tile([0.,1.,0.],(len(a)*3,1)).ravel(),'uv':np.zeros(len(a)*6),'c':np.ones(len(a)*12)};nd,count=cut(d,mouths,list(HEIGHT.values()));newcols[k]=nd['v']
print(save_zst(P/'assets/v15/ES-site-replacement.pack.zst',{'surfaces':changed,'colliders':newcols,'signs':[],'lights':[]}))
banks=study['escalators']
for e in banks:
 e['id']=e['id'].replace('STUDY','B-WEST-V15');e['wing']='B'
 for field in['c','test_start','test_end']:e[field][0]-=192;e[field][2]-=15.5
transfers=study['transfers']
for t in transfers:
 t['from']=t['from'].replace('STUDY','B-WEST-V15');t['to']=t['to'].replace('STUDY','B-WEST-V15');t['status']='UNAPPROVED site candidate; centreline proposal, physics pending'
 for q in t['points']:q[0]-=192;q[2]-=15.5
write(P/'source/v15/ES-site-proposal.json',{'status':'UNAPPROVED independent B-west site alternative','centre_world':[-192,0,-15.5],'escalators':banks,'transfers':transfers,'connectors':connectors,'erase_surfaces':erase,'rail_mouth_cuts':railcuts,'retired_machine_ids':[e['id']for e in old],'deleted_collision_triangles':counts,'basement_status':'NOT_INSTALLED: candidate conflicts with B1 vehicle aisle and 4 parking stalls; separate reallocation approval needed','controller_unchanged':True,'stores_relocated':False,'RF_SUPPORT_16':'UNAPPROVED','structural_capacity_verified':False})
