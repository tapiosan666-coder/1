from pathlib import Path
import sys,json,math,io,numpy as np,collections
P=Path(__file__).resolve().parents[1];D=Path('/workspace/1/docs/visual-review-v15');D.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
import fitz
from PIL import Image
# Reuse tested layout helpers; no historical data load or old report content.
src=(P/'authoring/report_v7.py').read_text().split("geo=read(")[0];src=src.replace("D=read(P/'source/site-v7.json');",'').replace('敷地・構造検証 v7 | 2026-10-27 JST','建築・動線検証 v15 | 2026-10-28 JST');exec(src)
# Use the original system CJK face for PDF CID mapping. Runtime font remains unchanged.
font=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
D=Path('/workspace/1/docs/visual-review-v15');E=P/'evidence/v15';F=read(P/'source/v11/floors-updated.json');C=[f for f in F if f['wing']=='C'];cp=read(P/'source/v15/C-outlet-proposal.json');oldcp=read(P/'source/v12/C-outlet-proposal.json');es=read(P/'source/v15/ES-site-proposal.json');audit=read(P/'source/v15/preservation-audit.json');inv=read(P/'source/v15/store-inventory.json');conf=read(P/'source/v15/ES-basement-conflicts.json');bed=read(P/'source/v15/BRF-GARDEN-2-BED-4-review.json')
def picture(p,path,r,caption):
 path=Path(path)
 if not path.exists():raise FileNotFoundError(path)
 im=Image.open(path).convert('RGB');b=io.BytesIO();im.save(b,format='JPEG',quality=88,optimize=True);p.insert_image(fitz.Rect(r),stream=b.getvalue(),keep_proportion=True);text(p,(r[0],r[3]+5,r[2],r[3]+35),caption,8)
def section(title,rows):return paragraph(title,rows)
def draw_c(p,f,plate,frame,title,public=None,cols=False):
 bounds=f['shell'].union(f['floor_plate']).bounds;pt,sc=transform(frame,bounds);geom(p,plate,pt,(.91,.92,.88),(.25,.33,.35));geom(p,(public if public is not None else f['public']).intersection(plate),pt,(.78,.89,.91),None)
 for s in f['stores']:
  geom(p,s['sales'],pt,(.72,.83,.73),(.28,.39,.29));geom(p,s['backroom'],pt,(.85,.76,.61),(.45,.39,.25));q=pt(s['polygon'].representative_point().coords[0]);text(p,(q.x-30,q.y-5,q.x+34,q.y+10),s['id'],5.7);e=np.array(s['entry']);u=np.array(s['u']);w=float(s.get('door_width_m',2.4));p.draw_line(pt(e-u*w/2),pt(e+u*w/2),color=(.85,.20,.13),width=1.5)
 for core in f['cores']:geom(p,core['outline'],pt,(.70,.77,.85),(.2,.3,.4))
 for ee in f['escalators']:geom(p,rect(ee['c'],ee['u'],ee['run_m'],2),pt,(.91,.70,.36),(.55,.35,.14))
 if cols:
  for r in cp['gallery_connections']:
   if f['level']in r.get('levels',[]):line(p,LineString(r['points']),pt,(.15,.4,.55),.7)
  if f['level']<2:
   for s in cp['supports']:geom(p,box(s['world_xz'][0]-429-.21,s['world_xz'][1]+46-.21,s['world_xz'][0]-429+.21,s['world_xz'][1]+46+.21),pt,(.20,.24,.28),None)
 text(p,(frame[0],frame[1]-28,frame[2],frame[1]-3),title,13,GREEN);x0,y0,x1,y1=bounds;text(p,(frame[0],frame[3]+4,frame[2],frame[3]+25),f'幅 {x1-x0:.1f}m × 奥行 {y1-y0:.1f}m / 床 {plate.area:,.1f}㎡',9)
section('FIND YOURSELF｜v15 建築・動線 総合確認',[
 ('今回の成果と扱い','通常版の建築原本を維持した独立検証版です。C館の回廊・屋根・安全柵を連動させた構造別案、B館西吹き抜けの1F〜RF連続ES敷地別案、代表業種の機能設備を収録。F4でC別案、F6でES別案、F9で更新箇所を確認できます。構造別案の採用は未承認です。'),
 ('v13・v14から保護した内容',f"15層・480店舗ID・有効な通常版16建築パックと旧別案2点の原本・player/ES/EV/扉/設定の主要処理を保護。地下51店舗、屋上22区画、60トイレ、17植栽槽・168植物を継承。ゲーム本体のNPC・スキャン・AP・セーブへ統合していません。"),
 ('地下ESは成立したと扱わない',f"当初の5層モジュールを実敷地へ置くと、地下車路 {conf['vehicle_aisle_overlap_m2']:.2f}㎡と駐車4区画に干渉します。地下の敷地設置を見送り、既存駐車・搬入を保持しました。F7の5層単体モジュールは敷地配置の合格を意味しません。"),
 ('完成範囲の限界','全館の最終美術完成やFF16級品質ではありません。代表店舗に役割別の設備を追加した段階で、全480店の個別内装設計は未完です。人間による実操作とWindows GPU FPSは未検証。144は設定上限です。')])
section('原因調査と再発を防ぐ生成ルール',[
 ('床と仕上げが別々に残る問題','旧C別案は床本体を削っても、別パックの仕上げ床・天井・手すり・小物が追従しない構成でした。最終床ポリゴンを基準に各レイヤーを照合。境界三角形は重心で消さず、ポリゴン交差と頂点属性補間で分割します。手すり上端や天井端の薄い縦面が残る原因は、部材の一部しか撤去せず、平面投影が線になる三角形を処理していなかったことでした。垂直面も線区間で正確に分割します。部材全体を撤去・再生成し、配置物の支持確認も同じ床データに合わせます。'),
 ('手すりと接続の問題','新橋だけを置くと旧吹き抜けの台座とガラスが接続口に残りました。敷地側とモジュール側の手すりを実際の接続幅で分割し、表示形状と衝突の両方へ同じ切り欠きを反映しています。C館の本体衝突配列だけが切り抜き処理を通らず、描画撤去後も見えない旧ガラス支柱が残る不具合も特定。本体の旧三角形と新生成部材を分け、旧衝突にも同じ処理を適用しました。また、旧経路全体を柵の切欠きに使うと内部回廊にも落下口が生じるため、切欠きは館外からの実接続位置に限定しました。見えない壁で解決したものではありません。'),
 ('階ごとの役割と降り場への接続','2階は6棟を結ぶ回遊路、3階は各棟の階段・EVで利用する独立ギャラリーに整理。CE12の2階降り場、CN23の3階降り場から、前へ出て曲がる専用アクセス橋を追加。機械開口を斜めに横切らない経路へ修正しています。旧方式では屋上店舗6区画の入口問題も検出できませんでした。屋上入口に必要な前面床を含め、その最終床端から柵を生成。C館の店舗入口・設備経路186件と、安全柵への入力試験を別々に検査します。'),
 ('用途台帳の照合','床から店舗・共用・設備核だけを引くと、駐車・登録設備帯・躯体を誤って未割当と数えます。登録program/service_zones/floor_roles等も照合し、数値残余は用途不明の実通路と区別。未確定部分を勝手に倉庫へ変更していません。')])
for r in cp['floors']:
 f=next(f for f in C if f['level']==r['level']);o=next(q for q in oldcp['floors']if q['level']==r['level']);p=page('C館 '+f['label']+'｜通常版・旧別案・v15別案',f'店舗 {len(f["stores"])}区画と入口座標を維持 / 赤：店舗入口 / 緑：売場 / 黄土：バックヤード / 水色：共用 / 青灰：設備核 / 別案は未承認',1684,1191)
 for plate,frame,title,pub,co in[(f['floor_plate'],(32,160,548,1035),'v14 通常版（保持）',None,False),(o['proposed_floor'],(584,160,1100,1035),'v14 未承認C別案',o['proposed_public'],False),(r['proposed_floor'],(1136,160,1652,1035),'v15 未承認C別案',r['proposed_public'],True)]:draw_c(p,f,plate,frame,title,pub,co)
 text(p,(40,1090,1640,1142),f"撤去 {r['removed_m2']:,.1f}㎡・アクセス橋の追加 {r['added_m2']:,.1f}㎡・床の純減 {r['net_reduction_m2']:,.1f}㎡ / 売場面積の欠損 {r['retail_area_lost_m2']:.6f}㎡ / 平面寸法はゲーム用設計値です。柱・梁は配置検討で、荷重・基礎・耐震の実証はありません。",10)
p=page('B館西吹き抜け｜1F〜RFのES敷地別案','橙：新しい上り・下り機械 / 水色：連絡床 / 灰：既存店舗 / 赤：旧機械位置 / B1は未施工。広場・店舗区画・館間接続は通常版を維持。',1684,1191)
for i,lev in enumerate([0,1,2,3]):
 f=next(f for f in F if f['wing']=='B'and f['level']==lev);x=35+(i%2)*830;y=145+(i//2)*475;pt,sc=transform((x,y,x+790,y+410),(-672,-8,-572,66));geom(p,f['floor_plate'].intersection(box(-672,-8,-572,66)),pt,(.92,.93,.89),(.3,.4,.4));geom(p,f['public'].intersection(box(-672,-8,-572,66)),pt,(.78,.88,.90),None)
 for s in f['stores']:
  if s['polygon'].intersects(box(-672,-8,-572,66)):geom(p,s['polygon'].intersection(box(-672,-8,-572,66)),pt,(.78,.82,.78),(.3,.4,.3))
 ring=box(-633,19.5,-609,41.5).difference(box(-628.4,23.1,-613.6,37.9)if lev>0 else Polygon());geom(p,ring,pt,(.66,.85,.89),(.2,.4,.5))
 for c in es['connectors']:
  if c['level']==lev:geom(p,affinity.translate(c['geometry'],-429,46),pt,(.66,.85,.89),(.2,.4,.5))
 for e in es['escalators']:
  if lev not in e['levels']:continue
  cen=[e['c'][0]-429,e['c'][2]+46];geom(p,rect(cen,e['u'],e['run_m'],1.6),pt,(.92,.69,.35),(.5,.3,.12));q=pt(cen);text(p,(q.x-40,q.y-7,q.x+60,q.y+14),e['id'],6)
 for e in f['escalators']:
  if e['id'].startswith('E1-'):line(p,rect(e['c'],e['u'],e['run_m'],2).boundary,pt,(.82,.25,.20),.7)
 text(p,(x,y-28,x+790,y-4),f['label']+f" / 床標高 {f['height']:.3f}m",14,GREEN)
text(p,(40,1115,1640,1152),'左右の接続橋は幅4.2m。旧柵と台座を接続位置で分割。ES移動コントローラーはv14と同一。敷地版は6基・4層、単体F7の8基・5層とは別です。',10)
p=page('地下ESの敷地配置を見送った理由／上下階断面','地下を無理に通した完成案ではありません。駐車4区画・車路・設備用途と干渉する候補範囲を表示。通常版の地下駐車は変更しません。',1684,1191);f=next(f for f in F if f['wing']=='B'and f['level']==-1);pt,sc=transform((40,155,980,960),(-650,9,-595,52));geom(p,f['floor_plate'].intersection(box(-650,9,-595,52)),pt,(.94,.94,.90),None);geom(p,f['parking']['vehicle_aisles'].intersection(box(-650,9,-595,52)),pt,(.58,.62,.65),None);geom(p,f['parking']['protected_pedestrian'].intersection(box(-650,9,-595,52)),pt,(.68,.87,.87),None)
for s in f['parking']['stalls']:
 if s['polygon'].intersects(box(-650,9,-595,52)):geom(p,s['polygon'],pt,None,(.3,.4,.4),.7)
for r in conf['program_conflicts']:geom(p,r['geometry'],pt,(.90,.80,.70),(.60,.4,.3))
geom(p,conf['candidate_module_footprint'],pt,None,(.85,.20,.17),2)
for r in conf['parking_stalls']:
 geom(p,r['geometry'],pt,(.92,.58,.53),(.65,.2,.2));q=pt(r['geometry'].centroid.coords[0]);text(p,(q.x-40,q.y-6,q.x+70,q.y+20),r['id'],7)
text(p,(50,1000,960,1090),f"車路との交差面積 {conf['vehicle_aisle_overlap_m2']:.2f}㎡。4台を自動的に削除・移設していません。地下ESは位置の再検討か、駐車・設備・搬入を含む別の再配置案が必要です。",12)
# A dimensioned schematic section from the actual bank profiles, not a Godot screenshot.
xx=lambda x:1100+(x+12)*18;yy=lambda y:910-y*28
for lev,y in HEIGHT.items():
 p.draw_line(fitz.Point(1060,yy(y)),fitz.Point(1630,yy(y)),color=(.35,.43,.46),width=1);text(p,(1050,yy(y)-24,1620,yy(y)-3),f'{LABEL[lev]}  {y:.3f}m'+('  敷地ES未施工'if lev==-1 else''),10)
for e in es['escalators']:
 if e['direction']!='UP':continue
 u=np.asarray(e['u']);c=np.asarray([e['c'][0]+192,e['c'][2]+15.5]);aa=c-u*e['run_m']/2;bb=c+u*e['run_m']/2;p.draw_line(fitz.Point(xx(aa[0]),yy(e['low_y'])),fitz.Point(xx(bb[0]),yy(e['high_y'])),color=(.80,.44,.16),width=5)
text(p,(1060,1020,1640,1110),'断面は2つの並行バンクを重ねた投影図。実際は別々のZ位置にあり、同一空間で交差しません。転送経路は別途物理検査しています。',10)
# Real Viewport comparisons. Native full-resolution PNGs remain separate in Review ZIP.
for title,ids,before,after in[
 ('C館｜張り出しと空の見え方',['C-deck-opening','C-yard-open-sky'],'before-v14-C-option','after-C-option'),
 ('C館｜3階回廊とES降り場の接続',['C-upper-gallery','C-ES-CN23'],'before-v14-C-option','after-C-option'),
 ('B館｜ESの敷地配置',['ES-west-site','ES-west-upper'],'before-v14-normal','after-ES-option')]:
 p=page(title,'Godot Forward+実Viewport / 同一位置・角度・FOV / 1920×1080。PDFは圧縮表示、原寸PNGを別途収録。')
 for i,sid in enumerate(ids):
  y=130+i*326;picture(p,E/('before-v14-normal'if sid=='C-ES-CN23'else before)/(sid+'.png'),(35,y,580,y+285),'左：'+before+' / '+sid);picture(p,E/after/(sid+'.png'),(610,y,1155,y+285),'右：'+after+' / '+sid)
services=read(P/'source/v15/service-cameras.json')
for k in range(0,len(services),2):
 p=page('代表店舗｜役割別設備 '+str(k+1)+'〜'+str(min(k+2,len(services))),'売場全体の最終美術完成ではありません。入口・回遊・レジ等の既存動線を保護し、専用設備を配置。')
 for i,s in enumerate(services[k:k+2]):
  y=130+i*326;sid=s['id'];picture(p,E/'before-v14-normal'/(sid+'.png'),(35,y,580,y+285),'v14 / '+sid);picture(p,E/'after-normal'/(sid+'.png'),(610,y,1155,y+285),'v15 / '+sid)
p=page('通常版｜A館・B館と保護した共用空間','通常版の広場・基本仕上げはv14を維持。今回、代表店舗の機能設備を追加しています。全館の景観刷新を完了したとは扱っていません。')
picture(p,E/'after-normal/01-A-plaza.png',(35,130,580,425),'A館1F / 通常版');picture(p,E/'after-normal/03-B-time-plaza.png',(610,130,1155,425),'B館 時の広場 / 通常版');picture(p,E/'after-normal/A-reported-passage.png',(35,485,580,780),'A館 X=393.2,Z=-51.4 / 登録客用共用床（区画間の距離目安 約4m）');text(p,(610,500,1150,750),'ご指摘座標の周辺は店舗A1F-005とA1F-007の前面をつなぐ登録共用床でした。隙間と決めつけて閉鎖していません。全480店の境界を断面検査しましたが、これは各店舗を人間が歩いて景観評価したことを意味しません。',14)
# Independent categories, no inflated combined count.
summary=read(D/'test-summary.json');rows=[]
for r in summary['tests']:rows.append([r['name'],str(r['passed']),str(r['failed']),r['method']])
table('検査結果｜図面・物理・実画面を区別',['項目','合格','不合格','検査方法'],rows,[285,65,65,695],sub='人間による実操作なし。数値合格は建築・美術品質の完成判定ではありません。')
section('残課題と次の承認範囲',[
 ('未承認の構造','C館別案とES敷地別案は通常版へ反映していません。地下ESの配置は車路・駐車4区画に干渉するため未施工。RF-SUPPORT-16は未承認のまま。柱・梁の耐力・基礎・構造荷重の実証は行っていません。'),
 ('残余形状と全店目視','境界断面458店舗は欠落未検出。屋上22区画は開放用途を含み、閉鎖壁がないことを不合格とは扱いません。短辺や鋭角など225区画の数値候補は欠陥確定ではなく、全店舗の立体景観評価は未完了です。登録用途を含めても対応付けが残る床形状はsource台帳に掲載。特にC館地下は躯体帯との照合を継続します。'),
 ('屋上花壇',f"BRF-GARDEN-2-BED-4は実衝突床 {bed['missing_rendered_collision_floor_m2']:.2f}㎡、計画床 {bed['missing_canonical_planned_floor_m2']:.2f}㎡が不足。床増築ではなく、既存支持床上へ {bed['relocation_distance_m']:.2f}m移す未承認案のみ提示。通常版では槽・植物とも未設置を維持。"),
 ('性能・素材・品質','1920×1080、上限144FPS、VSync初期ON、物理60Hzを維持。実画面はLinux llvmpipeソフトウェアVulkan。Windows GPU FPSと144FPS達成は未計測です。新規8モデルはBlenderによるオリジナル制作、外部素材はv14の出典・ライセンスを継承。FF16級の環境品質は未達です。')])
section('実画面で残っている美術上の課題',[
 ('店舗全体のレイアウト','今回の専用設備は売場の役割を分ける基礎検証です。アパレルの中央ラックの反復、書店のジャンル表示、各業種の商品バリエーションは十分ではありません。代表店を含め、売場全体の最終内装が完成したとは判断していません。'),
 ('大型売場の密度','食品売場のレジは専用化しましたが、広い空間の部門構成・陳列密度・買い回りの完成度は継続課題です。空白を什器数で埋めるだけの対応にはしていません。家電の画面・商品説明、化粧品の鏡面反射、カフェの注文と作業領域の細部も未仕上げです。'),
 ('A・B館の共用景観','通常版の広場・建築仕上げはv14の構造を維持しています。今回のC構造別案とES案を、全館の高品質な美術完成として扱いません。白い壁・単調な天井が残る視点もあります。'),
 ('未実施の確認','人間による自由歩行での印象評価とWindows GPU性能は未実施。提出PNGは実際のGodot画面ですが、長期目標のFF16級品質には到達していません。')])
# Font is already subset with preserved glyph IDs. MuPDF re-subsetting CFF
# corrupts glyph mappings; embed the supplied subset unchanged.
output=D/'FIND_YOURSELF-v15-Review.pdf';doc.save(output,garbage=4,deflate=True);print('V15_REVIEW_PDF',len(doc),'pages',output.stat().st_size,'bytes')
