from pathlib import Path
P=Path(__file__).resolve().parents[1];src=(P/'authoring/retail_models_v10.py').read_text();exec(src[:src.index('for var in range(3):bookcase')]);OUT=P/'assets/v14/models'
cast=material('Honed_cast_stone_planter',(.44,.43,.39),.82);soil=material('Organic_planting_medium',(.065,.043,.025),.98)
box('Cast_base',(0,0,.035),(4.0,1.4,.07),cast,.015)
for y in[-.64,.64]:box('Long_planter_rim',(0,y,.20),(4.0,.12,.40),cast,.014)
for x in[-1.94,1.94]:box('End_planter_rim',(x,0,.20),(.12,1.16,.40),cast,.014)
box('Recessed_planting_soil',(0,0,.305),(3.76,1.16,.06),soil,.009)
finish('raised_roof_bed')
