from pathlib import Path
import sys,math,collections
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np
R=Path('/workspace/v16-review');(R/'plans').mkdir(parents=True,exist_ok=True);F=read(P/'source/v11/floors-updated.json');D=read(P/'source/v16/commons.json');font=FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams['font.family']=font.get_name();plt.rcParams['axes.unicode_minus']=False
col={'always':'#3c8469','aichi_fair':'#c2863f','es_option':'#a45b90'}
def draw(ax,g,c,edge=None,alpha=1):
 for po in polys(g):
  xy=np.asarray(po.exterior.coords);ax.fill(xy[:,0],xy[:,1],c,edgecolor=edge,linewidth=.4,alpha=alpha)
  for h in po.interiors:
   xy=np.asarray(h.coords);ax.fill(xy[:,0],xy[:,1],'white')
def page(wing,lev):
 f=next(q for q in F if q['wing']==wing and q['level']==lev);fig,ax=plt.subplots(figsize=(16,10));W=lambda g:affinity.translate(g,429,-46)
 draw(ax,W(f['floor_plate']),'#e9e7e0','#8a887e');draw(ax,W(f['public']),'#d8edf0')
 for s in f['stores']:
  draw(ax,W(s['polygon']),'#c5c3b6','#888');p=W(s['polygon']).representative_point();ax.text(p.x,p.y,s['id'],fontsize=4.5,ha='center');e=np.array(s['entry'])+[429,-46];ax.plot(e[0],e[1],'.',color='#d85543',ms=2)
 for q in f['cores']:draw(ax,W(q['outline']),'#9aacbe','#4c6174')
 for q in D['pads']:
  z=next(z for z in D['zones']if z['id']==q['zone'])
  if z['wing']==wing and z['level']==lev:draw(ax,q['geometry'],'#ead5a2','#a98a48',.7)
 for q in D['instances']:
  if q['wing']!=wing or q['level']!=lev or q['host']:continue
  draw(ax,q['footprint'],col[q['activation']],'#27523c',.9)
 for z in D['zones']:
  if z['wing']==wing and z['level']==lev and z['implemented']:
   x,y=z['preferred'];ax.annotate(z['id'],(x,y),(x+5,y+4),fontsize=6,color='#30583c',arrowprops=dict(arrowstyle='-',lw=.4,color='#30583c'))
 ax.set_aspect('equal');ax.grid(alpha=.18);ax.set_xlabel('World X / m');ax.set_ylabel('World Z / m');ax.set_title(wing+'館 '+f['label']+' / v16 実装位置・既存店舗ID（建築躯体はv15を維持）',fontproperties=font);fig.text(.03,.025,'青：既存共用床  灰：既存店舗  赤点：既存入口  緑：新什器の実寸外形  黄土：催事・用途別舗装。これは設計データ図でありGodot画面ではありません。',fontproperties=font,fontsize=9)
 if wing=='C'and lev==0:ax.set_xlim(-200,190);ax.set_ylim(-425,-170)
 fig.savefig(R/'plans'/f'{wing}-{f["label"]}.png',dpi=110,bbox_inches='tight');return fig
with PdfPages(R/'plans/FIND_YOURSELF-v16-配置図.pdf')as pdf:
 for wing,lev in[(w,0)for w in'ABC']+[(w,l)for l in[-1,3]for w in'ABC']:
  fig=page(wing,lev);pdf.savefig(fig);plt.close(fig)
 # F6 existing geometry, not a new approved design.
 fig,axes=plt.subplots(1,2,figsize=(16,9));es=read(P/'source/v15/ES-site-proposal.json')
 for j,y in enumerate([5.525,10.875]):
  ax=axes[j];draw(ax,box(-204,-26.5,-180,-4.5),'#edf0eb','#555');draw(ax,box(-201,-21.5,-183,-9.5),'white','#aaa')
  for e in es['escalators']:
   if abs(e['low_y']-y)>.01 and abs(e['high_y']-y)>.01:continue
   d=np.array(e['u']);p=np.array([e['c'][0],e['c'][2]]);draw(ax,rect(p,d,e['run_m']+2,1.4),'#b3bdac','#567')
  t=es['transfers'][j];pts=np.array([(p[0],p[2])for p in t['points']]);ax.plot(pts[:,0],pts[:,1],'-o',c='#bf742b',label='UP 8.4m')
  x=-199.8 if j==0 else-184.2;side=-200.8 if j==0 else-183.2;z0=-19.8 if j==0 else-13.4;z1=-13.4 if j==0 else-19.8;pts=np.array([[x,z0],[side,z0],[side,z1],[x,z1]]);ax.plot(pts[:,0],pts[:,1],'-o',c='#4672a5',label='DOWN 8.4m')
  ax.set_aspect('equal');ax.grid(alpha=.25);ax.legend();ax.set_title(('2F'if j==0 else'3F')+' F6 未承認・同じ広場内の上下乗り継ぎ',fontproperties=font)
 fig.suptitle('B館西広場 F6：配置維持＋下り乗り継ぎも再検査。B1延伸は車路・4台分の駐車と干渉するため採用しない。',fontproperties=font);pdf.savefig(fig);fig.savefig(R/'plans/B-F6-transfer.png',dpi=120);plt.close(fig)
print('V16_REVIEW_PLANS',R/'plans')
