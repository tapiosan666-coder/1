from pathlib import Path
import sys,copy,json,numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
from shapely.ops import transform
rings=lambda g:[[list(p.exterior.coords)]+[list(r.coords)for r in p.interiors]for p in polys(g)]
normal=read(P/'source/v13/map-data.json');c=copy.deepcopy(normal);e=copy.deepcopy(normal);cp=read(P/'source/v15/C-outlet-proposal.json');es=read(P/'source/v15/ES-site-proposal.json')
for f in c:
 if f['wing']!='C' or f['level']<1:continue
 r=next(r for r in cp['floors']if r['level']==f['level']);f['floor']=rings(r['proposed_floor']);f['public']=rings(r['proposed_public']);f['variant']='v15 UNAPPROVED'
for f in e:
 if f['wing']!='B':continue
 f['variant']='v15 ES SITE UNAPPROVED'
 f['items']=[i for i in f['items']if i['id']not in es['retired_machine_ids']]
 for q in es['escalators']:
  if f['level']not in q['levels']:continue
  cen=[q['c'][0]-429,q['c'][2]+46];g=rect(cen,q['u'],q['run_m'],1.6);f['items'].append({'id':q['id'],'kind':'エスカレーター','geometry':rings(g),'point':cen,'implemented':True})
 # Actual option slab/circulation, including central ring and both public connectors.
 if f['level']>=0:
  floor=unary_union([Polygon(p[0],p[1:])for p in f['floor']]);public=unary_union([Polygon(p[0],p[1:])for p in f['public']]);outer=box(-633,19.5,-609,41.5);hole=box(-628.4,23.1,-613.6,37.9)if f['level']>0 else Polygon();ring=outer.difference(hole)
  bridges=unary_union([transform(lambda x,z,zz=None:(np.asarray(x)-429,np.asarray(z)+46),q['geometry'])for q in es['connectors']if q['level']==f['level']]);floor=floor.difference(hole).union(ring).union(bridges);public=public.difference(hole).union(ring).union(bridges);f['floor']=rings(floor);f['public']=rings(public)
write(P/'source/v15/map-data-C-option.json',c);write(P/'source/v15/map-data-ES-option.json',e)
