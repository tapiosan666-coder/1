from pathlib import Path
import sys,json,shutil,csv,hashlib,collections
P=Path(__file__).resolve().parents[1];D=Path('/workspace/1/docs/visual-review-v15');D.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
S=D/'source';T=D/'tests';S.mkdir(exist_ok=True);T.mkdir(exist_ok=True)
for f in(P/'source/v15').glob('*'):
 if f.is_file()and not f.name.endswith('.import'):shutil.copy2(f,S/f.name)
# Entire tests, not just passing totals. Superseded exploratory logs are not mixed into final evidence.
testfiles={'normal-physical/physics-all.json':'normal-945.json','C-physical/physics-C.json':'C-186.json','physics-ES.json':'ES-site-input.json','physics-C.json':'C-gallery-input.json','edges-ES.json':'ES-edge-input.json','edges-C.json':'C-edge-input.json','service-walk.json':'service-walk.json','controls/controls-amenities.json':'controls.json','normal-es/es-approach-input.json':'normal-ES-approach.json','normal-EV/physics-EV.json':'normal-EV-rides.json','C-es/es-approach-input.json':'C-ES-approach.json','C-external/physics-EXTERNAL.json':'C-external-connections.json','cache-normal.json':'cache-normal.json','cache-C-option.json':'cache-C-option.json'}
for a,b in testfiles.items():shutil.copy2(P/'evidence/v15'/a,T/b)
rows=[]
def add(name,file,key='checks',method=''):
 d=json.loads((T/file).read_text());checks=d[key];expected={'normal-945.json':945,'C-186.json':186,'ES-edge-input.json':12,'C-edge-input.json':len(read(P/'source/v15/C-edge-cases.json')),'C-gallery-input.json':8,'C-ES-approach.json':4,'C-external-connections.json':14,'service-walk.json':7,'normal-ES-approach.json':40,'normal-EV-rides.json':119,'controls.json':33,'cache-normal.json':6,'cache-C-option.json':1};assert len(checks)==expected[file],(file,len(checks));good=sum(bool(c['pass'])for c in checks);bad=len(checks)-good;rows.append({'name':name,'passed':good,'failed':bad,'method':method,'source':'tests/'+file});return d
add('通常版の指定歩行経路','normal-945.json',method='実衝突のカプセル自動経路追従。人間の操作ではありません。')
add('C館別案の入口・設備経路','C-186.json',method='B1〜RFのC館経路を別案で再実行。屋上6入口を含みます。')
es=json.loads((T/'ES-site-input.json').read_text());checks=es['checks']+es['transfers'];assert len(checks)==16;rows.append({'name':'ES敷地案の乗降・乗継・接続','passed':sum(c['pass']for c in checks),'failed':sum(not c['pass']for c in checks),'method':'6機械＋2乗継＋8通路接続。W入力注入、1F〜RFのみ。','source':'tests/ES-site-input.json'})
add('新ES開口のガードへの入力','ES-edge-input.json','cases','2F・3F・RFの4方向。見える柵へ160tick進み、落下・通過を検査。')
add('C館新回廊のガードへの入力','C-edge-input.json','cases','2Fの回廊・必要アクセス橋と3Fの独立棟端部。床端の代表位置。全境界の連続保証ではありません。')
add('C館別案の回廊・アクセス橋','C-gallery-input.json',method='8経路の実W入力。2階回遊6経路とES降り場への接続2経路。')
add('C館別案のES乗降','C-ES-approach.json',method='既存C館4機械の乗場・フライト・退出。')
add('C館別案の館間・駐車場接続','C-external-connections.json',method='A/B・B/Cと駐車場橋を含む指定接続経路。')
add('代表店舗の設備への到達','service-walk.json',method='既存什器を避けた経路で実衝突を検査。')
add('既存ESの乗降・退出','normal-ES-approach.json',method='通常版40機械。W入力で乗場・フライト・降場を通過。')
add('既存EVの連続昇降・乗降','normal-EV-rides.json',method='通常版119ケース。かごの連続移動、床との位置差、退出を検査。')
add('F9・M・表示位置','controls.json',method='更新後の28行先など33チェック。地下照明天井支持247点は別記。')
add('通常版の間接光キャッシュ','cache-normal.json',method='最終スクリプト・アセットと6キャッシュの署名照合。')
add('C別案の間接光キャッシュ','cache-C-option.json',method='C代表エリア1キャッシュを別案で再ベイク・照合。')
a=read(P/'source/v15/preservation-audit.json');rows.insert(0,{'name':'通常建築・移動処理の保護','passed':len(a['normal_building_and_control_checks']),'failed':0,'method':'18建築パック＋10主要コード・データのSHA比較。','source':'source/preservation-audit.json'});rows.insert(1,{'name':'閉鎖店舗の境界断面','passed':a['boundary_non_RF_stores']-a['boundary_non_RF_uncovered_stores'],'failed':a['boundary_non_RF_uncovered_stores'],'method':'実描画・実衝突、床+1.15m、辺サンプル間隔0.5m以下。屋上22区画は別評価。','source':'source/boundary-audit.json'})
assert all(r['failed']==0 for r in rows),[(r['name'],r['failed'])for r in rows if r['failed']]
maxrise=max(c.get('detail',{}).get('max_frame_rise_m',0)for c in es['checks']);summary={'version':'v15','tests':rows,'no_combined_quality_pass_count':True,'ES_max_per_physics_frame_vertical_motion_m':maxrise,'human_playtest':False,'Windows_GPU_FPS':None,'FPS_144_reached':None,'renderer_for_screenshots':'Godot 4.6.3 Forward+ / Linux llvmpipe (software Vulkan)','main_game_integrated':False,'normal_building_preserved':True,'C_variant':'UNAPPROVED','ES_site_variant':'UNAPPROVED, 1F-RF only; B1 not installed','RF_SUPPORT_16':'UNAPPROVED','quality_status':'Architectural and representative-service validation; not full-mall or FF16 quality completion'}
write(D/'test-summary.json',summary)
# Quantitative ledgers remain CSV, not hundreds of repetitive report pages.
F=read(P/'source/v11/floors-updated.json');lookup={s['id']:(f,s)for f in F for s in f['stores']};ledger=[];matches=[]
for sid,(f,s)in lookup.items():
 frontage=s.get('frontage_m');depth=s.get('depth_m');method='source dimensions'
 if frontage is None:frontage=LineString(s['front']).length if s.get('front')else None;method='front boundary length / projected depth'
 if depth is None:
  co=[q for po in polys(s['polygon'])for q in po.exterior.coords];n=s['n'];vals=[q[0]*n[0]+q[1]*n[1]for q in co];depth=max(vals)-min(vals)
 g=s['polygon'].area;b=s['backroom'].area;e=s['entry'];ledger.append([sid,f['wing'],f['label'],s['category'],g,s['sales'].area,b,100*b/g,frontage,depth,method,e[0]+429,f['height'],e[1]-46]);matches.append([sid,sid,e[0]+429,f['height'],e[1]-46,e[0]+429,f['height'],e[1]-46,'unchanged shop plot/entry; C public floor option is separate'])
with(S/'store-ledger-480.csv').open('w',encoding='utf-8-sig',newline='')as fp:w=csv.writer(fp);w.writerow(['store_id','wing','floor','category','gross_m2','sales_m2','backroom_m2','backroom_percent','frontage_m','depth_m','dimension_method','entry_world_x','entry_world_y','entry_world_z']);w.writerows(ledger)
with(S/'ID-coordinate-correspondence-480.csv').open('w',encoding='utf-8-sig',newline='')as fp:w=csv.writer(fp);w.writerow(['old_ID','new_ID','old_X','old_Y','old_Z','new_X','new_Y','new_Z','note']);w.writerows(matches)
with(S/'remaining-shape-components.csv').open('w',encoding='utf-8-sig',newline='')as fp:
 w=csv.writer(fp);w.writerow(['ID','wing','floor','world_X','world_Y','world_Z','area_m2','width_index_m','classification','adjacent_roles'])
 for r in read(P/'source/v15/unassigned-space-audit.json'):w.writerow([r['id'],r['wing'],r['floor'],*r['world'],r['area_m2'],r['width_index_m'],r['classification'],'; '.join(r['adjacent_roles'])])
print('V15_REVIEW_DATA',len(rows),'test groups, 480 ledgers, all asserted passing in their stated scope')
