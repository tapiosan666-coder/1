"""Original, deterministic calibrated surface textures and fictional retail graphics. No downloaded imagery."""
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
P=Path(__file__).resolve().parents[1];O=P/'assets/v14/materials';O.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(14104);N=512
font_path='/workspace/1/assets/fonts/NotoSansCJKjp-Regular.otf'
def font(n):return ImageFont.truetype(font_path,n)
def noise(n=32):
 a=Image.fromarray(rng.integers(0,256,(n,n),dtype=np.uint8)).resize((N,N),Image.Resampling.BICUBIC);return np.array(a,dtype=float)/255-.5
x,y=np.meshgrid(np.arange(N),np.arange(N));fine=noise(512);large=noise(12);mid=noise(70)
for name,col,rough in [('limestone',(193,189,177),.37),('terrazzo',(211,209,197),.43),('plaster',(214,211,200),.85),('paving',(167,157,139),.83),('ceramic',(199,204,198),.38),('fabric',(141,133,116),.9),('wood',(132,92,56),.52)]:
 h=.3*mid+.08*fine+.15*large;a=np.ones((N,N,3))*np.array(col)+h[:,:,None]*11
 if name=='terrazzo':
  im=Image.fromarray(np.uint8(np.clip(a,0,255)));d=ImageDraw.Draw(im)
  for i in range(1800):
   xx,yy=rng.integers(0,N,2);r=int(rng.choice([1,1,2,2,3,4]));c=[(178,182,171),(191,193,182),(219,218,204),(202,197,180),(230,224,209)][i%5];d.polygon([(xx-r,yy),(xx,yy-r),(xx+r,yy+1),(xx+1,yy+r)],fill=c)
  a=np.array(im);h+=fine*.06
 elif name=='limestone':
  vein=np.sin(x*.021+3*large+np.sin(y*.01))*np.sin(y*.013+large*4);a+=vein[:,:,None]*3;h+=vein*.02
 elif name=='wood':
  grain=np.sin(x*.17+np.sin(y*.012)*1.4+large*8)+.3*np.sin(x*1.1+large*10);a+=grain[:,:,None]*np.array([9,7,5]);h+=grain*.07
 elif name=='fabric':
  weave=(np.sin(x*np.pi)*np.sin(y*np.pi)+np.sin(x*1.57)*np.cos(y*1.57))*.1;h+=weave;a+=weave[:,:,None]*18
 if name=='paving':a+=large[:,:,None]*10
 dx=(np.roll(h,-1,1)-np.roll(h,1,1))*.22;dy=(np.roll(h,-1,0)-np.roll(h,1,0))*.22
 norm=np.stack([-dx,-dy,np.ones_like(h)],axis=2);norm/=np.linalg.norm(norm,axis=2)[:,:,None]
 Image.fromarray(np.uint8(np.clip(a,0,255))).save(O/(name+'-albedo.png'),optimize=True)
 Image.fromarray(np.uint8((norm*.5+.5)*255)).save(O/(name+'-normal.png'),optimize=True)
 Image.fromarray(np.uint8(np.clip(rough+h*.05,0,1)*255)).save(O/(name+'-rough.png'),optimize=True)
# 4x4 label atlas: entirely invented product names, typographic hierarchy and colour bands.
im=Image.new('RGB',(1024,1024),'#eeeade');d=ImageDraw.Draw(im)
names=['朝の穀物','HARBOR OATS','トマトソース','FOREST TEA','焼き菓子','OLIVE & HERB','白桃の果実','CITRUS WATER','植物のうるおい','NOMA SKIN','LUMI SERUM','BOTANICA','丁寧な暮らし','DELI SELECT','星の珈琲','HONEY BLEND']
colors=['#546c4c','#324c5a','#a64e38','#b69452','#805e47','#546451','#be876c','#8c9f55']
for i,name in enumerate(names):
 xx=(i%4)*256;yy=(i//4)*256;c=colors[i%len(colors)];d.rectangle((xx+4,yy+4,xx+251,yy+251),fill='#eeeade');d.rectangle((xx+4,yy+4,xx+251,yy+50),fill=c)
 d.text((xx+18,yy+13),'F / Y   SELECT',font=font(18),fill='white');d.text((xx+18,yy+80),name,font=font(24),fill=c)
 d.ellipse((xx+82,yy+126,xx+174,yy+196),outline=c,width=3);d.line((xx+91,yy+165,xx+128,yy+142,xx+163,yy+173),fill=c,width=3)
 d.text((xx+18,yy+216),'ORIGINAL   /   240g',font=font(14),fill=c)
im.save(O/'retail-labels.png',optimize=True)
im=Image.new('RGB',(1024,512),'#efe9dc');d=ImageDraw.Draw(im)
for i,(t,sub)in enumerate([('旬の野菜','FRESH PRODUCE'),('暮らしの食品','PANTRY & DAILY'),('ミルク・チーズ','CHILLED SELECTION'),('焼き菓子と珈琲','BAKERY & COFFEE')]):
 yy=i*128;d.rectangle((0,yy,1023,yy+127),fill=colors[i]);d.text((32,yy+13),t,font=font(42),fill='#fff7e7');d.text((35,yy+77),sub,font=font(23),fill='#ede4ce');d.text((850,yy+22),'F/Y',font=font(54),fill='#fff7e7')
im.save(O/'department-signs.png',optimize=True)
print('V14_TEXTURES',len(list(O.glob('*.png'))),sum(f.stat().st_size for f in O.iterdir()))
