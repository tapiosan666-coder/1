"""Lossless GLB image deduplication. Buffer/accessor bytes and image bytes are independently checked."""
from pathlib import Path
import struct,json,hashlib
P=Path(__file__).resolve().parents[1];T=P/'assets/v14/textures';T.mkdir(exist_ok=True);rows=[]
sha=lambda x:hashlib.sha256(x).hexdigest()
for f in (P/'assets/v14/models').glob('*.glb'):
 raw=f.read_bytes();count=struct.unpack_from('<I',raw,12)[0];j=json.loads(raw[20:20+count]);bin_start=20+count+8;blob=raw[bin_start:];removed=set();images=[]
 for im in j.get('images',[]):
  if 'bufferView'not in im:continue
  k=im['bufferView'];v=j['bufferViews'][k];data=blob[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];suffix='.png'if im['mimeType']=='image/png'else'.jpg';name=sha(data)+suffix;(T/name).write_bytes(data);removed.add(k);images.append({'sha256':sha(data),'bytes':len(data),'uri':'../textures/'+name});im.pop('bufferView');im['uri']='../textures/'+name
 if not removed:continue
 newbin=bytearray();views=[];indices={};streams=[]
 for i,v in enumerate(j['bufferViews']):
  if i in removed:continue
  data=blob[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];streams.append(sha(data))
  newbin.extend(b'\0'*((-len(newbin))%4));indices[i]=len(views);v['byteOffset']=len(newbin);newbin.extend(data);views.append(v)
 for accessor in j.get('accessors',[]):
  if 'bufferView'in accessor:accessor['bufferView']=indices[accessor['bufferView']]
  for key in ['indices','values']:
   if key in accessor.get('sparse',{}):accessor['sparse'][key]['bufferView']=indices[accessor['sparse'][key]['bufferView']]
 j['bufferViews']=views;j['buffers'][0]['byteLength']=len(newbin)
 text=json.dumps(j,separators=(',',':'),ensure_ascii=False).encode();text+=b' '*((-len(text))%4);newbin.extend(b'\0'*((-len(newbin))%4));result=b'glTF'+struct.pack('<II',2,12+8+len(text)+8+len(newbin))+struct.pack('<I',len(text))+b'JSON'+text+struct.pack('<I',len(newbin))+b'BIN\0'+newbin
 f.write_bytes(result)
 # Read back all geometry byte ranges; image data kept verbatim in unique PNGs.
 reread=json.loads(text);newstreams=[sha(newbin[v['byteOffset']:v['byteOffset']+v['byteLength']])for v in reread['bufferViews']];assert newstreams==streams
 assert all(sha((f.parent/q['uri']).resolve().read_bytes())==q['sha256']for q in images)
 rows.append({'file':str(f.relative_to(P)),'before_sha256':sha(raw),'after_sha256':sha(result),'geometry_buffer_ranges_unchanged':True,'image_bytes_unchanged':True,'images':images})
if rows:
 target=P/'source/v14/lossless-packaging.json';old=json.loads(target.read_text())if target.exists()else[];combined={r['file']:r for r in old}
 for r in rows:combined[r['file']]=r
 target.write_text(json.dumps(list(combined.values()),ensure_ascii=False,indent=2))
print('LOSSLESS_GLBS',len(rows),'unique images',len(list(T.iterdir())))
