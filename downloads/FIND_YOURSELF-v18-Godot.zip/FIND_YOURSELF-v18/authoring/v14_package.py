"""A single complete v14 archive. Retired seven meshes replaced through explicit legacy-AABB registry."""
from pathlib import Path
import zipfile,json,hashlib,sys,struct,posixpath
P=Path(__file__).resolve().parents[1];D=Path('/workspace/1/downloads');D.mkdir(exist_ok=True)
base=(P/'authoring/v13_package.py').read_text();# Reuse its established pruning rules, not mutate prior release.
base=base[:base.index("manifest={'version'")]
ns={'__file__':str(P/'authoring/v13_package.py')};exec(base,ns);files=ns['files'];registry=json.loads((P/'source/v14/asset-bounds.json').read_text());retired={(P/'assets/v10'/(key+'.glb')).resolve().relative_to(P).as_posix()for key in registry};out=[]
for f,r in files:
 if r in retired:continue
 if r.startswith("assets/v10/gi-")and r.endswith(".res"):continue # incompatible old material/mesh GI caches
 if r.startswith('assets/v14/models/')and f.suffix!='.glb':continue # importer regenerates embedded image extracts
 if any(r.startswith(str(Path(k).with_suffix(''))+'_')and f.suffix=='.png'for k in retired):continue
 out.append((f,r))
# Prove which old source texture files are still referenced by surviving GLBs.
needed=set()
for f,r in out:
 if f.suffix!='.glb':continue
 b=f.read_bytes();n=struct.unpack_from('<I',b,12)[0];gltf=json.loads(b[20:20+n])
 for ref in gltf.get('images',[])+gltf.get('buffers',[]):
  uri=ref.get('uri','')
  if uri and not uri.startswith('data:'):needed.add(posixpath.normpath(posixpath.join(posixpath.dirname(r),uri)))
out=[(f,r)for f,r in out if not(r.startswith('assets/v10/textures/')or r.startswith('assets/v14/textures/'))or r in needed]
assert all((P/r).is_file()for r in needed)
manifest={'version':'v14 combined quality validation','single_archive':True,'main_game_integrated':False,'retired_meshes':sorted(retired),'replacement_registry':'source/v14/asset-bounds.json','files':[{'path':r,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f,r in out]}
(P/'release-manifest-v14.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));out.append((P/'release-manifest-v14.json','release-manifest-v14.json'))
path=D/('FIND_YOURSELF-v14-Combined-Godot-TRIAL.zip'if'--trial'in sys.argv else'FIND_YOURSELF-v14-Combined-Godot.zip')
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f,r in out:z.write(f,'FIND_YOURSELF-v14/'+r)
print('V14_PACKAGE',path.stat().st_size,len(out),'files',len(retired),'retired models','104857600 byte limit');assert path.stat().st_size<104857600
