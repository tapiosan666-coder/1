from pathlib import Path
import sys,json,hashlib,collections
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
floors=read(P/'source/v11/floors-updated.json');F={(f['wing'],f['level']):f for f in floors};D=read(P/'source/v16/commons.json');terrain=read(P/'source/terrain-v7.json');checks=[]
for d in D['instances']:
 if d['host']:continue
 f=F[d['wing'],d['level']];foot=shape(d['footprint']);floor=affinity.translate(unary_union([f.get('floor_plate',f['shell']),f.get('outdoor_ground',Polygon())]+[r['geometry']for r in terrain['layers']if d['wing']=='C'and d['level']==0]),429,-46)
 missing=foot.difference(floor).area
 checks.append(dict(id=d['id'],test='design_floor_or_ground_coverage',missing_m2=round(missing,6),passed=missing<.0001,method='design floor + registered outdoor ground and terrain-v7 layers; native downward support rays are a separate check'))
for d in D['pads']:
 checks.append(dict(id=d['id'],test='surface_finish_not_new_structural_floor',passed=d['structural_floor']is False))
ids=[s['id']for f in floors for s in f['stores']];checks.append(dict(test='480_shop_ids_unchanged',count=len(ids),passed=len(ids)==480 and len(set(ids))==480))
for name in['player.gd','escalator_v2.gd']:
 checks.append(dict(test='smooth_controller_unchanged',path=name,passed=(P/name).read_bytes()==(Path('/workspace/FIND_YOURSELF-Site-v15')/name).read_bytes()))
report={'pass':all(c['passed']for c in checks),'checks':checks,'failed':[c for c in checks if not c['passed']],'method':'design geometry only; no manual playtest, structural engineering or vehicle tracking claim','rejected_placements':read(P/'source/v16/layout-rejections.json')}
write(P/'source/v16/geometry-check.json',report);print('V16_GEOMETRY',len(checks),'failed',len(report['failed']));print(json.dumps(report['failed'],ensure_ascii=False))
