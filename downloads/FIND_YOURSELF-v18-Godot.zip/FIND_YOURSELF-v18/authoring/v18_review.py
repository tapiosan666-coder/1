"""Offline concise review. All photographic panels link untouched native Viewport PNGs."""
from pathlib import Path
import json,shutil,hashlib,csv,html,collections
from PIL import Image
P=Path(__file__).resolve().parents[1];OUT=Path('/workspace/v18-review');BASE=Path('/workspace/1/docs/visual-review-v17/after')
for folder in ['before','data','licenses']:(OUT/folder).mkdir(exist_ok=True)
load=lambda p:json.loads(Path(p).read_text())
write=lambda p,d:Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2))
selected=['AB1-003-interior','BB1-MARKET-interior','B-RF-garden','ARF-002-terrace','v15-B1-030-beauty_tester_bar','v15-B1-N03-electronics_media_demo','shop-apparel-C1F-CW-1','shop-book-A1F-007','shop-cafe-C1F-CSW-3','V17-A-long-street','V17-B2-gallery','V17-B3-gallery']
prior=load(OUT/'before/captures.json')if(OUT/'before/captures.json').exists()else{'shots':[]};extra=[s for s in prior['shots']if s['id']not in selected]
base=load(BASE/'captures.json');metadata=[s for s in base['shots']if s['id']in selected]
for id in selected:shutil.copy2(BASE/(id+'.png'),OUT/'before'/(id+'.png'))
write(OUT/'before/captures.json',{'shots':extra+metadata,'v17_source':'Immutable delivered v17 project and its actual Viewport outputs. Two additional views re-captured from protected v17; no v18 assets loaded.'})
for f in(P/'source/v18').glob('*.json'):shutil.copy2(f,OUT/'data'/f.name)
for f in(P/'licenses').glob('*'):
 if f.is_file():shutil.copy2(f,OUT/'licenses'/f.name)
plan=load(P/'source/v18/retail-plan.json');people=load(P/'source/v18/shoppers.json');geometry=load(P/'source/v18/layout-check.json')
# Protect all v17 storefront model/image assets, not just the new brand registry.
protected=load(OUT/'data/protected-baseline.json');known={r['path']for r in protected['checks']};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P17=Path('/workspace/FIND_YOURSELF-Site-v17')
for f in(P/'assets/v17').rglob('*'):
 if not f.is_file()or f.suffix in['.import','.uid']:continue
 rel=f.relative_to(P).as_posix()
 if rel not in known and(P17/rel).exists():protected['checks'].append({'path':rel,'v17_sha256':sha(P17/rel),'v18_sha256':sha(f),'unchanged':sha(P17/rel)==sha(f)})
assert all(r['unchanged']for r in protected['checks']);write(OUT/'data/protected-baseline.json',protected)
checks=[]
for name,field in [('physics-all.json','checks'),('physics-ES.json','checks'),('physics-EV.json','checks'),('v18-interior-physics.json','checks'),('v18-npc-controls.json','checks'),('edges-C.json','cases'),('edges-ES.json','cases')]:
 f=OUT/'physics'/name
 if f.exists():
  d=load(f);rows=d[field];checks.append({'file':'physics/'+name,'name':name,'passed':sum(bool(r['pass'])for r in rows),'total':len(rows)})
for name in ['site-physics-C.json','site-physics-ES.json']:
 f=OUT/'physics'/name
 if f.exists():
  d=load(f);rows=d.get('checks',[])+d.get('transfers',[]);checks.append({'file':'physics/'+name,'name':name,'passed':sum(bool(r['pass'])for r in rows),'total':len(rows)})
f=OUT/'F6-rounded-width-and-belt.json'
if f.exists():
 rows=load(f)['checks'];checks.append({'file':f.name,'name':'F6 7.532m candidate / +/-0.35m margins','passed':sum(r['pass']for r in rows),'total':len(rows)})
crowd=load(OUT/'physics/v18-crowd-physics.json');rows=crowd['checks'];checks.append({'file':'physics/v18-crowd-physics.json','name':'43 NPC / 60 simulated seconds','passed':sum(r['pass']for r in rows),'total':len(rows)})
controls=OUT/'physics/controls/controls-amenities.json'
if controls.exists():
 d=load(controls);checks.append({'file':'physics/controls/controls-amenities.json','name':'F9 / M / F11 / arrival floors','passed':d['passed'],'total':d['passed']+d['failed']})
settings=OUT/'physics/settings-save-restore-v18.json'
if settings.exists():
 rows=load(settings)['checks'];checks.append({'file':'physics/settings-save-restore-v18.json','name':'Display settings save / restore','passed':sum(r['pass']for r in rows),'total':len(rows)})
write(OUT/'data/check-summary.json',checks)
# Per-file screenshot evidence: dimensions and bytes, no retouching or concept render.
images=[]
for folder in ['before','after','people','after-C-option','after-ES-option']:
 for file in sorted((OUT/folder).glob('*.png')):
  with Image.open(file)as im:resolution=list(im.size)
  assert resolution==[1920,1080],file
  images.append({'file':str(file.relative_to(OUT)),'resolution':resolution,'sha256':sha(file),'actual_Godot_Viewport':True})
write(OUT/'data/viewport-image-integrity.json',images)
# Compare camera coordinates, projection and look vector, not resized collage screenshots.
after=load(OUT/'after/captures.json');before=load(OUT/'before/captures.json');bymeta={s['id']:s for s in before['shots']};camera_checks=[]
for s in after['shots']:
 if s['id']not in bymeta:continue
 b=bymeta[s['id']];okay=all(s[k]==b[k]for k in['eye','look','fov','resolution']);camera_checks.append({'id':s['id'],'same_view':okay})
assert all(r['same_view']for r in camera_checks);write(OUT/'data/same-view-validation.json',camera_checks)
# Retain rejection of unsafe 6.4m candidate explicitly as historical evidence.
old=Path('/workspace/1/docs/visual-review-v17/F6-route-width-and-belt.json')
if old.exists():shutil.copy2(old,OUT/'data/F6-6.4m-rejection-v17-historical.json')
issues=[
 '全館の景観・全480店舗の内装が完成した版ではありません。代表8店を再構成し、残る472店は従来内装を維持しています。',
 '人物は試験用の造形・手続きアニメーションです。服装の形状差、顔・手指・髪の質感、着席時の細かな接触や自然な演技は未完成です。商用品質の人物完成とは扱いません。',
 '屋上、遠景の長い壁、白い天井、大きな空白は残っています。屋上の新休憩家具1組を屋上全域の完成とはしていません。',
 '食品パッケージや書籍のデザインは反復が多く、棚を越えた売場演出と商品種類は追加制作が必要です。',
 'NPCは1Fの短い指定経路のみです。EV・ES・階段への乗降は未実装で、経路を機械周辺から離しています。高度な群衆回避や長時間耐久は未検証です。',
 'C館F4、B館F6、C館水上庭園、RF-SUPPORT-16は未承認。通常版へ統合していません。構造耐力・水盤荷重を実証していません。',
 '人間による手動操作、Windows GPUのFPSは未測定です。FF16級の環境品質、144FPS達成を主張しません。'
]
write(OUT/'data/open-issues.json',{'issues':issues,'main_game_integrated':False,'human_playtest':False,'Windows_GPU_test':False,'AAA_quality_reached':False})
md='''# FIND YOURSELF v18 検証資料

`index.html` をブラウザで開くと、実Godot画面を同じ視点で比較できます。画像をクリックすると1920×1080の元PNGを開きます。左右比較は表示方法だけを変え、撮影画像そのものは加工していません。

## 実装した範囲

- 代表8店・7業種の売場を組み直し。新しい店内203配置＋共用休憩11配置、計214配置。
- 試験用買い物客43人（A14/B15/C14）。歩行15、着席10、商品閲覧6、会話6、催事4、案内閲覧2。F12で描画・衝突・更新をまとめて切替。
- 480店舗ID、15層、v17のブランド・正面・広告、館間連絡、プレイヤー／ES移動処理を維持。
- 旧什器を除去した後にも残っていた120mm以下の陳列台台座の孤立衝突を、対象8店の売場に限って除去。床・壁用の構造材料は除外。
- 書店等で壁面什器の向きが逆になっていた配置規則を修正。C館の会話役は植栽台上から実床へ移動。腕の向きと着席姿勢を修正。

## 完成扱いにしない範囲

'''+''.join('- '+s+'\n'for s in issues)+'''
## 検証の意味

`physics/` はGodotの実衝突判定を用いる自動検査です。`data/layout-check.json` は2D図面・什器配置の幾何検査です。両者を区別し、人間の操作テストや美術品質の合格とは扱っていません。店内40経路は実カプセルで再検査。人物は60秒のシミュレーションで床支持・移動・ON/OFFを確認しました。最初の店内検査で停止した経路や、植栽台に立った人物も、実画面・実物理で見つけて修正しています。

画像の人物位置・姿勢は、実際に20秒間シミュレーションしたスナップショットで固定しています。NPCなし／あり比較でカメラや床・照明は変えていません。性能観察も姿勢固定で描画差を比較しており、移動中の総合ベンチマークではありません。

## 未承認のF6候補

機械配置を変えず、7.532mの角を丸めた乗り継ぎ候補と左右0.35mの余裕を実歩行で確認。6ケースを確認しています。候補の通常版採用やES移設の承認ではありません。6.4m案の過去の手すり干渉は棄却のままです。

## データとライセンス

`data/representative-stores.csv`、`data/floors-15.csv`、`data/shoppers.json`、`plans/representative-layouts.svg` で実装範囲と配置を確認できます。SVGは2D設計データであり、Godot実画面ではありません。

新規什器・包装・部門表示・髪・バッグは本プロジェクト向けのオリジナル制作。人物のMakeHuman由来加工素材はCC0。PBR素材・フォントは継承した条件を維持し、`licenses/` に原出典と条件を同梱しています。実在ブランドの広告や写真を新規の看板に流用していません。
'''
(OUT/'README.md').write_text(md)
escape=html.escape
styles='''body{margin:0;background:#111b20;color:#edf1eb;font:16px/1.7 system-ui,sans-serif}main{max-width:1200px;margin:auto;padding:38px 24px}h1{font-size:32px}h2{margin-top:50px;color:#d6c99e}a{color:#aad7d0}.lead{max-width:900px}.note,article{background:#1d2b30;padding:20px;border-radius:10px;margin:18px 0}.warn{border-left:4px solid #e2b26f}table{border-collapse:collapse;width:100%;font-size:14px}td,th{text-align:left;padding:10px;border-bottom:1px solid #3c4b4e}.compare{position:relative;aspect-ratio:16/9;overflow:hidden;background:#050708}.compare img{position:absolute;width:100%;height:100%;object-fit:contain}.compare .new{clip-path:inset(0 50% 0 0)}input{width:100%}.caps{display:flex;justify-content:space-between;font-size:13px}.badge{font-size:12px;color:#d7bb88}details{margin:14px 0}code{color:#c9d3b7}ul{padding-left:22px}.thumb{width:100%;height:auto}nav a{margin-right:20px}footer{padding:30px 0;color:#aab8bb}'''
def card(title,a,b,left='v17',right='v18',note=''):
 if not(OUT/a).exists()or not(OUT/b).exists():return ''
 return f'''<article><h3>{escape(title)}</h3><div class="compare"><img loading="lazy" src="{a}" alt="{left}"><img class="new" loading="lazy" src="{b}" alt="{right}"></div><input aria-label="比較画像の境界" type="range" min="0" max="100" value="50" oninput="this.previousElementSibling.querySelector('.new').style.clipPath='inset(0 '+(100-this.value)+'% 0 0)'"><div class="caps"><a href="{b}">{right} の元PNG</a><a href="{a}">{left} の元PNG</a></div><p>{escape(note)}</p><span class="badge">実Godot Viewport / 1920×1080 / 同じ視点。スライダー左側が{right}。</span></article>'''
parts=[f'<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>FIND YOURSELF v18 Review</title><style>{styles}</style><main><p>FIND YOURSELF · INDEPENDENT VALIDATION</p><h1>v18：売場と、43人の買い物客</h1><p class="lead">代表8店舗の内装を業種別に再構成し、少人数の利用風景を検証しました。全館の完成版ではありません。まずNPCなし／あり、次にv17／v18を同じGodot視点で比較してください。</p><nav><a href="#people">人物比較</a><a href="#retail">店舗内装</a><a href="#floors">15層の範囲</a><a href="#checks">検査と性能</a><a href="#open">未完成</a><a href="README.md">説明書</a></nav><p class="note warn">ゲーム本体へ未統合。F4・F6・水上庭園・RF-SUPPORT-16は未承認。人間の手動操作、Windows GPU性能は未検証です。</p><h2 id="people">NPCなし／あり</h2><p>43人＝A14 / B15 / C14。歩行15・着席10・商品閲覧6・会話6・催事4・案内閲覧2。20秒の実物理状態を固定して撮影。F12で人物の描画・衝突・更新を切り替えられます。</p>']
bytitle={s['id']:s.get('title',s['id'])for s in load(P/'source/v18/review-cameras.json')}
for id in ['V17-A-long-street','V16-A-visitor','V16-B-aichi','V16-B-fair-close','V18-B-time-people','V16-C-courtyard','V16-C-kids','V16-C-dog','V16-C-melon','V18-C-cafe-people']:
 parts.append(card(bytitle[id],'after/'+id+'.png','people/'+id+'.png','NPCなし','NPCあり','人物造形と動きは試験品質です。座席・閲覧先・会話相手を割り当てています。'))
parts.append('<h2 id="retail">代表8店舗：v17／v18</h2><p>旧什器を重ねずに置き換え、入口展示・中央売場・壁面売場・会計を区別しました。店舗区画・入口・バックヤードは維持。商品図柄の反復や売場密度は引き続き改善が必要です。</p>')
for id in ['shop-book-A1F-007','V18-A-home-interior','shop-apparel-C1F-CW-1','v15-B1-030-beauty_tester_bar','v15-B1-N03-electronics_media_demo','shop-cafe-C1F-CSW-3','AB1-003-interior','BB1-MARKET-interior']:
 parts.append(card(bytitle[id],'before/'+id+'.png','after/'+id+'.png',note='元の売場形状と主動線を維持。内装の全面更新はこの8店が対象です。'))
parts.append('<h2>地下・屋上・上階</h2><p>屋上は局所的な休憩配置にとどまり、広い空白や簡素な建築が残っています。B館3F・RFの景観全域を改善済みとはしていません。</p>')
for id in ['V18-A-roof-lounge','ARF-002-terrace','B-RF-garden','V17-B2-gallery','V17-B3-gallery']:parts.append(card(bytitle[id],'before/'+id+'.png','after/'+id+'.png',note='未変更の場所を含む正直な比較です。新規配置と維持範囲は15層一覧を参照。'))
parts.append('<h2 id="floors">15層の実装範囲</h2><table><tr><th>館・階</th><th>店舗ID</th><th>新しい休憩配置</th><th>新内装店舗</th><th>状態</th></tr>')
for r in plan['floor_review']:
 count=sum(s['wing']==r['wing']and s['floor']==r['floor']for s in plan['stores']);status='局所改善・全域未完成'if r['new_public_clusters']or count else'v17維持・今回追加なし';parts.append(f'<tr><td>{r["wing"]} {r["floor"]}</td><td>{r["shops"]}</td><td>{r["new_public_clusters"]}</td><td>{count}</td><td>{status}</td></tr>')
parts.append('</table><p><a href="data/floors-15.csv">15層CSV</a> / <a href="data/representative-stores.csv">代表店舗台帳</a> / <a href="plans/representative-layouts.svg">売場配置図（2D設計データ）</a> / <a href="data/shoppers.json">43人の配置・役割・経路</a></p><h2>未承認の構造案</h2><p>F4・F6は通常版と別シーンのまま維持。F6の中央7.532m候補と左右余裕は実衝突で検証しています。通常版の移設採用ではありません。</p>')
for folder in ['after-C-option','after-ES-option']:
 for f in sorted((OUT/folder).glob('*.png')):parts.append(f'<article><h3>{escape(f.stem)} · 未承認別案</h3><a href="{folder}/{f.name}"><img class="thumb" loading="lazy" src="{folder}/{f.name}"></a></article>')
parts.append('<h2 id="checks">検査結果</h2><p>2D幾何検査、Godot自動歩行、人間の手動操作は別です。下記は自動検査であり、建築・美術品質の完成判定ではありません。</p><table><tr><th>検査</th><th>通過／実行</th><th>原結果</th></tr>')
for row in checks:parts.append(f'<tr><td>{escape(row["name"])}</td><td>{row["passed"]}/{row["total"]}</td><td><a href="{row["file"]}">JSON</a></td></tr>')
parts.append('</table><p>人物の床支持不一致：'+str(len(crowd['unsupported_samples']))+'。代表店舗の什器配置214件は2Dで売場・共用床包含と保護通路を確認しています。床／壁／ガラスの構造材料は退役対象にしていません。</p><p><a href="data/protected-baseline.json">v17保護データの同一性</a> / <a href="data/same-view-validation.json">カメラ一致</a> / <a href="data/viewport-image-integrity.json">実画面解像度・SHA</a> / <a href="F6-rounded-width-and-belt.json">F6 7.53m候補と左右余裕</a></p>')
perf=OUT/'physics/v18-render-performance.json'
parts.append('<h3>性能観察</h3><p>Linux Vulkan llvmpipeソフトウェア描画。Windows GPUなし。人物は同一姿勢に固定した描画比較で、移動中の総合ベンチマークではありません。144FPS達成は確認していません。8フレームずつの実行順・キャッシュ・他の検査のCPU負荷を含む観察で、A館のON側が速い値も性能改善と解釈しません。</p>')
if perf.exists():
 d=load(perf);parts.append('<table><tr><th>視点</th><th>人物</th><th>観察FPS換算</th><th>中央値フレームms</th></tr>')
 for row in d['measurements']:parts.append(f'<tr><td>{escape(row["camera"])}</td><td>{"ON"if row["NPC_enabled"]else"OFF"}</td><td>{row["derived_observation_fps"]:.2f}</td><td>{row["median_frame_ms"]:.1f}</td></tr>')
 parts.append('</table><a href="physics/v18-render-performance.json">8フレーム／条件の生データと描画回数・プリミティブ数</a>')
else:parts.append('<p>性能の観察結果は未取得。画像のFPS表示を定常ベンチマークとしては使用しません。</p>')
parts.append('<h2 id="open">未完成・未承認事項</h2><ul>'+''.join('<li>'+escape(s)+'</li>'for s in issues)+'</ul><footer>Godot 4.6.3 / Viewport 1920×1080。画像生成によるイメージ図は使用していません。新規素材とMakeHuman・PBR・フォントの条件は <a href="licenses/v18-original-assets.txt">オリジナル素材</a>、<a href="licenses/v18-PROVENANCE.json">人物の出典</a>、同梱licensesを参照してください。</footer></main></html>')
(OUT/'index.html').write_text(''.join(parts));print('V18_REVIEW',len(images),'native PNGs',len(checks),'test groups',len(camera_checks),'same views')
