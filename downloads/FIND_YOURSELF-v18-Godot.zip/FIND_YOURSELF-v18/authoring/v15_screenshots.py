from pathlib import Path
import json,shutil,math,hashlib
from PIL import Image
P=Path(__file__).resolve().parents[1];D=Path('/workspace/1/docs/visual-review-v15');E=P/'evidence/v15';out=D/'screenshots';out.mkdir(exist_ok=True)
services=[s['id']for s in json.load(open(P/'source/v15/service-cameras.json'))]
normal=['01-A-plaza','03-B-time-plaza','A-reported-passage'];es=['ES-west-site','ES-west-upper'];c=['05-C-storefront','C-yard-open-sky','C-deck-opening','C-upper-gallery','C-ES-CN23']
selected={'after-normal':services+normal,'before-v14-normal':services+es+['C-ES-CN23']+normal[:2],'after-C-option':c,'before-v14-C-option':c[:-1],'after-ES-option':es};index=[];meta={}
for folder,ids in selected.items():
 m=json.load(open(E/folder/'captures.json'));shots={r['id']:r for r in m['shots']};dest=out/folder;dest.mkdir(exist_ok=True);ms=[]
 for sid in ids:
  r=shots[sid];src=E/folder/(sid+'.png');im=Image.open(src);assert im.size==(1920,1080),(folder,sid,im.size);assert r['actual_Godot_Viewport'];assert max(abs(a-b)for a,b in zip(r['eye'],r['actual_camera_global']))<.003
  shutil.copy2(src,dest/src.name);ms.append(r);meta[(folder,sid)]=r;index.append({'folder':folder,'id':sid,'file':'screenshots/'+folder+'/'+src.name,'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'width':1920,'height':1080})
 (dest/'captures.json').write_text(json.dumps({'runtime':m['runtime'],'shots':ms},ensure_ascii=False,indent=2))
pairs=[]
for a,b,ids in[('before-v14-normal','after-normal',services+normal[:2]),('before-v14-normal','after-ES-option',es),('before-v14-C-option','after-C-option',c[:-1]),('before-v14-normal','after-C-option',['C-ES-CN23'])]:
 for sid in ids:
  x=meta[(a,sid)];y=meta[(b,sid)];err=max(abs(p-q)for p,q in zip(x['actual_camera_global'],y['actual_camera_global']));direction=max(abs(p-q)for p,q in zip(x['actual_look_direction'],y['actual_look_direction']));assert err<.003 and direction<.0001 and x['fov']==y['fov'],(sid,err,direction);pairs.append({'id':sid,'before':a,'after':b,'camera_error_m':err,'direction_error':direction,'FOV':x['fov'],'pass':True})
(D/'screenshot-index.json').write_text(json.dumps({'images':index,'comparison_pairs':pairs,'renderer':'Godot 4.6.3 Forward+ / Linux llvmpipe software Vulkan','human_playtest':False,'Windows_GPU_FPS':None},ensure_ascii=False,indent=2));print('SCREENSHOTS',len(index),'native PNGs;',len(pairs),'matched camera pairs')
