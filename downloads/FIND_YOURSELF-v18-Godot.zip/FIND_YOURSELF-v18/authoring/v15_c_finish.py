"""Clip every active finish layer to the same C proposal slab. Never centroid-delete a boundary triangle."""
from pathlib import Path
import sys,numpy as np,copy,json
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'))
from site_v2_common import *
from pack_tools_v11 import *
from shapely import contains_xy,intersects_xy,constrained_delaunay_triangles,polygons as triangle_polygons,covers as covers_geom
from shapely.ops import transform
F=read(P/'source/v11/floors-updated.json');C=[f for f in F if f['wing']=='C'];proposal=read(P/'source/v15/C-outlet-proposal.json')
world=lambda g:transform(lambda x,z,zz=None:(np.asarray(x)+429,np.asarray(z)-46),g)
levels=[(r['height'],world(next(f for f in C if f['level']==r['level'])['floor_plate']),world(r['proposed_floor']))for r in proposal['floors']]
public_extent_by_y={rr["height"]:world(next(f for f in C if f["level"]==rr["level"])["shell"].convex_hull)for rr in proposal["floors"]}
protected_by_y={}
for f in C:
 if f['level']<1:continue
 protected_by_y[f['height']]=world(unary_union([ss['polygon'].buffer(.32,join_style=2)for ss in f['stores']]+[cc['outline'].buffer(.32,join_style=2)for cc in f['cores']]))
unsupported_furniture={}
furniture_audit=[]
for rr in proposal['floors']:
 f=next(f for f in C if f['level']==rr['level']);bad=[]
 for item in f.get('furniture',[]):
  if item['geom'].difference(rr['proposed_floor'].buffer(.005)).area>.001:
   bad.append(item['geom'].buffer(.025));furniture_audit.append({'id':item['id'],'floor':f['label'],'geometry':item['geom'],'action':'Remove unsupported authored furniture in C option only; no new floor to hide problem'})
 unsupported_furniture[rr['height']]=world(unary_union(bad))
write(P/'source/v15/C-unsupported-furniture.json',furniture_audit)
paths=[r['path']for r in read(P/'source/v13/pack-manifest.json') if r['path']not in ['assets/v10/base-site.pack.zst','assets/v12/C-outlet.pack.zst','assets/v12/C-supported-finish.pack.zst','assets/v12/es-transfer-study.pack.zst']]
base=load_pack(P/'assets/v15/C-outlet.pack.zst');S=base['surfaces'];cols={};changed={};erase=[];audit=[]
def clip(d,key=""):
 a=triangles(d);indices=np.asarray(d.get('i',np.arange(len(a)*3))).reshape(-1,3);remove=np.zeros(len(a),bool);partial={};vertical={}
 for y,old,new in levels:
  ct=a.mean(1);remove|=(a[:,:,1].min(1)>=y-.01)&(a[:,:,1].max(1)<=y+3.05)&intersects_xy(unsupported_furniture[y],ct[:,0],ct[:,2]);flat=np.ptp(a[:,:,1],axis=1)<.012
  # Floor finishes and actual slab soffits. Roofs inside retail footprints remain.
  eligible=(a[:,:,1].min(1)>=y-.98)&(a[:,:,1].max(1)<=y+.10)&intersects_xy(old.buffer(.35),ct[:,0],ct[:,2])
  mat=key.split('@@')[0].removeprefix('COLLIDER:')
  if mat in['glass','v10_guard_glass','v10_darkstone','v10_metal','metal']or'GUARD'in key:
   guard=(a[:,:,1].min(1)>=y-.01)&(a[:,:,1].max(1)<=y+1.26)&((np.ptp(a[:,:,1],axis=1)>.08)|(a[:,:,1].min(1)>=y+.06))&intersects_xy(public_extent_by_y[y],ct[:,0],ct[:,2])&~intersects_xy(protected_by_y[y],ct[:,0],ct[:,2]);remove|=guard
  if key.startswith("COLLIDER:"):
   orphan=(a[:,:,1].min(1)>=y+.015)&(a[:,:,1].max(1)<=y+3.05)&intersects_xy(old,ct[:,0],ct[:,2])&~intersects_xy(new.buffer(.12),ct[:,0],ct[:,2]);remove|=orphan
  ii=np.flatnonzero(eligible)
  if not len(ii):continue
  vv=a[ii][:,:,[0,2]];allin=covers_geom(new.buffer(.0001),triangle_polygons(vv))
  for j in ii[~allin]:
   g=Polygon(a[j][:,[0,2]])
   if g.area<1e-9:
    src=a[j][:,[0,2]];pairs=[(np.linalg.norm(src[i]-src[k]),i,k)for i in range(3)for k in range(i)]
    length,i,k=max(pairs)
    if length<1e-7:continue
    origin=src[k];axis=(src[i]-origin)/length;segment=LineString([origin,origin+axis*length])
    if new.buffer(.0001).covers(segment):continue
    pieces=lines(segment.intersection(new));intervals=[]
    for piece in pieces:
     ts=[float(np.dot(np.asarray(q)-origin,axis))for q in piece.coords];intervals.append((min(ts),max(ts)))
    remove[j]=True;vertical[j]=(origin,axis,intervals);continue
   if not g.is_valid:continue
   q=g.intersection(new);remove[j]=True
   if q.area>1e-8:partial[j]=q
 if not remove.any():return d,0
 # Expand only changed surfaces. Attributes are interpolated in original triangles.
 attrs={k:np.asarray(d[k]).reshape(-1,n)[indices]for k,n in [('v',3),('n',3),('uv',2),('c',4)]}
 result={k:[v[~remove].reshape(-1,v.shape[-1])]for k,v in attrs.items()}
 for j,g in partial.items():
  src=a[j][:,[0,2]];mat=np.vstack([src.T,np.ones(3)]);inverse=np.linalg.inv(mat)
  for gg in polys(g):
   for t in constrained_delaunay_triangles(gg).geoms:
    pts=np.asarray(t.exterior.coords)[:3];weights=(inverse@np.vstack([pts.T,np.ones(3)])).T
    v=weights@attrs['v'][j];normal=np.mean(attrs['n'][j],axis=0)
    if np.dot(np.cross(v[1]-v[0],v[2]-v[0]),normal)*np.dot(np.cross(a[j,1]-a[j,0],a[j,2]-a[j,0]),normal)<0:weights=weights[[0,2,1]]
    for k in result:result[k].append(weights@attrs[k][j])
 # Exact vertical triangle clipping: the XZ projection is a line, not a
 # polygon. Keep the same source winding and interpolate all attributes.
 for j,(origin,axis,intervals)in vertical.items():
  ts=(a[j][:,[0,2]]-origin)@axis
  for lo,hi in intervals:
   vertices=[(np.eye(3)[i],float(ts[i]))for i in range(3)]
   for bound,sign in[(lo,1),(hi,-1)]:
    clipped=[]
    for prev,cur in zip(vertices[-1:]+vertices[:-1],vertices):
     pin=sign*(prev[1]-bound)>=-1e-8;cin=sign*(cur[1]-bound)>=-1e-8
     if pin!=cin:
      t=(bound-prev[1])/(cur[1]-prev[1]);clipped.append((prev[0]+t*(cur[0]-prev[0]),bound))
     if cin:clipped.append(cur)
    vertices=clipped
    if not vertices:break
   for ii in range(1,len(vertices)-1):
    weights=np.array([vertices[0][0],vertices[ii][0],vertices[ii+1][0]])
    if np.linalg.norm(np.cross(*(np.diff(weights@a[j],axis=0))))<1e-10:continue
    for key in result:result[key].append(weights@attrs[key][j])
 return {k:np.concatenate(v).astype(np.float32).ravel()for k,v in result.items()},int(remove.sum())
# The old base collider arrays must be clipped too. They previously bypassed
# the surface pass and left invisible guard posts at new connection mouths.
# Separate newly generated C-option triangles from original base triangles so
# the final slab/guard geometry is never mistaken for an old guard to remove.
original_base=load_pack(P/'assets/v10/base-site.pack.zst')
for key,values in base['colliders'].items():
 raw=np.asarray(values,dtype='<f4').reshape(-1,9);reference=original_base['colliders'].get(key,np.array([],dtype='<f4')).reshape(-1,9)
 legacy=np.isin(raw.view('V36').ravel(),np.asarray(reference,dtype='<f4').view('V36').ravel())
 a=raw[legacy].reshape(-1,3,3)
 if len(a):
  d={'v':a.ravel(),'n':np.tile([0.,1.,0.],(len(a)*3,1)).ravel(),'uv':np.zeros(len(a)*6),'c':np.ones(len(a)*12)};nd,count=clip(d,'COLLIDER:'+key);cols[key]=[nd['v'],raw[~legacy].ravel()]
 else:cols[key]=[raw.ravel()]
for path in paths:
 print('C_FINISH_SCAN',path,flush=True);g=load_pack(P/path)
 for key,d in g['surfaces'].items():
  nd,count=clip(d,key)
  if count:
   changed[key]=nd;audit.append({'pack':path,'surface':key,'clipped_triangles':count})
   if not len(nd['v']):erase.append(key)
 for k,v in g['colliders'].items():
  a=v.reshape(-1,3,3);d={'v':a.ravel(),'n':np.tile([0.,1.,0.],(len(a)*3,1)).ravel(),'uv':np.zeros(len(a)*6),'c':np.ones(len(a)*12)};nd,count=clip(d,"COLLIDER:"+k)
  cols.setdefault(k,[]).append(nd['v'])
# Replacement colliders contain all normal layers, but base-site is the new C option.
# Existing V11 boundary guards are opaque/glass vertical faces; remove unsupported decorative guard segments only.
for key,d in list(changed.items()):
 if not len(d['v']):changed.pop(key)
original=load_pack(P/'assets/v10/base-site.pack.zst')
for key,d in list(base['surfaces'].items()):
 if 'V15-C-'not in key:
  d,count=clip(d,key)
  if count:base['surfaces'][key]=d
 old=original['surfaces'].get(key)
 if old is None or set(old)!=set(d) or any(not np.array_equal(np.asarray(d[k]),np.asarray(old[k]))for k in d):
  if len(triangles(d)):changed[key]=d
  elif key not in erase:erase.append(key)
for key in original['surfaces']:
 if key not in base['surfaces']:erase.append(key)
pack={'surfaces':changed,'colliders':{k:np.concatenate(v)for k,v in cols.items()},'signs':[],'lights':[]}
print(save_zst(P/'assets/v15/C-finish-replacement.pack.zst',pack));write(P/'source/v15/C-finish-audit.json',{'changed':audit,'erase_surfaces':erase,'method':'Exact horizontal polygon and vertical segment intersections with attribute interpolation; all active layers inspected','vertical_guard_review_pending':True})
# Drawn and usable map regions match the option floor, not the old v12 branch.
m=json.loads((P/'source/v13/map-data.json').read_text());print('MAP_TYPE',type(m).__name__,'keys',list(m)[:8] if isinstance(m,dict)else'',flush=True)
write(P/'source/v15/C-plan-floors.json',[{'wing':'C','label':r['floor'],'level':r['level'],'height':r['height'],'floor':r['proposed_floor'],'public':r['proposed_public']}for r in proposal['floors']])
