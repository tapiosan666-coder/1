from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parents[1];T=P/'assets/v16/textures';T.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(160)
y,x=np.mgrid[:512,:512];grain=np.sin(x*.22+np.sin(y*.018)*1.9)+.5*np.sin(x*.79+np.sin(y*.027)*2)+rng.normal(0,.18,x.shape)
for name,base in [('oak',(153,120,77)),('walnut',(85,58,37))]:
 a=np.stack([np.clip(c+grain*7,0,255)for c in base],2).astype('uint8');Image.fromarray(a).save(T/(name+'.png'),optimize=True)
a=Image.new('RGB',(512,512),'#142d58');d=ImageDraw.Draw(a)
for yy in range(-20,530,42):
 for xx in range(-20,530,42):
  d.ellipse((xx-13,yy-13,xx+13,yy+13),outline='#a9c5d9',width=3);d.ellipse((xx-5,yy-5,xx+5,yy+5),fill='#d3e2e7')
a.save(T/'shibori-original.png',optimize=True)
print('V16_ORIGINAL_TEXTURES',3)
