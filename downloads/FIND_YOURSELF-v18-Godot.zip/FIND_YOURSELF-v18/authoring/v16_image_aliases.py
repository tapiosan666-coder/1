from pathlib import Path
import struct,json,hashlib,os
P=Path(__file__).resolve().parents[1];T=P/'assets/shared/textures';T.mkdir(parents=True,exist_ok=True);rows=[]
for f in(P/'assets').rglob('*.glb'):
 b=f.read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);tail=b[20+n:];changed=[]
 for im in j.get('images',[]):
  uri=im.get('uri','')
  if not uri or uri.startswith('data:'):continue
  old=(f.parent/uri).resolve();data=old.read_bytes();h=hashlib.sha256(data).hexdigest();dest=T/(h+old.suffix.lower());dest.write_bytes(data);im['uri']=os.path.relpath(dest,f.parent)
  assert (f.parent/im['uri']).resolve().read_bytes()==data
  if old!=dest:changed.append({'old':str(old.relative_to(P)),'new':str(dest.relative_to(P)),'sha256':h})
 if changed:
  text=json.dumps(j,separators=(',',':'),ensure_ascii=False).encode();text+=b' '*((-len(text))%4);out=b'glTF'+struct.pack('<II',2,20+len(text)+len(tail))+struct.pack('<I',len(text))+b'JSON'+text+tail;assert out[20+len(text):]==tail;f.write_bytes(out);rows.append({'path':str(f.relative_to(P)),'geometry_buffer_bytes_unchanged':True,'images':changed})
(P/'source/v16/lossless-image-aliases.json').write_text(json.dumps(rows,indent=2));print('V16_IDENTICAL_IMAGE_ALIASES',len(rows))
