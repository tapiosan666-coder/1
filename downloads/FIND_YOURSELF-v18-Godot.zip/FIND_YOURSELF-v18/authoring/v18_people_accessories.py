from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parents[1];exec((P/'authoring/v17_models.py').read_text().split('# Original campaign products;')[0]);OUT=P/'assets/v18/models'
hairmat=material('Original_flowing_hair',(.055,.032,.020),.62)
def hp(x,y,z):return(x,-z,y-1.5)
for style in ['bob','ponytail']:
 verts=[];uv=[];N=64;K=18
 for j in range(K+1):
  t=j/K
  for i in range(N):
   a=i*math.tau/N;front=max(0,-math.cos(a));theta=t*(1.38 if front>.2 else 2.35);x=.123*math.sin(theta)*math.sin(a);z=.009+.146*math.sin(theta)*math.cos(a);y=1.752+.154*math.cos(theta)
   if style=='bob'and front<.4:y-=.075*t**3
   verts.append(hp(x,y,z));uv.append((i/N,t))
 faces=[]
 for j in range(K):
  for i in range(N):a=j*N+i;b=j*N+(i+1)%N;faces.append((a,b,b+N,a+N))
 mesh('Shaped_hair_shell',verts,faces,hairmat,uv)
 for i in range(12):
  a=i*math.tau/12;front=max(0,-math.cos(a));top=1.90;end=1.73 if front>.4 else 1.58 if style=='bob'else 1.69
  points=[hp(.04*math.sin(a),top,.02+.03*math.cos(a)),hp(.115*math.sin(a),1.82,.12*math.cos(a)),hp(.125*math.sin(a),end,.135*math.cos(a))];tube('Directional_hair_flow',points,.008,hairmat)
 if style=='ponytail':
  for k in range(7):tube('Curved_tied_hair',[hp(k*.006-.018,1.80,.14),hp(k*.010-.03,1.75,.24),hp(k*.008-.024,1.55,.25),hp(k*.004-.012,1.43,.20)],.014,hairmat)
  lathe('Hair_tie',[(0,0),(.04,0),(.04,.018),(0,.018)],sage,(0,-.175,.29),24)
 done('hair_'+style)
# Crossbody bag attaches to the torso/pelvis; curved strap has supported metal adjusters.
box('Canvas_bag_body',(.23,.11,.02),(.25,.13,.29),walnut,.035);box('Foldover_flap',(.23,.039,.10),(.25,.018,.16),wood,.018)
tube('Crossbody_strap',[(-.13,.09,.46),(-.08,.10,.40),(.07,.12,.25),(.23,.12,.14)],.015,metal)
box('Strap_adjuster',(.04,.11,.28),(.04,.025,.055),brass,.006);done('crossbody_bag')
