"""Current quality review + complete v13 combined report, in one PDF. Native images, no synthetic render substitutes."""
from pathlib import Path
import fitz,json,io
from PIL import Image
P=Path(__file__).resolve().parents[1];D=Path('/workspace/1/docs/visual-review-v14');O=Path('/workspace/1/downloads');doc=fitz.open();W,H=1400,1000
r=lambda p:json.loads(p.read_text())
def text(p,box,s,size=18):
 result=p.insert_textbox(fitz.Rect(box),s,fontname='japan',fontsize=size,color=(.11,.18,.20))
 if result<0:raise RuntimeError('PDF text overflow: '+s[:60])
def page(title,sub):
 p=doc.new_page(width=W,height=H);p.insert_font(fontname='japan');p.draw_rect(p.rect,fill=(.97,.98,.97),color=None);text(p,(40,28,1360,83),title,28);text(p,(40,94,1360,140),sub,15);text(p,(40,970,1360,998),'FIND YOURSELF v14 / v13を含む統合報告 / 独立検証・ゲーム本体へ未統合 / '+str(len(doc)),12);return p
def image(p,path,rect):
 # PDF uses high-quality JPEG compression only. Original 1920x1080 PNGs retained in review folder.
 im=Image.open(path).convert('RGB');b=io.BytesIO();im.save(b,format='JPEG',quality=93,subsampling=0);p.insert_image(fitz.Rect(rect),stream=b.getvalue(),keep_proportion=True)
p=page('FIND YOURSELF v14｜素材・売場・屋上の品質更新','今回の結果を先頭にまとめ、後半に前回v13の統合報告を全文収録しています。これ1本で確認できます。')
text(p,(55,165,1340,400),'今回の変更\n全館の共通仕上げを見直し、床の素材と目地、壁・天井の落ち着いた質感、木材・陶器などの表面表現を調整。食品棚・青果台・冷蔵棚・健康用品棚・書店ゴンドラ・植栽付きベンチを専用モデルへ置換しています。パッケージ、部門表示、棚札は架空の独自デザインです。',23)
text(p,(55,435,1340,645),'維持したもの\n15層・480店舗ID・建物と床開口・衝突データ・店舗入口・階段・EV・ESの移動処理を維持。前回のトイレ60か所、地下51店舗、屋上22区画も含む単独ZIPです。\nRF-SUPPORT-16、C館構造別案、敷地の連続ES配置は未承認のままです。',22)
text(p,(55,690,1340,935),'今回で全館完成とはしません\n共通仕上げは全館へ反映、実画面の品質比較は代表12視点です。全店舗の専用内装や最終照明を作り終えたものではなく、FF16級の品質を達成したという報告でもありません。人間の実操作とWindows GPUのFPSは未検証です。',21)
p=page('品質更新の範囲と、配置を守る方法','グラフィック変更で通路や店舗境界を動かさないことを優先しました。')
audit=r(P/'source/v14/preservation-and-scope.json')
text(p,(55,160,1340,450),'7種類・718配置の売場／ベンチを更新\n新モデルはGodotから読み取ったv13の実測AABBへ収め、表示する部品の変換後の占有範囲も再計算しました。床・壁・扉・什器の既存衝突は保持し、既存設計の植栽区画内に植栽槽の可視モデルと衝突を追加しています。書店は棚端の編集案内、食品売場は品種・包装・木箱・棚札・冷蔵棚の設備表現を追加しています。\nインポート素材の複製・一括加工で異常発光が発生したため、その処理を撤回。元の素材参照を保持しています。複製と個別パラメータのどれが引き金かは未分離です。建築メッシュの接線検査は313万頂点で非有限値・長さ不足0件です。',22)
text(p,(55,485,1340,760),'B館屋上：17基の植栽槽と168点の植物\n既存の18植栽区画を対象に、庭園経路と干渉しない候補を抽出。178候補のうち、植栽槽の全範囲で支持床を確認した17区画に168点を配置。部分的に支持床のない1区画は槽ごと見送り、植物10候補を除外しました。新しい支持床を追加していません。\n見送りは BRF-GARDEN-2-BED-4。槽の中心は x=18.40m、z=12.40m、寸法4.0×1.4mで、3.57㎡の支持床を確認できません。元の設計との照合を残課題とし、舗装から直接生える見た目も解消しています。',21)
text(p,(55,790,1340,952),'素材と照明\n局所反射プローブは描画乱れの切り分けにより既定OFF。店舗照明・SSR・SSILを維持し、GIは現行素材用に再ベイク。キャッシュの一致検査を追加しています。\n新モデル内の重複画像を外部共有化。画像バイトとメッシュのバッファを照合する無劣化整理です。未参照テクスチャのみ配布から除外し、モデルを単純化して容量を減らしていません。',16)
shots=r(P/'source/v14/cameras.json')
for offset in range(0,len(shots),2):
 p=page('Godot実画面｜v13 → v14','左：保護したv13　右：v14。同じ位置・方向・画角。Godot 4.6.3 Forward+、1920×1080、扉は共通の開状態。')
 for j,s in enumerate(shots[offset:offset+2]):
  y=148+j*399;text(p,(45,y,1355,y+35),s['id'],19)
  image(p,D/'screenshots/before'/(s['id']+'.png'),(45,y+40,685,y+400));image(p,D/'screenshots/after'/(s['id']+'.png'),(715,y+40,1355,y+400))
p=page('追加のGodot実画面｜商品近景・屋上植栽','追加視点です。比較前の同一視点画像は撮影していないため、前後比較としては扱いません。')
for j,s in enumerate(r(P/'source/v14/detail-cameras.json')):
 yy=150+j*395;text(p,(45,yy,1355,yy+40),s['title'],20);image(p,D/'screenshots/details'/(s['id']+'.png'),(45,yy+45,1030,yy+388));text(p,(1050,yy+65,1355,yy+345),'Godot 4.6.3\n1920×1080\nプレイヤー高さ1.65m\n\nカメラ足元の衝突床を別途確認。人間の実歩行検証ではありません。',17)
p=page('再検査結果｜自動操作と見た目の確認を区別','形状確定後の再検査に加え、植栽槽施工後の屋上を再検査。表示素材の変更と物理歩行を分け、最終配布候補の起動も確認。')
summary=r(D/'test-summary.json');y=160
for row in summary['rows']:
 text(p,(55,y,1340,y+58),row['label']+'：'+row['result'],21);y+=66
text(p,(55,715,1340,945),'経路追従、実際のW/Fキー入力、図面上の占有域、Godot実画面の目視確認はそれぞれ別の検査です。人間によるゲーム操作は行っていません。\n描画はLinux llvmpipeソフトウェア実行。Windows GPU FPSは測定できておらず、144FPS達成は主張しません。初期設定の1080p・上限144・VSync ONを保持しています。\n見た目は代表地点の画像で評価しています。通行検査合格をもって建築品質まで完成扱いにはしません。',18)
p=page('残課題・使用素材・起動方法','次ページからは前回v13の報告原本です。過去の結果・起動直後の表示は当時の履歴として読んでください。')
text(p,(55,160,1340,505),'残課題\n・設備／搬入／管理区画の詳細、C館の残余帯、見送った屋上植栽槽の床との整合性。\n・全店舗の業種別専用モデルと売場の仕上げ。今回の共通モデル更新だけで全館の内装完成とはしていません。\n・全館の最終ライティング、鏡の専用反射、細かなサインと駐車場の仕上げ。\n・未承認構造の支持力、避難性能、車両軌跡等の専門検証。\n・Windows実機の性能測定と、人間による全館実操作。\n・Linux描画終了時のTexture RID解放警告。反射／間接光の実行中切替での描画乱れは診断で再現し、任意切替の安定性は未保証。',21)
text(p,(55,550,1340,760),'素材\n今回の什器・商品・植物は独自Blenderモデル。パッケージ等は架空の独自図案。新しい共通仕上げは手続き生成のPBRテクスチャであり、写真スキャン素材ではありません。既存CC0の木材画像も使用。実在ブランド・FF資産は使用していません。既存素材のCC0／CC-BY／OFL／MIT等の出典・条件はlicenses/に保持しています。',20)
text(p,(55,800,1340,950),'起動\n統合ZIPを1つの新しいフォルダへすべて展開し、Godot 4.6.3で project.godot を開いてインポート後F5。最初はB館地下食品売場です。F9：今回と前回の確認地点、F8：代表店舗、M：館内図、F10：設定。Windows EXEは不要との指定により同梱していません。',18)
# Append actual previous combined report unmodified; historical evidence remains identifiable.
old=fitz.open(O/'FIND_YOURSELF-v13-Combined-Review.pdf');count=len(doc);doc.insert_pdf(old);doc.set_toc([[1,'v14 今回の品質更新',1],[1,'v14 Godot同一視点比較',3],[1,'v14 再検査',10],[1,'v14 残課題と起動',11],[1,'v13 前回の統合報告（履歴）',count+1]])
path=O/'FIND_YOURSELF-v14-Combined-Review.pdf';doc.save(path,garbage=4,deflate=True);print('V14_COMBINED_REPORT',len(doc),'pages',path.stat().st_size,'bytes')
