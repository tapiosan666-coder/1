"""Resolve ownership against registered building programme AND parking/landscape, not just public + tenant area."""
from pathlib import Path
import sys
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
F=read(P/'source/v11/floors-updated.json');rows=[];summary=[]
def geometries(v):
 if hasattr(v,'geom_type'):return[v]
 if isinstance(v,dict):return[g for k,x in v.items()for g in geometries(x)if k not in['entry','point','c']]
 if isinstance(v,list):return[g for x in v for g in geometries(x)]
 return[]
for f in F:
 ownership=[]
 for role,items in [('tenant',[s['polygon']for s in f['stores']]),('core',[c['outline']for c in f['cores']]),('public',[f['public']]),('registered programme',f.get('program',[])),('registered service zones',f.get('service_zones',[])),('machine islands',f.get('machine_islands',[])),('construction poche',[f.get('construction_poche',Polygon())]),('registered floor roles',f.get('floor_roles',[])),('parking',f.get('parking',{})),('garden',f.get('gardens',[])),('landscape',f.get('landscape',[])),('ground exterior',[f.get('outdoor_ground',Polygon())]),('building wall',[f.get('envelope_walls',Polygon()),f.get('facade_wall_solids',Polygon())])]:
  gg=geometries(items)
  if gg:ownership.append((role,unary_union(gg)))
 used=unary_union([g for _,g in ownership]);unknown=f['floor_plate'].difference(used);total=0
 for i,g in enumerate(polys(unknown)):
  if g.area<.05:continue
  total+=g.area;p=g.representative_point();width=2*g.area/max(g.length,.001);rows.append({'id':f'{f["wing"]}-{f["label"]}-RESIDUAL-{i}','wing':f['wing'],'floor':f['label'],'world':[p.x+429,f['height'],p.y-46],'area_m2':g.area,'width_index_m':width,'geometry':g,'adjacent_roles':[role for role,q in ownership if q.distance(g)<.03],'classification':'Wall/interface remainder; verify against actual mesh'if width<.45 else'Unresolved ownership; no invented room assigned','human_playtest':False,'status':'REVIEW'})
 summary.append({'wing':f['wing'],'floor':f['label'],'unattributed_area_m2':total,'roles':[r for r,_ in ownership],'registered_program_3D_fit_not_certified':True})
write(P/'source/v15/unassigned-space-audit.json',rows);write(P/'source/v15/ownership-summary.json',summary);print('OWNERSHIP',len(rows),'components',sum(q['unattributed_area_m2']for q in summary),'m2');print(summary)
