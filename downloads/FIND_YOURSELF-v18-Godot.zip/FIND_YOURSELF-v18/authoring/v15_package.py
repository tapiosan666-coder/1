"""One complete runtime project; no split archives or external Data downloads."""
from pathlib import Path
import json,hashlib,zipfile,struct,posixpath,sys
P=Path(__file__).resolve().parents[1];D=Path('/workspace/1/downloads');D.mkdir(exist_ok=True)
base=(P/'authoring/v14_package.py').read_text();base=base[:base.index("\nmanifest={'version'")];ns={'__file__':str(P/'authoring/v14_package.py')};exec(base,ns);out=ns['out'];unused={'assets/v12/C-outlet.pack.zst','assets/v12/C-supported-finish.pack.zst','assets/v15/C-outlet.pack.zst','assets/v15/repairs-C.pack.zst','source/v12/boundary-audit-before.json','source/v15/boundary-audit.json'}
out=[(f,r)for f,r in out if r not in unused and not(r.startswith('assets/v14/gi-')and r.endswith('.res'))]
# Remove importer-extracted copies. GLBs refer directly to original image files, not these generated duplicates.
out=[(f,r)for f,r in out if not(r.startswith('assets/v15/models/')and f.suffix!='.glb')]
refs=set()
for f,r in out:
 if f.suffix!='.glb':continue
 b=f.read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n])
 for ref in j.get('images',[])+j.get('buffers',[]):
  uri=ref.get('uri','')
  if uri and not uri.startswith('data:'):refs.add(posixpath.normpath(posixpath.join(posixpath.dirname(r),uri)))
paths={r for f,r in out};missing=refs-paths;assert not missing,missing
manifest={'version':'v15 independent architectural validation','single_archive':True,'main_game_integrated':False,'human_playtest':False,'C_option':'UNAPPROVED','ES_site_option':'UNAPPROVED','RF_SUPPORT_16':'UNAPPROVED','files':[{'path':r,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f,r in out]}
f=P/'release-manifest-v15.json';f.write_text(json.dumps(manifest,ensure_ascii=False,indent=2));out.append((f,f.name));path=D/('FIND_YOURSELF-v15-TRIAL.zip'if'--trial'in sys.argv else'FIND_YOURSELF-v15-Godot.zip')
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f,r in out:z.write(f,'FIND_YOURSELF-v15/'+r)
print('V15_SINGLE_ZIP',path.stat().st_size,'bytes',len(out),'files',len(refs),'external image references checked',flush=True)
with zipfile.ZipFile(path)as z:assert z.testzip()is None
print('SIZE_LIMIT_OK',path.stat().st_size<104857600,flush=True)
