from pathlib import Path
import sys
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch
OUT=Path('/workspace/v18-review/plans');OUT.mkdir(exist_ok=True)
d=read(P/'source/v18/retail-plan.json');fig,axes=plt.subplots(2,4,figsize=(18,11))
for ax,s in zip(axes.flat,d['stores']):
 for geom,col,alpha in[(s['sales_world'],'#eee2cb',1),(s['backroom_world'],'#a7acae',1),(s['protected_aisles_world'],'#9dcfd7',.7)]:
  for part in polys(geom):ax.add_patch(Patch(list(part.exterior.coords),facecolor=col,edgecolor='#657477',alpha=alpha,linewidth=.5))
 for r in d['instances']:
  if r['store_id']!=s['id']:continue
  for part in polys(r['footprint']):ax.add_patch(Patch(list(part.exterior.coords),facecolor='#54786b'if r['role']!='checkout'else'#bd8847',edgecolor='#294b40',linewidth=.5))
 e=s['entry_world'];ax.plot(e[0],e[1],'o',color='#b84b3a',ms=5)
 b=s['sales_world'].union(s['backroom_world']).bounds;ax.set_xlim(b[0]-1.5,b[2]+1.5);ax.set_ylim(b[1]-1.5,b[3]+1.5);ax.set_aspect('equal');ax.invert_yaxis();ax.grid(alpha=.15);ax.tick_params(labelsize=7);ax.set_title(s['id']+' / '+s['category']+'\n'+str(round(s['sales_m2']))+' m² sales',fontsize=10)
fig.suptitle('v18 representative shop refits — 2D design data, NOT a Godot Viewport\nGreen: fixtures / gold: checkout / blue: protected aisles / grey: backroom / red: entry',fontsize=13);fig.tight_layout(rect=(0,0,1,.94));fig.savefig(OUT/'representative-layouts.svg');plt.close(fig)
print('V18_PLANS_SVG')
