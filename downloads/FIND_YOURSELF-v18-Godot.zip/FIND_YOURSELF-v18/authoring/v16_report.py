from pathlib import Path
import json,html,hashlib,io,zipfile,shutil,collections
from PIL import Image
import fitz
P=Path(__file__).resolve().parents[1];R=Path('/workspace/v16-review');FONT='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
def read(p):return json.loads(Path(p).read_text())
def collect_images():
 pairs=[]
 for before,after,label in [('before','after','通常版'),('before-C-option','after-C-option','C館F4・未承認別案'),('before-ES-option','after-ES-option','B館F6・未承認別案')]:
  a=read(R/after/'captures.json');b=read(R/before/'captures.json');by={r['id']:r for r in b['shots']}
  assert a['runtime']['main_script_sha256']==hashlib.sha256((P/'main.gd').read_bytes()).hexdigest(),after
  assert b['runtime']['main_script_sha256']==hashlib.sha256((Path('/workspace/FIND_YOURSELF-Site-v15')/'main.gd').read_bytes()).hexdigest(),before
  assert a['runtime']['renderer']=='forward_plus'
  assert a['runtime']['proposal_C']==(label=='C館F4・未承認別案')
  assert a['runtime']['proposal_ES']==(label=='B館F6・未承認別案')
  selected_normal={'V16-A-visitor','V16-B-aichi','V16-B-fair-close','V16-C-kids','V16-C-dog','V16-C-melon','V16-C-courtyard','AB1-003-interior','BB1-MARKET-interior','CB1-CW-1-interior','B-RF-garden','ARF-002-terrace','C-RF-arrival'}
  for s in a['shots']:
   if label=='通常版'and s['id']not in selected_normal:continue
   if label=='C館F4・未承認別案'and s['id']not in['V16-C-kids','V16-C-courtyard']:continue
   t=by[s['id']];assert s['resolution']==t['resolution']==[1920,1080];assert s['eye']==t['eye']and s['look']==t['look']and s['fov']==t['fov']
   assert max(abs(x-y)for x,y in zip(s['actual_camera_global'],t['actual_camera_global']))<.002
   assert max(abs(x-y)for x,y in zip(s['actual_look_direction'],t['actual_look_direction']))<.0001
   assert s['actual_Godot_Viewport']and t['actual_Godot_Viewport']
   row={'id':s['id'],'title':s.get('title',s['id']),'variant':label,'before':before+'/'+s['id']+'.png','after':after+'/'+s['id']+'.png','eye':s['eye'],'look':s['look'],'fov':s['fov'],'actual_camera_match':True,'resolution':[1920,1080],'actual_Godot_Viewport':True,'software_renderer':a['runtime']['adapter'],'reference_fps_1s_window':s.get('reference_fps_1s_window'),'not_Windows_GPU_FPS':True,'not_steady_state_benchmark':True}
   for k in ['before','after']:
    f=R/row[k];assert Image.open(f).size==(1920,1080);row[k+'_sha256']=hashlib.sha256(f.read_bytes()).hexdigest()
   pairs.append(row)
 assert len(pairs)==17,len(pairs);(R/'screenshot-index.json').write_text(json.dumps(pairs,ensure_ascii=False,indent=2));return pairs

def gallery(pairs):
 body=['<!doctype html><html lang="ja"><meta charset="utf-8"><title>FIND YOURSELF v16 実画面比較</title><style>body{font-family:system-ui,sans-serif;background:#101917;color:#eee;margin:24px;max-width:1600px}h1{color:#e5cd91}p{line-height:1.8}.pair{display:grid;grid-template-columns:1fr 1fr;gap:12px}img{width:100%;height:auto;border:1px solid #617369}section{margin:42px 0}a{color:#ddc789}small{color:#b5c9ba}pre{white-space:pre-wrap}button{padding:8px 18px}@media(max-width:800px){.pair{grid-template-columns:1fr}}</style><h1>FIND YOURSELF v16</h1><p>実際のGodot 4.6.3 / Forward+ / 1920×1080。同じカメラ位置・向き・FOVで撮影。画像をクリックすると原寸PNGを開きます。<br>全館の仕上げ完了・FF16級の品質とはしていません。人間の実操作とWindows GPUのFPSは未検証です。</p><p><a href="FIND_YOURSELF-v16-Review.pdf">簡潔なPDF</a> / <a href="plans/FIND_YOURSELF-v16-配置図.pdf">用途別の配置図</a> / <a href="未完成・未承認.md">残課題</a> / <a href="検査結果.json">検査結果</a></p>']
 for r in pairs:
  body.append('<section><h2>'+html.escape(r['title'])+'</h2><small>'+html.escape(r['variant'])+' — 実画面 / 同一視点</small><div class="pair">')
  for key,title in [('before','v15'),('after','v16')]:body.append('<div><p>'+title+'</p><a href="'+r[key]+'"><img loading="lazy" src="'+r[key]+'" alt="'+title+' '+html.escape(r['id'])+'"></a></div>')
  body.append('</div></section>')
 body.append('<h2>実UI</h2>')
 for p in sorted((R/'ui').glob('*.png')):body.append('<p>'+html.escape(p.stem)+'</p><a href="ui/'+p.name+'"><img loading="lazy" src="ui/'+p.name+'"></a>')
 body.append('<h2>C館RF 水上庭園：生成コンセプト・未承認・未実装</h2><p>以下はGodot画面ではありません。設置場所、荷重、支持、排水、避難は未検証。通常版・F4にはありません。</p><a href="proposals/C-RF-生成コンセプト-未実装.png"><img loading="lazy" src="proposals/C-RF-生成コンセプト-未実装.png"></a></html>');(R/'index.html').write_text('\n'.join(body))

def jpeg(path):
 im=Image.open(path).convert('RGB');b=io.BytesIO();im.save(b,'JPEG',quality=90,optimize=True);return b.getvalue()
def pdf(pairs):
 doc=fitz.open();pages=[]
 def page(title,subtitle='Godot 4.6.3 / 1920×1080 / 独立検証版 / 2026-10-29 JST'):
  p=doc.new_page(width=842,height=1190);p.insert_font(fontname='jp',fontfile=FONT);p.draw_rect(fitz.Rect(0,0,842,84),color=None,fill=(.06,.13,.11));p.insert_text((28,40),title,fontname='jp',fontsize=22,color=(.96,.91,.77));p.insert_text((28,67),subtitle,fontname='jp',fontsize=10,color=(.8,.86,.82));pages.append(p);return p
 def text(p,t,y=106,size=12,box=None):
  rect=fitz.Rect(28,y,814,1150)if box is None else fitz.Rect(box);left=p.insert_textbox(rect,t,fontname='jp',fontsize=size,lineheight=1.55,color=(.09,.15,.13));assert left>=0,(left,t[:80]);return left
 def image(p,path,rect,caption):
  p.insert_image(fitz.Rect(rect),stream=jpeg(path),keep_proportion=True);text(p,caption,box=(rect[0],rect[3]+3,rect[2],rect[3]+38),size=10)
 def pair(p,id,y,variant='通常版'):
  r=next(q for q in pairs if q['id']==id and q['variant']==variant);image(p,R/r['before'],(28,y,411,y+215),'v15 / '+r['title']);image(p,R/r['after'],(431,y,814,y+215),'v16 / '+r['title'])
 p=page('v16：共用空間に、使い道と変化をつくる')
 text(p,'v15の15層・480店舗ID・館間接続・滑らかな昇降処理を維持し、共用施設・催事・休憩と案内を重点的に追加しました。建築パック19個と主要移動処理の原本を保護。ゲーム本体へ統合していません。\n\n全館の仕上げ完成ではありません。FF16級の品質にも未到達です。店舗奥の密度、長い壁、通常版C館のデッキ、植栽や仕上げの自然さには残課題があります。',size=13)
 for j,id in enumerate(['V16-A-visitor','V16-B-aichi','V16-C-melon']):
  r=next(q for q in pairs if q['id']==id and q['variant']=='通常版');image(p,R/r['after'],(28+j*266,315,280+j*266,457),r['title'])
 text(p,'A館：案内・待合と専門店街の展示、既存映画館・ゲームセンターの入口。\nB館：愛知の食6店・工芸3店、ステージ。F11で催事の表示・衝突を切替。\nC館：キッズ、二重ゲート式ドッグラン、キッチンカーと屋外席。\n地下・屋上：既存51店舗・22区画を維持し、3館の代表区画を充実。\n\n専用32モデル・198配置。看板は通常45面＋F6別案2面。数だけでは品質の合格としていません。今回更新していない箇所は、同梱の15層台帳に明記しています。\n\n起動：Godot ZIPを新しいフォルダに全展開 → project.godotをGodot 4.6.3で開く → インポート後F5。F9で更新地点、Mでマップ、F10で設定。Windows EXE・分割ZIP・追加Data ZIPはありません。',y=525,size=13)
 p=page('A館・B館：同じ視点の修正前後')
 pair(p,'V16-A-visitor',108);pair(p,'V16-B-aichi',392);pair(p,'V16-B-fair-close',676)
 text(p,'広場の主動線と開放感を維持。情報・滞留・食・工芸に役割を分けています。ステージ画面の取り付け位置は実画面で確認して修正。催事をOFFにすると衝突も解除し、再開位置に人が重なると再開を拒否します。',y=970,size=12)
 p=page('C館：用途のある中庭と、既存植栽の整理')
 for id,y in [('V16-C-kids',108),('V16-C-dog',392),('V16-C-melon',676)]:pair(p,id,y)
 text(p,'遊び場550㎡・ドッグラン460.8㎡・キッチンカー前庭702㎡は、実在施設の実測値ではなくゲーム用設計値です。新舗装に重なる旧GLB植栽558配置と旧草・低木メッシュ4,197三角形を除去。建物・床・手すりは選択せず、衝突形状の変更は0件。雨庭を保護しています。\n遊具・営業・車両搬入の安全性は未実証。通常版の上階デッキは保持し、F4は未承認別案です。',y=970,size=11)
 p=page('地下・屋上：既存の用途を活かす')
 shots=['AB1-003-interior','BB1-MARKET-interior','CB1-CW-1-interior','ARF-002-terrace','B-RF-garden','C-RF-arrival']
 # Pick actual available IDs; no synthetic evidence or missing-image placeholders.
 for j,id in enumerate(shots):
  r=next(q for q in pairs if q['id']==id and q['variant']=='通常版');x=28+(j%2)*403;y=108+(j//2)*284;image(p,R/r['after'],(x,y,x+383,y+215),r['title'])
 text(p,'A/B地下は既存食品売場へ青果・惣菜・案内を追加。C地下は修理・受け取りの用途を維持。屋上は既存床の支持を確認できる場所へ休憩・飲食・案内を追加しました。すべての地下・屋上空間を完成したという報告ではありません。C屋上の追加パーゴラ等は配置不成立で省略し、未確認支持箇所へ植栽を追加していません。',y=970,size=12)
 p=page('移動・表示の検証と、残る制約')
 summary=read(R/'検査結果.json');lines=[]
 for t in summary['tests']:lines.append(t['name']+'：'+str(t['passed'])+' / '+str(t['passed']+t['failed'])+'　'+t['method'])
 text(p,'\n'.join(lines),y=106,size=10.5,box=(28,106,814,595))
 image(p,R/'plans/B-F6-transfer.png',(28,624,814,1005),'F6：未承認。上り・下りとも同じ広場内、各8.4m。配置は維持し、案内と下り検査を追加。')
 text(p,'図面検査・自動歩行・キー入力注入・実Viewport確認を区別。人間による実操作は未検証です。描画はLinuxのllvmpipe（ソフトウェアVulkan）で確認。撮影時の参考FPSは定常性能やWindows GPUの値ではなく、144FPS達成は主張しません。',y=1058,size=11)
 p=page('未承認案・未完成範囲と、使用素材')
 image(p,R/'proposals/C-RF-生成コンセプト-未実装.png',(28,108,814,554),'生成コンセプト：Godot実画面ではありません。C館RFへの設置位置・支持は未決定、通常版・F4には未実装。')
 text(p,'水上庭園は設計検討のみ。仮に水面240㎡・水深80mmなら水だけで19.2t（約0.785kN/㎡）です。既存床の耐荷力を示す値ではありません。躯体・防水・排水・避難・風・積雪・利用者荷重などの検証が必要です。\n\nC館F4、B館F6、RF-SUPPORT-16、支持未確認の屋上箇所は未承認を維持。B1へのES延伸候補は車路と4台分の駐車に干渉するため採用していません。\n\n未完成：B館3Fの追加休憩候補、C屋上の追加パーゴラ等、全館の内装刷新、売買・チケット・子どもや犬のゲーム処理。全店舗が今回の専用モデルへ置換されたわけではありません。\n\n新モデル・手描きのグラフィック・木材/絞り柄は本プロジェクト向けオリジナル。愛知のキービジュアルはOpenAI ImageGen生成。添付参考写真・実在ロゴを素材へ転用していません。Noto Sans CJK JPはOFL、継承したCC0/CC-BY等の素材の出典・ライセンスを同梱しています。\n\n参照：添付3コンセプトボード・9実画面を目視。施設の観察メモは受領資料として扱い、リンク先を今回新たに閲覧したと報告していません。画像原本を新実装の証拠として使用していません。\n\n詳細はindex.html、配置図、施設台帳、検査結果、未完成・未承認の一覧をご確認ください。',y=610,size=11.5)
 for i in range(len(doc)):
  p=doc[i];p.insert_text((28,1171),'FIND YOURSELF v16  |  '+str(i+1)+' / '+str(len(pages)),fontname='jp',fontsize=9,color=(.3,.4,.34))
 out=R/'FIND_YOURSELF-v16-Review.pdf';doc.save(out,garbage=4,deflate=True);doc.close();print('V16_PDF',out.stat().st_size)

if __name__=='__main__':
 pairs=collect_images();gallery(pairs);pdf(pairs);print('V16_REVIEW',len(pairs),'matched real Viewport pairs')
