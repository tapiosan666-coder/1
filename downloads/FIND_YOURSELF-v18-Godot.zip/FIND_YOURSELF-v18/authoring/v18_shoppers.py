"""43 landscape-test shoppers. Curated purposes, real seats and floor-contained paths; no gameplay identities."""
from pathlib import Path
import sys,math,numpy as np,collections
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
F=read(P/'source/v11/floors-updated.json');F={f['wing']:f for f in F if f['level']==0};old=read(P/'source/v16/commons.json');v17=read(P/'source/v17/scene-design.json');new=read(P/'source/v18/retail-plan.json');actors=[];occupied=[];rejected=[];W=lambda g:affinity.translate(g,429,-46)
obstacles=collections.defaultdict(list)
for r in old['instances']+v17['instances']+new['instances']:
 if r.get('level')==0 and r.get('host')is None:
  if r.get('store_id')in new['replacement_store_ids']and r not in new['instances']:continue
  obstacles[r['wing']].append((r['id'],r['footprint'].buffer(.32)))
for w,f in F.items():
 for r in f.get('furniture',[]):
  if'geom'in r:obstacles[w].append(('designed-furniture',W(r['geom']).buffer(.30)))
 for c in f['cores']:obstacles[w].append(('vertical-core',W(c['outline']).buffer(.80)))
# Register the real machine zones of normal and independent alternatives as non-NPC space.
for path in ['source/scene-manifest.json','source/site-manifest-v7.json','source/v15/ES-site-proposal.json']:
 for e in read(P/path).get('escalators',[]):
  c=e.get('c');u=e.get('u');low=e.get('low_y',c[1]if len(c)>2 else 0)
  if abs(low)>.1:continue
  pos=(c[0],c[2]);area=rect(pos,u,float(e.get('run_m',12))+5,4.7).buffer(.4)
  for w,f in F.items():
   if W(f['shell']).buffer(5).intersects(area):obstacles[w].append(('NO-NPC-ES-'+str(e['id']),area))
spaces={w:W(f['public']).union(unary_union([s['sales_world']for s in new['stores']if s['wing']==w and s['height']==0])).buffer(-.05)for w,f in F.items()}
for w in spaces:
 if w=='C':spaces[w]=spaces[w].union(unary_union([r['geometry']for r in old['pads']if r['zone'].startswith('C-')]))
def clear(w,p,ignore=None):
 po=Point(*p);circle=po.buffer(.43)
 if not spaces[w].covers(circle):return False
 if any(identity!=ignore and shape.intersects(circle)for identity,shape in obstacles[w]):return False
 if any(po.distance(q)<.88 for q in occupied):return False
 return True

def add(w,role,p,target=None,search=3,seat=None,seat_height=.49,ignore=None):
 base=np.array(p,float);chosen=None
 offsets=sorted([(x,z)for x in np.arange(-search,search+.01,.5)for z in np.arange(-search,search+.01,.5)],key=lambda v:v[0]**2+v[1]**2)if search else[(0,0)]
 for x,z in offsets:
  q=base+[x,z]
  if role=='seated' or clear(w,q,ignore):chosen=q;break
 if chosen is None:rejected.append({'wing':w,'role':role,'p':list(p)});return None
 i=len(actors);heading=0 if target is None else math.atan2(-(target[0]-chosen[0]),-(target[1]-chosen[1]));row={'id':f'V18-{w}-{i+1:02d}','wing':w,'floor':'1F','role':role,'p':[chosen[0],0.,chosen[1]],'yaw':heading,'style':i%6,'scale':.91+(i%5)*.018,'phase':i*1.731,'speed':.95+(i%5)*.045,'seat_body':seat,'seat_height':seat_height};actors.append(row);occupied.append(Point(*chosen));return row
# Ten actual seats: A/B benches, C parent bench, outdoor cafe and refitted cafe.
seat_ids=['A-WEST-VISITOR-outdoor_bench-8','B-TIME-AICHI-outdoor_bench-49','C-KIDS-outdoor_bench-5']
for id in seat_ids:
 d=next(r for r in old['instances']if r['id']==id);p=np.array([d['p'][0],d['p'][2]]);n=np.array(d['n']);u=np.array([n[1],-n[0]])
 for dx in[-.52,.52]:q=p+u*dx+n*.02;add(d['wing'],'seated',q,q+n,0,seat=id,seat_height=.5075)
for d in [next(r for r in old['instances']if r['id']=='C-MELON-TRUCK-outdoor_table_set-11'),next(r for r in new['instances']if r['store_id']=='C1F-CSW-3'and r['role']=='customer_seating')]:
 p=np.array([d['p'][0],d['p'][2]]);n=np.array(d['n']);u=np.array([n[1],-n[0]])
 for dx in[-1.04,1.04]:q=p+u*dx;add('C','seated',q,p,0,seat=d['id'],seat_height=.505)
# Browsers face actual refitted displays, with the sales aisle kept free.
for w,ids in [('A',['A1F-007','A1F-005']),('B',['B1-030','B1-N03']),('C',['C1F-CW-1','C1F-CSW-3'])]:
 for id in ids:
  candidates=[r for r in new['instances']if r['store_id']==id and r['role']in['arrival_display','perimeter_department','central_department']]
  for d in candidates:
   n=np.array(d['n']);p=np.array([d['p'][0],d['p'][2]]);q=p+n*1.10
   if add(w,'browsing',q,p,search=1.0):break
# Wayfinding and conversation have a declared target, not a generic idle lineup.
for dx in[-.6,.6]:add('A','information',(354+dx,-45),(354,-43),search=2)
for w,c in [('A',(344,-34)),('B',(35,22)),('C',(-92,-220))]:
 for sign in[-1,1]:add(w,'conversation',(c[0]+sign*.60,c[1]),(c[0]-sign*.60,c[1]),search=4)
# Event visitors stay in front of real stalls, outside their toggled footprints.
for d in [r for r in old['instances']if r['model']=='fair_food_booth'][:4]:
 n=np.array(d['n']);p=np.array([d['p'][0],d['p'][2]]);add('B','event',p+n*2.2,p,search=3)
# Walkers follow floor-contained short shopping circuits. Their paths never enter ES zones.
anchors={'A':[(337,-43),(370,-47),(388,-49),(339,-25),(363,-16),(400,-49)],'B':[(-5,30),(8,28),(22,25),(36,16),(41,2),(-17,24)],'C':[(-103,-291),(-124,-289),(-91,-300),(-90,-216)]}
for w,items in anchors.items():
 for k,anchor in enumerate(items):
  found=None;avoid=unary_union([g for identity,g in obstacles[w]]+[q.buffer(.62)for q in occupied]);free=spaces[w].difference(avoid)
  for length in[10.,8.,6.,4.]:
   for angle in[0.,math.pi/2,-.17,math.pi/4]:
    direction=np.array([math.cos(angle),math.sin(angle)])
    for dx,dz in[(0,0),(2,0),(-2,0),(0,2),(0,-2),(3,3),(-3,-3),(5,0),(-5,0)]:
     mid=np.array(anchor)+[dx,dz];a=mid-direction*length/2;b=mid+direction*length/2;line=LineString([a,b]);band=line.buffer(.48,cap_style=1)
     if free.covers(band):found=(a,b);break
    if found:break
   if found:break
  if found:
   a,b=found;row=add(w,'walking',a,b,0)
   if row:row['path']=[[a[0],0.,a[1]],[b[0],0.,b[1]]];row['path_length_m']=math.dist(a,b)
  else:rejected.append({'wing':w,'role':'walking','p':anchor,'reason':'No contained route meeting current protected space'})
write(P/'source/v18/shoppers.json',{'purpose':'Small independent landscape/flow test only','people':actors,'count':len(actors),'default_enabled':True,'toggle':'F12','no_gameplay_systems':True,'no_escalator_use':True,'rejected':rejected});print('V18_SHOPPERS',len(actors),collections.Counter(r['wing']for r in actors),collections.Counter(r['role']for r in actors),'rejected',len(rejected))
