from pathlib import Path
P=Path(__file__).resolve().parents[1]
s=(P/"authoring/v15_models.py").read_text()
exec(s[:s.index("# Apparel:")])
exec(s[s.index("# Beauty:"):s.index("# Electronics:")])
