from pathlib import Path
import sys,numpy as np,math
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely.ops import transform
parts=[]
for r in read(P/'source/v13/pack-manifest.json'):
 if r['path']in['assets/v12/C-outlet.pack.zst','assets/v12/C-supported-finish.pack.zst','assets/v12/es-transfer-study.pack.zst']:continue
 for raw in load_pack(P/r['path'])['colliders'].values():
  a=raw.reshape(-1,3,3);m=(np.ptp(a[:,:,1],axis=1)<.001)&(abs(a[:,:,1].mean(1)-16.4)<.004)
  for t in a[m]:
   po=Polygon(t[:,[0,2]])
   if po.area>.00001:parts.append(po)
supported=unary_union(parts);F=read(P/'source/v11/floors-updated.json');f=next(f for f in F if f['wing']=='B'and f['level']==3);world=lambda g:transform(lambda x,z,zz=None:(np.asarray(x)+429,np.asarray(z)-46),g);planned=world(f['floor_plate']);fp=box(16.4,11.7,20.4,13.1);missing=fp.difference(supported);plannedmissing=fp.difference(planned);candidates=[]
for dx in np.arange(-6,6.01,.25):
 for dz in np.arange(-6,6.01,.25):
  if math.hypot(dx,dz)<.1:continue
  g=box(16.4+dx,11.7+dz,20.4+dx,13.1+dz)
  if supported.buffer(.0001).covers(g)and planned.buffer(.0001).covers(g):candidates.append((math.hypot(dx,dz),dx,dz,g))
best=min(candidates,key=lambda r:r[0])if candidates else None
write(P/'source/v15/BRF-GARDEN-2-BED-4-review.json',{'status':'UNAPPROVED relocation option; not installed','old_world':[18.4,16.4,12.4],'old_footprint':fp,'missing_rendered_collision_floor_m2':missing.area,'missing_canonical_planned_floor_m2':plannedmissing.area,'missing_geometry':missing,'cause':'Garden furnishing footprint is not clipped to the final roof slab; centre-only planting validation was insufficient. Compare planned and physical overlap explicitly.','proposal_world':[18.4+best[1],16.4,12.4+best[2]]if best else None,'proposal_footprint':best[3]if best else Polygon(),'relocation_distance_m':best[0]if best else None,'no_new_support_floor':True,'engineering_and_route_clearance_approval_pending':True,'RF_SUPPORT_16':'UNAPPROVED','normal_bed_still_omitted':True})
print('BED4',missing.area,plannedmissing.area,'proposed',best[:3]if best else None)
