from pathlib import Path
import sys,numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
F=read(P/'source/v11/floors-updated.json');shots=read(P/'source/v15/compare-cameras.json')
def draw(ax,g,colour,edge=None,alpha=1):
 for po in polys(g):
  xy=np.asarray(po.exterior.coords)+[429,-46];ax.fill(xy[:,0],xy[:,1],color=colour,edgecolor=edge,linewidth=.5,alpha=alpha)
  for h in po.interiors:
   xy=np.asarray(h.coords)+[429,-46];ax.fill(xy[:,0],xy[:,1],color='white')
for wing in 'ABC':
 f=next(f for f in F if f['wing']==wing and f['level']==0);fig,ax=plt.subplots(figsize=(15,11));draw(ax,f['floor_plate'],'#eeeeea','#777777');draw(ax,f['public'],'#c1e8ed')
 if wing=='C':
  g=f['outdoor_ground'];g=unary_union([x.get('polygon',x.get('geom',Polygon()))for x in g])if isinstance(g,list)else g;draw(ax,g,'#e0ecd2')
 for s in f['stores']:
  draw(ax,s['polygon'],'#d3c9b8','#888888');c=s['polygon'].representative_point();ax.text(c.x+429,c.y-46,s['id'],fontsize=5,ha='center');e=s['entry'];ax.plot(e[0]+429,e[1]-46,'r.',markersize=3)
 for c in f['cores']:draw(ax,c['outline'],'#9bafcf','#4d6491')
 for x in f.get('furniture',[]):
  if 'geom'in x:draw(ax,x['geom'],'#985e58')
 for c in shots:
  x,y,z=c['eye']
  if (wing=='A'and x>300)or(wing=='B'and-300<x<200 and z> -160)or(wing=='C'and z< -170):
   if y<2:ax.plot(x,z,'k*');ax.text(x+1,z+1,c['id'],fontsize=7)
 ax.set_aspect('equal');ax.grid(alpha=.25);ax.set_xlabel('World X (m)');ax.set_ylabel('World Z (m)');ax.set_title(wing+' 1F existing public / shops / cores / furniture');fig.savefig('/tmp/v16-plan-'+wing+'.png',dpi=110,bbox_inches='tight');plt.close(fig)
