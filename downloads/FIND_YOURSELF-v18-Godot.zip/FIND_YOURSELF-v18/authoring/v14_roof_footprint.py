"""Whole plant footprint against actual RF collision triangles, not only a downward centre ray."""
from pathlib import Path
import sys,numpy as np,json
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import set_precision
parts=[]
for n in ['assets/v10/base-b.pack.zst','assets/v10/base-site.pack.zst','assets/v11/repairs.pack.zst','assets/v12/es-safety.pack.zst']:
 for raw in load_pack(P/n)['colliders'].values():
  a=np.asarray(raw).reshape(-1,3,3);m=(np.ptp(a[:,:,1],axis=1)<.001)&(abs(a[:,:,1].mean(1)-16.4)<.004)
  for t in a[m]:
   po=Polygon(t[:,[0,2]])
   if po.area>.001:parts.append(po)
supported=set_precision(unary_union(parts),.001);d=json.loads((P/'source/v14/roof-planting.json').read_text());rows=[]
for q in d['instances']:
 x,y,z=q['p'];fp=box(x-.29,z-.29,x+.29,z+.29);outside=fp.difference(supported).area;rows.append({'bed_id':q['bed_id'],'p':q['p'],'outside_floor_m2':outside,'pass':outside<.00001})
out={'checks':rows,'passed':sum(q['pass']for q in rows),'failed':sum(not q['pass']for q in rows),'method':'0.58 x 0.58m whole footprint minus union of actual horizontal collision triangles; 1mm precision; not structural load certification'}
(P/'source/v14/roof-full-footprint.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('ROOF_FULL_FOOTPRINT',out['passed'],out['failed'])
