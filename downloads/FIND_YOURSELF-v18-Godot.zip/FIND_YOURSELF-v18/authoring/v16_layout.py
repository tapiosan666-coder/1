"""Purposeful v16 fit-out. Original architectural sources and all 480 shop IDs stay fixed.
Functional clusters are curated; nearby search only resolves occupied/path intersections.
"""
from pathlib import Path
import sys,math,numpy as np,collections,copy
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
F=read(P/'source/v11/floors-updated.json');by={(f['wing'],f['level']):f for f in F};models=read(P/'source/v16/model-bounds.json');routes=read(P/'source/physical-routes-v11.json');Copt=read(P/'source/v15/C-outlet-proposal.json');instances=[];boards=[];zones=[];pads=[];gates=[];rejected=[];occupied=collections.defaultdict(list);special_walk=collections.defaultdict(list)
W=lambda g:affinity.translate(g,429,-46)
normal=lambda n:np.asarray(n,float)/np.linalg.norm(n)
def rectw(p,n,w,d):
 n=normal(n);return rect(p,(n[1],-n[0]),w,d)
def local_point(f,s,x=0,z=0):return np.asarray(s['entry'])+[429,-46]+np.asarray(s['u'])*x+np.asarray(s['n'])*z
primary=collections.defaultdict(list)
for route in routes:
 for a,b in zip(route['points'],route['points'][1:]):
  if abs(a[1]-b[1])<.03:primary[round(a[1],3)].append(LineString([(a[0],a[2]),(b[0],b[2])]).buffer(.72,cap_style=2))
# Deliberately continuous walk bands in the two indoor priority areas.
special_walk[('A',0)]=[box(304,-57.5,380,-50.5),box(332,-49.5,339.5,18)]
special_walk[('B',0)]=[LineString([(-12,36),(2,26),(28,19),(60,30)]).buffer(3.4,cap_style=2),LineString([(0,-63),(0,-28),(6,-16),(6,14)]).buffer(3.3,cap_style=2)]
primary={y:unary_union(v)for y,v in primary.items()}
oldprops=collections.defaultdict(list)
for f in F:
 for x in f.get('furniture',[]):
  if 'geom'in x:oldprops[(f['wing'],f['level'])].append(W(x['geom']).buffer(.10))
 for s in f['stores']:oldprops[(f['wing'],f['level'])].append(W(Point(s['entry']).buffer(1.6)))
# Ground-level footprints of the previously authored assets, not their decorative upper products.
for name in ['source/v12/scene-art.json','source/v13/amenities-public.json','source/v13/basement-retail.json','source/v13/roof-retail.json','source/v15/retail-services.json']:
 data=read(P/name)
 for d in data.get('instances',[]):
  p=d['p'];near=[f for f in F if abs(f['height']-p[1])<.20 and W(f['shell'].convex_hull).buffer(30).covers(Point(p[0],p[2]))]
  if not near:continue
  f=min(near,key=lambda f:W(f['public']).distance(Point(p[0],p[2])));dim=d.get('max_xz')
  if dim and max(dim)<15:oldprops[(f['wing'],f['level'])].append(rect((p[0],p[2]),d['u'],dim[0],dim[1]).buffer(.06))
avoid={}
for f in F:
 key=f['wing'],f['level'];extra=special_walk.get(key,[])
 avoid[key]=unary_union(oldprops[key]+extra+[primary.get(round(f['height'],3),Polygon())])
# Both normal and F6 equipment must remain clear; this does not adopt the F6 geometry.
for lev in[0,1,2,3]:avoid[('B',lev)]=avoid[('B',lev)].union(box(-205,-27.5,-179,-3.5)).union(box(-222,-18.4,-162,-12.6))
for f in F:
 key=f['wing'],f['level'];bounds=[W(c['outline']).buffer(.8)for c in f['cores']]+[W(f['shafts']).buffer(.7)]
 avoid[key]=avoid[key].union(unary_union(bounds))
 if f['wing']=='B'and f['level']==3:avoid[key]=avoid[key].union(W(f.get('overhang',Polygon())).buffer(.5)).union(box(15,10.8,21,14))

def zone(id,wing,lev,title,preferred,space=None,store=None,activation='always',role='public'):
 f=by[(wing,lev)]
 if space is None:space=W(f['public']).buffer(-.25)
 if wing=='C'and lev>0:space=space.intersection(W(next(r['proposed_floor']for r in Copt['floors']if r['level']==lev)))
 z={'id':id,'wing':wing,'level':lev,'floor':f['label'],'height':f['height'],'title':title,'preferred':list(preferred),'space':space,'store_id':store,'activation':activation,'role':role};zones.append(z);return z

def footprint(model,p,n,scale=1,scale_x=1):
 b=models[model];u=np.array([n[1],-n[0]]);lo=b['min'];hi=b['max'];return Polygon([np.asarray(p)+u*x*scale*scale_x+np.asarray(n)*z*scale for x,z in[(lo[0],lo[2]),(hi[0],lo[2]),(hi[0],hi[2]),(lo[0],hi[2])]])
def add(z,model,p,n=(0,1),id=None,search=0,scale=1,collision='auto',activation=None,host=None,height_offset=0,clearance=.32,allow_walk=False,scale_x=1):
 n=normal(n);p=np.asarray(p,float);key=z['wing'],z['level'];fp=None;found=None
 offsets=[(0.,0.)]
 if search:
  offsets=sorted([(x,d)for x in np.arange(-search,search+.01,.5)for d in np.arange(-search,search+.01,.5)],key=lambda q:(q[0]**2+q[1]**2,abs(q[1]),q[0]))
 for x,d in offsets:
  q=p+[x,d];candidate=footprint(model,q,n,scale,scale_x)
  if host is None:
   if not z['space'].buffer(.001).covers(candidate):continue
   if not allow_walk and avoid[key].intersects(candidate.buffer(clearance)):continue
   if any(candidate.distance(g)<clearance for g in occupied[key]):continue
  fp=candidate;found=q;break
 if found is None:
  rejected.append({'zone':z['id'],'model':model,'preferred_world':p.tolist(),'reason':'No placement preserving declared space, existing furniture, entrances and protected walk bands'});return None
 identity=id or z['id']+'-'+model+'-'+str(sum(r['zone']==z['id']for r in instances)+1)
 rec={'id':identity,'zone':z['id'],'wing':z['wing'],'level':z['level'],'model':model,'p':[float(found[0]),z['height']+height_offset,float(found[1])],'n':n.tolist(),'scale':float(scale),'scale_x':float(scale_x),'footprint':fp,'collision':collision,'activation':activation or z['activation'],'host':host,'store_id':z['store_id'],'role':z['role']}
 instances.append(rec)
 if host is None:occupied[key].append(fp)
 return rec

def at(r,x=0,z=0):return np.array([r['p'][0],r['p'][2]])+np.array([r['n'][1],-r['n'][0]])*x+np.array(r['n'])*z

def sign(z,tile,p,n=(0,1),w=1.0,h=1.5,y=1.6,host=None,activation=None,title=None):
 b={'id':z['id']+'-SIGN-'+str(len(boards)+1),'zone':z['id'],'tile':tile,'p':[float(p[0]),z['height']+y,float(p[1])],'n':normal(n).tolist(),'w':w,'h':h,'activation':activation or z['activation'],'store_id':z['store_id'],'host':host,'title':title};boards.append(b);return b

def pylon(z,p,n,tile='directory',search=3):
 r=add(z,'digital_info_pylon',p,n,search=search)
 if r:sign(z,tile,at(r,0,.105),n,.62,1.55,1.32,r['id'])
 return r

def seat_tree(z,p,n=(0,1),search=4,tree=.64):
 r=add(z,'planted_seating_island',p,n,search=search)
 if r:add(z,'atrium_ficus_tree',at(r,-.85,0),n,scale=tree,collision='trunk',host=r['id'],height_offset=.64)
 return r
# A: the west visitor plaza, specialist street and existing upper-floor facilities.
a=zone('A-WEST-VISITOR', 'A',0,'西広場・案内と休憩', (355,-43))
r=add(a,'information_counter',(354,-43),(0,-1),search=5)
if r:sign(a,'information',at(r,0,.59),r['n'],2.30,.48,.58,r['id'])
seat_tree(a,(346,-38),(0,1),search=5);seat_tree(a,(360,-40),(1,0),search=4);pylon(a,(347,-48),(.1,-1),'a_directory',4)
for p,n in[((319,-30),(1,0)),((356,-20),(-1,0))]:add(a,'outdoor_bench',p,n,search=4)
a2=zone('A-POPUP', 'A',0,'専門店街入口・週末クラフト展示',(365,-45))
for p in[(365,-45),(373,-44)]:
 r=add(a2,'fair_craft_booth',p,(0,-1),search=4)
 if r:
  sign(a2,'weekend_market',at(r,0,1.52),r['n'],2.1,.54,2.54,r['id']);add(a2,'craft_seto',at(r,-.55,.9),r['n'],host=r['id'],height_offset=1.01,collision='none');add(a2,'craft_shibori',at(r,.55,.9),r['n'],host=r['id'],height_offset=1.01,collision='none')
# Information islands vary by place, not repeated at equal intervals.
for x,zv in[(419,-48),(511,-47),(593,-18)]:
 za=zone('A-STREET-'+str(x),'A',0,'専門店街の案内・滞留',(x,zv));pylon(za,(x,zv),(0,-1),'a_street',4);add(za,'outdoor_bench',(x+3,zv+1),(0,-1),search=3)
# A2 existing large book/lifestyle shop approach.
f=by[('A',1)];s=next(s for s in f['stores']if s['category']=='書店');ep=np.asarray(s['entry'])+[429,-46];z=zone('A-2F-READING','A',1,'書店前・読書と待合',ep-np.asarray(s['n'])*4)
seat_tree(z,z['preferred'],(-s['n'][0],-s['n'][1]),search=5,tree=.58);pylon(z,ep-np.asarray(s['n'])*3+np.asarray(s['u'])*5,(-s['n'][0],-s['n'][1]),'book_launch',5)
# Existing cinema/amusement entrances remain their original shop IDs.
for sid,kind in[('A3F-001','cinema'),('A3F-012','arcade')]:
 f=by[('A',2)];s=next(s for s in f['stores']if s['id']==sid);space=W(s['sales']).buffer(-.3);ep=np.asarray(s['entry'])+[429,-46];n=-np.asarray(s['n']);z=zone('A-'+kind.upper(),'A',2,'既存映画館ロビー'if kind=='cinema'else'既存ゲームセンター入口',ep,space,sid,role='shop')
 for i in range(3 if kind=='cinema' else 4):
  r=add(z,'cinema_ticket_kiosk'if kind=='cinema'else'capsule_toy_machine',local_point(f,s,3.3+i*.85,3.7),n,search=3)
  if r and kind=='cinema':sign(z,'cinema_tickets',at(r,0,.263),n,.47,.42,1.15,r['id'])
 pylon(z,local_point(f,s,-3.5,3.2),n,'cinema_poster'if kind=='cinema'else'arcade',4)
# B time square: compact fair with a genuinely clear central circulation band.
b=zone('B-TIME-AICHI','B',0,'時の広場｜愛知県うまいもの・ものづくりフェア',(12,8),activation='aichi_fair')
stage=add(b,'fair_stage',(21,-9),(0,1),search=5)
if stage:sign(b,'aichi_hero',at(stage,.75,-1.445),stage['n'],4.10,2.35,2.40,stage['id'])
foods=[('miso_katsu',(-5,0),(1,0)),('tebasaki',(-5,10),(1,0)),('kishimen',(-5,20),(1,0)),('hitsumabushi',(20,0),(-1,0)),('uiro',(21,10),(-1,0)),('ogura_toast',(24,21),(-1,0))]
for name,p,n in foods:
 r=add(b,'fair_food_booth',p,n,id='AICHI-'+name,search=5)
 if not r:continue
 sign(b,'food_'+name,at(r,0,1.52),r['n'],2.62,.58,2.55,r['id'])
 for i in range(4):add(b,'dish_'+name,at(r,-.88+i*.57,.84),r['n'],host=r['id'],height_offset=1.01,collision='none')
crafts=[('tokoname',(34,12),(0,1)),('seto',(34,24),(-1,0)),('shibori',(9,30),(0,-1))]
for name,p,n in crafts:
 r=add(b,'fair_craft_booth',p,n,id='AICHI-'+name,search=6)
 if not r:continue
 sign(b,'craft_'+name,at(r,0,1.52),r['n'],2.62,.58,2.55,r['id'])
 for i in range(4):add(b,'craft_'+name,at(r,-.85+i*.55,.84),r['n'],host=r['id'],height_offset=1.01,collision='none')
for p,n in[((30,-3),(-1,0)),((-7,28),(1,0)),((25,30),(0,-1))]:add(b,'outdoor_bench',p,n,search=4)
pylon(b,(9,25),(0,1),'aichi_program',4)
for p in[(-14,14),(38,20)]:seat_tree(b,p,(0,1),search=4,tree=.60)
# Light square is a dry planted retreat; no unverified water load is introduced.
bg=zone('B-LIGHT-GARDEN','B',0,'光の広場｜木陰の庭',(146,12))
for p,n in[((144,10),(1,0)),((158,11),(-1,0)),((149,-7),(0,1))]:seat_tree(bg,p,n,search=5,tree=.70)
pylon(bg,(136,18),(-1,0),'garden',5)
bw=zone('B-WING-SEASON','B',0,'翼の広場｜季節のクラフト展示',(-204,8))
for p,n in[((-211,7),(0,1)),((-177,8),(0,1))]:
 r=add(bw,'fair_craft_booth',p,n,search=4)
 if r:
  sign(bw,'season_exhibit',at(r,0,1.52),n,2.4,.56,2.55,r['id']);add(bw,'craft_seto',at(r,0,.9),n,host=r['id'],height_offset=1.01,collision='none')
# Upper indoor streets receive focused rest/sign clusters; untouched shops stay unchanged.
for wing,lev,p,title in [('A',1,(592,-12),'A館2F 東回廊'),('B',1,(16,22),'B館2F 専門店街'),('B',2,(160,2),'B館3F シネマ・飲食街')]:
 z=zone(wing+'-UPPER-'+str(lev),wing,lev,title,p);seat_tree(z,p,(0,1),search=6,tree=.57);pylon(z,(p[0]+4,p[1]+3),(0,1),'dining'if lev==2 else'directory',6)
# C: landscape reuse, not a new building or a station road.
f=by[('C',0)];yard=W(f['shell'].convex_hull).difference(W(unary_union([s['polygon']for s in f['stores']]+[c['outline']for c in f['cores']]))).buffer(-.5)
rain=W(unary_union([q['geom']for q in f['landscape']if q['kind']=='rain_garden']));yard=yard.difference(rain.buffer(2.0))
ck=zone('C-KIDS','C',0,'こもれびキッズ広場',(-111,-312),yard,role='outdoor')
kpad=box(-124,-322,-99,-300);pads.append({'id':'C-KIDS-SAFETY','zone':ck['id'],'geometry':kpad,'y':.018,'material':'epdm','activation':'always','kind':'衝撃緩和舗装','structural_floor':False})
add(ck,'kids_play_tower',(-111,-313),(0,1),search=3,collision='mesh',allow_walk=True)
add(ck,'kids_climb_pod',(-118,-306),(0,1),search=2,collision='mesh',allow_walk=True)
add(ck,'shade_sail',(-103,-315),(0,1),search=2,allow_walk=True)
for p,n in[((-121,-317),(1,0)),((-120,-302),(0,-1))]:add(ck,'outdoor_bench',p,n,search=2,allow_walk=True)
pylon(ck,(-103,-302),(0,1),'kids_rules',3)
# Dog run has a real visible fence and a double-gate vestibule, away from children.
cd=zone('C-DOG-RUN','C',0,'ひだまりドッグガーデン',(-118,-263.5),yard,role='outdoor')
center=np.array([-118.,-263.5]);hw=12.;hd=9.6;dogarea=box(center[0]-hw,center[1]-hd,center[0]+hw,center[1]+hd);pads.append({'id':'C-DOG-TURF','zone':cd['id'],'geometry':dogarea,'y':.012,'material':'turf','activation':'always','kind':'ドッグラン芝生','structural_floor':False})
def fence_line(a,b):
 a=np.asarray(a,float);b=np.asarray(b,float);d=b-a;length=np.linalg.norm(d);u=d/length;n=np.array([-u[1],u[0]]);parts=math.ceil(length/2.4)
 for i in range(parts):
  mid=a+d*((i+.5)/parts);add(cd,'dog_fence_segment',mid,n,scale_x=length/parts/2.4,collision='fence',host='DOG-BOUNDARY',allow_walk=True)
x,zv=center
fence_line((x-hw,zv-hd),(x-.6,zv-hd));fence_line((x+.6,zv-hd),(x+hw,zv-hd));fence_line((x-hw,zv+hd),(x+hw,zv+hd));fence_line((x-hw,zv-hd),(x-hw,zv+hd));fence_line((x+hw,zv-hd),(x+hw,zv+hd))
fence_line((x-.9,zv-hd-3.6),(x-.9,zv-hd));fence_line((x+.9,zv-hd-3.6),(x+.9,zv-hd));fence_line((x-.9,zv-hd-3.6),(x-.6,zv-hd-3.6));fence_line((x+.6,zv-hd-3.6),(x+.9,zv-hd-3.6))
for name,zgate in [('outer',zv-hd-3.6),('inner',zv-hd)]:gates.append({'id':'C-DOG-'+name,'pair':'C-DOG-'+('inner'if name=='outer'else'outer'),'p':[x-.6,.02,zgate],'n':[0,1],'width':1.2,'label':'ドッグラン 二重ゲート','zone':cd['id']})
for p,n in[((x-7,zv+6),(0,-1)),((x+7,zv+6),(0,-1))]:add(cd,'outdoor_bench',p,n,search=1,allow_walk=True)
add(cd,'dog_service_station',(x+8,zv-5),(0,-1),search=2,allow_walk=True);pylon(cd,(x+2.5,zv-hd-1.5),(0,-1),'dog_rules',2)
# Food truck: a stopped trading scene. Surface vehicle entry/turning remains a candidate, not certified.
ct=zone('C-MELON-TRUCK','C',0,'麦日和 焼きたてメロンパン',(-88,-324),yard,role='outdoor')
truck=add(ct,'melon_food_truck',(-88,-324),(0,1),search=4,collision='mesh',allow_walk=True)
if truck:
 sign(ct,'melon_brand',at(truck,0,1.11),truck['n'],3.55,.43,2.54,truck['id'])
 for i in range(9):add(ct,'melon_bread',at(truck,-2.1+i*.37,1.13),truck['n'],host=truck['id'],height_offset=1.31,collision='none')
 pylon(ct,at(truck,3.6,2.0),(0,1),'melon_menu',3)
 for j in range(4):
  a=at(truck,-1.2+j*.8,2.6);b=at(truck,-.8+j*.8,2.6);pads.append({'id':'C-QUEUE-'+str(j),'zone':ct['id'],'geometry':LineString([a,b]).buffer(.035,cap_style=2),'y':.025,'material':'queue','activation':'always','kind':'待機列目印','structural_floor':False})
for p in[(-78,-316),(-78,-309)]:add(ct,'outdoor_table_set',p,(0,1),search=3,allow_walk=True)
for p in[(-96,-332),(-69,-315)]:
 r=add(ct,'planted_seating_island',p,(0,1),search=3,allow_walk=True)
 if r:add(ct,'atrium_ficus_tree',at(r,-.85,0),(0,1),scale=.85,host=r['id'],height_offset=.64,collision='trunk')
# Purposeful surface spurs connect the three facilities to the existing main promenade.
for name,pts in [('KIDS',[(-106,-289.5),(-106,-300)]),('DOG',[(-118,-289.5),(-118,zv-hd-3.6)]),('FOOD',[(-86,-289.5),(-86,-318)])]:
 pads.append({'id':'C-ACCESS-'+name,'zone':'C-MELON-TRUCK'if name=='FOOD'else'C-'+('KIDS'if name=='KIDS'else'DOG-RUN'),'geometry':LineString(pts).buffer(1.65,cap_style=2,join_style=2),'y':.008,'material':'pavers','activation':'always','kind':'施設アクセス舗装','structural_floor':False})
# C shared upper galleries: only supported floor common to normal and F4.
for lev,sid in[(1,'C2F-CW-2'),(2,'C3F-CSE-2')]:
 f=by[('C',lev)];s=next(s for s in f['stores']if s['id']==sid);ep=np.asarray(s['entry'])+[429,-46];n=-np.asarray(s['n']);z=zone('C-UPPER-'+str(lev),'C',lev,'C館上階の休憩・案内',ep+n*3)
 add(z,'outdoor_bench',ep+n*3+np.asarray(s['u'])*5,n,search=5);pylon(z,ep+n*2+np.asarray(s['u'])*9,n,'c_upper',5)
# Existing basement uses: food in A/B, repair-and-pickup in C. No new duplicate supermarkets.
for wing,sid,role in [('A','AB1-003','food'),('B','BB1-MARKET','market'),('C','CB1-CW-1','repair')]:
 f=by[(wing,-1)];s=next(s for s in f['stores']if s['id']==sid);n=-np.asarray(s['n']);z=zone(wing+'-B1-FOCUS',wing,-1,'地下食品専門店'if role=='food'else'地下食品スーパー'if role=='market'else'地下受取・リペアサービス',np.asarray(s['entry'])+[429,-46],W(s['sales']).buffer(-.3),sid,role='shop')
 if role in['food','market']:
  for xx,dep,model in[(-5,6,'produce_market_bay'),(5,7,'deli_refrigerated_showcase'),(-5,12,'produce_market_bay'),(5,13,'produce_market_bay')]:add(z,model,local_point(f,s,xx,dep),n,search=4)
  pylon(z,local_point(f,s,4.5,3.4),n,'basement_food',4)
 else:
  add(z,'repair_pickup_counter',local_point(f,s,4.5,5.5),n,search=4);pylon(z,local_point(f,s,-4,4),n,'repair_services',4)
# Public basement arrival signs use existing locker/EV hubs, not additional locker banks.
for wing,p in [('A',(350,24)),('B',(-117,-42)),('C',(-146,-258))]:
 z=zone(wing+'-B1-ARRIVAL',wing,-1,'既存地下サービスへの案内',p);pylon(z,p,(0,1),'basement_directory',5)
# A roof cafe and C existing roof lounge are fit out within their own unchanged sales parcels.
for wing,sid in [('A','ARF-002'),('C','CRF-CW-1')]:
 f=by[(wing,3)];s=next(s for s in f['stores']if s['id']==sid);n=-np.asarray(s['n']);z=zone(wing+'-RF-TERRACE',wing,3,'既存屋上区画の展望・休憩',np.asarray(s['entry'])+[429,-46],W(s['sales']).buffer(-.4),sid,role='shop')
 for xx,dd in[(-4,6),(4,7)]:add(z,'outdoor_table_set',local_point(f,s,xx,dd),n,search=4)
 add(z,'terrace_pergola',local_point(f,s,0,11),n,search=3,allow_walk=True)
 pylon(z,local_point(f,s,4,3.5),n,'roof_terrace',3)
# B roof western garden: floor-supported dry seating, never the unapproved central bed.
f=by[('B',3)];g=f['public'].union(unary_union([x['polygon']for x in f['gardens']])).intersection(f['floor_plate']);z=zone('B-RF-GARDEN','B',3,'翼の広場屋上前庭・木陰テラス',(-195,-34),W(g))
add(z,'terrace_pergola',(-201,-34),(1,0),search=6);add(z,'outdoor_table_set',(-191,-34),(0,1),search=5);pylon(z,(-184,-34),(0,-1),'roof_terrace',4)
# Supplemental boards are mounted on actual authored components, not unsupported signs.
for zid,tile,model,offset,w,h,y in [('C-KIDS','kids_rules','shade_sail',(0,2.22),1.65,.78,1.90),('C-MELON-TRUCK','melon_menu','melon_food_truck',(2.02,1.52),.72,1.12,1.77)]:
 z=next(q for q in zones if q['id']==zid);r=next(q for q in instances if q['zone']==zid and q['model']==model)
 sign(z,tile,at(r,*offset),r['n'],w,h,y,r['id'])
# Portrait original event artwork remains aspect-correct; framed within the stage backdrop.
if stage:sign(next(z for z in zones if z['id']=='B-TIME-AICHI'),'aichi_original',at(stage,-2.18,-1.435),stage['n'],1.18,1.57,2.4,stage['id'])
# F6 ONLY: wall-mounted transfer signs on existing bridge guard frames, no added floor objects.
for lev,p,n in [(1,(-211,-17.55),(0,1)),(2,(-173,-13.45),(0,-1))]:
 z=zone('B-F6-TRANSFER-'+str(lev),'B',lev,'西広場・連続ES乗り継ぎ（未承認別案）',p,activation='es_option')
 sign(z,'es_transfer',p,n,1.55,.58,.78,'F6-EXISTING-BRIDGE-GUARD')
pads.append({'id':'C-FOOD-FORECOURT','zone':'C-MELON-TRUCK','geometry':box(-99,-330,-72,-304),'y':.018,'material':'pavers','activation':'always','kind':'販売窓口・屋外席・搬入待機の舗装区画','structural_floor':False})
# Keep the original interfaces; new objects are separate, reversible fit-out data.
clean_zones=[]
for z in zones:
 rec={k:v for k,v in z.items()if k!='space'};rec['placed_models']=sum(i['zone']==z['id']for i in instances);rec['display_surfaces']=sum(i['zone']==z['id']for i in boards);rec['implemented']=rec['placed_models']>0 or rec['display_surfaces']>0;clean_zones.append(rec)
write(P/'source/v16/commons.json',{'version':16,'instances':instances,'boards':boards,'zones':clean_zones,'pads':pads,'gates':gates,'default_aichi_fair':True,'structural_integration':False,'RF_SUPPORT_16':'UNAPPROVED','roof_water_garden':'DESIGN_ONLY_NOT_IMPLEMENTED','human_playtest':False})
write(P/'source/v16/layout-rejections.json',rejected)
write(P/'source/v16/protected-walk-bands.json',[{'wing':k[0],'level':k[1],'geometry':unary_union(v)}for k,v in special_walk.items()])
print('V16_LAYOUT',len(instances),'models',len(boards),'boards',len(gates),'gates',len(clean_zones),'zones',len(rejected),'omitted candidates')
print('PUBLIC FEATURE COUNTS',dict(collections.Counter(i['zone']for i in instances)));print('REJECTED',[(r['zone'],r['model'])for r in rejected])
