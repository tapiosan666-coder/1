"""Original retail replacements. Active loader fits each model INSIDE v13 AABB; no shop, route or collider moves."""
from pathlib import Path
P=Path(__file__).resolve().parents[1];src=(P/'authoring/retail_models_v10.py').read_text();exec(src[:src.index('for var in range(3):bookcase')]);OUT=P/'assets/v14/models';OUT.mkdir(parents=True,exist_ok=True)
labels=material('V14_original_label_atlas',(1,1,1),.65,texture='assets/v14/materials/retail-labels.png')
prices=material('V14_original_price_labels',(1,1,1),.72,texture='assets/v14/materials/price-labels.png')
signs=material('V14_department_graphics',(1,1,1),.65,texture='assets/v14/materials/department-signs.png')
colors=[material('V14_food_colour_'+str(i),c,.48)for i,c in enumerate([(.65,.12,.055),(.76,.55,.15),(.18,.38,.16),(.69,.65,.51),(.10,.25,.32)])]
def label(x,y,z,w,h,i=0,dep=False,price=False):
 u0=(i%4)/4;u1=u0+.25;v0=1-(i//4+1)/4;v1=v0+.25
 if dep:u0,u1=0,1;v0=1-(i+1)/4;v1=v0+.25
 return mesh('Original_printed_label',[(x-w/2,y,z-h/2),(x+w/2,y,z-h/2),(x+w/2,y,z+h/2),(x-w/2,y,z+h/2)],[(0,1,2,3)],signs if dep else prices if price else labels,[(u0,v0),(u1,v0),(u1,v1),(u0,v1)])
def pack(x,y,z,i,style=0):
 if style==0:
  h=.17+(i%3)*.025;box('Cardboard_food_carton',(x,y,z+h/2),(.10,.14,h),colors[i%5],.005);label(x,y-.071,z+h*.55,.089,h*.80,i%16)
 elif style==1:
  h=.21;lathe('Preserve_jar',[(0,0),(.045,0),(.05,.025),(.05,.16),(.039,.185),(.039,.21),(0,.21)],ceramics[i%3],(x,y,z),20);lathe('Twist_cap',[(0,0),(.043,0),(.043,.018),(0,.018)],brass,(x,y,z+.21),20);label(x,y-.051,z+.10,.068,.11,i%16)
 else:
  box('Sealed_paper_pouch',(x,y,z+.11),(.12,.065,.22),colors[i%5],.012);box('Folded_pouch_seam',(x,y,z+.215),(.11,.070,.013),white,.003);label(x,y-.034,z+.11,.10,.17,i%16)
# Double-sided gondola, perforated standards, pricing strips, printed cartons and glass jars.
box('Gondola_shadow_plinth',(0,0,.055),(2.08,.92,.11),metal,.015);box('Shared_central_back',(0,0,.87),(2.04,.038,1.55),white,.006)
for x in [-1.01,0,1.01]:
 box('Adjustable_standard',(x,0,.87),(.026,.07,1.58),metal,.004)
 for h in [.25,.5,.75,1.,1.25,1.5]:box('Perforation',(x,-.037,h),(.012,.002,.025),rubber,.001)
for side in [-1,1]:
 before=set(bpy.context.scene.objects)
 for j,h in enumerate([.16,.52,.88,1.24]):
  box('Pressed_shelf',(0,-.245,h),(2.06,.43,.028),white,.006);box('Shelf_price_rail',(0,-.46,h+.028),(2.07,.018,.056),white,.004)
  for k in range(11):
   x=-.91+k*.182;pack(x,-.25,h+.02,j*11+k,(j+k//4)%3)
   # Back row for real shelf density, partly hidden but visible from side.
   if k%2==0:pack(x,-.10,h+.02,j*11+k+3,(j+k//4)%3)
  for k in range(5):label(-.82+k*.40,-.471,h+.029,.17,.044,7+k,price=True)
 # Rotate the full second front, not just geometry origin.
 if side==1:
  bpy.context.view_layer.update()
  for o in set(bpy.context.scene.objects)-before:o.matrix_world=Matrix.Rotation(math.pi,4,'Z')@o.matrix_world
box('Category_header',(0,0,1.64),(2.08,.06,.15),wood,.012);label(0,-.034,1.64,2.0,.14,1,True);o=label(0,-.034,1.64,2.0,.14,1,True);o.matrix_world=Matrix.Rotation(math.pi,4,'Z')@o.matrix_world
finish('grocery_gondola')
# Low produce fixture, timber slats, actual crates, layered mixed fruit with stems and leaves.
box('Fruit_plinth',(0,0,.06),(1.94,.88,.12),metal,.012)
for x in [-.88,-.44,0,.44,.88]:box('Slatted_oak_front',(x,-.438,.34),(.40,.032,.49),wood,.012)
box('Crate_support',(0,0,.49),(1.97,.87,.08),walnut,.012)
for x in [-.89,.89]:box('Load_bearing_case_end',(x,0,.30),(.10,.83,.48),wood,.012)
box('Recessed_case_back',(0,.34,.30),(1.78,.05,.48),walnut,.009)
for i in range(4):
 cx=-.745+i*.495
 for sy in [-1,1]:box('Crate_rail',(cx,sy*.414,.62),(.47,.027,.21),wood,.006)
 for sx in [-1,1]:box('Crate_end',(cx+sx*.237,0,.62),(.026,.82,.21),wood,.006)
 for j in range(4):
  for k in range(3):
   x=cx+(k-1)*.136;y=-.27+j*.17;z=.60+.025*((j+k)%2)
   bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,location=(x,y,z));o=bpy.context.object;o.name='Fresh_fruit';o.scale=(.065,.060,.068 if i%2 else.074);o.data.materials.append(colors[i%3])
   for face in o.data.polygons:face.use_smooth=True
   tube('Fruit_stem',[(x,y,z+.055),(x+.007,y,z+.082)],.003,walnut)
 label(cx,-.457,.56,.27,.075,i,price=True)
finish('produce_island')
# Refrigerated multideck, luminous canopy, bottle/cup products, vent toe and proper handles.
box('Insulated_refrigerator_back',(0,.32,1.08),(2.08,.09,2.10),white,.025)
for x in [-1.,1.]:box('Rounded_case_end',(x,0,1.08),(.08,.73,2.10),white,.025)
box('Cooling_base',(0,0,.12),(2.08,.73,.24),metal,.018)
for i in range(30):box('Air_intake_slot',(-.92+i*.064,-.373,.13),(.028,.009,.115),rubber,.003)
for j,h in enumerate([.34,.76,1.18,1.60]):
 box('Chilled_shelf',(0,0,h),(1.95,.58,.028),white,.006)
 box('Shelf_price_strip',(0,-.30,h+.025),(1.96,.023,.046),white,.003)
 for k in range(4):label(-.72+k*.48,-.313,h+.025,.20,.045,j*4+k,price=True)
 for k in range(12):pack(-.87+k*.158,-.12,h+.02,j*12+k,(j+1)%3)
box('Cooling_canopy',(0,0,2.03),(2.08,.74,.16),metal,.018);label(0,-.377,2.03,1.95,.15,2,True)
box('Underside_LED',(0,-.25,1.94),(1.9,.08,.014),white,.003)
finish('refrigerated_case')
# Health / cosmetic wall unit with label-facing packages and warm shelves.
box('Health_wall_joinery',(0,.21,1.05),(2.0,.04,2.1),white,.018)
for z in [.16,.56,.96,1.36,1.76]:
 box('Product_shelf',(0,-.02,z),(2.0,.48,.033),wood,.008)
 for j in range(11):pack(-.88+j*.17,-.11,z+.023,j+8,1 if j%3==0 else 0)
finish('health_wall_bay')
# A real bench integrated with end planting, all geometry inside inherited footprint.
planter=material('Cast_stone_planter',(.38,.39,.35),.83);leafm=[material('Leaf_satin_'+str(i),c,.77)for i,c in enumerate([(.075,.19,.085),(.12,.27,.10),(.20,.34,.14)])]
for yy in [-.20,-.067,.067,.20]:box('Bench_slatted_seat',(0,yy,.46),(1.34,.115,.055),wood,.016)
for z in [.65,.79,.93]:box('Bench_backrest',(0,.24,z),(1.34,.045,.10),wood,.015)
for x in [-.51,.51]:tube('Bench_steel_frame',[(x,-.23,.02),(x,-.23,.43),(x,.24,.43),(x,.24,.97)],.024,steel)
for x in [-.91,.91]:
 box('Planted_end_tub',(x,0,.28),(.35,.48,.56),planter,.04);box('Soil',(x,0,.565),(.30,.42,.018),walnut,.01)
 for j in range(18):
  a=j*2.399;rr=.11*(.4+(j%3)*.2);tip=(x+math.cos(a)*rr,math.sin(a)*.18,.70+(j%5)*.043)
  tube('Plant_stem',[(x,0,.57),tip],.004,leafm[j%3]);dx=.035;dy=.014
  mesh('Curved_lance_leaf',[(tip[0],tip[1],tip[2]-.04),(tip[0]+dx,tip[1]+dy,tip[2]),(tip[0],tip[1]+.035,tip[2]+.08),(tip[0]-dx,tip[1]+dy,tip[2])],[(0,1,2,3)],leafm[j%3])
finish('planted_bench')
print('V14_MODELS_COMPLETE',flush=True)
