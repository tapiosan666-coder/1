"""Canonical ownership and all-480 audit; geometric candidates never become approved architectural uses automatically."""
from pathlib import Path
import sys,math,numpy as np,collections
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
F=read(P/'source/v11/floors-updated.json');rows=[];spaces=[];corridors=[]
for f in F:
 S=unary_union([s['polygon']for s in f['stores']]);cores=unary_union([c['outline']for c in f['cores']]);public=f['public'];used=S.union(cores).union(public);unassigned=f['floor_plate'].difference(used)
 for i,g in enumerate(polys(unassigned)):
  if g.area<.05:continue
  p=g.representative_point();width=2*g.area/max(g.length,.001);touch=[s['id']for s in f['stores']if s['polygon'].distance(g)<.3]
  spaces.append({'id':f'{f["wing"]}-{f["label"]}-OWN-{i}','wing':f['wing'],'floor':f['label'],'world_x':p.x+429,'world_y':f['height'],'world_z':p.y-46,'area_m2':g.area,'hydraulic_width_m':width,'neighbors':touch,'geometry':g,'classification':'wall/poche candidate, inspect actual wall'if width<.45 else'purpose unresolved; not automatically storage or public passage','status':'REVIEW'})
 for s in f['stores']:
  coords=list(max(polys(s['polygon']),key=lambda p:p.area).exterior.coords)[:-1];edges=[];angles=[]
  for i,p in enumerate(coords):
   a=np.array(coords[i-1])-p;b=np.array(coords[(i+1)%len(coords)])-p;edges.append(float(np.linalg.norm(b)))
   if np.linalg.norm(a)*np.linalg.norm(b)>1e-10:
    orientation=1 if max(polys(s['polygon']),key=lambda p:p.area).exterior.is_ccw else -1
    angles.append((-orientation*math.degrees(math.atan2(float(a[0]*b[1]-a[1]*b[0]),float(np.dot(a,b)))))%360)
  r=s['polygon'].minimum_rotated_rectangle;e=list(r.exterior.coords);dims=sorted([math.dist(e[0],e[1]),math.dist(e[1],e[2])]);entry=Point(s['entry']);door=float(s.get('door_width_m',2.4));n=np.array(s['n']);u=np.array(s['u']);q=np.array(s['entry']);p1=Point(q+n*.9);p2=Point(q-n*.9);inside=n if s['sales'].distance(p1)<s['sales'].distance(p2)else-n;outside=Point(q-inside*1.0);status=[]
  if min(edges)<.25:status.append('SHORT_EDGE')
  if min(angles)<35:status.append('ACUTE_CORNER')
  if dims[0]<3.5:status.append('THIN_PLOT')
  if public.distance(outside)>.5:status.append('ENTRY_TO_PUBLIC_REVIEW')
  rows.append({'id':s['id'],'wing':f['wing'],'floor':f['label'],'category':s['category'],'frontage_m':s.get('frontage_m',None),'depth_m':s.get('depth_m',None),'gross_m2':s['polygon'].area,'sales_m2':s['sales'].area,'backroom_m2':s['backroom'].area,'min_edge_m':min(edges),'min_angle_deg':min(angles),'min_rect_dims_m':dims,'entry_world':[q[0]+429,f['height'],q[1]-46],'door_width_m':door,'entry_public_distance_m':public.distance(outside),'flags':status,'open_roof_use':f['level']==3,'human_walk_verified':False})
 # Candidate strip detector: report geometry and keep declared routes rather than filling alleys.
 strip=S.buffer(.65,join_style=2).buffer(-.65,join_style=2).difference(S).intersection(f['floor_plate'])
 for i,g in enumerate(polys(strip)):
  if g.area<.08:continue
  p=g.representative_point();is_public=public.intersection(g).area>.02;corridors.append({'id':f'{f["wing"]}-{f["label"]}-NARROW-{i}','geometry':g,'area_m2':g.area,'world':[p.x+429,f['height'],p.y-46],'neighbors':[s['id']for s in f['stores']if s['polygon'].distance(g)<.03],'declared_public':is_public,'action':'Preserve registered customer access; visual check'if is_public else'Ownership/common-wall generation review, do not add a cover wall'})
a=next(f for f in F if f['wing']=='A'and f['level']==0);pt=Point(393.2-429,-51.4+46);near=sorted(a['stores'],key=lambda s:s['polygon'].distance(pt))[:2];point={'world':[393.2,0,-51.4],'declared_public':a['public'].covers(pt),'nearest_stores':[s['id']for s in near],'width_between_store_boundaries_m':sum(s['polygon'].distance(pt)for s in near),'decision':'Do not seal: approximately 4m declared customer cross-passage. Verify its endpoints and native screen; signage/display should explain the connection.','native_visual_review_pending':True}
write(P/'source/v15/store-inventory.json',rows);write(P/'source/v15/unassigned-space-audit.json',spaces);write(P/'source/v15/narrow-space-audit.json',corridors);write(P/'source/v15/A-reported-point.json',point)
head=['id','wing','floor','category','frontage_m','depth_m','gross_m2','sales_m2','backroom_m2','min_edge_m','min_angle_deg','door_width_m','entry_public_distance_m','flags'];csvwrite(P/'source/v15/store-inventory.csv',head,[[str(r[k])for k in head]for r in rows]);print('V15_INVENTORY',len(rows),'stores',sum(bool(r['flags'])for r in rows),'flagged candidates',len(spaces),'ownership components',len(corridors),'narrow candidates');print(point)
