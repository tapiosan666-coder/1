"""Role-based specialist bays inserted only into validated vacant sales floor; inherited sellable areas and main aisles unchanged."""
from pathlib import Path
import sys,numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import constrained_delaunay_triangles
F=read(P/'source/v11/floors-updated.json');lookup={s['id']:(f,s)for f in F for s in f['stores']};scene=read(P/'source/v12/scene-art.json');layouts={s['id']:s for s in read(P/'source/v12/retail-layouts.json')};instances=[];rows=[];M={};coll={};render_group=''
def pos(x,y,z):return[float(x+429),float(y),float(z-46)]
exec((P/'authoring/mesh_primitives.py').read_text())
programs=[('C1F-CW-1','apparel_fitting_room',(2.02,1.78),2.36,'Fitting suite with opaque enclosure, mirror, stool and parked curtain','rear'),('A1F-007','book_magazine_display',(1.58,.75),1.38,'Face-out magazine/new release department, separate from spine browsing','front'),('B1-030','beauty_tester_bar',(2.4,.90),1.77,'Consultation and seated tester service','front'),('B1-N03','electronics_media_demo',(2.88,.72),2.35,'TV/audio demonstration and concealed cable cabinet','rear'),('C1F-CSW-3','cafe_barista_station',(2.48,.90),1.55,'Barista preparation separate from customer seating','rear'),('A1F-001','grocery_checkout_lane',(3.0,.86),1.55,'Conveyor checkout and operator service zone','front')]
programs.append(('C1F-CW-1','apparel_window_mannequin',(.80,.80),1.80,'Entrance outfit presentation / sculpted display mannequin','front'))
for sid,asset,dim,h,role,zone in programs:
 f,s=lookup[sid];e=np.asarray(s['entry']);u=np.asarray(s['u']);n=np.asarray(s['n']);sales=s['sales'];occupied=[]
 for i in scene['instances']+instances:
  if i['group']!=sid or i.get('max_xz')is None:continue
  occupied.append(rect((i['p'][0]-429,i['p'][2]+46),i['u'],*i['max_xz']))
 main=LineString(s.get('main_route',[e.tolist(),(e+n*5).tolist()]));keep=main.buffer(1.1,cap_style=2,join_style=2).union(rect(e,u,s.get('door_width_m',2.4)+1.2,3.2));safe=sales.buffer(-.30,join_style=2).difference(keep);coords=np.concatenate([np.asarray(p.exterior.coords)for p in polys(sales)]);local=coords-e;ts=local@u;ds=local@n;candidates=[]
 for dd in np.arange(max(3.8,min(ds)+1.5),max(ds)-.8,.55):
  for tt in np.arange(min(ts)+1.2,max(ts)-1.0,.55):
   c=e+n*dd+u*tt;fp=rect(c,u,*dim)
   if safe.covers(fp)and all(fp.distance(q)>=1.05 for q in occupied):candidates.append((dd,abs(tt),c,fp))
 if not candidates:rows.append({'id':sid,'asset':asset,'status':'NOT_PLACED','reason':'No sufficiently clear bay, no forced insertion'});continue
 # Rear service bay vs entrance department. Keep clear path on at least three sides.
 best=min(candidates,key=lambda x:(-x[0]if zone=='rear'else x[0],x[1]));dd,tt,c,fp=best;nn=-n if zone=='rear'else n
 instances.append({'asset':'../v15/models/'+asset,'p':pos(c[0],f['height'],c[1]),'u':u.tolist(),'front':nn.tolist(),'group':sid,'max_xz':list(dim),'target_height':None,'foliage_only':False});render_group='V15-RETAIL-'+sid
 # Proxy shares exact occupied bay; open fitting room has walls only, not a filled inaccessible box.
 if asset=='apparel_fitting_room':
  for t in[-.98,.98]:extrude(rect(c+u*t,u,.065,1.70),f['height'],2.36,'v12_fixture_proxy',True)
  extrude(rect(c-nn*.82,u,1.99,.065),f['height'],2.36,'v12_fixture_proxy',True)
 else:extrude(fp,f['height'],min(h,1.15),'v12_fixture_proxy',True)
 rows.append({'id':sid,'asset':asset,'industry':s['category'],'status':'PLACED','role':role,'world':pos(c[0],f['height'],c[1]),'footprint':fp,'declared_max_xz':dim,'height':h,'closest_existing_fixture_m':min([fp.distance(q)for q in occupied],default=None),'primary_aisle_reserved_width_m':2.2,'sales_area_unchanged_m2':sales.area,'human_playtest':False})
 print('V15_ROLE_BAY',sid,asset,'placed',flush=True)
# Proxy collision only, actual visible Blender mesh is loaded by the same retail batching system.
save_zst(P/'assets/v15/retail-services.pack.zst',{'surfaces':{},'colliders':coll,'signs':[],'lights':[]});write(P/'source/v15/retail-services.json',{'instances':instances,'signs':[],'lights':[]});write(P/'source/v15/retail-layouts.json',rows)
