from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parents[1];out=P/'assets/v14/materials/price-labels.png';im=Image.new('RGB',(1024,512),'#fff9e9');d=ImageDraw.Draw(im);font='/workspace/1/assets/fonts/NotoSansCJKjp-Regular.otf'
f=lambda n:ImageFont.truetype(font,n)
for i in range(16):
 x=i%4*256;y=i//4*128;d.rectangle((x+3,y+3,x+252,y+124),outline='#d0c8b6',width=2);d.text((x+12,y+5),['本日のおすすめ','毎日の定番','こだわりの品質','旬のセレクト'][i%4],font=f(15),fill='#334c3c');d.text((x+15,y+32),'¥ '+str([198,298,348,498,218,158,398,548][i%8]),font=f(40),fill='#283d32');d.text((x+15,y+93),'税込 / F Y  M A R K E T',font=f(12),fill='#6a6b5c')
im.save(out,optimize=True);print(out)
