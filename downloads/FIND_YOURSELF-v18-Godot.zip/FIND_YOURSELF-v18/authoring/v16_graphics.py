from pathlib import Path
import json,math
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parents[1];D=P/'assets/v16/signs';D.mkdir(exist_ok=True)
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';bold='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
labels={
'information':('ご案内','INFORMATION'), 'a_directory':('西の広場','ご案内・待ち合わせ\n休憩スペース\nM 館内マップ'), 'weekend_market':('暮らしの手しごと市','WEEKEND CRAFT MARKET'), 'a_street':('専門店街','お気に入りを見つける\nお買い物・お食事\nM 館内マップ'), 'book_launch':('本と、ひと息。','新刊・暮らし・旅\n読書と待ち合わせ'), 'cinema_tickets':('TICKET','上映案内・発券'), 'cinema_poster':('星を旅する','ORIGINAL CINEMA\nここから、別の世界へ'), 'arcade':('PLAY & SMILE','カプセルトイ\nゲーム・アミューズメント'),
'aichi_hero':('あいち 食と手しごと市','味わう。出会う。持ち帰る。\n味噌カツ / 手羽先 / きしめん / ひつまぶし\n常滑焼 / 瀬戸焼 / 絞り染め'),
'food_miso_katsu':('八丁の小路','味噌カツ'), 'food_tebasaki':('手羽庵 つばめ','香ばしい手羽先'), 'food_kishimen':('麺処 しら波','つるり、きしめん'), 'food_hitsumabushi':('炭の葉','ひつまぶし'), 'food_uiro':('和菓子 つむぎ','彩りういろう'), 'food_ogura_toast':('喫茶 日和','小倉トースト'), 'craft_tokoname':('陶房 あかつち','常滑焼のある暮らし'), 'craft_seto':('瀬ノ音','瀬戸のうつわ'), 'craft_shibori':('青窓工房','絞り染めの布小物'), 'aichi_program':('あいちの市','食の屋台 6店\n手しごと 3店\n本日の催事\nF11 催事 ON / OFF'), 'garden':('ひかりの休憩所','植栽に囲まれてひと休み\n通路をあけてご利用ください'), 'season_exhibit':('季節のしつらえ','暮らしと手しごと'), 'directory':('館内ご案内','M 館内マップ\n現在地・店舗・共用設備'), 'dining':('お食事と休憩','DINING & RELAX'), 'kids_rules':('こもれび広場','こどもの遊び場\n保護者の方とご利用ください\n走り抜けにご注意ください'), 'dog_rules':('しっぽの庭','DOG RUN\n二重ゲートは一枚ずつ\nF ゲート開閉\n水・袋・休憩コーナー'), 'melon_brand':('こもれびメロンパン','焼きたてを、そらの下で。'), 'melon_menu':('焼きたて、いかが？','プレーン / チョコ / 抹茶\n窓口でご注文ください'), 'c_upper':('そらの回廊','店舗と中庭をつなぐデッキ\nM 館内マップ'), 'basement_food':('毎日の、おいしい。','青果・お惣菜\n既存食品売場のおすすめ'), 'repair_services':('くらしのサービス','修理・お受け取り\n既存サービス店舗'), 'basement_directory':('地下フロアご案内','お買い物・暮らしのサービス\n既存ロッカーは館内マップへ'), 'roof_terrace':('そらのテラス','屋上のお食事と休憩\n既存の床・店舗内でご利用ください'), 'es_transfer':('次の階へ','西広場 連続エスカレーター\n乗り継ぎは同じ広場内\nF6 未承認・敷地別案')}
records={b['tile']:(b['w'],b['h'])for b in json.load(open(P/'source/v16/commons.json'))['boards']};
for key,size in {'kids_rules':(.62,1.55),'melon_menu':(.62,1.55),'es_transfer':(.62,1.55)}.items():records.setdefault(key,size)
for key,(w,h)in records.items():
 if key=='aichi_original':continue
 W=1536 if w/h>2 else 768;H=round(W*h/w);H=min(1920,H);W=round(H*w/h)
 bg='#183d38'if key.startswith(('c_','dog','kids','melon'))else'#192d48'if key.startswith(('aichi','food_','craft_','season'))else'#eee8dc';fg='#f6efdb'if bg!='#eee8dc'else'#203a38';gold='#c8a66b'
 im=Image.new('RGB',(W,H),bg);d=ImageDraw.Draw(im);margin=max(10,round(min(W,H)*.07));d.rectangle((margin,margin,W-margin,H-margin),outline=gold,width=max(2,margin//8));title,body=labels[key]
 fs=min(int(H*.30),int((W-margin*3)/max(1,len(title))))
 if H>W:fs=int(W*.085)
 ft=ImageFont.truetype(bold,max(18,fs));fb=ImageFont.truetype(font,max(13,int(fs*.48)))
 lines=body.split('\n');th=fs*1.5;bh=len(lines)*fb.size*1.65;top=(H-th-bh)/2
 if H>W:
  d.text((W/2,H*.09),'FIND YOURSELF',font=fb,anchor='mt',fill=gold);top=H*.29
 d.text((W/2,top),title,font=ft,anchor='mt',fill=fg)
 for i,t in enumerate(lines):d.text((W/2,top+th+i*fb.size*1.65),t,font=fb,anchor='mt',fill=fg)
 if H>W:d.text((W/2,H*.90),'M  館内マップ',font=fb,anchor='mt',fill=gold)
 im.save(D/(key+'.png'),optimize=True)
print('V16_ORIGINAL_SIGN_TILES',len(records))
