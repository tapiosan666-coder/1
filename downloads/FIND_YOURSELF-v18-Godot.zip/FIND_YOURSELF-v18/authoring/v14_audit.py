"""Check protected v13 architecture/data and quantify quality-update scope. Plan and physics are separate."""
from pathlib import Path
import json,hashlib,collections
P=Path(__file__).resolve().parents[1];B=Path('/workspace/FIND_YOURSELF-Site-v13')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=[p for p in B.rglob('*.pack.zst')if'evidence'not in p.parts]+[B/n for n in ['player.gd','escalator_v2.gd','elevators_v11.gd','staff_doors.gd','settings_v7.gd']]+list((B/'source/v13').glob('*.json'))
checks=[{'path':str(f.relative_to(B)),'sha256':sha(f),'unchanged':(P/f.relative_to(B)).exists()and sha(f)==sha(P/f.relative_to(B))}for f in files]
assert all(r['unchanged']for r in checks)
bounds=load(P/'source/v14/asset-bounds.json');affected=collections.Counter();byfloor=collections.Counter()
for n in ['source/v12/scene-art.json','source/v13/amenities-public.json','source/v13/basement-retail.json','source/v13/roof-retail.json']:
 for d in load(P/n)['instances']:
  if d['asset']in bounds:affected[d['asset']]+=1
roof=load(P/'source/v14/roof-planting.json');types=[]
for asset,d in bounds.items():
 types.append({'old_asset':asset,'new_asset':d['replacement'],'instances':affected[asset],'old_size_m':d['old']['size'],'raw_new_size_m':d['new']['size'],'normalization_scale':[a/b for a,b in zip(d['old']['size'],d['new']['size'])],'original_bounds_manifest_sha256':d['old']['sha256'],'new_sha256':sha(P/d['replacement'].replace('res://',''))})
out={'version':'v14','source':'protected v13','original_game_modified':False,'all_architecture_and_collision_packs_unchanged':True,'checks':checks,'replacement_types':types,'replacement_placements':sum(affected.values()),'additional_roof_plants':len(roof['instances']),'excluded_plant_candidates':len(roof['excluded_unsupported'])+len(roof.get('excluded_partial_bed',[])),'installed_raised_beds':len(roof.get('raised_beds',[])),'unsupported_whole_bed_excluded':1,'model_bounds_runtime_reports':'evidence/v14/*/v14-model-bounds-*.json; re-evaluated transformed meshes, tolerance 0.1mm','floors_retained':15,'store_IDs_retained':480,'RF_SUPPORT_16':'UNAPPROVED','C_option':'UNAPPROVED','site_ES_relocation':'UNAPPROVED','windows_GPU_FPS':'UNMEASURED','human_playtest':False,'quality_limit':'Visual representative review, not full-mall commercial or FF16 quality certification'}
(P/'source/v14/preservation-and-scope.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('V14_AUDIT',len(checks),'preserved resources',sum(affected.values()),'replaced placements',len(types),'types',len(roof['instances']),'plants')
