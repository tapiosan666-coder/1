from pathlib import Path
P=Path(__file__).resolve().parents[1];src=(P/'authoring/retail_models_v10.py').read_text();exec(src[:src.index('for var in range(3):bookcase')]);OUT=P/'assets/v14/models'
leafs=[material('Roof_botanical_leaf_'+str(i),c,.77)for i,c in enumerate([(.06,.18,.065),(.12,.29,.10),(.23,.36,.14)])]
for branch in range(12):
 a=branch*2.399;height=.47+.24*rng.random();end=Vector((math.cos(a)*.15,math.sin(a)*.15,height));tube('Botanical_woody_stem',[(0,0,0),end*.5,end],.004,walnut)
 for j in range(7):
  t=.20+j*.105;base=end*t;angle=a+j*2.399;axis=Vector((math.cos(angle),math.sin(angle),.5));axis.normalize();side=Vector((-math.sin(angle),math.cos(angle),0));length=.10+.015*(j%3);tip=base+axis*length
  vv=[tuple(base),tuple(base+axis*length*.45+side*.034),tuple(base+axis*length*.62+Vector((0,0,.012))),tuple(tip),tuple(base+axis*length*.45-side*.034)];mesh('Folded_living_leaf',vv,[(0,1,2),(1,3,2),(3,4,2),(4,0,2)],leafs[(branch+j)%3])
finish('roof_botanical')
