"""Original v16 functional mall furniture, event equipment and outdoor facilities.
Authored in metres around a fixed ground origin. No reference-image pixels are used.
"""
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parents[1]
src=(P/'authoring/retail_models_v10.py').read_text().split('def book(')[0]
src=src.replace('assets/v10/wood-oak.png','assets/v16/textures/oak.png').replace('assets/v10/wood-walnut.png','assets/v16/textures/walnut.png').replace('assets/v8/book-spines.png','assets/v16/textures/shibori-original.png')
exec(src);OUT=P/'assets/v16/models';OUT.mkdir(exist_ok=True)
original_finish=finish
bounds_manifest={}
def finish(name):
 bpy.context.view_layer.update();points=[o.matrix_world@Vector(corner)for o in bpy.context.scene.objects if o.type in['MESH','CURVE']for corner in o.bound_box]
 lo=[min(v[i]for v in points)for i in range(3)];hi=[max(v[i]for v in points)for i in range(3)]
 bounds_manifest[name]={'min':[lo[0],lo[2],-hi[1]],'max':[hi[0],hi[2],-lo[1]],'fixed_origin':True,'unit':'metres'}
 (P/'source/v16/model-bounds.json').write_text(json.dumps(bounds_manifest,indent=2));original_finish(name)
cream=material('Warm_cream_enamel',(.78,.73,.60),.44);sage=material('Sage_powder_coat',(.18,.30,.24),.48,.12);indigo=material('Fair_indigo_canvas',(.035,.09,.18),.85);red=material('Fair_vermilion',(.53,.12,.075),.64);gold=material('Fair_ochre',(.75,.48,.15),.71);epdm=material('Playground_sunflower',(.81,.52,.14),.74);clay=material('Tokoname_clay',(.42,.14,.055),.82);blue=material('Seto_indigo_glaze',(.035,.13,.24),.18);leaf=material('Leaf_green',(.16,.30,.08),.85);bread=material('Melon_bread_crust',(.72,.44,.15),.67);crumb=material('Bread_scoring',(.46,.24,.065),.79);shibori=material('Original_shibori_pattern',(1,1,1),.95,texture='assets/v16/textures/shibori-original.png')
def upright_cylinder(name,loc,r,h,mat):return lathe(name,[(0,0),(r,0),(r,h),(0,h)],mat,loc,24)
def rail(a,b,r=.025,mat=metal):return tube('Fabricated_rail',[a,b],r,mat)
def sphere(name,loc,scale,mat,seg=16):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=seg,ring_count=8,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(mat)
 for f in o.data.polygons:f.use_smooth=True
 return o

def bench(x=0,y=0,w=2.4):
 for xx in[-w*.36,w*.36]:
  box('Bench_foot',(x+xx,y,.08),(.12,.60,.14),metal,.015);box('Bench_leg',(x+xx,y,.27),(.07,.46,.44),metal,.01)
 for i in range(6):box('Weatherproof_seat_slat',(x,y-.25+i*.10,.48),(w,.075,.055),wood,.014)
 for i in range(4):box('Weatherproof_back_slat',(x,y+.28,.63+i*.105),(w,.05,.078),wood,.012)
 for side in[-1,1]:tube('Arm_rest',[(x+side*(w/2-.12),y+.26,.57),(x+side*(w/2-.12),y+.25,.78),(x+side*(w/2-.12),y-.22,.77)],.025,metal)
bench();finish('outdoor_bench')
# Curved visitor information counter with separate staff access and brochure bays.
for xx in[-1.2,0,1.2]:lathe('Counter_pedestal',[(0,0),(.45,0),(.48,.06),(.43,.88),(.48,.96),(0,.96)],wood,(xx,0,0))
box('Curved_edge_counter',(0,0,.97),(3.45,1.16,.09),stone,.10)
for i in range(31):box('Vertical_counter_fluting',(-1.62+i*.108,-.49,.48),(.046,.065,.83),walnut,.01)
for side in[-1,1]:
 box('Visitor_terminal_stalk',(side*.89,.16,1.13),(.04,.05,.30),metal,.004);o=box('Visitor_terminal',(side*.89,.12,1.33),(.39,.08,.26),metal,.012);o.rotation_euler.x=math.radians(14)
for i in range(4):box('Brochure_holder',(-.42+i*.28,-.18,1.08),(.22,.18,.19),brass,.007);box('Original_brochures',(-.42+i*.28,-.19,1.16),(.17,.025,.23),paper,.002)
finish('information_counter')
# Seating island: curved joinery and an open planting bowl; foliage placed separately.
lathe('Planter_body',[(0,0),(.72,0),(.84,.12),(.84,.64),(.77,.70),(.66,.70),(.66,.61),(0,.61)],stone,(-.85,0,0),48)
lathe('Planter_soil',[(0,0),(.65,0),(.65,.03),(0,.03)],walnut,(-.85,0,.61),40)
for i in range(24):
 a=-math.pi*.55+i*math.pi*1.1/23;xx=-.85+1.20*math.cos(a);yy=1.20*math.sin(a);o=box('Radial_bench_slat',(xx,yy,.46),(.66,.095,.065),wood,.014);o.rotation_euler.z=a
for a in[-1.25,-.4,.4,1.25]:upright_cylinder('Seat_leg',(-.85+1.20*math.cos(a),1.20*math.sin(a),.05),.045,.39,metal)
finish('planted_seating_island')
# Pavilion shade structures are light furniture studies, not certified structural designs.
for x in[-2.75,2.75]:
 for y in[-1.65,1.65]:box('Pergola_baseplate',(x,y,.025),(.28,.28,.05),metal,.015);box('Pergola_column',(x,y,1.56),(.15,.15,3.1),wood,.018)
for y in[-1.65,1.65]:box('Pergola_main_beam',(0,y,3.10),(5.9,.18,.22),wood,.022)
for x in np.linspace(-2.8,2.8,19):
 o=box('Pergola_sun_louvre',(x,0,3.25),(.085,3.65,.15),cream,.012);o.rotation_euler.y=.30
finish('terrace_pergola')
# Outdoor cafe set with open space between each seat.
lathe('Table_stem',[(0,0),(.32,0),(.32,.06),(.06,.10),(.06,.73),(.53,.73),(.53,.78),(0,.78)],sage)
for ang in[0,math.pi/2,math.pi,math.pi*1.5]:
 x,y=1.04*math.cos(ang),1.04*math.sin(ang)
 for dx in[-.17,.17]:
  for dy in[-.17,.17]:rail((x+dx,y+dy,.03),(x+dx,y+dy,.46),.017)
 lathe('Outdoor_chair_seat',[(0,0),(.25,0),(.25,.045),(0,.045)],wood,(x,y,.46),24)
 pts=[(x+.25*math.cos(a),y+.25*math.sin(a),.90)for a in np.linspace(ang-math.pi*.45,ang+math.pi*.45,12)];tube('Curved_chair_back',pts,.03,sage)
for i in range(2):lathe('Cafe_cup',[(0,0),(.045,0),(.055,.09),(.045,.095),(.04,.02),(0,.02)],white,(-.18+i*.32,0,.79),20)
finish('outdoor_table_set')
# Reusable event booth. The transaction counter and vendor bay are distinct.
def booth(canvas):
 for x in[-1.52,1.52]:
  for y in[-1.34,1.34]:upright_cylinder('Folding_canopy_pole',(x,y,0),.032,2.72,steel);box('Canopy_foot',(x,y,.025),(.17,.17,.05),metal,.008)
 verts=[(-1.68,-1.50,2.65),(1.68,-1.50,2.65),(1.68,1.50,2.65),(-1.68,1.50,2.65),(0,0,3.03)]
 mesh('Tensioned_canopy',verts,[(0,1,4),(1,2,4),(2,3,4),(3,0,4)],canvas)
 for y in[-1.5,1.5]:box('Canopy_valance',(0,y,2.55),(3.36,.025,.23),canvas,.004)
 box('Modular_sales_counter',(0,-.91,.47),(2.72,.74,.94),wood,.025);box('Counter_food_safe_top',(0,-.91,.97),(2.84,.83,.06),stone,.018)
 for x in[-1.28,1.28]:box('Food_guard_post',(x,-1.22,1.20),(.025,.025,.42),steel,.003)
 box('Food_display_guard',(0,-1.22,1.19),(2.55,.008,.40),glass,.002)
 box('Vendor_rear_prep',(0,1.0,.48),(2.2,.50,.96),steel,.016)
booth(indigo);finish('fair_food_booth')
booth(gold)
for x in[-.85,0,.85]:
 for z in[1.2,1.6,2.0]:box('Craft_wall_shelf',(x,1.12,z),(.75,.30,.035),wood,.005)
finish('fair_craft_booth')
# Temporary stage with a framed screen and small practical access steps.
box('Stage_deck',(0,0,.16),(7.8,3.8,.32),metal,.04);box('Stage_finished_top',(0,0,.33),(7.82,3.82,.025),wood,.008)
for x in[-3.6,3.6]:
 for xx in[-.11,.11]:rail((x+xx,1.60,.34),(x+xx,1.60,3.95),.033,steel)
 for zz in np.arange(.5,3.8,.35):rail((x-.11,1.60,zz),(x+.11,1.60,zz+.30),.012,steel)
rail((-3.7,1.60,3.95),(3.7,1.60,3.95),.05,steel)
box('Stage_screen_frame',(0,1.53,2.40),(6.1,.15,2.75),metal,.04)
for i in range(5):upright_cylinder('Compact_LED_par',( -2.8+i*1.4,1.44,3.58),.085,.17,metal)
for j in range(2):box('Stage_step',(-3.2,-2.08-j*.30,.08*(2-j)),(1.0,.35,.16*(2-j)),metal,.015)
finish('fair_stage')
# Distinct food products, not the same generic shelf in every booth.
def plate(r=.22):lathe('Glazed_serving_plate',[(0,0),(r*.7,0),(r,.025),(r,.045),(r*.8,.055),(0,.055)],white,steps=32)
plate()
for i in range(6):box('Miso_glazed_cutlet',(-.14+i*.055,0,.083),(.045,.20,.054),pastry,.014);box('Miso_sauce',(-.14+i*.055,0,.113),(.042,.19,.006),walnut,.003)
for i in range(13):tube('Shredded_cabbage',[(.10+i*.005,.09,.08),(.16,.14,.14),(.08,.19,.11)],.006,leaf)
finish('dish_miso_katsu')
plate()
for i in range(5):
 a=i*1.2;x=.11*math.cos(a);y=.11*math.sin(a);o=sphere('Glazed_chicken_wing',(x,y,.09),(.10,.035,.035),pastry);o.rotation_euler.z=a;rail((x,y,.09),(x+.10*math.cos(a),y+.10*math.sin(a),.08),.017,bread)
finish('dish_tebasaki')
lathe('Noodle_bowl',[(0,0),(.13,0),(.14,.02),(.22,.16),(.225,.18),(.21,.18),(.12,.04),(0,.04)],blue)
lathe('Amber_dashi',[(0,0),(.19,0),(.19,.006),(0,.006)],pastry,(0,0,.14),32)
for i in range(10):
 pts=[(-.14+j*.035,.045*math.sin(j*.9+i)+i*.012-.06,.155+.008*math.sin(j+i))for j in range(9)];tube('Broad_kishimen_ribbon',pts,.009,paper)
for i in range(9):box('Chopped_green_onion',(-.08+i*.016,.02,.17),(.014,.014,.01),leaf,.002)
finish('dish_kishimen')
box('Lacquer_unagi_box',(0,0,.045),(.37,.28,.09),red,.025);box('Steamed_rice',(0,0,.09),(.32,.23,.035),paper,.012)
for i in range(6):box('Grilled_eel_piece',(-.13+i*.052,0,.13),(.045,.21,.038),pastry,.009);box('Eel_glaze_ridge',(-.13+i*.052,0,.151),(.016,.20,.005),walnut,.003)
finish('dish_hitsumabushi')
plate(.24)
for i,c in enumerate([paper,sage,red]):
 for j in range(3):box('Steamed_uiro',(-.14+i*.13,-.085+j*.083,.085),(.115,.07,.08),c,.01)
finish('dish_uiro')
plate()
box('Toast_crust',(0,0,.07),(.27,.25,.085),pastry,.035);box('Toast_crumb',(0,-.004,.09),(.245,.225,.065),bread,.027)
for i in range(18):sphere('Sweet_azuki_beans',((i%5)*.035-.07,(i//5)*.04-.06,.13),(.024,.021,.014),red,12)
box('Butter',(0,0,.16),(.065,.058,.02),cream,.005);finish('dish_ogura_toast')
# Craft examples.
lathe('Tokoname_teapot_body',[(0,0),(.12,0),(.15,.07),(.12,.16),(.075,.18),(0,.18)],clay,steps=40)
lathe('Teapot_lid',[(0,0),(.082,0),(.07,.025),(.02,.035),(.018,.05),(0,.05)],clay,(0,0,.18),32)
tube('Teapot_spout',[(.10,0,.08),(.18,0,.11),(.20,0,.17)],.025,clay);tube('Teapot_side_handle',[(0,.11,.09),(0,.19,.12),(0,.18,.17)],.024,clay);finish('craft_tokoname')
for i in range(3):lathe('Seto_nested_bowl',[(0,0),(.09,0),(.15,.10),(.16,.12),(.15,.12),(.085,.02),(0,.02)],white,(i*.25-.25,0,i*.018),32)
for i in range(12):
 a=i*math.tau/12;sphere('Original_blue_glaze_motif',(.151*math.cos(a),.151*math.sin(a),.10),(.008,.008,.008),blue,8)
finish('craft_seto')
for i in range(4):box('Folded_shibori_textile',(0,i*.025,i*.045+.03),(.43,.31,.06),shibori,.018)
finish('craft_shibori')
# Low play tower with real stairs, continuous curved slide and visible safety rails.
for x in[-1.25,1.25]:
 for y in[-1.05,1.05]:upright_cylinder('Play_tower_post',(x,y,0),.055,2.55,sage)
box('Play_platform',(0,0,1.18),(2.7,2.3,.12),wood,.025)
for y in[-1.05,1.05]:
 for x in np.arange(-1.2,1.25,.24):
  if abs(x)>.6:box('Play_guard_picket',(x,y,1.78),(.045,.045,1.05),cream,.006)
 rail((-1.3,y,2.30),(-.6,y,2.30),.036,sage);rail((.6,y,2.30),(1.3,y,2.30),.036,sage)
# Entry stairs behind tower.
for i in range(8):box('Child_scale_step',(0,1.30+i*.24,1.2-(i+1)*.15),(.95,.27,.15),wood,.015)
for side in[-1,1]:tube('Stair_hand_rail',[(side*.54,1.20,2.05),(side*.54,3.15,.80)],.028,sage)
verts=[];faces=[]
for j,t in enumerate(np.linspace(0,1,28)):
 y=-1.12-t*3.0;z=.13+1.10*(.5+.5*math.cos(t*math.pi))
 for x in[-.54,-.42,.42,.54]:verts.append((x,y,z+(.22 if abs(x)>.5 else 0)))
for j in range(27):
 for i in range(3):k=j*4+i;faces.append((k,k+1,k+5,k+4))
mesh('One_piece_moulded_slide',verts,faces,epdm)
for y,z in[(-1.1,2.50),(1.1,2.50)]:pass
mesh('Play_roof',[(-1.48,-1.25,2.55),(1.48,-1.25,2.55),(1.48,1.25,2.55),(-1.48,1.25,2.55),(0,0,3.03)],[(0,1,4),(1,2,4),(2,3,4),(3,0,4)],sage)
finish('kids_play_tower')
# A small rounded climbing pod provides a different play action.
for x in[-.70,.70]:
 for y in[-.70,.70]:upright_cylinder('Climb_pod_leg',(x,y,0),.05,.45,wood)
box('Climb_pod_deck',(0,0,.43),(1.65,1.65,.12),wood,.05)
for i in range(5):sphere('Colour_climbing_grip',(-.55+i*.25,-.83,.15+(i%2)*.20),(.09,.055,.06),[sage,epdm][i%2],12)
finish('kids_climb_pod')
# Shade sail: tensioned fabric with catenary edges and four anchored columns.
pts=[(-2.6,-2.2,3.1),(2.6,-2.2,3.8),(2.6,2.2,3.2),(-2.6,2.2,3.7)]
for x,y,z in pts:upright_cylinder('Sail_mast',(x,y,0),.055,z+.10,steel);box('Sail_anchor',(x,y,.03),(.28,.28,.06),metal,.012)
verts=[(x*.88,y*.88,z-.10)for x,y,z in pts]+[(0,0,3.15)];mesh('Tensioned_shade_sail',verts,[(0,1,4),(1,2,4),(2,3,4),(3,0,4)],cream);finish('shade_sail')
# Dog run fencing is open mesh, not a solid wall.
def fence(width=2.4,gate=False):
 x0=0 if gate else-width/2;x1=x0+width
 for x in[x0,x1]:upright_cylinder('Fence_post',(x,0,0),.035,1.28,metal)
 for z in[.12,1.16]:rail((x0,0,z),(x1,0,z),.022,metal)
 for x in np.arange(x0+.12,x1,.12):rail((x,0,.14),(x,0,1.16),.008,metal)
 for z in np.arange(.26,1.1,.14):rail((x0,0,z),(x1,0,z),.008,metal)
fence();finish('dog_fence_segment')
fence(1.2,True);box('Gate_handle',(1.05,-.035,.91),(.035,.13,.07),steel,.008);finish('dog_gate_leaf')
box('Dog_bag_dispenser',(0,0,1.04),(.36,.21,.55),sage,.035);upright_cylinder('Station_post',(0,0,0),.045,.85,metal)
box('Bag_pickup_slot',(0,-.115,.96),(.23,.015,.055),metal,.006);lathe('Dog_water_bowl',[(0,0),(.22,0),(.24,.10),(.22,.13),(.19,.04),(0,.04)],steel,(.50,0,.04),32)
tube('Drinking_spout',[(.75,.15,.0),(.75,.15,.40),(.53,.04,.42)],.025,steel);finish('dog_service_station')
# Purpose-built stop-service food truck. No real vehicle or commercial branding.
box('Truck_chassis',(-.1,0,.49),(5.6,1.92,.20),metal,.06);box('Service_body',(-.65,0,1.61),(4.20,2.10,2.18),cream,.17)
# Remove the service side centre from the opaque shell by modelling actual separate wall pieces.
for o in list(bpy.context.scene.objects):
 if o.name.startswith('Service_body'):bpy.data.objects.remove(o,do_unlink=True)
box('Truck_rear_wall',(-2.73,0,1.63),(.10,2.10,2.15),cream,.03);box('Truck_roof',(-.65,0,2.72),(4.25,2.12,.15),cream,.07);box('Truck_far_wall',(-.65,1.03,1.62),(4.20,.08,2.08),sage,.035)
box('Service_sill',(-.65,-1.03,.91),(4.20,.08,.75),sage,.03);box('Service_header',(-.65,-1.03,2.52),(4.20,.08,.34),cream,.03)
for x in[-2.68,1.40]:box('Service_side_post',(x,-1.03,1.72),(.10,.10,1.48),cream,.02)
box('Cab_lower',(2.10,0,.91),(1.48,2.02,.83),sage,.19);box('Cab_roof',(2.02,0,2.35),(1.58,2.04,.16),cream,.08)
mesh('Slanted_windscreen',[(2.76,-.90,1.38),(2.76,.90,1.38),(2.56,.90,2.25),(2.56,-.90,2.25)],[(0,1,2,3)],glass)
for side in[-1,1]:
 box('Cab_pillar',(1.36,side*.98,1.85),(.10,.08,.90),cream,.02);mesh('Cab_side_window',[(1.43,side*1.01,1.48),(2.70,side*1.01,1.48),(2.54,side*1.01,2.25),(1.43,side*1.01,2.25)],[(0,1,2,3)],glass)
 box('Door_handle',(1.76,side*1.04,1.22),(.20,.035,.035),steel,.008)
 for xx in[-1.75,1.95]:
  o=lathe('Rubber_tyre',[(.20,-.14),(.36,-.14),(.40,-.08),(.40,.10),(.35,.16),(.20,.16)],rubber,steps=40);o.matrix_world=Matrix.Translation((xx,side*.98,.43))@Matrix.Rotation(math.pi/2,4,'X')
  o=lathe('Wheel_hub',[(0,0),(.24,0),(.24,.045),(0,.045)],steel,steps=32);o.matrix_world=Matrix.Translation((xx,side*1.13,.43))@Matrix.Rotation(math.pi/2,4,'X')
 for i in range(2):box('Front_headlamp',(2.80,side*.66,.93),(.05,.31,.16),white,.045)
box('Bumper',(2.86,0,.62),(.18,2.05,.17),steel,.06)
box('Sales_counter',(-.63,-1.12,1.25),(3.80,.42,.09),wood,.03)
o=box('Raised_service_hatch',(-.63,-1.40,2.46),(3.92,1.12,.07),cream,.045);o.rotation_euler.x=math.radians(12)
for x in[-2.47,1.21]:rail((x,-1.04,1.98),(x,-1.85,2.46),.014,steel)
box('Baking_oven',(-1.50,.44,1.34),(1.0,.73,1.32),steel,.05);box('Oven_glass',(-1.50,.065,1.40),(.81,.015,.54),glass,.015)
for z in[1.22,1.47,1.72]:box('Baking_tray',(-1.50,.32,z),(.75,.48,.035),metal,.006)
box('Interior_prep',(.35,.41,1.04),(1.50,.70,.08),steel,.02)
box('Roof_vent',(-.90,0,2.92),(.72,.62,.27),steel,.045)
for i in range(9):box('Vent_louvre',(-1.18+i*.07,-.32,2.93),(.025,.035,.17),metal,.003)
finish('melon_food_truck')
# Melon bread shows the scored biscuit crust rather than a generic sphere.
lathe('Melon_pan_dome',[(0,0),(.095,0),(.115,.035),(.105,.080),(.075,.115),(.025,.135),(0,.137)],bread,steps=32)
for side in[-1,1]:
 for off in[-.065,-.025,.025,.065]:
  pts=[]
  for t in np.linspace(-.085,.085,18):
   x=t;y=off+side*t*.6;r2=x*x+y*y
   if r2<.0105:pts.append((x,y,.035+.10*math.sqrt(max(0,1-r2/.013))))
  if len(pts)>1:tube('Biscuit_crust_scoring',pts,.0028,crumb)
finish('melon_bread')
# Produce has angled crates and distinct varieties, with a clear customer side.
for i in range(3):
 x=-.76+i*.76;box('Produce_crate',(x,0,.57),(.70,1.04,.88),wood,.02);o=box('Sloped_crate_bottom',(x,-.02,1.04),(.66,.94,.045),walnut,.008);o.rotation_euler.x=math.radians(-12)
 for j in range(20):
  px=x-.25+(j%4)*.16;py=-.35+(j//4)*.16;z=1.09+py*.19
  if i==0:sphere('Citrus',(px,py,z),(.067,.067,.064),gold,12)
  elif i==1:sphere('Green_apple',(px,py,z),(.066,.068,.070),leaf,12)
  else:sphere('Red_produce',(px,py,z),(.065,.060,.060),red,12)
finish('produce_market_bay')
box('Deli_case_carcass',(0,0,.49),(2.4,.96,.98),wood,.045);box('Deli_chilled_deck',(0,0,1.00),(2.30,.88,.05),steel,.015)
for x in[-1.18,1.18]:box('Deli_glass_side',(x,0,1.31),(.012,.91,.59),glass,.006)
o=box('Deli_front_glass',(0,-.44,1.29),(2.35,.012,.57),glass,.003);o.rotation_euler.x=-.12;box('Deli_case_top',(0,0,1.60),(2.42,.96,.05),steel,.015)
for i in range(4):
 x=-.85+i*.57;box('Food_display_tray',(x,0,1.055),(.51,.60,.035),white,.012)
 for j in range(9):sphere('Prepared_food',(x-.15+(j%3)*.14,-.19+(j//3)*.18,1.10),(.055,.064,.035),[leaf,gold,pastry,red][i],12)
finish('deli_refrigerated_showcase')
# Service / repair, not a duplicate food market in the C basement.
box('Repair_counter',(0,0,.49),(2.8,.87,.98),wood,.045);box('Repair_worktop',(0,0,1.00),(2.9,.95,.065),stone,.03)
for i in range(3):box('Received_parcel',(-.88+i*.44,.10,1.16),(.36,.31,.27),cream,.008);box('Parcel_label',(-.88+i*.44,-.06,1.18),(.20,.005,.10),paper,.002)
for i in range(5):box('Repair_tool_handle',(.65+i*.11,-.12,1.06),(.045,.19,.034),sage,.012);rail((.65+i*.11,-.22,1.06),(.65+i*.11,-.34,1.06),.009,steel)
finish('repair_pickup_counter')
# Freestanding visitor information / advertising display.
box('Pylon_base',(0,0,.04),(.86,.54,.08),metal,.035);box('Slim_signage_body',(0,0,1.18),(.74,.17,2.27),metal,.07);box('Screen_bezel',(0,-.095,1.32),(.65,.015,1.61),brass,.03);finish('digital_info_pylon')
# Capsule toys belong at the existing amusement storefront.
box('Capsule_machine_base',(0,0,.52),(.60,.55,1.04),cream,.045);sphere('Transparent_capsule_drum',(0,0,1.18),(.29,.25,.32),glass,24)
for i in range(16):a=i*2.4;r=.17*((i%3+1)/3);sphere('Toy_capsule',(r*math.cos(a),r*math.sin(a),1.10+(i%4)*.065),(.047,.047,.047),[sage,gold,red,blue][i%4],12)
box('Coin_slot',(0,-.29,.79),(.09,.02,.035),metal,.008);o=lathe('Turn_handle',[(0,0),(.055,0),(.055,.035),(0,.035)],steel);o.matrix_world=Matrix.Translation((0,-.30,.82))@Matrix.Rotation(math.pi/2,4,'X')
box('Toy_pickup_hatch',(0,-.286,.40),(.37,.015,.21),metal,.025);finish('capsule_toy_machine')
# Ticket machine / ATM are graphic panels on an actual equipment cabinet.
box('Kiosk_foot',(0,0,.04),(.72,.58,.08),metal,.045);box('Ticket_machine_body',(0,0,.82),(.64,.46,1.58),cream,.07);box('Ticket_screen_bezel',(0,-.245,1.15),(.52,.025,.47),metal,.025);box('Card_reader',( .17,-.28,.77),(.16,.09,.12),metal,.014);box('Receipt_slot',(-.10,-.25,.59),(.27,.015,.027),metal,.004);finish('cinema_ticket_kiosk')
print('V16_MODELS_DONE',flush=True)
