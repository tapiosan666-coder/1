# FIND YOURSELF v11 比較・検証資料

最初に `FIND_YOURSELF-v11-実画面比較.pdf` を開くと、13視点の修正前後とC館未承認案を確認できます。原寸の実Godot PNGは `screenshots`、詳細な変更・未完成箇所は `変更内容と残課題.md` にあります。

- `plans`：15層の図面、入口変更、EV構成、ES乗り継ぎ案、C館構造案。Godot画像ではなく設計図です。
- `design-data`：480店舗の面積・業種・形状台帳、入口と実3D開口の差、座標、境界残余、床データ、未承認案。
- `tests`：実衝突の自動歩行・F/M操作・高さトレース・ZIP展開検証・ソフトウェア描画測定。人間の操作とは区別します。
- `licenses`：既存素材とv11オリジナル制作の権利情報。新規の外部素材は取得していません。

ゲームを開くには、別の `FIND_YOURSELF-v11-Godot.zip` だけを展開してください。このReview ZIPは起動に不要です。Windows EXEや分割Dataはありません。Godot 4.6.3 Standardで project.godot を開きF5です。

## 再生成する場合のみ

`authoring-inputs/project-source/source` をGodotプロジェクトの source へコピーすると、起動に不要な履歴入力を復元できます。`FIND_YOURSELF_V10_BASELINE` に `authoring-inputs/v10` の絶対パスを指定し、同梱の authoring/v11_layout.py → v11_environment.py → v11_audit_and_plans.py → v11_guard_repair.py → v11_guard_finish_actual.py を実行します。Pythonのnumpy/shapely/zstandard、モデル再制作にはBlenderが必要です。RF-guard-missing.jsonは基準packから作成した調査結果を収録しています。通常起動にはこの工程は不要です。

60／144FPS、Windows実機、人間の実操作、FF16級の品質は未確認・未達です。全館の内装完成として扱いません。C館支持フレーム・ES移設は未施工、RF-SUPPORT-16は未承認です。
