extends Node3D
var player:CharacterBody3D
var font:Font
var manifest:Dictionary
var mats:Dictionary={}
var hud:Label
var frame_times:Array=[]
var results:Dictionary={}
var mode:String="interactive"
var preview:bool=false
var output:String="res://evidence"
var mesh_count:int=0
var start_usec:int=0
var animator:Node3D
var animation_capture:bool=false
var only_shot:String=""
var staff:Node3D
var brand_registry:Dictionary={}
var elevators:Node3D
var ui:CanvasLayer
var baseline:bool=false
var visual_v7:bool=false
var fitout:Dictionary={}
var showcase:Node
var with_context:bool=true
var context_only:bool=false
func v3(a:Array)->Vector3:return Vector3(a[0],a[1],a[2])
func read_json(p:String):return JSON.parse_string(FileAccess.get_file_as_string(p))
func load_geometry(path:String)->Dictionary:
 var raw=FileAccess.get_file_as_bytes(path).decompress_dynamic(1800000000,FileAccess.COMPRESSION_GZIP)
 if not path.ends_with(".pack.gz"):return JSON.parse_string(raw.get_string_from_utf8())
 var count=raw.decode_u32(4);var head:Dictionary=JSON.parse_string(raw.slice(8,8+count).get_string_from_utf8());var start=8+count
 for key:String in head.surfaces:
  for field:String in head.surfaces[key]:
   var slot:Array=head.surfaces[key][field];head.surfaces[key][field]=raw.slice(start+int(slot[0]),start+int(slot[0])+int(slot[1])).to_int32_array()if field=="i"else raw.slice(start+int(slot[0]),start+int(slot[0])+int(slot[1])).to_float32_array()
 for key:String in head.colliders:
  var slot:Array=head.colliders[key];head.colliders[key]=raw.slice(start+int(slot[0]),start+int(slot[0])+int(slot[1])).to_float32_array()
 return head
func _ready()->void:
 start_usec=Time.get_ticks_usec()
 for arg:String in OS.get_cmdline_user_args():
  if arg=="--capture":mode="capture"
  if arg=="--v7-visual":visual_v7=true
  if arg=="--benchmark-v8":mode="benchmark-v8"
  if arg=="--walk-v8":mode="walk-v8"
  if arg=="--baseline":
   push_error("v7 does not reconstruct the v6 comparison. Open the preserved v6 project for that baseline.");get_tree().quit(2);return
  if arg=="--no-context":with_context=false
  if arg=="--context-only":context_only=true
  if arg=="--preview":mode="capture";preview=true
  if arg=="--walk-test":mode="walk-test"
  if arg=="--vehicle-test":mode="vehicle-test"
  if arg=="--ui-test":mode="ui-test"
  if arg=="--animation":mode="animation"
  if arg.begins_with("--single="):only_shot=arg.trim_prefix("--single=")
  if arg.begins_with("--output="):output=arg.trim_prefix("--output=")
 DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(output))
 manifest=read_json("res://source/scene-manifest-before.json"if baseline else"res://source/scene-manifest.json")
 font=load("res://assets/NotoSansCJKjp-Regular.otf")
 build_environment();build_materials()
 if not visual_v7:fitout=read_json("res://source/fitout-v8.json");load("res://finish_v8.gd").new().extend(mats);load("res://finish_v9.gd").new().extend(mats)
 var geometry_path="res://assets/geometry-before.json.gz"if baseline else("res://assets/baseline-b-v7.pack.gz"if visual_v7 else"res://assets/base-b-v8-indexed.pack.gz")
 var geo:Dictionary=load_geometry(geometry_path)
 if context_only:
  geometry_path="res://assets/site-v7.json.gz";geo=load_geometry(geometry_path);manifest.escalators=[];manifest.staff_doors=[]
 elif with_context:
  var ctx:Dictionary=load_geometry("res://assets/baseline-site-v7.pack.gz"if visual_v7 else"res://assets/base-site-v8-indexed.pack.gz")
  geo.surfaces.merge(ctx.surfaces)
  for key:String in ctx.colliders:
   if geo.colliders.has(key):geo.colliders[key].append_array(ctx.colliders[key])
   else:geo.colliders[key]=ctx.colliders[key]
 
 if not visual_v7:
  var dress:Dictionary=load_geometry("res://assets/fitout-v8-indexed.pack.gz")
  geo.surfaces.merge(dress.surfaces)
  for k:String in dress.colliders:
   if geo.colliders.has(k):geo.colliders[k].append_array(dress.colliders[k])
   else:geo.colliders[k]=dress.colliders[k]
 if not visual_v7:
  var art:Dictionary=load_geometry("res://assets/art-v9-indexed.pack.gz")
  geo.surfaces.merge(art.surfaces)
  for k:String in art.colliders:
   if geo.colliders.has(k):geo.colliders[k].append_array(art.colliders[k])
   else:geo.colliders[k]=art.colliders[k]
 for key:String in geo.surfaces:
  var material_key:String=key.split("@@")[0]
  var data:Dictionary=geo.surfaces[key];var a:Array=[];a.resize(Mesh.ARRAY_MAX)
  var vs=PackedVector3Array();var ns=PackedVector3Array();var uvs=PackedVector2Array();var cs=PackedColorArray()
  for i in range(0,data.v.size(),3):vs.append(Vector3(data.v[i],data.v[i+1],data.v[i+2]));ns.append(Vector3(data.n[i],data.n[i+1],data.n[i+2]))
  for i in range(0,data.uv.size(),2):uvs.append(Vector2(data.uv[i],data.uv[i+1]))
  for i in range(0,data.c.size(),4):cs.append(Color(data.c[i],data.c[i+1],data.c[i+2],data.c[i+3]))
  a[Mesh.ARRAY_VERTEX]=vs;a[Mesh.ARRAY_NORMAL]=ns;a[Mesh.ARRAY_TEX_UV]=uvs;a[Mesh.ARRAY_COLOR]=cs
  if data.has("i"):a[Mesh.ARRAY_INDEX]=data.i
  var mesh=ArrayMesh.new();mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,a);mesh.surface_set_material(0,mats.step_support if material_key=="step"else mats[material_key])
  if mats[material_key] is ShaderMaterial and material_key not in["glass","roof_glass"]:
   var st=SurfaceTool.new();st.create_from(mesh,0);st.generate_tangents();mesh=st.commit();mesh.surface_set_material(0,mats.step_support if material_key=="step"else mats[material_key])
  var instance=MeshInstance3D.new();instance.mesh=mesh;instance.name="Architecture_"+key
  var room_group:String=key.split("@@")[-1]
  if room_group.begins_with("B"):
   var room_index:int=0
   for si in range(manifest.shops.size()):
    if manifest.shops[si].id==room_group:room_index=si;break
   instance.layers=1|(1<<((room_index%18)+1))
  if material_key in ["glass","roof_glass","light"]:instance.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
  if material_key=="yellow"and room_group.begins_with("ARCH"):instance.visible=false
  if not visual_v7 and (material_key.begins_with("v8_")or material_key.begins_with("v9_")):
   instance.visibility_range_end=155.0;instance.visibility_range_end_margin=20.0
  add_child(instance);mesh_count+=1
 for key:String in geo.colliders:
  var data=geo.colliders[key];var points=PackedVector3Array()
  for i in range(0,data.size(),3):points.append(Vector3(data[i],data[i+1],data[i+2]))
  var body=StaticBody3D.new();body.name="Collision_"+key;body.collision_layer=3 if key in ["plaster","wall_sand","wall_sage","wall_chalk","wall_taupe","dark_stone"]else 1
  var col=CollisionShape3D.new();var shape=ConcavePolygonShape3D.new();shape.backface_collision=true;shape.set_faces(points);col.shape=shape;body.add_child(col);add_child(body)
 for sign_data:Dictionary in geo.signs:build_sign(sign_data)
 var sm=read_json("res://source/site-manifest-v7.json")
 manifest.staff_doors.append_array(sm.staff_doors)
 manifest.escalators.append_array(sm.escalators)
 for sd:Dictionary in sm.signs:add_vector_sign(sd)
 for brand:Dictionary in read_json("res://source/brands-v7.json"if visual_v7 else"res://source/brands-v8.json"):
  brand_registry[brand.store_id]=brand
  if visual_v7 or not brand.get("review_area",false):add_brand_slot(brand)
 if not visual_v7:
  for sd:Dictionary in fitout.signs:build_store_sign(sd)
  for d:Dictionary in fitout.lights:
   var l=SpotLight3D.new();l.position=v3(d.p);l.rotation_degrees.x=-90;l.light_color=Color(1,.85,.66)if d.warm else Color(1,.95,.84);l.light_energy=float(d.energy);l.spot_range=float(d.range);l.spot_angle=65;l.spot_attenuation=1.1;l.distance_fade_enabled=true;l.distance_fade_begin=50;l.distance_fade_length=20;add_child(l)
 # v6 scope-boundary markers removed: full A/C destinations now generated.
 
 # Low, local fixtures on three levels, after spatially grouping storefronts.
 for i in range(geo.lights.size()):
  var d:Dictionary=geo.lights[i]
  if d.get("type","")=="common" and i%8!=0:continue
  var light:SpotLight3D=SpotLight3D.new();light.position=v3(d.p);light.rotation_degrees.x=-90;light.light_color=Color(1,.91,.78)if d.get("type","")=="shop"else Color(1,.97,.89);light.light_energy=float(d.get("energy",.3));light.spot_range=8;light.spot_angle=62;light.spot_attenuation=1.2;light.shadow_enabled=false
  if d.get("type","")=="shop":light.light_cull_mask=1<<(int(d.get("room_index",0))%18+1)
  if not visual_v7:light.distance_fade_enabled=true;light.distance_fade_begin=55;light.distance_fade_length=20
  add_child(light)
 if not visual_v7:
  var furnishings=load("res://art_v9.gd").new();add_child(furnishings);furnishings.setup(self,read_json("res://source/art-v9.json"))
 if not visual_v7:
  var pendants=load("res://pendants_v8.gd").new();add_child(pendants);pendants.setup(self)
 if not visual_v7:
  for d:Dictionary in read_json("res://source/ceiling-lights-v8.json"):
   var light=OmniLight3D.new();light.position=v3(d.position);light.omni_range=9;light.omni_attenuation=1.3;light.light_color=Color(1,.93,.80);light.light_energy=2.3;light.shadow_enabled=false;light.distance_fade_enabled=true;light.distance_fade_begin=35;light.distance_fade_length=15;add_child(light)
 staff=load("res://staff_doors.gd").new();add_child(staff);staff.setup(manifest.get("staff_doors",[]),mats)
 animator=load("res://escalator_v2.gd").new();add_child(animator);animator.setup(manifest,mats)
 if mode!="interactive":animator.paused=true;animator.set_time(1.75)
 if visual_v7 and mode not in["walk-test","walk-v8","ui-test"]:
  var probe=ReflectionProbe.new();probe.name="Atrium_Box_Reflection";probe.position=Vector3(0,7,3);probe.size=Vector3(82,19,105);probe.interior=false;probe.box_projection=true;probe.intensity=.6;probe.max_distance=100;probe.enable_shadows=false;probe.ambient_mode=0;probe.update_mode=0;add_child(probe)
 player=load("res://player.gd").new();player.name="WalkCapsule";add_child(player);player.position=Vector3(325.43976,.06,-63.75212)if not visual_v7 else Vector3(-3,.06,22.3)
 if not visual_v7:interactive_pose(read_json("res://source/cameras-v8.json")[0])
 for e:Dictionary in manifest.escalators:
  if not e.has("low_y"):
   e.low_y=manifest.floors[int(e.levels[0])].height;e.high_y=manifest.floors[int(e.levels[1])].height
  player.escalators.append(e)
 elevators=load("res://elevators_v7.gd").new();add_child(elevators);elevators.setup(read_json("res://source/elevators-v7.json"),player,mats,font)
 ui=load("res://ui_v7.gd").new();add_child(ui);ui.setup(self)
 for arg:String in OS.get_cmdline_user_args():
  if arg.begins_with("--resolution="):
   var val=arg.trim_prefix("--resolution=");ui.settings.resolution_index=1 if val=="1440" else 2 if val=="2160" else 0;ui.settings.apply(false)
 var layer=CanvasLayer.new();add_child(layer)
 hud=Label.new();hud.add_theme_font_override("font",font);hud.add_theme_font_size_override("font_size",17);hud.position=Vector2(22,16);hud.add_theme_color_override("font_outline_color",Color(.08,.1,.09,.85));hud.add_theme_constant_override("outline_size",5);layer.add_child(hud)
 var bottom=Label.new();bottom.add_theme_font_override("font",font);bottom.add_theme_font_size_override("font_size",14);bottom.position=Vector2(22,1025);bottom.text="独立検証 v9・代表エリア仕上げ（全館未完成） | F1 A館 / F2 B館 / F3 C館 | WASD 移動 / Shift 速歩 / F 扉・EV / M 館内マップ / F10 設定 / Esc カーソル";layer.add_child(bottom)
 if mode!="interactive":player.input_enabled=false
 results={"godot_version":Engine.get_version_info(),"renderer":RenderingServer.get_current_rendering_method(),"adapter":RenderingServer.get_video_adapter_name(),"resolution":[1920,1080],"msaa":"4x","source_sha256":manifest.source_original_sha256,"context_included":with_context,"context_geometry_sha256":FileAccess.get_sha256("res://assets/baseline-site-v7.pack.gz"if visual_v7 else"res://assets/base-site-v8-indexed.pack.gz"),"main_game_loaded":false,"graphics_revision":"v7-preserved-baseline"if visual_v7 else"v9-three-1F-review-zones","animation_shader_sha256":FileAccess.get_sha256("res://rubber.gdshader"),"staff_script_sha256":FileAccess.get_sha256("res://staff_doors.gd"),"animation_script_sha256":FileAccess.get_sha256("res://escalator_v2.gd"),"art_v9_sha256":FileAccess.get_sha256("res://assets/art-v9-indexed.pack.gz"),"fitout_sha256":""if visual_v7 else FileAccess.get_sha256("res://assets/fitout-v8-indexed.pack.gz"),"geometry_sha256":FileAccess.get_sha256(geometry_path),"main_script_sha256":FileAccess.get_sha256("res://main.gd"),"player_script_sha256":FileAccess.get_sha256("res://player.gd"),"scene_build_seconds":(Time.get_ticks_usec()-start_usec)/1000000.0}
 print("VALIDATION_READY ",JSON.stringify(results))
 await get_tree().physics_frame;await get_tree().physics_frame
 if mode=="capture":await load("res://showcase_v9.gd").new().capture(self)
 if mode=="benchmark-v8":await load("res://showcase_v9.gd").new().benchmark(self)
 if mode=="walk-v8":await load("res://showcase_v9.gd").new().walk(self)
 if mode=="walk-test":await load("res://validation_v7.gd").new().walk(self)
 if mode=="vehicle-test":await load("res://validation_v7.gd").new().vehicle(self)
 if mode=="ui-test":await load("res://validation_v7.gd").new().ui_test(self)
 
func _process(dt:float)->void:
 if player==null:return
 hud.text="代表3エリア   映像品質確認 v9\n位置 %.1f / %.2f / %.1f m   FPS %.1f\n%s"%[player.position.x,player.position.y,player.position.z,Engine.get_frames_per_second(),"ESCALATOR "+player.belt_id if player.belt_id!="" else ""]
 if mode=="interactive" and ui.overlay=="":
  if Input.is_physical_key_pressed(KEY_1):player.position=Vector3(-3,.08,28.3)
  if Input.is_physical_key_pressed(KEY_2):player.position=Vector3(-3,5.605,28.3)
  if Input.is_physical_key_pressed(KEY_3):player.position=Vector3(-3,10.955,28.3)
  if Input.is_physical_key_pressed(KEY_4):player.position=Vector3(-118.99913,16.48,63.99970)
  if Input.is_physical_key_pressed(KEY_B):player.position=Vector3(-111.00000,-5.27,-40.00000)
func build_environment()->void:
 var world=WorldEnvironment.new();var env=Environment.new();world.environment=env
 env.background_mode=Environment.BG_SKY
 var sky=Sky.new();var sky_mat=ProceduralSkyMaterial.new();sky_mat.sky_top_color=Color(.38,.52,.67);sky_mat.sky_horizon_color=Color(.87,.89,.85);sky_mat.ground_bottom_color=Color(.38,.35,.30);sky_mat.ground_horizon_color=Color(.77,.75,.67);sky.sky_material=sky_mat;env.sky=sky
 env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;env.ambient_light_color=Color(.88,.89,.88);env.ambient_light_energy=.70;env.reflected_light_source=2
 env.tonemap_mode=Environment.TONE_MAPPER_FILMIC;env.tonemap_exposure=.90
 if not visual_v7:
  env.ambient_light_energy=.48;env.ambient_light_color=Color(.85,.89,.94);env.tonemap_exposure=1.04;env.tonemap_white=5.0;env.ssao_enabled=true;env.ssao_radius=1.4;env.ssao_intensity=1.5;env.ssil_enabled=true;env.ssil_intensity=.45;env.ssr_enabled=true;env.glow_enabled=true;env.glow_intensity=.18
 add_child(world)
 var sun=DirectionalLight3D.new();sun.name="Daylight";sun.rotation_degrees=Vector3(-58,-32,0);sun.light_energy=.12;sun.light_color=Color(1,.98,.93);sun.shadow_enabled=true;sun.directional_shadow_max_distance=95;sun.shadow_bias=.12;sun.shadow_normal_bias=1.2;sun.directional_shadow_mode=DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS;add_child(sun)
 if not visual_v7:sun.light_energy=.95;sun.light_color=Color(1,.94,.80);sun.shadow_bias=.035;sun.shadow_normal_bias=.75
 var fill=DirectionalLight3D.new();fill.rotation_degrees=Vector3(-30,140,0);fill.light_color=Color(.72,.82,1);fill.light_energy=.08;fill.shadow_enabled=false;add_child(fill)
func plain(color:Color,rough:float=.5,metal:float=0)->StandardMaterial3D:
 var m=StandardMaterial3D.new();m.albedo_color=color;m.roughness=rough;m.metallic=metal;m.vertex_color_use_as_albedo=true;m.cull_mode=BaseMaterial3D.CULL_DISABLED;m.texture_filter=BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC;return m
func build_materials()->void:
 mats=load("res://material_library.gd").new().build(baseline)
func old_sign_hidden(d:Dictionary)->bool:
 if visual_v7 or fitout.is_empty():return false
 for sd:Dictionary in fitout.signs:
  if str(sd.id).ends_with("-window"):continue
  if v3(d.p).distance_to(v3(sd.p))<1.5:return true
 return false
func build_sign(d:Dictionary)->void:
 if not str(d.file).begins_with("v8/")and old_sign_hidden(d):return
 var mesh=QuadMesh.new();mesh.size=Vector2(d.w,d.h)
 var m=plain(Color.WHITE,.6);m.albedo_texture=load("res://assets/"+d.file);m.emission_enabled=true;m.emission=m.albedo_color;m.emission_texture=m.albedo_texture;m.emission_energy_multiplier=.12;mesh.material=m
 var n=MeshInstance3D.new();n.mesh=mesh;n.position=v3(d.p)
 var dir=Vector3(d.n[0],0,d.n[1]);n.basis=Basis(Vector3.UP.cross(dir),Vector3.UP,dir);add_child(n)
func write_json(name:String,data)->void:
 var file=FileAccess.open(output+"/"+name,FileAccess.WRITE);file.store_string(JSON.stringify(data,"  "))
func _unhandled_input(e:InputEvent)->void:
 if e is InputEventKey and e.pressed and e.keycode==KEY_F and ui.overlay=="":
  if staff.interact(player.position,player.get_rid()):return
  var index=elevators.nearest()
  if index>=0:ui.show_lift(index)
func collision_diagnostics()->Array:
 var a:Array=[]
 for i in range(player.get_slide_collision_count()):
  var c=player.get_slide_collision(i);a.append({"collider":str(c.get_collider().name),"normal":str(c.get_normal()),"position":str(c.get_position())})
 return a
func add_scope_markers()->void:
 for d:Dictionary in read_json("res://source/preview-markers.json"):
  var root=Node3D.new();root.position=v3(d.position);var normal=Vector3(d.normal[0],0,d.normal[1]);root.basis=Basis(Vector3.UP.cross(normal),Vector3.UP,normal);add_child(root)
  var mesh=QuadMesh.new();mesh.size=Vector2(d.width,.85);var m=StandardMaterial3D.new();m.albedo_color=Color(.055,.14,.12);m.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED;m.cull_mode=BaseMaterial3D.CULL_DISABLED;mesh.material=m;var board=MeshInstance3D.new();board.mesh=mesh;root.add_child(board)
  var label=Label3D.new();label.font=font;label.text=d.text;label.font_size=56;label.pixel_size=.0028;label.outline_size=0;label.modulate=Color.WHITE;label.position.z=.012;root.add_child(label)
func settle(p:Vector3)->void:
 player.auto_active=false;player.velocity=Vector3.ZERO;player.position=p+Vector3(0,.06,0)
 for i in range(14):await get_tree().physics_frame
func walk_points(points:Array,speed:float=5.0)->Dictionary:
 var max_error:float=0;var ticks:int=0;var contacts:int=0;var checkpoints:Array=[]
 player.auto_speed=speed;player.auto_active=true
 for pp in points:
  var target=v3(pp);player.auto_target=target
  var start=player.position;var budget=int((start.distance_to(target)/speed+4.0)*60);var reached:bool=false
  for i in range(budget):
   await get_tree().physics_frame;ticks+=1
   var flat=Vector2(player.position.x-target.x,player.position.z-target.z).length()
   max_error=max(max_error,abs(player.position.y-target.y))
   if player.get_slide_collision_count()>0:contacts+=1
   if flat<.16 and abs(player.position.y-target.y)<.22:reached=true;break
   if player.position.y<min(start.y,target.y)-1.5:return {"pass":false,"reason":"fell below floor","position":player.position,"target":target,"ticks":ticks,"colliders":collision_diagnostics()}
  if not reached:
   player.auto_active=false
   return {"pass":false,"reason":"not reached within physical tick budget","position":player.position,"target":target,"ticks":ticks,"colliders":collision_diagnostics()}
  checkpoints.append({"position":[player.position.x,player.position.y,player.position.z],"on_floor":player.is_on_floor()})
 player.auto_active=false
 return {"checkpoints":checkpoints,"pass":true,"ticks":ticks,"contact_ticks":contacts,"max_vertical_difference_m":max_error,"position":player.position}

func add_vector_sign(d:Dictionary)->void:
 if old_sign_hidden(d):return
 var n=Label3D.new();n.font=font;n.text=d.text;n.font_size=38;n.pixel_size=min(.009,float(d.w)/max(font.get_string_size(str(d.text),HORIZONTAL_ALIGNMENT_LEFT,-1,38).x,1.));n.outline_size=4;n.modulate=Color(.2,.30,.28);n.position=v3(d.p);var normal=Vector3(d.n[0],0,d.n[1]);n.basis=Basis(Vector3.UP.cross(normal),Vector3.UP,normal);add_child(n)
func _input(e:InputEvent)->void:
 if ui==null or mode!="interactive":return
 if e is InputEventKey and e.pressed and not e.echo and ui.overlay=="":
  if e.keycode in [KEY_F1,KEY_F2,KEY_F3]:
   var idx=int(e.keycode)-int(KEY_F1);var shots=read_json("res://source/cameras-v8.json");var shot=shots[[0,2,4][idx]];interactive_pose(shot);get_viewport().set_input_as_handled();return
 if e is InputEventKey and e.pressed and not e.echo:
  if e.keycode==KEY_M:ui.show_map();get_viewport().set_input_as_handled()
  elif e.keycode==KEY_F10:ui.show_settings();get_viewport().set_input_as_handled()
  elif e.keycode==KEY_ESCAPE and ui.overlay!="":ui.close();get_viewport().set_input_as_handled()

func add_brand_slot(d:Dictionary)->void:
 var slot=Node3D.new();slot.name="BrandSlot_"+d.store_id;slot.position=v3(d.sign_position);slot.set_meta("brand",d);add_child(slot)
 if not visual_v7:return
 # Final sign work is deferred. A per-ID asset activates immediately when supplied; no global duplicated brand texture.
 if d.get("logo_asset")!=null and FileAccess.file_exists("res://assets/"+str(d.logo_asset)):
  build_sign({"file":d.logo_asset,"p":d.sign_position,"n":d.normal,"w":d.max_width_m,"h":.75})
 elif d.get("show_provisional_name",false):
  add_vector_sign({"text":d.name,"p":d.sign_position,"n":d.normal,"w":d.max_width_m,"h":.65})

func interactive_pose(shot:Dictionary)->void:
 var eye=v3(shot.eye);var direction=v3(shot.look)-eye
 player.position=eye-Vector3(0,1.65,0);player.velocity=Vector3.ZERO;player.auto_active=false
 player.rotation=Vector3(0,atan2(-direction.x,-direction.z),0)
 player.camera.rotation=Vector3(atan2(direction.y,Vector2(direction.x,direction.z).length()),0,0)

func build_store_sign(data:Dictionary)->void:
 var sign_data=data.duplicate(true)
 var id:String=str(sign_data.get("id",""))
 if brand_registry.has(id):
  var brand:Dictionary=brand_registry[id]
  if brand.get("logo_asset")!=null:sign_data.file=str(brand.logo_asset)
  var placement:Dictionary=brand.get("sign_override",{})
  for key:String in ["p","n","w","h"]:
   if placement.has(key):sign_data[key]=placement[key]
  if not FileAccess.file_exists("res://assets/"+str(sign_data.file)):
   add_vector_sign({"text":str(brand.name),"p":sign_data.p,"n":sign_data.n,"w":sign_data.w});return
 build_sign(sign_data)
