extends Node3D
var player:CharacterBody3D
var font:Font
var manifest:Dictionary
var mats:Dictionary={}
var hud:Label
var frame_times:Array=[]
var results:Dictionary={}
var mode:String="interactive"
var preview:bool=false
var output:String="res://evidence"
var mesh_count:int=0
var start_usec:int=0
func v3(a:Array)->Vector3:return Vector3(a[0],a[1],a[2])
func read_json(p:String):return JSON.parse_string(FileAccess.get_file_as_string(p))
func _ready()->void:
 start_usec=Time.get_ticks_usec()
 for arg:String in OS.get_cmdline_user_args():
  if arg=="--capture":mode="capture"
  if arg=="--preview":mode="capture";preview=true
  if arg=="--walk-test":mode="walk-test"
  if arg.begins_with("--output="):output=arg.trim_prefix("--output=")
 DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(output))
 manifest=read_json("res://source/scene-manifest.json")
 font=load("res://assets/NotoSansCJKjp-Regular.otf")
 build_environment();build_materials()
 var geo:Dictionary=read_json("res://assets/geometry.json")
 for key:String in geo.surfaces:
  var data:Dictionary=geo.surfaces[key];var a:Array=[];a.resize(Mesh.ARRAY_MAX)
  var vs=PackedVector3Array();var ns=PackedVector3Array();var uvs=PackedVector2Array();var cs=PackedColorArray()
  for i in range(0,data.v.size(),3):vs.append(Vector3(data.v[i],data.v[i+1],data.v[i+2]));ns.append(Vector3(data.n[i],data.n[i+1],data.n[i+2]))
  for i in range(0,data.uv.size(),2):uvs.append(Vector2(data.uv[i],data.uv[i+1]))
  for i in range(0,data.c.size(),4):cs.append(Color(data.c[i],data.c[i+1],data.c[i+2],data.c[i+3]))
  a[Mesh.ARRAY_VERTEX]=vs;a[Mesh.ARRAY_NORMAL]=ns;a[Mesh.ARRAY_TEX_UV]=uvs;a[Mesh.ARRAY_COLOR]=cs
  var mesh=ArrayMesh.new();mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,a);mesh.surface_set_material(0,mats[key])
  if key in ["stone","plaster","wood","dark_stone"]:
   var st=SurfaceTool.new();st.create_from(mesh,0);st.generate_tangents();mesh=st.commit();mesh.surface_set_material(0,mats[key])
  var instance=MeshInstance3D.new();instance.mesh=mesh;instance.name="Architecture_"+key
  if key in ["glass","roof_glass","light"]:instance.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
  add_child(instance);mesh_count+=1
 for key:String in geo.colliders:
  var data:Array=geo.colliders[key];var points=PackedVector3Array()
  for i in range(0,data.size(),3):points.append(Vector3(data[i],data[i+1],data[i+2]))
  var body=StaticBody3D.new();body.name="Collision_"+key
  var col=CollisionShape3D.new();var shape=ConcavePolygonShape3D.new();shape.backface_collision=true;shape.set_faces(points);col.shape=shape;body.add_child(col);add_child(body)
 for sign_data:Dictionary in geo.signs:build_sign(sign_data)
 # Indirect fill approximates a daylit commercial interior. It is explicitly not baked GI.
 for i in range(geo.lights.size()):
  if i%9!=0:continue
  var light=OmniLight3D.new();light.position=v3(geo.lights[i].p);light.light_color=Color(1,.90,.76);light.light_energy=.25;light.omni_range=12;light.omni_attenuation=1.3;light.shadow_enabled=false;add_child(light)
 player=load("res://player.gd").new();player.name="WalkCapsule";add_child(player);player.position=Vector3(-3,.06,22.3)
 for e:Dictionary in manifest.escalators:
  e.low_y=manifest.floors[int(e.levels[0])].height;e.high_y=manifest.floors[int(e.levels[1])].height;player.escalators.append(e)
 var layer=CanvasLayer.new();add_child(layer)
 hud=Label.new();hud.add_theme_font_override("font",font);hud.add_theme_font_size_override("font_size",17);hud.position=Vector2(22,16);hud.add_theme_color_override("font_outline_color",Color(.08,.1,.09,.85));hud.add_theme_constant_override("outline_size",5);layer.add_child(hud)
 var bottom=Label.new();bottom.add_theme_font_override("font",font);bottom.add_theme_font_size_override("font_size",14);bottom.position=Vector2(22,674);bottom.text="独立検証 v1  |  WASD 移動 / マウス 視点 / Shift 速歩 / Esc カーソル / 1・2・3 検証階へ移動";layer.add_child(bottom)
 if mode!="interactive":player.input_enabled=false
 results={"godot_version":Engine.get_version_info(),"renderer":RenderingServer.get_current_rendering_method(),"adapter":RenderingServer.get_video_adapter_name(),"resolution":[1280,720],"msaa":"4x","source_sha256":manifest.source_sha256,"main_game_loaded":false,"geometry_sha256":FileAccess.get_sha256("res://assets/geometry.json"),"main_script_sha256":FileAccess.get_sha256("res://main.gd"),"player_script_sha256":FileAccess.get_sha256("res://player.gd"),"scene_build_seconds":(Time.get_ticks_usec()-start_usec)/1000000.0}
 print("VALIDATION_READY ",JSON.stringify(results))
 await get_tree().physics_frame;await get_tree().physics_frame
 if mode=="capture":await capture()
 if mode=="walk-test":await test_walk()
func _process(dt:float)->void:
 if player==null:return
 hud.text="B館 / 時の広場   建築検証\n位置 %.1f / %.2f / %.1f m   FPS %.1f\n%s"%[player.position.x,player.position.y,player.position.z,Engine.get_frames_per_second(),"ESCALATOR "+player.belt_id if player.belt_id!="" else ""]
 if mode=="interactive":
  if Input.is_physical_key_pressed(KEY_1):player.position=Vector3(-3,.08,28.3)
  if Input.is_physical_key_pressed(KEY_2):player.position=Vector3(-3,5.605,28.3)
  if Input.is_physical_key_pressed(KEY_3):player.position=Vector3(-3,10.955,28.3)
func build_environment()->void:
 var world=WorldEnvironment.new();var env=Environment.new();world.environment=env
 env.background_mode=Environment.BG_SKY
 var sky=Sky.new();var sky_mat=ProceduralSkyMaterial.new();sky_mat.sky_top_color=Color(.38,.52,.67);sky_mat.sky_horizon_color=Color(.87,.89,.85);sky_mat.ground_bottom_color=Color(.38,.35,.30);sky_mat.ground_horizon_color=Color(.77,.75,.67);sky.sky_material=sky_mat;env.sky=sky
 env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;env.ambient_light_color=Color(.88,.86,.81);env.ambient_light_energy=.50;env.reflected_light_source=2
 env.tonemap_mode=Environment.TONE_MAPPER_FILMIC;env.tonemap_exposure=1.0
 add_child(world)
 var sun=DirectionalLight3D.new();sun.name="Daylight";sun.rotation_degrees=Vector3(-58,-32,0);sun.light_energy=1.25;sun.light_color=Color(1,.96,.86);sun.shadow_enabled=true;sun.directional_shadow_max_distance=95;sun.shadow_bias=.12;sun.shadow_normal_bias=1.2;sun.directional_shadow_mode=DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS;add_child(sun)
 var fill=DirectionalLight3D.new();fill.rotation_degrees=Vector3(-30,140,0);fill.light_color=Color(.72,.82,1);fill.light_energy=.18;fill.shadow_enabled=false;add_child(fill)
func plain(color:Color,rough:float=.5,metal:float=0)->StandardMaterial3D:
 var m=StandardMaterial3D.new();m.albedo_color=color;m.roughness=rough;m.metallic=metal;m.vertex_color_use_as_albedo=true;m.cull_mode=BaseMaterial3D.CULL_DISABLED;m.texture_filter=BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC;return m
func build_materials()->void:
 var colors={"ceiling_panel":Color(.80,.79,.75),"grout":Color(.31,.32,.3),"metal":Color(.56,.58,.57),"bronze":Color(.40,.31,.18),"black":Color(.022,.027,.026),"yellow":Color(.89,.64,.13),"step":Color(.22,.25,.25),"soil":Color(.055,.04,.025),"leaf":Color(.10,.21,.095),"goods_cream":Color(.79,.72,.58),"goods_green":Color(.19,.33,.27),"goods_rust":Color(.52,.21,.13),"goods_charcoal":Color(.12,.15,.17),"scope_wall":Color(.23,.27,.25)}
 for key:String in colors:mats[key]=plain(colors[key],.55,.65 if key in["metal","bronze","step"]else 0.0)
 for key:String in["plaster","wood","dark_stone"]:
  var m=plain(Color.WHITE,.5)
  m.albedo_texture=load("res://assets/"+key+"_albedo.png");m.normal_enabled=true;m.normal_texture=load("res://assets/"+key+"_normal.png");m.normal_scale=.10;m.roughness=.9;m.roughness_texture=load("res://assets/"+key+"_roughness.png");m.roughness_texture_channel=BaseMaterial3D.TEXTURE_CHANNEL_RED;m.uv1_scale=Vector3(.5,.5,1)
  if key=="plaster":m.roughness_texture=null;m.roughness=.82
  mats[key]=m
 var stone=ShaderMaterial.new();stone.shader=load("res://stone.gdshader");stone.set_shader_parameter("albedo_map",load("res://assets/stone_albedo.png"));stone.set_shader_parameter("normal_map",load("res://assets/stone_normal.png"));stone.set_shader_parameter("rough_map",load("res://assets/stone_roughness.png"));mats.stone=stone
 var glass=plain(Color(.66,.83,.82,.13),.08,.08);glass.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA;glass.shading_mode=BaseMaterial3D.SHADING_MODE_PER_PIXEL;glass.cull_mode=BaseMaterial3D.CULL_DISABLED;mats.glass=glass
 var roof=glass.duplicate();roof.albedo_color=Color(.65,.82,.86,.25);mats.roof_glass=roof
 var emit=plain(Color(1,.91,.73));emit.emission_enabled=true;emit.emission=Color(1,.86,.62);emit.emission_energy_multiplier=2.3;mats.light=emit
func build_sign(d:Dictionary)->void:
 var mesh=QuadMesh.new();mesh.size=Vector2(d.w,d.h)
 var m=plain(Color.WHITE,.6);m.albedo_texture=load("res://assets/"+d.file);m.emission_enabled=true;m.emission=m.albedo_color;m.emission_texture=m.albedo_texture;m.emission_energy_multiplier=.12;mesh.material=m
 var n=MeshInstance3D.new();n.mesh=mesh;n.position=v3(d.p)
 var dir=Vector3(d.n[0],0,d.n[1]);n.basis=Basis(Vector3.UP.cross(dir),Vector3.UP,dir);add_child(n)
func write_json(name:String,data)->void:
 var file=FileAccess.open(output+"/"+name,FileAccess.WRITE);file.store_string(JSON.stringify(data,"  "))
func capture()->void:
 var shots:Array=[
 {"id":"01-1F-time-plaza","p":Vector3(4,1.65,12),"look":Vector3(-14,7.5,-12)},
 {"id":"02-1F-west-escalators","p":Vector3(-9,1.65,22),"look":Vector3(-22,4.3,16)},
 {"id":"03-2F-crossing-bridge","p":Vector3(16,7.175,3),"look":Vector3(-14,8.2,-5)},
 {"id":"04-2F-storefront","p":Vector3(-31,7.175,27),"look":Vector3(-19,7.8,35)},
 {"id":"05-3F-void-and-roof","p":Vector3(14,12.525,0),"look":Vector3(-14,8.8,-4)},
 {"id":"06-1F-north-shopping-street","p":Vector3(-2,1.65,-28),"look":Vector3(8,2.4,-35)},
 {"id":"07-1F-cafe-interior","p":Vector3(-20.68,1.65,-34),"look":Vector3(-13,1.65,-40.5)},
 {"id":"08-1F-bookshop-interior","p":Vector3(-70.59,1.65,2.02),"look":Vector3(-72,1.6,-4)}]
 var performance:Array=[];hud.visible=false
 for shot:Dictionary in shots:
  player.set_physics_process(false);player.rotation=Vector3.ZERO;player.camera.global_position=shot.p;player.camera.look_at(shot.look)
  var measure:bool=not preview and shot.id in ["01-1F-time-plaza","03-2F-crossing-bridge","05-3F-void-and-roof"]
  for i in range(12 if measure else 3):await get_tree().process_frame
  await RenderingServer.frame_post_draw
  var image=get_viewport().get_texture().get_image();var err=image.save_png(output+"/"+shot.id+".png")
  print("CAPTURE ",shot.id," ",err)
  if not measure:continue
  var samples:Array=[];var counters:Array=[]
  var last=Time.get_ticks_usec()
  for i in range(30):
   await get_tree().process_frame
   var now=Time.get_ticks_usec();samples.append((now-last)/1000.0);last=now
   counters.append({"draw_calls":Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),"objects":Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME),"primitives":Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME)})
  var sorted=samples.duplicate();sorted.sort();var sum_ms:float=0
  for t:float in samples:sum_ms+=t
  performance.append({"id":shot.id,"camera_eye_local":shot.p,"look_at_local":shot.look,"warmup_frames":12,"sample_frames":samples.size(),"mean_ms":sum_ms/samples.size(),"fps_from_mean_frame_time":1000.0/(sum_ms/samples.size()),"p50_ms":sorted[15],"p95_ms":sorted[28],"samples_ms":samples,"last_counters":counters.back()})
 if not preview:
  player.rotation=Vector3.ZERO;player.camera.position=Vector3(0,1.65,0);player.camera.rotation=Vector3(-.12,0,0);player.set_physics_process(true);player.belt_enabled=false
  await settle(Vector3(-3,0,28.3));player.auto_active=true;player.auto_speed=4.3;player.auto_target=Vector3(-3,0,21)
  var samples:Array=[];var last=Time.get_ticks_usec()
  for i in range(60):
   if Vector2(player.position.x-player.auto_target.x,player.position.z-player.auto_target.z).length()<.3:player.auto_target=Vector3(-3,0,28.3) if player.auto_target.z<25 else Vector3(-3,0,21)
   await get_tree().process_frame
   var now=Time.get_ticks_usec();samples.append((now-last)/1000.0);last=now
  player.auto_active=false;player.set_physics_process(false)
  var sorted=samples.duplicate();sorted.sort();var sum_ms:float=0
  for t:float in samples:sum_ms+=t
  results.walking_performance={"path":"1F plaza public floor out-and-back, CharacterBody3D movement","sample_frames":60,"mean_ms":sum_ms/60,"fps_from_mean_frame_time":60000.0/sum_ms,"p50_ms":sorted[30],"p95_ms":sorted[56],"samples_ms":samples}
 results.performance=performance;results.screenshot_kind="actual Godot 3D viewport; no image generation or retouch";results.npc_count=0;results.software_gpu="llvmpipe" in String(results.adapter).to_lower()
 write_json("render-results.json",results);print("CAPTURE_COMPLETE");get_tree().quit()
func settle(p:Vector3)->void:
 player.auto_active=false;player.velocity=Vector3.ZERO;player.position=p+Vector3(0,.06,0)
 for i in range(14):await get_tree().physics_frame
func walk_points(points:Array,speed:float=5.0)->Dictionary:
 var max_error:float=0;var ticks:int=0;var contacts:int=0
 player.auto_speed=speed;player.auto_active=true
 for pp in points:
  var target=v3(pp);player.auto_target=target
  var start=player.position;var budget=int((start.distance_to(target)/speed+4.0)*60);var reached:bool=false
  for i in range(budget):
   await get_tree().physics_frame;ticks+=1
   var flat=Vector2(player.position.x-target.x,player.position.z-target.z).length()
   max_error=max(max_error,abs(player.position.y-target.y))
   if player.get_slide_collision_count()>0:contacts+=1
   if flat<.16 and abs(player.position.y-target.y)<.22:reached=true;break
   if player.position.y< -1.5:return {"pass":false,"reason":"fell below floor","position":player.position,"target":target,"ticks":ticks,"colliders":collision_diagnostics()}
  if not reached:
   player.auto_active=false
   return {"pass":false,"reason":"not reached within physical tick budget","position":player.position,"target":target,"ticks":ticks,"colliders":collision_diagnostics()}
 player.auto_active=false
 return {"pass":true,"ticks":ticks,"contact_ticks":contacts,"max_vertical_difference_m":max_error,"position":player.position}
func test_walk()->void:
 var checks:Array=[];player.belt_enabled=false
 var routes:Array=read_json("res://source/walk-routes.json")
 for route:Dictionary in routes:
  await settle(v3(route.points[0]))
  var result=await walk_points(route.points)
  result.id=route.id;result.kind="capsule_move_and_slide_to_shop_or_public_waypoint";result.distance_m=route.distance_m;checks.append(result)
  print("WALK ",route.id," ",result["pass"])
 # Also test the actual four escalators uphill and downhill over their collidable inclines.
 for e:Dictionary in manifest.escalators:
  var a=v3(e.test_start);var b=v3(e.test_end)
  for reverse in[false,true]:
   var aa=b if reverse else a;var bb=a if reverse else b
   await settle(aa)
   # slope requires y-interpolated near endpoints, traversal uses physical slope contact
   var result=await walk_points([[bb.x,bb.y,bb.z]],2.0)
   result.id=e.id+("-down"if reverse else"-up");result.kind="physical_escalator_slope_walk";checks.append(result);print("ESC_WALK ",result.id," ",result["pass"])
 player.belt_enabled=true
 for e:Dictionary in manifest.escalators:
  var a=v3(e.test_start);var b=v3(e.test_end);var u=Vector3(e.u[0],0,e.u[1])
  var start=a+u*.85 if e.direction=="UP" else b-u*.85
  var target=b-u*.65 if e.direction=="UP" else a+u*.65
  await settle(start);player.auto_active=false
  var passed:bool=false;var ticks:int=0
  for i in range(1800):
   await get_tree().physics_frame;ticks+=1
   if Vector2(player.position.x-target.x,player.position.z-target.z).length()<.30 and abs(player.position.y-target.y)<.2:passed=true;break
  checks.append({"id":e.id+"-belt","kind":"automatic_conveyor_without_movement_input","pass":passed,"position":player.position,"target":target,"ticks":ticks})
  print("BELT ",e.id," ",passed)
 player.belt_enabled=false
 # Barrier probes: push into actual glazing/guardrail, not just source polygons.
 var probes:Array=[{"id":"2F-void-guard-west","a":Vector3(-13.5,5.525,0),"b":Vector3(-9,5.525,0)},{"id":"3F-void-guard-west","a":Vector3(-13.5,10.875,0),"b":Vector3(-9,10.875,0)}]
 for probe:Dictionary in probes:
  await settle(probe.a);player.auto_active=true;player.auto_target=probe.b;player.auto_speed=3
  for i in range(100):await get_tree().physics_frame
  player.auto_active=false
  var passed=player.position.x< -12 and abs(player.position.y-probe.a.y)<.2
  checks.append({"id":probe.id,"kind":"guardrail_prevents_fall","pass":passed,"end":player.position})
 # Actual 3D ray checks separate open atrium from crossing-bridge slab.
 var rays:Array=[
 {"id":"1F-departure-underfloor-support","a":Vector3(-20,.5,17),"b":Vector3(-20,-.5,17),"hit_expected":true},
 {"id":"2F-departure-underfloor-support","a":Vector3(23,5.9,17),"b":Vector3(23,5.0,17),"hit_expected":true},
 {"id":"2F-void-has-no-floor","a":Vector3(-1,5.9,2),"b":Vector3(-1,5.0,2),"hit_expected":false},
 {"id":"3F-void-has-no-floor","a":Vector3(-1,11.3,2),"b":Vector3(-1,10.4,2),"hit_expected":false},
 {"id":"2F-crossing-bridge-floor","a":Vector3(0,5.9,-6),"b":Vector3(0,5.0,-6),"hit_expected":true},
 {"id":"3F-crossing-bridge-floor","a":Vector3(0,11.3,-6),"b":Vector3(0,10.4,-6),"hit_expected":true},
 {"id":"1F-under-void-ground-floor","a":Vector3(-1,.5,2),"b":Vector3(-1,-.5,2),"hit_expected":true}]
 for ray:Dictionary in rays:
  var query=PhysicsRayQueryParameters3D.create(ray.a,ray.b);query.exclude=[player.get_rid()]
  var hit=get_world_3d().direct_space_state.intersect_ray(query)
  checks.append({"id":ray.id,"kind":"actual_3D_floor_or_void_raycast","pass":(not hit.is_empty())==ray.hit_expected,"hit":not hit.is_empty(),"hit_position":hit.get("position",null)})
 var passed:int=0
 for c:Dictionary in checks:
  if c["pass"]:passed+=1
 results.checks=checks;results.passed=passed;results.failed=checks.size()-passed;results.total=checks.size();results.kind="Godot CharacterBody3D collision walking, automated; not a human playtest";results.capsule_radius_m=.3;results.capsule_height_m=1.8;results.physics_hz=60;results.projection_or_teleport_during_route=false
 write_json("walk-results.json",results);print("WALK_COMPLETE ",passed,"/",checks.size());get_tree().quit(0 if passed==checks.size()else 1)

func collision_diagnostics()->Array:
 var out:Array=[]
 for i in range(player.get_slide_collision_count()):
  var c=player.get_slide_collision(i);out.append({"name":c.get_collider().name,"normal":c.get_normal(),"point":c.get_position()})
 return out
