"""Package source + original screenshots, no engine cache and no existing game data."""
from pathlib import Path
import json,hashlib,zipfile,shutil
P=Path(__file__).resolve().parents[1];R=Path('/workspace/1');OUT=R/'downloads/FIND_YOURSELF-B-Time-Plaza-Validation-v1.zip';D=R/'docs/b-time-plaza-validation-v1'
files=[p for p in P.rglob('*')if p.is_file() and not any(x in p.relative_to(P).parts for x in ['.godot','__pycache__','builds'])and p.suffix!='.import'and p.name!='release-manifest.json']
manifest={'project':'FIND YOURSELF B Time Plaza standalone validation v1','engine':'Godot 4.6.3','main_game_modified':False,'frozen_design_modified':False,'integration_performed':False,'files':[{'path':str(p.relative_to(P)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(files)]}
(P/'release-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));files.append(P/'release-manifest.json')
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(files):z.write(p,'FIND_YOURSELF-B-Time-Plaza-v1/'+str(p.relative_to(P)))
with zipfile.ZipFile(OUT)as z:
 crc=z.testzip();bad=[]
 for e in manifest['files']:
  data=z.read('FIND_YOURSELF-B-Time-Plaza-v1/'+e['path'])
  if hashlib.sha256(data).hexdigest()!=e['sha256']:bad.append(e['path'])
assert crc is None and not bad
receipt={'zip_bytes':OUT.stat().st_size,'zip_sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'archive_members':len(files),'crc_valid':True,'manifest_hash_mismatches':bad,'excludes_godot_import_cache':True,'includes_windows_executable':False,'project_requires_Godot_4_6_3':True}
(D/'zip-verification.json').write_text(json.dumps(receipt,indent=2));shutil.copy(P/'release-manifest.json',D/'release-manifest.json');print(json.dumps(receipt,indent=2))
