#!/usr/bin/env python3
"""Evidence book: actual Godot viewport PNGs plus explicit measured/untested states."""
from pathlib import Path
import json,sys,csv,hashlib,shutil,platform,subprocess
sys.path.append('/workspace/.venvs/find-yourself/lib/python3.12/site-packages')
import fitz
from shapely.geometry import shape,box
P=Path(__file__).resolve().parents[1];E=P/'evidence';S=P/'source';D=Path('/workspace/1/docs/b-time-plaza-validation-v1');D.mkdir(exist_ok=True)
m=json.load(open(S/'scene-manifest.json'));w=json.load(open(E/'walk-results.json'));r=json.load(open(E/'render-results.json'));v=json.load(open(E/'geometry-verification.json'));design=json.load(open(S/'design-extract.json'))
fontfile=str(P/'assets/NotoSansCJKjp-Regular.otf');font=fitz.Font(fontfile=fontfile)
pdf=fitz.open();page=None
W,H=842,595;ink=(.14,.18,.19);teal=(.10,.35,.32);muted=(.37,.41,.41)
def txt(x,y,t,size=10,color=ink):
 page.insert_text((x,y),str(t),fontname='JP',fontfile=fontfile,fontsize=size,color=color)
def boxtext(x,y,width,t,size=10,line=17,color=ink):
 # Explicit wrapping with the exact embedded font width.
 yy=y
 for para in str(t).split('\n'):
  row=''
  for c in para:
   if row and font.text_length(row+c,fontsize=size)>width:txt(x,yy,row,size,color);yy+=line;row=c
   else:row+=c
  if row:txt(x,yy,row,size,color)
  yy+=line
 return yy

def new(title,sub=''):
 global page
 page=pdf.new_page(width=W,height=H);page.insert_font(fontname='JP',fontfile=fontfile)
 page.draw_rect(fitz.Rect(0,0,W,8),color=None,fill=teal)
 txt(30,42,title,19,teal)
 if sub:txt(30,64,sub,9,muted)
 txt(30,578,'FIND YOURSELF / B館「時の広場」独立Godot検証 v1  |  2026-10-26 JST',8,muted);txt(782,578,str(len(pdf)),8,muted)
def row(y,label,value):
 page.draw_line((30,y+7),(812,y+7),color=(.84,.87,.86),width=.4);txt(35,y,label,10,muted);boxtext(220,y,578,value,11,17)
def polys(g):return[]if g.is_empty else[g]if g.geom_type=='Polygon'else[x for x in getattr(g,'geoms',[])if x.geom_type=='Polygon']
def lines(g):return[]if g.is_empty else[g]if g.geom_type=='LineString'else[x for x in getattr(g,'geoms',[])if x.geom_type=='LineString']
def screenshot(path,rect):page.insert_image(rect,filename=str(path),keep_proportion=True)
new('B館「時の広場＋周辺店舗街」 3D検証 v1','敷地全体設計v3からの初回建築スライス / ゲーム本体には未統合 / 承認待ち')
screenshot(E/'01-1F-time-plaza.png',fitz.Rect(30,83,535,367))
boxtext(558,105,253,'3階吹き抜け・横断橋・店舗街・エスカレーターをGodot内に構築。左は実ViewportのPNGです。\nFF15級の完成品質には未到達。今回は構造・通行と意匠の方向性を確認する段階です。',12,23)
row(406,'検証範囲','163×140m、1F・2F・3F。80区画が交差、49区画の全形を含む。入口66か所を物理検査。')
row(452,'物理歩行検査',f"{w['passed']}/{w['total']} 合格、不合格 {w['failed']}。自動操作の実物理検査。人間による実機テストは未実施。")
row(498,'原本保護',f"旧ゲーム・旧設計など {len(json.load(open(S/'protected-originals.json'))):,} ファイルのSHA256を再照合。既存ゲームの変更・統合なし。")
new('検証範囲・座標・組立内容','全館・全15層の3D化ではありません。完成区画数と切出し区画数を区別します。')
for y,l,t in[(100,'座標','元世界X=-429、Z=46がシーン原点。1unit=1m。切出しX=-512〜-349、Z=-16〜124。'),(148,'床・吹き抜け','1F Y=0、2F Y=5.525、3F Y=10.875。床厚0.38m、元図面の穴と横断橋を保持して三角形化。'),(196,'外周・店舗','店舗境界、開いた入口、ガラス面、枠・巾木・看板・店内通路・バックルームを原座標から組立。'),(244,'共用部','床の目地、天井パネル・照明・給気スリット・スプリンクラー、ソファではなく源図のベンチと植栽。'),(292,'上下移動','西側1⇄2Fと東側2⇄3F、上下各1基の計4基。踏段・側板・手すり・くし板・乗降面。'),(340,'新規意匠案','600mm柱4本、トップライト、店舗造作・商品・架空看板・素材は検証用の提案。設計原本未反映。'),(388,'規模',f"描画三角形 {m['mesh_triangles']:,}、衝突三角形 {m['collision_triangles']:,}、材料バッチ {m['material_batches']}＋看板。造作棚 {m['generated_fixtures']}。"),(436,'範囲の終端','切出し境界の閉鎖面は検証用。館全体の外壁ではない。14入口は範囲外のため物理検査対象外。'),(484,'本体機能','NPC・スキャン・AP・セーブ・猫等は本体に維持。本シーンには持ち込まず、NPC0人で検査。')]:row(y,l,t)
new('3D化で判明した問題と、検証シーン内の修正','元の敷地v3、B館の設計原本、Godot本体は変更していません。')
boxtext(32,103,775,'1. 出発階エスカレーター下床の欠落\n2Dのshaftマスクをそのまま床開口にすると、上り始める階でもエスカレーター下の床がなくなりました。独立シーン内で出発階のみ受け床を追加しました。到着階の必要開口は維持しています。設計への反映は要確認です。',11,20)
y=239
for a in m['isolated_slab_additions']:
 txt(38,y,a['id'],10);txt(500,y,f"{['1F','2F','3F'][a['level']]} / {a['area_m2']:.2f}㎡",10);y+=24
boxtext(32,365,775,'2. 店舗のガラス端部での停止\n初回再検査ではB1-051とB3-057への経路が追加ガラスの端部で停止しました。入口位置を動かさず、実際のガラス・枠とカプセルの余裕0.06mを考慮して経路を再生成しました。経路途中の座標投影やテレポートは使っていません。\n3. 実画面の見え方\nガラスを不透明な遮光板として影に落としていた点、床の反射、柱で隠れた撮影位置を修正。変更前の歩行結果はwalk-before-correction.jsonに保存。\n閉鎖帯追加時の9件の退行はservice_zonesの適用修正で解消（walk-closure-regression.json）。',11,20)
# Source-exact vector floor plans, isolated slab changes separately highlighted.
crop=box(*m['crop_world_xz']);scale=3.05;ox,oy=85,100
minx,minz,maxx,maxz=m['crop_world_xz']
def xy(x,z):return fitz.Point(ox+(x-minx)*scale,oy+(z-minz)*scale)
def polygon(g,color,outline=(.28,.32,.31)):
 for po in polys(g.intersection(crop)):
  path=page.new_shape();path.draw_polyline([xy(x,z)for x,z in po.exterior.coords]);path.finish(color=outline,fill=color,closePath=True,width=.4);path.commit()
  for ring in po.interiors:
   path=page.new_shape();path.draw_polyline([xy(x,z)for x,z in ring.coords]);path.finish(color=outline,fill=(1,1,1),closePath=True,width=.3);path.commit()
for f in design['floors']:
 lev=f['level'];new(f"{f['label']} 切出し平面と検証対象",'ベクトル図面：拡大可能。IDは床別接頭辞B1/B2/B3を省略して末尾を表示。')
 polygon(shape(f['floor_plate']),(.94,.94,.91));polygon(shape(f['public']),(.90,.94,.94))
 for s in f['stores']:
  poly=shape(s['polygon']).intersection(crop)
  if poly.is_empty:continue
  polygon(poly,(.86,.88,.82));polygon(shape(s['backroom']),(.75,.77,.73))
  c=poly.representative_point();t=xy(c.x,c.y);txt(t.x-6,t.y,s['id'].split('-',1)[1],5.3)
  e=s['entry'];point=xy(*e)
  if crop.contains(shape({'type':'Point','coordinates':e})):page.draw_circle(point,2,color=teal,fill=(.22,.65,.51),width=.5)
 polygon(shape(f['void']),(1,1,1))
 for a in m['isolated_slab_additions']:
  if a['level']==lev:polygon(shape(a['polygon']),(.92,.77,.51))
 for e in f['escalators']:
  if e['atrium']==2:polygon(shape(e['shaft']),(.65,.71,.74),(.28,.33,.35))
 for s in f['stores']:
  for l in lines(shape(s['wall_solids']).boundary.intersection(crop)):
   co=list(l.coords);path=page.new_shape();path.draw_polyline([xy(x,z)for x,z in co]);path.finish(color=(.24,.27,.26),width=.3);path.commit()
 boxtext(695,106,120,'共用床: 淡青\n店舗: 淡緑\nバックルーム: 灰緑\n入口: 緑点\n吹き抜け: 白\nエスカレーター: 灰\n橙: 出発階補足床（灰の下）',9,18)
 boxtext(695,300,120,f"階高 Y={f['height']}m\n切出し163×140m\n右/下側に範囲外の続きあり。\n原本の館形状は変更なし。",9,18)
 page.draw_line((85,549),(85+20*scale,549),color=ink,width=2);txt(86,562,'0                    20m',8)
# Every actual eye-height viewport, no AI images or architectural stand-in renders.
shot_info={
'01-1F-time-plaza':('1F：時の広場・吹き抜け','眼高1.65m。3層の開口、横断橋、採光と周囲店舗のつながり。'),
'02-1F-west-escalators':('1F：西側エスカレーター','眼高1.65m。1⇄2Fの乗降面と周辺床。機械の循環アニメーションは未実装。'),
'03-2F-crossing-bridge':('2F：回廊・横断橋・対岸店舗','眼高7.175m（床から1.65m）。柱で視界が塞がれた撮影位置を修正済み。'),
'04-2F-storefront':('2F：店舗入口・ガラス・共用通路','眼高7.175m。開口・枠・店内造作の見え方。店舗ごとの完成内装は未施工。'),
'05-3F-void-and-roof':('3F：吹き抜けとトップライト','眼高12.525m（床から1.65m）。ガラス手すり、床端、上部骨組。'),
'06-1F-north-shopping-street':('1F：北側店舗街','眼高1.65m。架空看板とガラス面・店舗入口の連続。未施工の端部壁も含む。'),
'07-1F-cafe-interior':('1F：カフェ区画の内部','眼高1.65m。開いた造作棚とケース。家具・商品は検証用の意匠案。'),
'08-1F-bookshop-interior':('1F：書店区画の内部','眼高1.65m。棚・仮商品・入口からの見通し。専用書棚・完成商品表現は未施工。')}
for id,(title,caption)in shot_info.items():
 new(title,'実際のGodot 4.6.3 Viewport / 1280×720 / 生成画像・レタッチなし')
 screenshot(E/(id+'.png'),fitz.Rect(30,82,812,522));txt(32,548,caption,9)
new('実測性能：クラウドのソフトウェア描画','RTX 4060実機ではありません。NPCは0人。原本のゲーム性能を示す値ではありません。')
boxtext(32,101,775,f"GPU表示: {r['adapter']}\nGodot {r['godot_version']['string']} / {r['renderer']} / 1280×720 / MSAA4x / 2分割影 / VSync無効。エディタ付属実行バイナリで単独計測。Release版は未測定。初回読込・シェーダー準備後に主要3視点を各30フレーム計測。短時間サンプルです。",10,19)
y=205
for i,(l,x,sz)in enumerate([('視点',35,11),('平均FPS',355,11),('中央値ms',475,11),('95%点ms',590,11),('サンプル',713,11)]):txt(x,y,l,sz,teal)
y+=32
for x in r['performance']:
 txt(35,y,x['id'],10);txt(355,y,f"{x['fps_from_mean_frame_time']:.2f}",11);txt(475,y,f"{x['p50_ms']:.2f}",11);txt(590,y,f"{x['p95_ms']:.2f}",11);txt(713,y,str(x['sample_frames']),11);y+=35
x=r['walking_performance'];txt(35,y,'1F：実物理の往復移動',10);txt(355,y,f"{x['fps_from_mean_frame_time']:.2f}",11);txt(475,y,f"{x['p50_ms']:.2f}",11);txt(590,y,f"{x['p95_ms']:.2f}",11);txt(713,y,str(x['sample_frames']),11)
boxtext(32,420,775,'平均FPSはフレーム時間の平均から算出。95%点は1% Lowではありません。画面読出し・PNG保存は測定前に実施しています。全フレーム時間はrender-results.jsonに保存。\nRTX実機・Forward+・長時間負荷・5,000人時の性能・温度・VRAM上限・Windowsでの操作は未測定です。目標60FPSの達成判定は保留します。',11,20)
new('通行検証と独立した形状検査','Godotの実物理と、元図面に対する独立した幾何検査を分けて報告。')
kind_names={'capsule_move_and_slide_to_shop_or_public_waypoint':'店舗入口66＋共用経路9','physical_escalator_slope_walk':'4基の上下歩行','automatic_conveyor_without_movement_input':'4基の入力なし自動搬送','guardrail_prevents_fall':'2F・3Fの転落防止','actual_3D_floor_or_void_raycast':'床開口・横断橋・補足床レイ'}
y=106
for kind,label in kind_names.items():
 items=[x for x in w['checks']if x['kind']==kind];txt(35,y,label,12);txt(540,y,f"{sum(x['pass']for x in items)}/{len(items)} 合格",12,teal);y+=36
boxtext(32,316,775,f"物理検査合計: {w['passed']}/{w['total']}、不合格{w['failed']}。半径0.30m・全高1.80m、60Hz。各ケースの開始地点を設定し、その後はmove_and_slideで進行。途中ワープや到達点の投影なし。\n独立形状検査: {v['passed']}/{v['total']}合格、不合格{v['failed']}。床の衝突三角形を設計原本＋明示した補足床と比較。頂点量子化の面積差許容0.001㎡、重複許容0.000001㎡。",11,20)
boxtext(32,448,775,'未検証: 人間によるプレイ感、混雑時すれ違い、店舗入口全幅、全商品間、全位置での手すり安全性、車椅子、実機の段差/エスカレーター循環動作、館全体への連絡、他の12層。元設計の全館図面検査の合格を本シーンの実歩行合格へ読み替えていません。',10,19)
new('残課題・素材とライセンス','完成扱いにしない項目を、統合前の確認事項として残します。')
boxtext(32,103,775,'意匠: FF15級の最終品質は未達。GI・反射・細かな建材端部、店舗ごとの完成内装、休憩家具と植栽の品質、外周の白い壁、微細な汚れ、昼光と店舗照明の調整が必要。\n機構: 踏段は静止、ベルト搬送は実装。実機相当の循環・ドア・設備制御は今後。\n設計整合: 出発階の補足床4区画と新規柱・トップライトは検証案。原本への反映・本体統合は承認待ち。',11,21)
boxtext(32,290,775,'オリジナル: 建築メッシュ・造作・商品・看板・時計・数値生成石/木/塗装PBRマップ・シェーダー。本プロジェクト用に新規制作。新しい一般向け公開ライセンスは未設定。外部写真・HDRI・FF15資産・実在ブランドのロゴなし。\nフォント: Noto Sans CJK JP Regular / SIL OFL1.1、同梱licenses/Noto-OFL.txt。\nGodot 4.6.3: MIT。エンジンと第三者ライブラリ一覧をlicenses/へ同梱。\n制作専用: Shapely(BSD-3-Clause / GEOS LGPL)、NumPy(BSD-3-Clause等)、Pillow(HPND)、PyMuPDF(AGPL-3.0)。ライブラリ本体は配布プロジェクトに同梱しません。',10,20)
new('確認方法・提出データ','実装の統合は行わず、このシーンの画面・通行・品質をご確認いただく段階です。')
boxtext(32,105,775,'1. ZIPをすべて展開します。\n2. Godot 4.6.3のプロジェクト一覧でproject.godotをインポートします。\n3. 素材の初回インポートを待ち、F5で開始します。\n4. WASD・マウス・Shiftで歩き、必要に応じて1/2/3で検証階を選びます。エスカレーターでも上下移動できます。\n通常実行にはPythonや旧ゲームは不要です。既存ゲームにファイルを上書きしないでください。',12,25)
boxtext(32,310,775,'evidence/: 実画面PNG8枚、描画・移動FPSの生データ、物理歩行検査、独立床形状検査、修正前の不合格記録。\nsource/: 設計抽出、元SHA256、切出し範囲、店舗台帳、経路、3D差分。\nauthoring/: 制作・検査・レポート生成スクリプト。通常プレイには不要。\nlicenses/: 使用フォント・エンジンのライセンス原文。\nrelease-manifest.json: 配布ファイルのSHA256。',11,23)
txt(32,515,'承認前にゲーム本体へ統合しません。',13,teal)
out=Path('/workspace/1/downloads/FIND_YOURSELF-B-Time-Plaza-Validation-v1.pdf');pdf.save(out,garbage=4,deflate=True);print('PDF',len(pdf),out.stat().st_size)
# Font / layout / image integrity and all page rasters.
book=fitz.open(out);bad=[]
for i,p in enumerate(book):
 pix=p.get_pixmap(matrix=fitz.Matrix(.35,.35),alpha=False)
 if not pix.width or not pix.height:bad.append(i+1)
 for b in p.get_text('dict')['blocks']:
  if b['type']!=0:continue
  for l in b['lines']:
   for span in l['spans']:
    q=fitz.Rect(span['bbox'])
    if q.x0<-.5 or q.y0<-.5 or q.x1>W+.5 or q.y1>H+.5:bad.append({'page':i+1,'text':span['text'],'bbox':span['bbox']})
book_check={'pages':len(book),'all_pages_rendered':True,'text_outside_page':bad,'actual_viewport_pngs':8,'passed':not bad};(E/'pdf-verification.json').write_text(json.dumps(book_check,ensure_ascii=False,indent=2));print('PDF_VERIFY',book_check)
# Ledger and environment record with no secrets.
with open(S/'shop-ledger.csv','w',newline='',encoding='utf-8-sig')as outcsv:
 fields=['id','level','category','brand','clear_width_m','frontage_m','depth_m','full_polygon_in_scope','entrance_in_test_scope','fixtures','entry_world','entry_local'];writer=csv.DictWriter(outcsv,fields);writer.writeheader();writer.writerows({k:s[k]for k in fields}for s in m['shops'])
# Recompute asset hashes after the final geometry revision.
asset_rows=[]
for asset in sorted((P/'assets').glob('*')):
 if asset.suffix=='.import':continue
 role='日本語フォント' if asset.suffix=='.otf' else '設計由来3Dメッシュ・衝突形状' if asset.name=='geometry.json' else '数値生成PBRマップ' if any(k in asset.name for k in ['albedo','normal','roughness']) else 'オリジナル架空看板/時計'
 asset_rows.append({'file':str(asset.relative_to(P)),'role':role,'creator':'Noto Project' if asset.suffix=='.otf' else 'FIND YOURSELF project','license':'SIL OFL 1.1' if asset.suffix=='.otf' else 'Original project work; public reuse license not separately assigned','sha256':hashlib.sha256(asset.read_bytes()).hexdigest()})
with open(S/'asset-license-ledger.csv','w',newline='',encoding='utf-8-sig')as outcsv:
 writer=csv.DictWriter(outcsv,list(asset_rows[0]));writer.writeheader();writer.writerows(asset_rows)
for fn in['README.md']:
 shutil.copy(P/fn,D/fn)
for fn in['scene-manifest.json','shop-ledger.csv','asset-license-ledger.csv']:
 shutil.copy(S/fn,D/fn)
for fn in['render-results.json','walk-results.json','walk-before-correction.json','walk-closure-regression.json','geometry-verification.json','pdf-verification.json','render-walk-version-match.json',*[x+'.png'for x in shot_info]]:
 shutil.copy(E/fn,D/fn)
