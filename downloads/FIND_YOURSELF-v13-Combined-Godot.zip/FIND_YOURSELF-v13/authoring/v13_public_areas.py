"""Complete existing visitor arrival/terrace finishes, not repurpose unassigned service floor.
Finishes are clipped to real horizontal collision triangles; no decorative floor across a void.
"""
from pathlib import Path
import sys,math,numpy as np,copy
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import constrained_delaunay_triangles,set_precision
F=read(P/'source/v11/floors-updated.json');M={};coll={};render_group='';extra=[];signs=[];rows=[];garden_routes=[]
def pos(x,y,z):return[float(x),float(y),float(z)]
exec((P/'authoring/mesh_primitives.py').read_text())
def world(g):return affinity.translate(g,429,-46)
def pp(q,y):return pos(q[0]+429,y,q[1]-46)
# Combine actual top faces only; all keys/UVs of the underlying structural packs remain unchanged.
floor_triangles=[]
for path in ['assets/v10/base-b.pack.zst','assets/v10/base-site.pack.zst','assets/v11/repairs.pack.zst','assets/v12/es-safety.pack.zst']:
 g=load_pack(P/path)
 for a in g['colliders'].values():
  a=np.asarray(a).reshape(-1,3,3);mask=(np.ptp(a[:,:,1],axis=1)<.001)&((abs(a[:,:,1].mean(1)+5.35)<.004)|(abs(a[:,:,1].mean(1)-16.4)<.004));floor_triangles.extend(a[mask])
floor_triangles=np.asarray(floor_triangles);actual={}
for lev in[-1,3]:
 y=HEIGHT[lev];a=floor_triangles[abs(floor_triangles[:,:,1].mean(1)-y)<.004];actual[lev]=set_precision(unary_union([Polygon(t[:,[0,2]])for t in a if Polygon(t[:,[0,2]]).area>.001]),.001)
# Keep new C roof props and finishes on support shared by normal geometry and the reduced-deck option.
copt=next(q for q in read(P/'source/v12/C-outlet-proposal.json')['floors']if q['level']==3)['proposed_floor']
routes=read(P/'source/physical-routes-v11.json')
for f in F:
 lev=f['level'];wing=f['wing'];y=f['height']
 if lev not in[-1,3]:continue
 garden=unary_union([q['polygon']for q in f.get('gardens',[])if q.get('kind')=='roof_garden'])
 desired=f['public'].union(garden).intersection(f['floor_plate']);supported=world(desired).intersection(actual[lev]);render_group='V13-PUBLIC-'+wing+'-'+f['label']
 if wing=='C'and lev==3:supported=supported.intersection(world(copt))
 surf(supported,y+.003,'v10_floor_B'if lev==-1 else'v8_pavers')
 rows.append({'id':wing+'-'+f['label'],'existing_declared_public_m2':f['public'].area,'declared_garden_m2':garden.area,'render_finish_m2':supported.area,'uncovered_candidate_m2':world(desired).difference(supported).area,'structural_floor_added':False,'material':'basement tile'if lev==-1 else'roof terrace pavers'})
 # Existing three B roof gardens were labelled in the design, omitted from public map/amenity allocation.
 if wing!='B'or lev!=3:continue
 avoid=unary_union([LineString([(p[0]-429,p[2]+46)for p in r['points']]).buffer(1.05)for r in routes if any(abs(p[1]-y)<.01 for p in r['points'])]);beds=unary_union([p['polygon']for p in f.get('plant_beds',[])]);reserved=avoid.union(beds.buffer(.25));occupied=[]
 for zone in f['gardens']:
  safe=zone['polygon'].intersection(f['floor_plate']).difference(reserved).difference(f.get('overhang',Polygon())).buffer(-.18);centre=zone['polygon'].centroid;count=0
  bounds=safe.bounds
  candidates=sorted([(x,z)for x in np.arange(bounds[0],bounds[2],1.0)for z in np.arange(bounds[1],bounds[3],1.0)],key=lambda q:Point(q).distance(centre))if not safe.is_empty else[]
  for xx,zz in candidates:
   p=np.array([xx,zz]);n=np.array([0.,-1. if zz>centre.y else 1.]);u=np.array([1.,0.]);fp=rect(p,u,2.3,.70)
   if not safe.covers(fp):
    u=np.array([0.,1.]);n=np.array([-1. if xx>centre.x else 1.,0.]);fp=rect(p,u,2.3,.70)
   if count>=4 or not safe.covers(fp)or not world(fp).buffer(.001).within(actual[lev])or any(fp.distance(q)<3 for q in occupied):continue
   group='V13-'+zone['id'];extra.append({'asset':'../v13/models/public_bench','p':pp(p,y+.015),'u':u.tolist(),'front':n.tolist(),'group':group});render_group=group;visible=M;M={};extrude(world(fp),y,.97,'v10_oak',True);M=visible;occupied.append(fp);count+=1
   signs.append({'id':group+'-'+str(count),'text':zone['name']+' / 休憩テラス','p':pp(p+n*.37,y+2.2),'n':n.tolist(),'w':2.1,'role':'HUB'})
   rows.append({'id':group+'-bench-'+str(count),'kind':'roof-garden-bench','footprint':fp,'world_point':pp(p,y),'reserved_route_overlap_m2':fp.intersection(avoid).area,'supported':True,'private_plant_zone_reassigned':False})
  print('B_ROOF_GARDEN',zone['id'],count,'benches',flush=True)
# Variant-aware props, including RF arrival seating from the previous layout pass.
a=read(P/'source/v13/amenities.json');kept=[];suppressed=[]
for d in a['instances']:
 if d['group'].startswith('V13-HUB-C-RF'):
  point=Point(d['p'][0]-429,d['p'][2]+46)
  if not copt.buffer(-1.5).covers(point):suppressed.append(d);continue
 kept.append(d)
a['instances']=kept+extra;a['signs']+=signs;write(P/'source/v13/amenities-public.json',a);write(P/'source/v13/public-finish-audit.json',{'zones':rows,'C_RF_unsafe_prop_candidates_omitted':suppressed,'unassigned_service_rooms_completed':False,'existing_floor_15_layers_unchanged':True});save_zst(P/'assets/v13/public-areas.pack.zst',{'surfaces':M,'colliders':coll,'signs':[],'lights':[]});print('PUBLIC_AREAS_DONE',len(rows),len(extra),flush=True)
# M map: show accessible toilets, existing roof gardens, actual arrival clusters. No false equipment availability.
from shapely.geometry import mapping
def rings(g):return[[list(p.exterior.coords)]+[list(r.coords)for r in p.interiors]for p in polys(g)]
for variant in['map-data','map-data-C-option']:
 data=read(P/'source/v12'/(variant+'.json'))
 for m in data:
  if m['wing']not in['A','B','C']:continue
  f=next(f for f in F if f['wing']==m['wing']and f['label']==m['label'])
  for c in f['cores']:
   g=c['rooms']['accessible_wc'];m['items'].append({'id':c['id']+'-AWC','kind':'トイレ','geometry':rings(g),'point':list(g.centroid.coords)[0],'implemented':True})
  if f['wing']=='B'and f['level']==3:
   m['public']=rings(f['public'].union(unary_union([z['polygon']for z in f['gardens']])).intersection(f['floor_plate']))
   for z in f['gardens']:m['items'].append({'id':z['id'],'kind':'庭園','geometry':rings(z['polygon']),'point':list(z['polygon'].centroid.coords)[0],'implemented':True})
  for h in read(P/'source/v13/arrival-hubs.json'):
   if h.get('status')=='INSTALLED'and h.get('wing')==f['wing']and h.get('floor')==f['label']:m['items'].append({'id':h['id'],'kind':'休憩所'if f['level']==3 else'ロッカー','geometry':rings(h['footprint']),'point':[h['point'][0]-429,h['point'][2]+46],'implemented':True})
 write(P/'source/v13'/(variant+'.json'),data)
