from pathlib import Path
import sys,numpy as np,math,heapq
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
from shapely import set_precision
src=(P/'authoring/v12_transfer_plan_distances.py').read_text();exec(src[src.index('def route('):src.index('for r in rows:')].replace('step=.75','step=.25'))
rows=[];audit=[]
def pp(q,y):return[q[0]+429,y,q[1]-46]
for f in read(P/'source/v11/floors-updated.json'):
 for c in f['cores']:
  room=c['rooms'];ds={q['id']:q for q in c['doors']};q=ds['CORE'];n=np.array(room['front_lobby'].centroid.coords[0])-q['p'];n=n/np.linalg.norm(n);a=np.array(q['p'])-n*.7
  accessible=[room[k]for k in ['front_lobby','lift_access','ev_front_lobby','accessible_access','men','women','accessible_wc']if k in room];area=unary_union([set_precision(g,.001)for g in accessible]).union(set_precision(rect(q['p'],q['axis'],q['w'],2.0),.001));walls=c['room_wall_solids'].union(unary_union(c.get('cubicle_wall_solids',[])))
  for d in c['doors']:walls=walls.difference(rect(d['p'],d['axis'],d['w']+.04,.85))
  area=area.difference(walls).buffer(-.34,join_style=2)
  for key in ['women','men','accessible_wc']:
   goal=room[key].centroid.coords[0];path=route(a,goal,area)
   rid='ACCESS-'+f['wing']+'-'+f['label']+'-'+c['id']+'-'+key;audit.append({'id':rid,'plan_path_found':path is not None,'grid_m':.25,'method':'canonical room union minus walls, .34m capsule clearance; actual physics tested separately'})
   if path:rows.append({'id':rid,'kind':'public-access','wing':f['wing'],'floor':f['label'],'core':c['id'],'points':[pp(p,f['height'])for p in path]})
write(P/'source/v13/public-access-routes.json',rows);write(P/'source/v13/public-access-plan-audit.json',audit);print('PUBLIC_ACCESS',len(rows),'of',len(audit),flush=True)
