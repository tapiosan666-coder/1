from pathlib import Path
import sys,hashlib,json,csv,numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
F=read(P/'source/v11/floors-updated.json');lookup={s['id']:(f,s)for f in F for s in f['stores']};old=Path('/workspace/FIND_YOURSELF-Site-v12');audit=[]
for folder,name in [('v10','base-site'),('v12','C-outlet')]:
 before=load_pack(old/'assets'/folder/(name+'.pack.zst'));after=load_pack(P/'assets'/folder/(name+'.pack.zst'));changed=[];unexpected=[]
 for k,d in before['surfaces'].items():
  equal=k in after['surfaces']and np.array_equal(triangles(d),triangles(after['surfaces'][k]))
  if not equal:
   changed.append(k)
   if k.split('@@')[0]not in['oak','ceramic_0']:unexpected.append(k)
 collchanged=[k for k,v in before['colliders'].items()if not np.array_equal(v,after['colliders'].get(k,np.array([])))];unexpected+=['collider:'+k for k in collchanged if k not in['oak','ceramic_0']]
 audit.append({'pack':name,'changed_surface_keys':changed,'changed_collider_materials':collchanged,'unexpected_structure_changes':unexpected,'wall_floor_glass_geometry_unchanged':not unexpected})
 assert not unexpected
codes={}
for fn in['player.gd','escalator_v2.gd','elevators_v11.gd']:
 a=(old/fn).read_bytes();b=(P/fn).read_bytes();codes[fn]={'unchanged_from_v12':a==b,'sha256':hashlib.sha256(b).hexdigest()};assert a==b
canonical_same=(old/'source/site-v11.json.zst').read_bytes()==(P/'source/site-v11.json.zst').read_bytes();assert canonical_same
# New models intentionally have simple collision envelopes. Validate allocation, not full mesh equivalence.
retail=[]
for fn in['basement-store-ledger.json','roof-store-ledger.json']:
 for r in read(P/'source/v13'/fn):
  f,s=lookup[r['id']];fixtures=[q for q in r['fixtures']if q['role']!='table parasol'];out=sum(q['footprint'].difference(s['sales'].buffer(.002)).area for q in fixtures);retail.append({'id':r['id'],'industry':s['category'],'fixture_count':r['fixture_count'],'counter_placed':r.get('checkout_placed',r.get('counter_placed')),'fixtures_outside_sales_m2':out,'primary_aisle_m':2.1});assert out<.0001
summary={'floors':len(F),'store_IDs':len(lookup),'toilet_core_floor_locations':sum(len(f['cores'])for f in F),'original_canonical_design_bytes_unchanged':canonical_same,'original_scan_game_integrated':False,'code_invariants':codes,'geometry_changes':audit,'retail_allocations':retail,'structural_capacity_certified':False,'RF_SUPPORT_16':'UNAPPROVED'}
write(P/'source/v13/inventory-and-preservation.json',summary)
def csvout(name,fields,rows):
 p=P/'source/v13'/name
 with p.open('w',newline='',encoding='utf-8-sig')as f:w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');w.writeheader();w.writerows([{k:r.get(k,'')for k in fields}for r in rows])
 Path(str(p)+'.import').write_text('[remap]\n\nimporter="keep"\n')
csvout('store-fitout-summary.csv',['id','industry','fixture_count','counter_placed','fixtures_outside_sales_m2','primary_aisle_m'],retail)
remaining=[]
for f in F:
 if f['level']not in[-1,3]:continue
 for q in f.get('program',[]):
  if q.get('public',False)or q['polygon'].area<5:continue
  c=q['polygon'].representative_point();remaining.append({'id':q['id'],'wing':f['wing'],'floor':f['label'],'role':q.get('name',''),'area_m2':q['polygon'].area,'world_x':c.x+429,'world_y':f['height'],'world_z':c.y-46,'status':'v13 fit-out scope excluded / detailed equipment not verified'})
csvout('remaining-service-zones.csv',['id','wing','floor','role','area_m2','world_x','world_y','world_z','status'],remaining)
print('PRESERVATION',len(audit),'packs; unchanged player/ES/EV; canonical 15 floors /480 IDs; allocated retail',len(retail),flush=True)
