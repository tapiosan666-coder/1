"""All 51 existing B1 store IDs: purpose-specific merchandising, checkout and protected circulation.
Shop parcels, stockrooms, entrances and ceiling heights are unchanged. Not a claim of final art quality.
"""
from pathlib import Path
import sys,math,numpy as np,collections
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import constrained_delaunay_triangles,contains_xy
F=read(P/'source/v11/floors-updated.json');shops=[(f,s)for f in F if f['level']==-1 for s in f['stores']];ids={s['id']for f,s in shops};y=-5.35;M={};coll={};render_group='';instances=[];lights=[];ledgers=[];walks=[];cameras=[];bounds=read(P/'source/v13/asset-bounds.json')if(P/'source/v13/asset-bounds.json').exists()else{}
def pos(x,y,z):return[float(x),float(y),float(z)]
exec((P/'authoring/mesh_primitives.py').read_text())
def world(g):return affinity.translate(g,429,-46)
def point(p):return[p[0]+429,y,p[1]-46]
if '--layout-only'not in sys.argv:
 masks=world(unary_union([s['sales']for f,s in shops]));changes=[]
 for name,folder in [('base-site','v10'),('C-outlet','v12')]:
  g=load_pack(P/'assets'/folder/(name+'.pack.zst'));rr=0;cc=0
  for k,d in g['surfaces'].items():
   if k.split('@@')[0]=='oak'and k.split('@@')[-1]in ids:
    a=triangles(d);drop=(a[:,:,1].max(1)<y+1.01)&(a[:,:,1].min(1)>=y-.01);rr+=int(drop.sum());g['surfaces'][k]=retain(d,~drop)
  if 'oak'in g['colliders']:
   a=np.asarray(g['colliders']['oak']).reshape(-1,3,3);ct=a.mean(1);drop=(a[:,:,1].max(1)<y+1.01)&(a[:,:,1].min(1)>=y-.01)&contains_xy(masks,ct[:,0],ct[:,2]);cc=int(drop.sum());g['colliders']['oak']=a[~drop].ravel()
  save_zst(P/'assets'/folder/(name+'.pack.zst'),g);changes.append({'pack':name,'old_shelf_render_faces_removed':rr,'old_shelf_collision_faces_removed':cc,'criterion':'oak, B1 sales polygons, <1.0m; walls/frontages/stock and floors untouched'})
 write(P/'source/v13/basement-shelf-removal.json',changes)
def add(asset,p,u,n,fp,sid,width=None,height=1.3):
 global M
 d={'asset':asset,'p':[p[0]+429,y+.012,p[1]-46],'u':list(u),'front':list(n),'group':'V13-B1-'+sid}
 if width:d['max_xz']=[width,5.]
 instances.append(d);old=M;M={};extrude(world(fp),y,height,'v10_oak',True);M=old
for f,s in shops:
 sid=s['id'];cat=s['category'];sales=s['sales'];entry=np.array(s['entry']);u=np.array(s['u']);n=np.array(s['n']);normal_corrected=False
 positive=sales.intersection(rect(entry+n*1.2,u,2.4,2.4)).area;negative=sales.intersection(rect(entry-n*1.2,u,2.4,2.4)).area
 if negative>positive+.10:n=-n;normal_corrected=True
 co=np.concatenate([np.array(p.exterior.coords)for p in polys(sales)]);t=(co-entry)@u;d=(co-entry)@n;lo,hi=t.min(),t.max();dlo,dhi=d.min(),d.max();rows=[];placed=[]
 # Keep every existing validation route, the actual shop's spine and entry decompression.
 paths=[LineString(s['main_route']).intersection(sales)]
 for r in read(P/'source/physical-routes-v11.json'):
  if r['id']==sid:paths.append(LineString([(p[0]-429,p[2]+46)for p in r['points']]).intersection(sales))
 protect=unary_union([p.buffer(1.05,join_style=2)for p in paths]).union(rect(entry+n*1.8,u,max(3.6,s.get('door_width_m',3.0)),3.8))
 protected=sales.buffer(-.25).difference(protect);style='grocery'if'食品'in cat else'health'if'医薬'in cat else'book'if'書籍'in cat else'sport'if'スポーツ'in cat else'service'if any(k in cat for k in ['修理','サービス'])else'pickup'if any(k in cat for k in ['受取','物流'])else'home'
 def place(asset,pp,uu,nn,w,dep,h,role):
  dim=bounds.get(asset,{'x':w,'y':h,'z':dep});scale=min(1.,w/max(dim['x'],.001),5/max(dim['z'],.001));actual_w=dim['x']*scale;actual_d=dim['z']*scale;actual_h=dim['y']*scale
  fp=rect(pp,uu,actual_w,actual_d)
  if not protected.covers(fp)or any(fp.distance(g)<1.10 for g in placed):return False
  add(asset,pp,uu,nn,fp,sid,w,actual_h);placed.append(fp);rows.append({'role':role,'asset':asset,'footprint':fp,'point':point(pp)});return True
 # Dedicated till/reception close to the public frontage, with a clear approach distinct from stock.
 for side in[1,-1]:
  for depth in[3.2,5.0,7.0]:
   if place('retail/retail_counter',entry+u*side*4+n*depth,u,-n,2.1,.90,1.05,'checkout / reception'):break
  if any(q['role']=='checkout / reception'for q in rows):break
 if not any(q['role']=='checkout / reception'for q in rows):
  candidates=sorted([(tt,dd)for tt in np.arange(lo+.8,hi-.7,1.0)for dd in np.arange(dlo+1,min(dhi-1,12),1.0)],key=lambda q:q[0]**2+q[1]**2)
  for tt,dd in candidates:
   if place('../v13/models/compact_till',entry+u*tt+n*dd,u,-n,.88,.58,1.30,'checkout / reception'):break
 # Back/side display lanes: product types depend on the actual recorded use.
 for side in[-1,1]:
  tt=lo+1.0 if side<0 else hi-1.0
  for dd in np.arange(dlo+1.5,dhi-1.5,3.6):
   pp=entry+u*tt+n*dd;front=u*(-side);along=n
   asset='../v11/models/refrigerated_case'if style=='grocery'else'../v13/models/health_wall_bay'if style=='health'else'../v13/models/repair_workbench'if style=='service'else'../v13/models/visitor_lockers'if style=='pickup'else'retail/book_wall_0'if style=='book'else'../v11/models/shoe_shelf'if style=='sport'else'../v11/models/homeware_display'
   place(asset,pp,along,front,2.5,.75,1.75,'wall category / service equipment')
 # Islands keep two-direction cross aisles every 12m; shops are not split into new parcels.
 cap=max(8,min(240,int(sales.area/15)))
 for dd in np.arange(dlo+2,dhi-1.0,3.3):
  if int(dd)%14<3:continue
  for tt in np.arange(lo+2.2,hi-1.3,3.9):
   if len(rows)>=cap:break
   pp=entry+u*tt+n*dd;i=len(rows)
   if style=='grocery':asset='../v11/models/produce_island'if dd<max(12,dhi*.35)else'../v11/models/grocery_gondola'
   elif style=='health':asset='../v13/models/health_wall_bay'
   elif style=='service':asset='../v13/models/repair_workbench'if i%3==0 else'retail/electronics_table'
   elif style=='pickup':asset='../v13/models/visitor_lockers'
   elif style=='book':asset='../v12/models/book_double_gondola_'+str(i%2)
   elif style=='sport':asset=['../v11/models/travel_display','../v11/models/shoe_shelf','retail/garment_rack_0'][i%3]
   else:asset=['../v11/models/homeware_display','retail/lifestyle_table_0','../v12/models/home_dining_vignette'][i%3]
   place(asset,pp,u,n,2.4,1.15,1.25,'central sale / collection')
 # Existing top slab remains the ceiling; mounted strip lights/emitters, not floating decorative ceilings.
 render_group='V13-B1-LIGHTS-'+sid
 light_candidates=[np.array(p.centroid.coords[0])for p in polys(sales)]
 for dd in np.linspace(max(3,dlo+3),max(4,dhi-3),3):
  for tt in np.linspace(lo+2,hi-2,2):
   pp=entry+u*tt+n*dd
   if sales.buffer(-.5).covers(Point(pp)):light_candidates.append(pp)
 for pp in light_candidates[:7]:
  extrude(world(rect(pp,u,1.25,.16)),y+4.70,.05,'v10_metal',False);surf(world(rect(pp,u,1.18,.11)),y+4.695,'v10_emitter',False)
  lights.append({'p':[pp[0]+429,y+4.63,pp[1]-46],'energy':3.0,'color':[1,.95,.85],'range':9.,'shadow':False})
 ledger={'id':sid,'wing':f['wing'],'category':cat,'programme':style,'gross_m2':s['polygon'].area,'sales_m2':sales.area,'stock_m2':s['backroom'].area,'fixture_count':len(rows),'checkout_placed':any(q['role']=='checkout / reception'for q in rows),'protected_spine_width_m':2.10,'fixture_area_m2':sum(g.area for g in placed),'fixtures':rows,'original_ID_preserved':True,'inward_normal_corrected_for_fitout':normal_corrected,'actual_model_AABB_used':True,'fitout_status':'v13 industry-specific first full B1 fit-out; art refinement remains'};ledgers.append(ledger)
 # Original route is retained as actual run-time validation input, not used as proof of quality.
 route=LineString(s['main_route']).intersection(sales.buffer(-.95));segments=[q for q in getattr(route,'geoms',[route])if q.geom_type=='LineString']
 for i,seg in enumerate(segments):
  if seg.length>1:walks.append({'id':sid+'-'+str(i),'points':[point(p)for p in seg.coords]})
 if sid in ['AB1-003','BB1-MARKET','CB1-CW-1']:
  cameras.append({'id':sid+'-interior','eye':[entry[0]+n[0]*1.5+429,y+1.65,entry[1]+n[1]*1.5-46],'look':[entry[0]+n[0]*12+429,y+1.20,entry[1]+n[1]*12-46],'fov':76,'title':cat+' / 地下店舗'})
write(P/'source/v13/basement-retail.json',{'instances':instances,'lights':lights,'signs':[]});write(P/'source/v13/basement-store-ledger.json',ledgers);write(P/'source/v13/basement-retail-routes.json',walks);write(P/'source/v13/basement-store-cameras.json',cameras);save_zst(P/'assets/v13/basement-retail.pack.zst',{'surfaces':M,'colliders':coll,'signs':[],'lights':[]});print('BASEMENT_RETAIL',len(ledgers),'stores',len(instances),'fixtures',len(lights),'lights','checkout_missing',[r['id']for r in ledgers if not r['checkout_placed']],flush=True)
