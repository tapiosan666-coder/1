"""Original sanitary fittings and public-area joinery. All dimensions in metres."""
from pathlib import Path
P=Path(__file__).resolve().parents[1];src=(P/'authoring/retail_models_v10.py').read_text();exec(src[:src.index('for var in range(3):bookcase')]);OUT=P/'assets/v13/models'
porcelain=material('Glazed_sanitary_porcelain',(.82,.84,.82),.19)
seat=material('Warm_white_seat',(.76,.78,.75),.32)
chrome=material('Brushed_stainless',(.44,.48,.49),.24,.92)
mirror=material('Mirror_polished',(.65,.70,.72),.04,.98)
laminate=material('Toilet_walnut_laminate',(.17,.12,.085),.55)
# Pan is an open concave oval profile, not a solid cubicle block.
o=lathe('Bowl_outer_and_inner',[(0,.07),(.13,.07),(.18,.18),(.22,.33),(.225,.39),(.20,.405),(.17,.36),(.12,.24),(.05,.21)],porcelain,steps=48);o.scale=(1,1.34,1);o.location.y=-.08
lathe('Pedestal',[(0,0),(.16,0),(.17,.04),(.13,.25),(.16,.32),(0,.32)],porcelain,steps=32)
o=lathe('Open_oval_seat',[(.178,.409),(.228,.409),(.23,.425),(.225,.442),(.178,.442),(.174,.427),(.178,.409)],seat,steps=48);o.scale=(1,1.34,1);o.location.y=-.08
box('Concealed_cistern',(0,.265,.49),(.40,.18,.48),porcelain,.055);box('Cistern_top',(0,.265,.74),(.415,.19,.025),porcelain,.012);lathe('Dual_flush_button',[(0,0),(.027,0),(.027,.008),(0,.008)],chrome,(0,.265,.755),24)
tube('Supply_pipe',[(.12,.32,.10),(.12,.35,.20),(.10,.35,.23)],.012,chrome)
finish('wc_pan')
# Two real washbasins, curved tap and millwork; worktop holes cut before export.
body=box('Vanity_cabinet',(0,.015,.39),(2.6,.52,.68),laminate,.022)
top=box('Solid_surface_top',(0,0,.80),(2.72,.62,.055),stone,.012)
for x in [-.67,.67]:
 bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=.215,depth=.15,location=(x,-.035,.80));c=bpy.context.object;c.scale.y=.74
 mod=top.modifiers.new('Actual_basin_aperture','BOOLEAN');mod.operation='DIFFERENCE';mod.object=c;bpy.context.view_layer.objects.active=top;bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(c,do_unlink=True)
 o=lathe('Recessed_basin',[(.217,.825),(.205,.80),(.19,.745),(.15,.69),(.06,.675),(0,.675)],porcelain,(x,-.035,0),40);o.scale.y=.74
 tube('Sensor_tap',[(x,.20,.81),(x,.20,1.02),(x,.15,1.08),(x,.015,1.07)],.018,chrome)
 box('Tap_sensor',(x,.012,1.05),(.024,.014,.018),rubber,.003)
 box('Soap_dispenser',(x+.30,.20,.89),(.08,.09,.17),chrome,.014)
 box('Drawer_front',(x,-.26,.46),(1.27,.022,.55),laminate,.009)
box('Mirror_backing',(0,.315,1.43),(2.68,.04,1.05),chrome,.01);box('Wall_mirror',(0,.287,1.43),(2.62,.008,.99),mirror,.003)
box('Mirror_light',(0,.25,1.99),(2.57,.05,.035),white,.007)
finish('double_vanity')
# Wall-hung urinal: an open bowl integrated with a vertical curved ceramic back.
profile=[(.04,.32),(.09,.30),(.16,.34),(.19,.44),(.17,.62),(.12,.78),(.07,.82)]
v=[];faces=[]
for j,(r,h)in enumerate(profile):
 for i in range(33):
  a=math.pi*i/32;v.append((math.cos(a)*r,-math.sin(a)*r-.015,h))
for j in range(len(profile)-1):
 for i in range(32):k=j*33+i;faces.append((k,k+1,k+34,k+33))
mesh('Open_urinal_bowl',v,faces,porcelain);box('Ceramic_back',(0,.015,.60),(.34,.06,.59),porcelain,.07);box('Sensor_flush',(0,.045,1.03),(.09,.045,.12),chrome,.018)
finish('wall_urinal')
# Accessible WC rail assembly + emergency call, no decorative rail across the transfer side.
for x in [-.36,.36]:
 tube('Support_rail',[(x,.34,.70),(x,.13,.70),(x,-.40,.70)],.0175,chrome)
 box('Wall_rail_mount',(x,.355,.70),(.09,.022,.17),chrome,.012)
box('Emergency_call_plate',(.52,.36,.72),(.11,.025,.18),material('Emergency_red',(.55,.035,.025),.45),.012)
tube('Emergency_pull_cord',[(.52,.34,.69),(.52,.34,.12)],.004,material('Cord_red',(.65,.05,.025),.6))
finish('accessible_rails')
# Paper dispenser with actual roll profile.
box('Paper_mount',(0,.035,.63),(.18,.025,.12),chrome,.012)
o=lathe('Paper_roll',[(.02,0),(.055,0),(.055,.11),(.02,.11),(.02,0)],paper,steps=32);o.rotation_euler.y=math.pi/2;o.location=(-.055,-.035,.63)
box('Loose_paper',(0,-.092,.54),(.105,.003,.12),paper,.002)
finish('paper_dispenser')
# Slatted bench with curved steel supports, integrated planted end tubs added by layout.
for yy in [-.21,-.07,.07,.21]:box('Rounded_timber_seat',(0,yy,.46),(2.2,.115,.055),wood,.018)
for z in [.65,.79,.93]:box('Back_slats',(0,.27,z),(2.2,.052,.10),wood,.018)
for x in [-.82,.82]:
 tube('Curved_steel_frame',[(x,-.25,.035),(x,-.25,.39),(x,-.15,.43),(x,.22,.43),(x,.28,.52),(x,.28,.98)],.027,chrome)
 for yy in [-.25,.22]:box('Anchored_foot',(x,yy,.02),(.17,.13,.035),metal,.014)
finish('public_bench')
# Lockers give basement arrival zones a specific visitor use.
for x in [-.55,0,.55]:
 box('Locker_case',(x,0,.91),(.53,.45,1.82),white,.018)
 for z in [.49,1.34]:
  box('Locker_door',(x,-.235,z),(.49,.025,.80),laminate,.015);box('Keypad',(x+.13,-.258,z+.11),(.075,.018,.14),metal,.012)
  for k in range(4):box('Vent_slot',(x-.10+k*.06,-.252,z-.21),(.028,.005,.012),rubber,.002)
finish('visitor_lockers')
print('V13_AMENITY_MODELS_DONE',flush=True)
# Wheelchair approach: shallow single basin, open knee space and low mirror.
top=box('Accessible_basin_top',(0,0,.78),(.74,.55,.06),porcelain,.025)
bpy.ops.mesh.primitive_cylinder_add(vertices=40,radius=.22,depth=.16,location=(0,-.025,.78));c=bpy.context.object;c.scale.y=.72
mod=top.modifiers.new('Recessed_basin_opening','BOOLEAN');mod.operation='DIFFERENCE';mod.object=c;bpy.context.view_layer.objects.active=top;bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(c,do_unlink=True)
o=lathe('Accessible_bowl',[(.222,.81),(.21,.78),(.18,.70),(.12,.67),(0,.67)],porcelain,(0,-.025,0),40);o.scale.y=.72
tube('Accessible_sensor_tap',[(0,.18,.80),(0,.18,1.00),(0,.04,1.03)],.017,chrome)
box('Low_mirror',(0,.29,1.34),(.69,.025,.80),mirror,.01)
for x in[-.29,.29]:tube('Wall_bracket',[(x,.32,.58),(x,.32,.73),(x,-.18,.73)],.014,chrome)
finish('accessible_vanity')
# Closed fold-down changer stays on the wall; no unusable table across circulation.
box('Folded_baby_change',(0,.04,1.12),(.82,.12,.54),white,.07);box('Changing_handle',(0,-.035,1.31),(.22,.035,.05),chrome,.015)
finish('baby_change_wall')
# Repair/reception joinery, with tools and a service screen rather than a retail shelf.
box('Service_worktop',(0,0,.91),(2.2,.80,.075),wood,.025)
for x in[-.78,.78]:box('Workshop_drawer_pedestal',(x,0,.44),(.54,.70,.88),laminate,.018)
box('Tool_board',(0,.35,1.33),(2.15,.035,.76),metal,.012)
for i in range(7):
 x=-.78+i*.26;tube('Hand_tool',[(x,.31,1.10),(x,.31,1.33)],.013,chrome);box('Tool_grip',(x,.31,1.36),(.035,.05,.13),rubber,.01)
box('Service_screen',(0,-.12,1.18),(.59,.045,.34),metal,.015);box('Diagnostic_display',(0,-.149,1.18),(.54,.005,.29),material('Service_blue',(.04,.17,.22),.3),.002)
finish('repair_workbench')
# Health/household wall bay, with packaged goods of varied silhouettes and no real drug brand.
box('Health_cabinet_back',(0,.21,1.05),(2.0,.04,2.1),white,.015)
for level,z in enumerate([.16,.56,.96,1.36,1.76]):
 box('Health_adjustable_shelf',(0,-.02,z),(2.0,.48,.035),white,.008)
 for j in range(10):
  x=-.85+j*.19;h=.13+(j+level)%3*.035
  box('Original_health_package',(x,-.10,z+.027+h/2),(.13,.16,h),fabrics[(j+level)%5],.005)
finish('health_wall_bay')
box('Compact_till_plinth',(0,0,.445),(.82,.52,.89),laminate,.022);box('Compact_till_top',(0,0,.92),(.88,.58,.06),stone,.018)
box('POS_pedestal',(0,.04,1.045),(.08,.09,.19),metal,.012);box('POS_screen',(0,.015,1.20),(.31,.065,.20),metal,.012);box('Original_POS_interface',(0,-.023,1.20),(.28,.004,.17),material('POS_slate',(.04,.15,.16),.4),.002)
finish('compact_till')
# Free-standing terrace parasol with a curved eight-rib canopy, weighted base and real pole.
canvas=material('Terrace_canvas',(.71,.66,.51),.88)
lathe('Weighted_parasol_base',[(0,0),(.36,0),(.37,.055),(.26,.10),(0,.10)],stone,steps=32)
lathe('Umbrella_mast',[(0,0),(.022,0),(.022,2.54),(0,2.54)],chrome,steps=24)
verts=[];faces=[]
for j,(r,z)in enumerate([(0,2.56),(.32,2.53),(.82,2.40),(1.12,2.20)]):
 for i in range(32):
  a=i*math.tau/32;verts.append((r*math.cos(a),r*math.sin(a),z-.035*(math.sin(a*4)**2)))
for j in range(3):
 for i in range(32):a=j*32+i;b=j*32+(i+1)%32;faces.append((a,b,b+32,a+32))
mesh('Curved_textile_canopy',verts,faces,canvas)
for i in range(8):
 a=i*math.tau/8;tube('Parasol_rib',[(0,0,2.53),(.50*math.cos(a),.50*math.sin(a),2.47),(1.12*math.cos(a),1.12*math.sin(a),2.18)],.009,metal)
finish('terrace_parasol')
