"""22 declared RF outdoor shop plots: garden retail and terrace cafes, not enclosed mall stores."""
from pathlib import Path
import sys,math,numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import constrained_delaunay_triangles,contains_xy
F=read(P/'source/v11/floors-updated.json');shops=[(f,s)for f in F if f['level']==3 for s in f['stores']];ids={s['id']for f,s in shops};y=16.4;M={};coll={};render_group='';instances=[];rows=[];cameras=[];walks=[]
def pos(x,y,z):return[float(x),float(y),float(z)]
exec((P/'authoring/mesh_primitives.py').read_text())
def world(g):return affinity.translate(g,429,-46)
def point(p):return[p[0]+429,y,p[1]-46]
# Preserve explicit unapproved structure reservations.
unsupported=[]
for f in read(P/'source/v12/map-data.json'):
 for item in f['items']:
  if 'RF-SUPPORT-16'in item['id']:unsupported.extend([Polygon(g[0],g[1:])for g in item['geometry']])
unsupported=unary_union(unsupported)
if '--layout-only'not in sys.argv:
 mask=world(unary_union([s['sales']for f,s in shops]));audit=[]
 for name,folder in [('base-site','v10'),('C-outlet','v12')]:
  g=load_pack(P/'assets'/folder/(name+'.pack.zst'));count=0;cc=0
  for k,d in g['surfaces'].items():
   if k.split('@@')[0]!='oak'or k.split('@@')[-1]not in ids:continue
   a=triangles(d);drop=(a[:,:,1].min(1)>=y-.01)&(a[:,:,1].max(1)<y+1.01);count+=int(drop.sum());g['surfaces'][k]=retain(d,~drop)
  if'oak'in g['colliders']:
   a=np.asarray(g['colliders']['oak']).reshape(-1,3,3);ct=a.mean(1);drop=(a[:,:,1].min(1)>=y-.01)&(a[:,:,1].max(1)<y+1.01)&contains_xy(mask,ct[:,0],ct[:,2]);cc=int(drop.sum());g['colliders']['oak']=a[~drop].ravel()
  save_zst(P/'assets'/folder/(name+'.pack.zst'),g);audit.append({'pack':name,'roof_generic_faces_removed':count,'roof_generic_collision_faces_removed':cc})
 write(P/'source/v13/roof-shelf-removal.json',audit)
bounds=read(P/'source/v13/asset-bounds.json')
for f,s in shops:
 sid=s['id'];sales=s['sales'];entry=np.array(s['entry']);u=np.array(s['u']);n=np.array(s['n']);co=np.concatenate([np.array(p.exterior.coords)for p in polys(sales)]);t=(co-entry)@u;d=(co-entry)@n;garden='ガーデン'in s['category']or'庭園'in s['category'];placed=[];fixtures=[]
 protected=LineString(s['main_route']).buffer(1.05).union(rect(entry+n*1.6,u,max(3.4,s.get('door_width_m',3.)),3.6));usable=sales.intersection(f['floor_plate']).buffer(-.4).difference(protected).difference(unsupported);render_group='V13-RF-'+sid
 def put(asset,p,uu,nn,w,dep,h,role,target_height=None):
  global M
  size=bounds.get(asset,{'x':w,'y':h,'z':dep});scale=min(1.,w/max(.001,size['x']),5/max(.001,size['z']));ww=size['x']*scale;dd=size['z']*scale;hh=size['y']*scale
  if target_height:scale=target_height/max(.001,size['y']);ww=size['x']*scale;dd=size['z']*scale;hh=target_height
  fp=rect(p,uu,ww,dd)
  if not usable.covers(fp)or any(fp.distance(q)<1.1 for q in placed):return False
  record={'asset':asset,'p':[p[0]+429,y+.012,p[1]-46],'u':uu.tolist(),'front':nn.tolist(),'group':render_group,'max_xz':[w,5.]}
  if target_height:record.pop('max_xz');record['target_height']=target_height
  instances.append(record);old=M;M={};extrude(world(fp),y,hh,'v10_oak',True);M=old;placed.append(fp);fixtures.append({'role':role,'footprint':fp,'asset':asset});return True
 # Real counter, at a side of the entrance rather than across the visitor's route.
 found=False
 for dd in np.arange(d.min()+1,d.max()-1,1.5):
  for tt in np.arange(t.min()+1,t.max()-1,1.5):
   if put('retail/cafe_counter'if not garden else'../v13/models/compact_till',entry+u*tt+n*dd,u,-n,2.4 if not garden else .88,.8,1.3,'service counter'):found=True;break
  if found:break
 for dd in np.arange(d.min()+2,d.max()-1,3.7):
  for tt in np.arange(t.min()+2,t.max()-1,3.7):
   if len(fixtures)>=max(6,min(30,int(sales.area/20))):break
   p=entry+u*tt+n*dd
   if garden:
    put('models/DiffuseTransmissionPlant',p,u,n,1.0,1.0,1.1,'garden merchandise',1.1)
   else:put('retail/cafe_table',p,u,n,2.1,2.1,1.1,'outdoor seating')
 # Parasols belong only over tables, and only where the whole canopy remains inside the existing plot.
 if not garden:
  for ob in list(instances):
   if ob['group']!=render_group or ob['asset']!='retail/cafe_table':continue
   p=np.array([ob['p'][0]-429,ob['p'][2]+46]);canopy=Point(p).buffer(1.12)
   if sales.buffer(-.2).covers(canopy)and not canopy.intersects(unsupported):instances.append({'asset':'../v13/models/terrace_parasol','p':ob['p'],'u':u.tolist(),'front':n.tolist(),'group':render_group});fixtures.append({'role':'table parasol','footprint':canopy,'asset':'../v13/models/terrace_parasol'})
 rows.append({'id':sid,'wing':f['wing'],'category':s['category'],'sales_m2':sales.area,'programme':'open-air garden retail'if garden else'outdoor cafe / terrace lounge','counter_placed':found,'fixture_count':len(fixtures),'fixtures':fixtures,'primary_route_clear_width_m':2.10,'unapproved_structure_overlap_m2':sales.intersection(unsupported).area,'roof_enclosure_added':False,'structural_capacity_certified':False})
 for i,seg in enumerate([g for g in getattr(LineString(s['main_route']).intersection(sales.buffer(-.95)),'geoms',[LineString(s['main_route']).intersection(sales.buffer(-.95))])if g.geom_type=='LineString']):
  if seg.length>1:walks.append({'id':sid+'-RF-'+str(i),'kind':'roof-retail-spine','points':[point(p)for p in seg.coords]})
 if not cameras and not garden:cameras.append({'id':sid+'-terrace','eye':[entry[0]+n[0]*1.5+429,y+1.65,entry[1]+n[1]*1.5-46],'look':[entry[0]+n[0]*11+429,y+1.3,entry[1]+n[1]*11-46],'fov':72,'title':'屋上カフェ / 屋外席'})
write(P/'source/v13/roof-retail.json',{'instances':instances,'signs':[],'lights':[]});write(P/'source/v13/roof-store-ledger.json',rows);write(P/'source/v13/roof-retail-routes.json',walks);write(P/'source/v13/roof-store-cameras.json',cameras);save_zst(P/'assets/v13/roof-retail.pack.zst',{'surfaces':M,'colliders':coll,'signs':[],'lights':[]});print('ROOF_RETAIL',len(rows),'plots',len(instances),'models','missing_counter',[r['id']for r in rows if not r['counter_placed']],flush=True)
