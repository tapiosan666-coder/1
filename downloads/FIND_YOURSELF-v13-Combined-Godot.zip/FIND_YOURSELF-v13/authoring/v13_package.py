"""Single self-contained Godot archive. Prune caches, unused models and historical duplicate data, never active resources."""
from pathlib import Path
import zipfile,json,struct,hashlib,shutil,sys
P=Path(__file__).resolve().parents[1];D=Path('/workspace/1/downloads');D.mkdir(exist_ok=True)
large_old={'master-site-v3.json','parking-source-v3.json','design-v6.json','annex-v6.json','site-v7.json','design-v7.json'}
old_meta={'package-verification.json','unified-package-verification.json','export_presets.cfg','release-manifest-v13.json'}
art=json.loads((P/'source/v12/scene-art.json').read_text())
for name in ['amenities-public','basement-retail','roof-retail']:art['instances']+=json.loads((P/('source/v13/'+name+'.json')).read_text())['instances']
models={str((P/'assets/v10'/(r['asset']+'.glb')).resolve().relative_to(P))for r in art['instances']}
files=[]
for f in sorted(P.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(P);r=str(rel)
 if any(part in ['.godot','evidence','__pycache__','.git']for part in rel.parts):continue
 if f.suffix in ['.uid','.translation','.pyc']:continue
 if f.suffix=='.import'and not f.name.endswith('.csv.import'):continue
 if len(rel.parts)==1 and f.name in old_meta:continue
 if rel.parts[0]=='source'and len(rel.parts)==2 and f.name in large_old:continue
 if r in ['source/site-v11.json','source/v11/floors-baseline.json','source/v11/floors-updated.json','source/v11/map-data-C-option.json','source/map-data-v11.json','source/map-data-v7.json','source/v10/map-data-C-option.json','assets/v12/repairs-C.pack.zst','assets/v10/gi-A-book.res','source/v11/pack-manifest.json','source/v12/pack-manifest.json']:continue
 if f.name.startswith('release-manifest-'):continue
 if r=='assets/v10/base-site-C-option.pack.zst':continue
 if r.startswith('source/v12/boundary-audit')and f.name!='boundary-audit-before.json':continue
 if r.startswith('assets/v10/models/')or r.startswith('assets/v10/retail/')or r.startswith('assets/v11/models/')or r.startswith('assets/v12/models/'):
  if f.suffix=='.glb'and r not in models:continue
 if f.suffix in ['.exe','.pck','.7z','.cmd','.bat']:continue
 files.append((f,r))
manifest={'version':'v13 combined independent validation','single_archive':True,'main_game_integrated':False,'files':[{'path':r,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f,r in files]}
(P/'release-manifest-v13.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));files=[(f,r)for f,r in files if r!='release-manifest-v13.json'];files.append((P/'release-manifest-v13.json','release-manifest-v13.json'))
path=D/('FIND_YOURSELF-v13-Combined-Godot-TRIAL.zip'if'--trial'in sys.argv else'FIND_YOURSELF-v13-Combined-Godot.zip')
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f,r in files:z.write(f,'FIND_YOURSELF-v13/'+r)
print('PACKAGE',path.stat().st_size,'bytes',len(files),'files',len(models),'model types','limit 104857600')
assert path.stat().st_size<104857600,'Single artifact exceeds host limit; do not split or remove active assets.'
