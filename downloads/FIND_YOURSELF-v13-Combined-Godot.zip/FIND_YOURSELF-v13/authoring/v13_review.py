"""Combined v12 + v13 report, with real Godot Viewport comparisons and scalable design diagrams."""
from pathlib import Path
import sys,json,math,collections
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
import fitz
O=Path('/workspace/1/downloads');D=Path('/workspace/1/docs/visual-review-v13');D.mkdir(parents=True,exist_ok=True);F=read(P/'source/v11/floors-updated.json');shots=read(P/'source/v13/review-cameras.json');doc=fitz.open();W,H=1400,1000
font=P/'assets/NotoSansCJKjp-Regular.otf'
def text(p,box,s,size=17,color=(.12,.18,.22)):
 r=p.insert_textbox(fitz.Rect(box),str(s),fontname='japan',fontsize=size,color=color)
 if r<0:raise RuntimeError('PDF overflow '+str(s)[:80])
def page(title,sub=''):
 p=doc.new_page(width=W,height=H);p.insert_font(fontname='japan');p.draw_rect(p.rect,fill=(.97,.98,.98),color=None);text(p,(40,25,1360,80),title,29);text(p,(40,88,1360,135),sub,14);text(p,(40,970,1360,996),'FIND YOURSELF v13  |  v12＋今回の整備を統合  |  独立検証・ゲーム本体へ未統合  |  '+str(len(doc)),12);return p
def image(p,path,rect):p.insert_image(fitz.Rect(rect),filename=str(path),keep_proportion=True)
def draw(p,g,rect,bounds,color,stroke=(.27,.35,.38)):
 x,z,xx,zz=bounds;scale=min((rect[2]-rect[0])/(xx-x),(rect[3]-rect[1])/(zz-z));ox=(rect[0]+rect[2])/2-(x+xx)*scale/2;oy=(rect[1]+rect[3])/2-(z+zz)*scale/2
 def pt(q):return fitz.Point(q[0]*scale+ox,q[1]*scale+oy)
 for po in polys(g):
  for ring,fill in[(po.exterior,color)]+[(r,(.97,.98,.98))for r in po.interiors]:
   shape=p.new_shape();shape.draw_polyline([pt(q)for q in ring.coords]);shape.finish(color=stroke,fill=fill,width=.5,closePath=True);shape.commit()
 return pt
p=page('FIND YOURSELF v13｜公共設備・地下・屋上 統合確認','起動用ZIPは1本。前回v12の全機能・別案を保持し、今回のトイレ、地下51店舗、屋上22区画を追加しています。')
text(p,(50,160,1340,365),'今回の主な修正\nトイレの配置領域を高さ85cmの固まりにしていた生成不良を除去。全60設備核を対象に、個室・洗面・多目的設備と操作できる扉を整備しました。地下51店舗と屋上22区画には、用途に応じた売場・受付・屋外席などを配置しています。地下・屋上への階段とEVは保持しています。',23)
text(p,(50,400,1340,620),'前回から継続\nES開口と乗降口の修正、代表6業種店舗、C館余剰デッキの未承認別案、B1～RFの短いES乗継ぎ検討シーンを同梱。既存館へのES移設は未施工です。RF-SUPPORT-16も未承認のままです。\n\nF9：今回の15視点と全60トイレ。F8：前回の代表店舗。F4：C館別案。F7：ES乗継ぎ検討。M：案内図。',21)
text(p,(50,685,1340,935),'確認方法と限界\n実画面はGodot 4.6.3 Forward+、1920×1080。比較前は保護したv12、比較後はv13です。扉は比較撮影時に開いた共通状態で揃えています。画像加工で建物を描き足していません。\n人間による実操作とWindows GPUのFPSは未検証。Linux llvmpipeでの描画です。144FPS達成やFF16級品質、全館の最終美術完成を意味しません。',19)
p=page('全15層｜今回の整備範囲','480店舗IDと建物・開口・階段・EV・既存ES・館間接続・駐車場の基本構造は保持しています。')
text(p,(60,150,1340,188),'館・階        店舗数     設備核数       v13の主な追加',20)
y=205
for f in F:
 note='トイレ・地下売場・客用床・案内'if f['level']==-1 else'トイレ・屋外店舗・休憩・客用床・案内'if f['level']==3 else'トイレ（通常階の店舗は前回状態を保持）'
 text(p,(65,y,1335,y+39),f"{f['wing']}館 {f['label']:3}         {len(f['stores']):3}             {len(f['cores'])}               {note}",18);y+=43
text(p,(65,875,1335,950),'設備核はA15・B15・C30の計60か所。通常個室240、多目的トイレ60、小便器120。\n地下はA31・B2・C18の51区画、屋上はA15・B1・C6の22区画です。',17)
p=page('トイレ｜配置領域と実物を分けて生成','平面図は設計データの可視化です。右側の実物占有域と転回円の検査は、Godotの通行検査とは別です。')
f=next(f for f in F if f['wing']=='B'and f['level']==0);c=f['cores'][0];bounds=c['outline'].bounds
for rect,after,title in[((55,220,675,710),False,'修正前：器具領域を箱にした状態'),((725,220,1345,710),True,'修正後：個別モデル・通路・転回空間')]:
 text(p,(rect[0],155,rect[2],207),title,21);pt=draw(p,c['outline'],rect,bounds,(.91,.92,.92))
 for key,g in c['rooms'].items():draw(p,g,rect,bounds,(.84,.89,.90)if key in['women','men','accessible_wc']else(.92,.93,.93))
 draw(p,c['room_wall_solids'],rect,bounds,(.25,.30,.32))
 if not after:
  for o in c['fixtures']:draw(p,o['geom'],rect,bounds,(.78,.35,.29))
 else:
  for q in read(P/'source/v13/fixture-audit.json'):
   if q['id'].startswith('V13-CORE-B-1F-'+c['id']+'-'):
    draw(p,q['footprint'],rect,bounds,(.27,.59,.47))
    if q.get('turning_circle')is not None:draw(p,q['turning_circle'],rect,bounds,(.63,.83,.71))
text(p,(55,750,1345,945),'赤：旧器具の配置領域。緑：個別器具の占有域と多目的トイレの直径1.5m転回円。\nA/B館の個室扉120枚と、全館の多目的トイレ扉60枚を追加。既存C館個室扉120枚を保持しています。\n器具は独自のBlenderモデル。旧配置領域を実体へ一律押出しするルールを廃止しました。',20)
# Two before/after pairs per page: full-resolution PNGs embedded, not substitutes for native render.
for offset in range(0,len(shots),2):
 pair=shots[offset:offset+2];p=page('Godot実画面｜v12 → v13','左右は同じカメラ位置・向き・画角。原寸PNGと撮影記録は資料ZIPのscreenshots/・captures/にあります。')
 for j,s in enumerate(pair):
  yy=145+j*400;text(p,(45,yy,1355,yy+35),s['id']+'  /  '+s['title'],19)
  before=P/'evidence/v13'/('before-garden-final'if s['id']=='B-RF-garden'else'before'if offset+j<9 else'before-supplement')/(s['id']+'.png')
  after=P/'evidence/v13'/('after-guides-B1'if s['id']=='B-B1-arrival'else'after-guides-RF'if s['id']=='B-RF-arrival'else'after-frozen')/(s['id']+'.png');image(p,before,(45,yy+42,685,yy+402));image(p,after,(715,yy+42,1355,yy+402))
p=page('v12から保持｜安全対策・C館別案・連続ES検討','以下は前回v12で撮影したGodot実画面。対応する修正・別案は今回の単独v13 ZIPにも含まれています。')
old=Path('/workspace/1/docs/visual-review-v12/screenshots')
for path,rect,caption in[(old/'after/01-ES-upper-B.png',(45,170,685,530),'既存ES：見える床端の柵と乗降口修正'),(old/'ES-module/ES-study-1F.png',(715,170,1355,530),'同じ吹抜けでB1～RFを乗り継ぐ未承認モジュール')]:
 image(p,path,rect);text(p,(rect[0],545,rect[2],590),caption,19)
text(p,(55,630,1340,935),'C館余剰デッキを減らした別案、柱梁、舗装の支持範囲クリップ、6業種の代表店舗、境界の衝突欠落修正を保持。\n今回も既存スキャンゲーム本体には統合していません。C館別案と敷地へのES移設は承認待ちです。\nES検討モジュールの中間階乗継ぎは設計中心線8.4m。実際の各館へその配置を設置した結果ではありません。\nプレイヤー・ESの移動／アニメーション・EVのコードはv12と同一で、滑らかな移動処理を保持しています。',20)
p=page('検査結果｜図面・自動操作・未検証を区別','QAは固定60Hz。試験時に描画上限を外す場合がありますが、通常起動の144FPS上限・VSync ONは保持しています。')
summary=read(D/'test-summary.json');y=155
for r in summary['rows']:
 text(p,(55,y,1340,y+65),r['label']+'：'+r['result'],21);y+=70
text(p,(55,730,1340,940),'客用売場の経路は、スタッフ扉手前の立てる位置で終えています。裏方全域や設備室内部の実操作検証ではありません。\n図面の転回円・モデル占有域、衝突空間でのW/F入力、自動経路追従はそれぞれ別の検査です。人間による操作は未実施です。\n数値が合格しても、全地点の見た目・居心地・建築的な完成度を保証しません。',18)
p=page('残課題と素材｜今回で完成扱いにしないもの','未承認部分を家具や床で隠して確定させていません。次工程でも原本と独立検証を分けて扱います。')
text(p,(55,160,1340,540),'残課題\n・地下の設備・搬入・管理区画の詳細モデルと作業動線。C館残余帯など既存の用途確認候補。\n・商品形状、価格・部門表示、看板、細かな内装と照明の最終美術。今回の全区画への配置は最初の内装実装で、FF16級の完成品質ではありません。\n・C館構造別案、各館への連続ES配置、RF-SUPPORT-16は未承認。構造支持力・基礎・耐震・避難性能・車両軌跡は認定していません。\n・水栓、ベビー設備、家具の操作、専用平面反射の鏡は未実装。\n・人間による全館プレイと、Windows GPUでの性能測定。',21)
text(p,(55,600,1340,940),'素材と再現性\n新規衛生器具・家具・修理台・健康用品棚・パラソルはBlenderで独自制作。既存のCC0／CC-BY等の素材、Noto OFL、Godot MITの出典と条件はlicenses/に保持。新規の実在ブランド・FF16資産は使用していません。\n設計データ、器具・店舗台帳、撮影カメラ、検査JSON、生成スクリプトを同梱。ZIPは追加データなしで起動可能です。\nGodot 4.6.3でproject.godotをインポートし、初回処理後にF5。今回の確認はF9が入口です。',20)
out=O/'FIND_YOURSELF-v13-Combined-Review.pdf';doc.save(out,garbage=4,deflate=True);print('COMBINED_REVIEW',len(doc),'pages',out.stat().st_size,flush=True)
