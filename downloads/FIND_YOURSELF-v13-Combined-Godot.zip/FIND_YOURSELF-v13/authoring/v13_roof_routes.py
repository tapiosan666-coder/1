from pathlib import Path
import sys,numpy as np,math,heapq
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
from pack_tools_v11 import load_pack,triangles
from shapely import set_precision
src=(P/'authoring/v12_transfer_plan_distances.py').read_text();exec(src[src.index('def route('):src.index('for r in rows:')].replace('step=.75','step=.25'))
f=next(f for f in read(P/'source/v11/floors-updated.json')if f['wing']=='B'and f['level']==3);a=read(P/'source/v13/public-finish-audit.json');rows=[];audit=[];cameras=[]
models=read(P/'source/v13/amenities-public.json')['instances']
actual_pack=load_pack(P/'assets/v13/public-areas.pack.zst');actual_floor=unary_union([Polygon(t[:,[0,2]])for t in triangles(actual_pack['surfaces']['v8_pavers@@V13-PUBLIC-B-RF'])]).buffer(-.50)
area=unary_union([set_precision(f['public'],.001)]+[set_precision(z['polygon'],.001)for z in f['gardens']]).intersection(f['floor_plate']).difference(unary_union([b['polygon']for b in f.get('plant_beds',[])])).buffer(-.36)
for zone in f['gardens']:
 benches=[r for r in a['zones']if r.get('kind')=='roof-garden-bench'and r['id'].startswith('V13-'+zone['id'])]
 if not benches:continue
 bench=benches[0];goal=np.array(bench['world_point'])[[0,2]]-np.array([429,-46]);options=[]
 for c in f['cores']:
  q=next(d for d in c['doors']if d['id']=='CORE');n=np.array(c['rooms']['front_lobby'].centroid.coords[0])-q['p'];n/=np.linalg.norm(n);p=np.array(q['p'])-n*.8;options.append((np.linalg.norm(p-goal),p,c['id']))
 path=None
 for _,p,cid in sorted(options,key=lambda q:q[0]):
  # Stop alongside, not inside, the bench collider.
  record=min([d for d in models if d['asset']=='../v13/models/public_bench'and d['group']=='V13-'+zone['id']],key=lambda d:math.dist([d['p'][0],d['p'][2]],bench['world_point'][::2]));front=np.array(record['front']);along=np.array(record['u'])
  for delta in[front*1.25,-front*1.25,along*1.8,-along*1.8]:
   target=goal+np.array(delta)
   if not area.covers(Point(target)):continue
   path=route(p,target,area)
   if path:break
  if path:break
 audit.append({'id':zone['id'],'plan_path_found':path is not None,'from_core':cid,'actual_Godot_walk_passed':None})
 if path:rows.append({'id':zone['id'],'kind':'roof-garden-access','points':[[q[0]+429,16.4,q[1]-46]for q in path]})
 if not cameras:
  desired=goal+np.array([0,5.]);choices=[]
  for r in[3.8,4.5,5.5]:
   for angle in np.arange(0,math.tau,.2):
    candidate=goal+np.array([math.cos(angle),math.sin(angle)])*r
    if actual_floor.covers(Point(candidate[0]+429,candidate[1]-46)):choices.append((np.linalg.norm(candidate-desired),candidate))
  eye=min(choices,key=lambda q:q[0])[1]
  cameras.append({'id':'B-RF-garden','eye':[eye[0]+429,18.05,eye[1]-46],'look':[goal[0]+429,17.15,goal[1]-46],'fov':72,'title':'B館屋上前庭 / 休憩テラス'})
write(P/'source/v13/roof-garden-routes.json',rows);write(P/'source/v13/roof-garden-plan-audit.json',audit);write(P/'source/v13/garden-cameras.json',cameras);print('ROOF_GARDEN_ROUTES',len(rows),'of',len(audit),flush=True)
