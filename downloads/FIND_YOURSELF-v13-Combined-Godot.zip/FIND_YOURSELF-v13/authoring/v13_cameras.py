from pathlib import Path
import sys,numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
rows=read(P/'source/v13/cameras.json')+read(P/'source/v13/basement-store-cameras.json')+read(P/'source/v13/garden-cameras.json')+read(P/'source/v13/roof-store-cameras.json')
f=next(f for f in read(P/'source/v11/floors-updated.json')if f['wing']=='B'and f['level']==0);c=f['cores'][0];q=next(q for q in c['doors']if q['id']=='AWC');n=np.array(c['rooms']['accessible_wc'].centroid.coords[0])-q['p'];n/=np.linalg.norm(n);eye=np.array(q['p'])+n*.8;target=c['rooms']['accessible_wc'].centroid.coords[0]
rows.append({'id':'B-1F-accessible-WC','eye':[eye[0]+429,1.65,eye[1]-46],'look':[target[0]+429,1.0,target[1]-46],'fov':85,'title':'多目的トイレ / 膝下空間と手すり'})
write(P/'source/v13/review-cameras.json',rows);write(P/'source/v13/supplement-cameras.json',rows[9:]);print('REVIEW_CAMERAS',len(rows))
