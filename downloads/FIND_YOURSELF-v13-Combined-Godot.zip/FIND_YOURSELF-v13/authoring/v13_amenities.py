"""Replace the fixture-area extrusion bug; fit out existing public cores and B1/RF arrival zones.
No store parcel, stair, EV, escalator, floor opening or RF-SUPPORT-16 approval is changed.
"""
from pathlib import Path
import sys,math,copy,collections,numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import constrained_delaunay_triangles,contains_xy
F=read(P/'source/v11/floors-updated.json');site=read(P/'source/site-v11.json');M={};coll={};render_group='';instances=[];doors=[];checks=[];signals=[];lights=[];toilet_routes=[];hubs=[];cameras=[]
def pos(x,y,z):return[float(x),float(y),float(z)]
exec((P/'authoring/mesh_primitives.py').read_text())
def world(g):return affinity.translate(g,429,-46)
def pp(q,y):return pos(q[0]+429,y,q[1]-46)
def unit(v):
 v=np.array(v,float);return v/max(np.linalg.norm(v),1e-8)
def add(asset,point,y,n,group,width=None):
 y+=dict(double_vanity=.05,wall_urinal=.30,paper_dispenser=.48,accessible_rails=.12).get(asset,0)
 n=unit(n);u=np.array([n[1],-n[0]]);d={'asset':'../v13/models/'+asset,'p':pp(point,y),'u':u.tolist(),'front':n.tolist(),'group':group}
 if width:d['max_xz']=[width,10]
 instances.append(d);return d
def boxsolid(geom,y,h,mat='v10_chalk'):
 global M
 visible=M;M={};extrude(world(geom),y,h,mat,True);M=visible
def cnormal(axis,p,target):
 n=np.array([-axis[1],axis[0]]);return n if np.dot(n,np.array(target)-p)>0 else-n
def door_record(id,p,axis,y,width,n,room):
 return {'id':id,'p':pp(p,y),'u':list(axis),'n':list(n),'leaf_width_m':width-.02,'clear_width_m':width,'height_m':2.0,'hinge_side':-1,'mechanism':'sliding','slide_side':1,'room_label':room,'role':'public','role_label':'トイレ','amenity_v13':True}
# Exact same canonical fixture footprints used by v7 extrusion; remove only ceramic fixture material.
masks={y:world(unary_union([o['geom']for f in F if abs(f['height']-y)<.01 for c in f['cores']for o in c['fixtures']])).buffer(.003)for y in sorted({f['height']for f in F})}
removals=[]
if '--layout-only'not in sys.argv:
 for name,folder in [('base-site','v10'),('C-outlet','v12')]:
  path=P/'assets'/folder/(name+'.pack.zst');g=load_pack(path);rr=0;cc=0
  for k,d in g['surfaces'].items():
   if k.split('@@')[0]!='ceramic_0':continue
   a=triangles(d);ct=a.mean(1);drop=np.zeros(len(a),bool)
   for y,mask in masks.items():drop|=(a[:,:,1].min(1)>=y-.01)&(a[:,:,1].max(1)<=y+.86)&contains_xy(mask,ct[:,0],ct[:,2])
   rr+=int(drop.sum());g['surfaces'][k]=retain(d,~drop)
  if 'ceramic_0'in g['colliders']:
   a=np.asarray(g['colliders']['ceramic_0']).reshape(-1,3,3);ct=a.mean(1);drop=np.zeros(len(a),bool)
   for y,mask in masks.items():drop|=(a[:,:,1].min(1)>=y-.01)&(a[:,:,1].max(1)<=y+.86)&contains_xy(mask,ct[:,0],ct[:,2])
   cc=int(drop.sum());g['colliders']['ceramic_0']=a[~drop].ravel()
  save_zst(path,g);removals.append({'pack':str(path.relative_to(P)),'fixture_faces_removed':rr,'physical_faces_removed':cc,'criterion':'ceramic_0, canonical fixture mask, local y 0..0.85; walls/floors/doors excluded'});print('FIXTURE_AREA_BUG_REMOVED',name,rr,cc,flush=True)
 write(P/'source/v13/removed-fixture-blocks.json',removals)
else:removals=read(P/'source/v13/removed-fixture-blocks.json')
existing=read(P/'source/scene-manifest.json')['staff_doors']+read(P/'source/site-manifest-v7.json')['staff_doors']
for f in F:
 y=f['height'];wing=f['wing']
 for core in f['cores']:
  render_group='V13-CORE-'+wing+'-'+f['label']+'-'+core['id'];gid=render_group;rooms=core['rooms'];core_doors={q['id']:q for q in core['doors']};cubdoors=core.get('cubicle_doors',[])
  if not cubdoors:
   cubdoors=[{'id':'WC-'+q['room']+str(i),'p':q['door'],'axis':core['u'],'w':q['door_width_m']}for i,q in enumerate(core.get('cubicles',[]))]
  for index,o in enumerate(core['fixtures']):
   kind=o['kind'];geom=o['geom'];centre=np.array(geom.centroid.coords[0]);n=None;asset=None;foot=None
   if kind.startswith('WC'):
    candidates=[q for q in cubdoors if ('WC-W'in q['id'])==('WC-W'in kind)]
    q=min(candidates or cubdoors,key=lambda q:Point(q['p']).distance(geom));n=cnormal(q['axis'],centre,q['p']);uu=np.array([n[1],-n[0]]);co=np.array(geom.exterior.coords);dep=np.ptp(co@n);point=centre-n*max(0,dep/2-.55);asset='wc_pan';foot=rect(point,n,.85,.49)
    add(asset,point,y+.018,n,gid);boxsolid(foot,y,.76,'ceramic_0')
    # dispenser on cubicle side, outside the customer's clear approach.
    add('paper_dispenser',point+uu*.54,y,n,gid)
    target=np.array(q['p'])-n*.46;start=np.array(q['p'])+n*.70
    toilet_routes.append({'id':gid+'-cubicle-'+str(index),'kind':'cubicle','wing':wing,'floor':f['label'],'core':core['id'],'points':[pp(start,y),pp(target,y)],'fixture':pp(point,y),'clear_door_m':q['w']})
   elif kind=='SINK':
    room=min([rooms[k]for k in ['men','women']],key=lambda r:r.distance(geom.centroid));front=np.array(room.centroid.coords[0])-centre;co=list(geom.minimum_rotated_rectangle.exterior.coords);edges=[np.array(b)-a for a,b in zip(co,co[1:])];uu=unit(max(edges,key=np.linalg.norm));n=cnormal(uu,centre,centre+front);uu=np.array([n[1],-n[0]]);width=max(np.linalg.norm(e)for e in edges)-.12;asset='double_vanity';point=centre
    add(asset,point,y+.016,n,gid,width);foot=rect(point,uu,min(2.72,width),.62);boxsolid(foot,y,.84,'v10_oak')
    toilet_routes.append({'id':gid+'-wash-'+str(index),'kind':'wash','wing':wing,'floor':f['label'],'core':core['id'],'points':[pp(point+n*1.55,y),pp(point+n*.85,y)],'fixture':pp(point,y)})
   elif kind=='URINAL':
    front=np.array(rooms['men'].centroid.coords[0])-centre;u=unit(core_doors['M']['axis']);n=cnormal(u,centre,centre+front);point=centre;asset='wall_urinal';add(asset,point,y,n,gid);foot=rect(point,n,.43,.40);boxsolid(foot,y+.28,.85,'ceramic_0')
   # AWC is placed from the room rather than the old generic fixture block.
   if asset:checks.append({'id':gid+'-'+str(index),'kind':kind,'asset':asset,'point':pp(point,y),'footprint':foot,'within_allocated_room_or_fixture':bool(geom.buffer(.12).covers(foot)),'original_allocation':geom})
  # Accessible room: back-wall WC, transfer side, rails, washbasin, clear turning circle.
  room=rooms['accessible_wc'];q=core_doors['AWC'];axis=unit(q['axis']);center=np.array(room.centroid.coords[0]);n=cnormal(axis,center,q['p']);u=np.array([n[1],-n[0]]);coords=np.array(room.exterior.coords);depth=np.ptp(coords@n);width=np.ptp(coords@u);point=center-n*(depth/2-.59)-u*max(0,width/2-.85)
  add('wc_pan',point,y+.018,n,gid);add('accessible_rails',point,y+.018,n,gid);foot=rect(point,n,.86,.50);boxsolid(foot,y,.76,'ceramic_0');turn=Point(center+n*.15).buffer(.75)
  checks.append({'id':gid+'-AWC','kind':'AWC','point':pp(point,y),'footprint':foot,'turning_circle':turn,'turning_circle_in_room':room.buffer(-.10).covers(turn),'turning_circle_clear_of_pan':not turn.intersects(foot)})
  sinkpoint=center+u*(width/2-.55)-n*(depth/2-.425)
  add('accessible_vanity',sinkpoint,y+.566,n,gid);sinkfoot=rect(sinkpoint,u,.74,.55);boxsolid(sinkfoot,y+.66,.18,'ceramic_0')
  toilet_routes.append({'id':gid+'-accessible-wash','kind':'accessible-wash','wing':wing,'floor':f['label'],'core':core['id'],'points':[pp(sinkpoint+n*1.25,y),pp(sinkpoint+n*.85,y)]})
  add('baby_change_wall',center+n*(depth/2-.13)+u*(width/2-.55),y+.85,-n,gid)
  doors.append(door_record(gid+'-AWC',q['p'],axis,y,q['w'],cnormal(axis,q['p'],center),'多目的トイレ'))
  toilet_routes.append({'id':gid+'-accessible','kind':'accessible','wing':wing,'floor':f['label'],'core':core['id'],'points':[pp(np.array(q['p'])-cnormal(axis,q['p'],center)*.70,y),pp(center+n*.15,y)],'turning_diameter_m':1.5})
  # A/B authored cubicle cutouts previously had no interactive leaves at all.
  if wing in ['A','B']:
   for i,q in enumerate(cubdoors):
    p=np.array(q['p']);target=min([o['geom']for o in core['fixtures']if o['kind'].startswith('WC')],key=lambda g:g.distance(Point(p))).centroid
    doors.append(door_record(gid+'-cubicle-'+str(i),p,unit(q['axis']),y,q['w'],cnormal(q['axis'],p,target.coords[0]),'個室'))
  for key in ['women','men','accessible_wc']:
   room=rooms[key];surf(world(room.buffer(-.12)),y+.009,'v10_floor_A');doorcuts=unary_union([rect(d['p'],d['axis'],d['w']+.05,.8)for d in core['doors']]);band=room.buffer(-.105).difference(room.buffer(-.13)).difference(doorcuts)
   extrude(world(band),y+.02,1.17,'v10_darkstone'if wing=='A'else'v10_sage'if wing=='B'else'v10_clay',False)
   surf(world(room),y+3.31,'plaster',False);surf(world(room),y+3.33,'v10_chalk',True)
   pc=room.representative_point();cylinder((pc.x+429,pc.y-46),y+3.278,.12,.025,'v10_metal',False);surf(Point(pc.x+429,pc.y-46).buffer(.10,quad_segs=10),y+3.272,'v10_emitter',False);lights.append({'p':pp(pc.coords[0],y+3.16),'energy':2.4,'color':[1,.94,.84],'range':4.6,'shadow':False})
  for key,caption in [('W','女性トイレ'),('M','男性トイレ'),('AWC','多目的トイレ')]:
   q=core_doors[key];room=rooms[{'W':'women','M':'men','AWC':'accessible_wc'}[key]];n=cnormal(q['axis'],q['p'],room.centroid.coords[0]);signals.append({'id':gid+'-'+key,'text':caption,'p':pp(np.array(q['p'])-n*.15,y+2.48),'n':(-n).tolist(),'w':1.3,'role':'WC'})
 # Public basement/roof arrival clusters reuse an existing public floor and reserve all authored routes.
 if f['level']not in[-1,3]:continue
 pts=[]
 for core in f['cores']:
  for q in core['doors']:
   pts.append(Point(q['p']).buffer(2.2))
 routes=[]
 for r in read(P/'source/physical-routes-v11.json'):
  if any(abs(q[1]-y)<.05 for q in r['points']):
   line=LineString([(q[0]-429,q[2]+46)for q in r['points']]);routes.append(line.buffer(.95))
 avoid=unary_union(pts+routes);lobbies=unary_union([c['rooms']['front_lobby']for c in f['cores']]);usable=f['public'].union(lobbies).intersection(f['floor_plate']).difference(avoid).buffer(-.16)
 for ci,core in enumerate(f['cores']):
  origin=np.array(core['entry']);near=usable.intersection(Point(origin).buffer(20));candidates=[]
  for dx in np.arange(-18,18.1,1.5):
   for dz in np.arange(-18,18.1,1.5):
    v=origin+np.array([dx,dz]);fp=rect(v,(1,0),3.0,1.35)
    if near.covers(fp):candidates.append((np.linalg.norm(v-origin),v,fp))
  if not candidates:hubs.append({'id':f['wing']+f['label']+'-'+core['id'],'status':'NO CLEAR CLUSTER; NOT INSTALLED'});continue
  _,point,fp=min(candidates,key=lambda q:q[0]);gid='V13-HUB-'+wing+'-'+f['label']+'-'+core['id'];front=unit(origin-point);u=np.array([front[1],-front[0]]);fp=rect(point,u,2.75,1.12)
  # retry orientation conservatively; do not introduce an obstacle outside verified allocation.
  if not usable.covers(fp):front=np.array([0.,1.]);u=np.array([1.,0.]);fp=rect(point,u,2.75,1.12)
  if not usable.covers(fp):hubs.append({'id':gid,'status':'ORIENTATION ALLOCATION FAILED; NOT INSTALLED'});continue
  asset='visitor_lockers'if f['level']==-1 else'public_bench';add(asset,point,y+.018,front,gid);solid=rect(point,u,1.65 if f['level']==-1 else 2.2,.5 if f['level']==-1 else .65);render_group=gid;boxsolid(solid,y,1.82 if f['level']==-1 else 1.0,'v10_oak');usable=usable.difference(fp.buffer(.5))
  labels={'A':('地下フードマーケット / ロッカー','屋上庭園 / 休憩所'),'B':('地下連絡ロビー / ロッカー','屋上入口 / 休憩所'),'C':('地下専門店街 / ロッカー','屋上デッキ / 休憩所')};title=labels[wing][0 if f['level']==-1 else 1]
  signals.append({'id':gid,'text':title+'\n階段・EV → '+core['id'],'p':pp(point+front*.40,y+2.20),'n':front.tolist(),'w':2.1,'role':'HUB'})
  hubs.append({'id':gid,'wing':wing,'floor':f['label'],'core':core['id'],'point':pp(point,y),'footprint':fp,'collision_footprint':solid,'status':'INSTALLED','use':title,'preserves_reserved_routes':not solid.intersects(avoid),'authoring_distance_to_core_entry_m':float(np.linalg.norm(point-origin))})
  if ci==0:
   cameras.append({'id':wing+'-'+f['label']+'-arrival','eye':pp(point+front*5.0,y+1.65),'look':pp(point,y+1.0),'fov':70,'title':title})
# Narrow B service/roof corridors: preserve widths and mount wayfinding in the existing lobby.
for f in F:
 if f['wing']!='B'or f['level']not in[-1,3]:continue
 for ci,c in enumerate(f['cores']):
  q=next(d for d in c['doors']if d['id']=='CORE');n=cnormal(q['axis'],q['p'],c['rooms']['front_lobby'].centroid.coords[0]);point=np.array(q['p'])+n*.28;caption=('地下連絡 / 駐車場・専門店へ'if f['level']==-1 else '屋上連絡 / 駐車場・展望通路')
  signals.append({'id':'B-'+f['label']+'-'+c['id']+'-guide','text':caption+'\n階段・EV / '+c['id'],'p':pp(point,f['height']+2.35),'n':n.tolist(),'w':2.1,'role':'WC'})
  if ci==0:cameras.append({'id':'B-'+f['label']+'-arrival','eye':pp(np.array(c['rooms']['front_lobby'].centroid.coords[0]),f['height']+1.65),'look':pp(point,f['height']+1.8),'fov':72,'title':caption})
# Toilet representative cameras: open lobby view through real public doorway, no synthetic render.
for wing in ['A','B','C']:
 f=next(f for f in F if f['wing']==wing and f['level']==0);core=f['cores'][0];q=next(d for d in core['doors']if d['id']=='W');room=core['rooms']['women'];p=np.array(q['p']);n=cnormal(q['axis'],p,room.centroid.coords[0]);cameras.insert(0,{'id':wing+'-1F-toilet','eye':pp(p+n*1.1,f['height']+1.65),'look':pp(room.centroid.coords[0],f['height']+1.20),'fov':78,'title':wing+'館 女性トイレ'})
write(P/'source/v13/amenities.json',{'instances':instances,'lights':lights,'signs':signals,'doors':doors,'whole_mall_complete':False});write(P/'source/v13/fixture-audit.json',checks);write(P/'source/v13/toilet-routes.json',toilet_routes);write(P/'source/v13/arrival-hubs.json',hubs);write(P/'source/v13/cameras.json',cameras)
save_zst(P/'assets/v13/amenities.pack.zst',{'surfaces':M,'colliders':coll,'signs':[],'lights':[]})
print('V13_AMENITIES',len(instances),'models',len(doors),'new interactive doors',len(hubs),'hub entries',len(toilet_routes),'routes',len(cameras),'cameras',flush=True)
