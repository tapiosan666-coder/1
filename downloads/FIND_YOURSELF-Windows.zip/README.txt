FIND YOURSELF / Development build 0.1

ZIP全体を展開してから起動してください。
Windows: FIND_YOURSELF.exe をダブルクリック。
Linux: ./FIND_YOURSELF.x86_64（必要なら chmod +x）。
FIND_YOURSELF.pck は実行ファイルと同じフォルダーに置いてください。

ENTER THE ATRIUMで開始。WASD移動、マウス視点、左クリック射撃、
右クリック照準、Rリロード、Shiftダッシュ、Spaceジャンプ。
Tab強化、Fソナー、Q範囲スキャン、M案内図、Esc一時停止。
120人のうち本物は1人。偽物5発で10 AP。猫・範囲は本物の場所を通知し、
最後は通常銃でスキャンしてクリアします。

現版はA館1階の開発用セクターです。5,000人・15フロアの製品版ではありません。
写真顔生成、宝箱、セーブ、Steam連携は未実装。UIは英語です。
Windows版はクロスビルド済みで、Windows実機では未検証です。
音声は合成効果音です。外部API・インターネット接続は不要です。
Godot Engineおよび同梱ライブラリのライセンスはthird_party/をご覧ください。
