extends SceneTree
func _initialize()->void:
 var checks:Array=[]
 for row:Dictionary in JSON.parse_string(FileAccess.get_file_as_string("res://source/v10/unified-compression.json")):
  var compressed=FileAccess.get_file_as_bytes("res://assets/v10/"+str(row.new))
  var raw=compressed.slice(8).decompress(compressed.decode_u32(4),FileAccess.COMPRESSION_ZSTD)
  var hash=HashingContext.new();hash.start(HashingContext.HASH_SHA256);hash.update(raw)
  var actual=hash.finish().hex_encode()
  checks.append({"file":row.new,"pass":actual==row.uncompressed_sha256,"decoded_bytes":raw.size(),"sha256":actual})
 var result={"checks":checks,"passed":checks.filter(func(x):return x["pass"]).size(),"failed":checks.filter(func(x):return not x["pass"]).size(),"scope":"Godot Zstandard decoding reproduces original v10 geometry/collision metadata bytes exactly"}
 var out=FileAccess.open("res://package-verification.json",FileAccess.WRITE);out.store_string(JSON.stringify(result,"  "));print(JSON.stringify(result));quit(0 if result.failed==0 else 2)
