extends Node3D
var library:Dictionary={}
var batches:Dictionary={}
var stats:Dictionary={"asset_types":0,"placements":0,"draw_batches":0,"missing":[]}
func add_parts(node:Node,tr:Transform3D,out:Array,foliage:bool)->void:
 var local=tr
 if node is Node3D:local=tr*node.transform
 if node is MeshInstance3D and node.mesh!=null:
  var label=String(node.name).to_lower()
  if not foliage or(not label.contains("pot")and not label.contains("dirt")):
   var copy=node.mesh.duplicate()
   for index in range(copy.get_surface_count()):
    var mat=copy.surface_get_material(index)
    if mat!=null and String(mat.resource_name).to_lower().contains("glass"):
     var glass=ShaderMaterial.new();glass.shader=load("res://glass_v10.gdshader");copy.surface_set_material(index,glass)
   out.append({"mesh":copy,"transform":local})
 for ch in node.get_children():add_parts(ch,local,out,foliage)
func get_asset(asset:String,foliage:bool)->Dictionary:
 var key=asset+("-foliage"if foliage else"")
 if library.has(key):return library[key]
 var path="res://assets/v10/"+asset+".glb";path=path.simplify_path();var scene=load(path)
 if scene==null:stats.missing.append(path);return{}
 var node=scene.instantiate();var parts:Array=[];add_parts(node,Transform3D.IDENTITY,parts,foliage);node.free()
 var bound:AABB;var first:bool=true
 for part:Dictionary in parts:
  var a:AABB=part.transform*part.mesh.get_aabb()
  if first:bound=a;first=false
  else:bound=bound.merge(a)
 library[key]={"parts":parts,"bounds":bound,"key":key};return library[key]
func setup(g,data:Dictionary)->void:
 name="V11_Industry_Retail_Environment"
 for d:Dictionary in data.instances:
  var lib=get_asset(d.asset,d.get("foliage_only",false))
  if lib.is_empty():continue
  var bounds:AABB=lib.bounds;var dim=bounds.size;var scale:float=1.0
  if d.get("target_height")!=null:scale=float(d.target_height)/max(.0001,dim.y)
  if d.get("max_xz")!=null:scale=min(scale,min(float(d.max_xz[0])/max(dim.x,.0001),float(d.max_xz[1])/max(dim.z,.0001)))
  var center=bounds.position+dim/2;var normalize=Transform3D(Basis.from_scale(Vector3.ONE*scale),Vector3(-center.x,-bounds.position.y,-center.z)*scale)
  var u=Vector3(d.u[0],0,d.u[1]);var n=Vector3(d.front[0],0,d.front[1]);var transform=Transform3D(Basis(u,Vector3.UP,n),g.v3(d.p))*normalize
  for i in range(lib.parts.size()):
   var key:String=String(lib.key)+"|"+str(i)+"|"+str(d.group)+("|%d,%d"%[floor(float(d.p[0])/28),floor(float(d.p[2])/28)]if String(d.group).begins_with("PUBLIC")or String(d.group).begins_with("C-COVER")or String(d.group).begins_with("C-GARDEN")else "")
   if not batches.has(key):batches[key]={"mesh":lib.parts[i].mesh,"transforms":[],"group":d.group,"asset":d.asset}
   batches[key].transforms.append(transform*lib.parts[i].transform)
  stats.placements+=1
 for key:String in batches:
  var d:Dictionary=batches[key];var mm=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.mesh=d.mesh;mm.instance_count=d.transforms.size()
  for i in range(d.transforms.size()):mm.set_instance_transform(i,d.transforms[i])
  var node=MultiMeshInstance3D.new();node.physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF;node.multimesh=mm;node.gi_mode=GeometryInstance3D.GI_MODE_STATIC;node.name=("Shared_"+key).validate_node_name();node.visibility_range_end=100 if String(d.group).begins_with("PUBLIC")or String(d.group).begins_with("C-GARDEN")else 75;node.visibility_range_end_margin=12
  if String(d.group).begins_with("C-COVER"):node.visibility_range_end=42;node.visibility_range_end_margin=8
  if String(d.asset).contains("MaterialsVariantsShoe")or String(d.asset).contains("WaterBottle"):node.visibility_range_end=38;node.visibility_range_end_margin=8
  if String(d.group).begins_with("B"):
   for j in range(g.manifest.shops.size()):
    if g.manifest.shops[j].id==d.group:node.layers=1|(1<<(j%18+1));break
  add_child(node);stats.draw_batches+=1
 # Original brands become actual raised sign lettering, mounted on the designed fascia.
 for d:Dictionary in data.signs:
  var brand:Dictionary=g.brand_registry.get(d.store_id,{});var text=TextMesh.new();text.font=g.font;text.text=String(brand.get("name",d.store_id));text.font_size=96;text.pixel_size=.0044;text.depth=.022
  var size=text.get_aabb().size
  if size.x>d.width:text.pixel_size*=float(d.width)/size.x
  var m=StandardMaterial3D.new();m.albedo_color=Color(.88,.84,.71)if d.style in["book","fashion"]else Color(.20,.25,.22);m.roughness=.35;m.metallic=.25;m.emission_enabled=true;m.emission=m.albedo_color;m.emission_energy_multiplier=.12;text.material=m
  var mesh=MeshInstance3D.new();mesh.mesh=text;mesh.position=g.v3(d.p);var n=Vector3(d.normal[0],0,d.normal[1]);mesh.basis=Basis(Vector3.UP.cross(n),Vector3.UP,n);mesh.visibility_range_end=100;add_child(mesh)
 for d:Dictionary in data.lights:
  var light=SpotLight3D.new();light.position=g.v3(d.p);light.rotation_degrees.x=-90;light.light_color=Color(d.color[0],d.color[1],d.color[2]);light.light_energy=d.energy;light.spot_range=d.range;light.spot_angle=58;light.spot_attenuation=1.2;light.shadow_enabled=d.shadow;light.shadow_bias=.025;light.shadow_normal_bias=.15;light.distance_fade_enabled=true;light.distance_fade_begin=28;light.distance_fade_length=12;add_child(light)
 stats.asset_types=library.size();print("V10_RETAIL ",JSON.stringify(stats))
 g.write_json("retail-build.json",stats)
