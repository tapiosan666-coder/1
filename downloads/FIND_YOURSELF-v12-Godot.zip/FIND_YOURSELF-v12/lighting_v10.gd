extends Node3D
func setup(g,bake:bool=false)->void:
 if RenderingServer.get_current_rendering_method()!="forward_plus":return
 for d in [{"id":"A","p":Vector3(332,3,-62),"size":Vector3(44,12,48)},{"id":"B","p":Vector3(-4,4,18),"size":Vector3(54,15,58)},{"id":"C","p":Vector3(-101,3,-209),"size":Vector3(48,12,42)},{"id":"A-shoe","p":Vector3(366,3,-71),"size":Vector3(42,12,38)},{"id":"A-supermarket","p":Vector3(439,3,-2),"size":Vector3(44,12,54)},{"id":"B-travel","p":Vector3(-49,3,28),"size":Vector3(48,12,48)}]:
  if bake and g.only_shot!=""and d.id!=g.only_shot:continue
  var path="res://assets/v10/gi-"+str(d.id)+("-option"if d.id=="C"and g.c_open_proposal else"")+".res";var voxel=VoxelGI.new();voxel.name="IndirectLighting_"+str(d.id);voxel.position=d.p;voxel.size=d.size;voxel.subdiv=VoxelGI.SUBDIV_128;add_child(voxel)
  if bake:
   print("V10_GI_BAKE_BEGIN ",d.id);voxel.bake(g);print("V10_GI_BAKE_DATA ",d.id," ",voxel.data)
   if voxel.data!=null:
    voxel.data.energy=1.05;voxel.data.use_two_bounces=true;voxel.data.interior=false
    var err=ResourceSaver.save(voxel.data,path,ResourceSaver.FLAG_COMPRESS);print("V10_GI_BAKE_SAVED ",d.id," ",err)
  elif ResourceLoader.exists(path)and FileAccess.get_file_as_bytes(path).size()>1024:voxel.data=load(path);voxel.data.interior=false
  else:voxel.queue_free()
