from pathlib import Path
import sys,math,json
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
P=Path(__file__).resolve().parents[1];D=read(P/'source/site-v7.json');out=[];dev=[]
def local(p,y):return[p[0]+429,y,p[1]-46]
def rings(g):return[[list(po.exterior.coords),*[list(r.coords)for r in po.interiors]]for po in polys(g)]
for f in D['floors']:
 w=f['wing'];lev=f['level'];items=[]
 for s in f['stores']:items.append({'id':s['id'],'kind':'店舗','geometry':rings(s['polygon']),'point':s['entry'],'implemented':True})
 for c in f['cores']:
  for k,kind in [('stair','階段'),('lift','EV'),('women','トイレ'),('men','トイレ')]:
   g=c['rooms'].get(k)
   if g is not None:items.append({'id':c['id']+'-'+k,'kind':kind,'geometry':rings(g),'point':list(g.centroid.coords)[0],'implemented':True})
 for e in f['escalators']:items.append({'id':e['id'],'kind':'エスカレーター','geometry':rings(e['shaft']),'point':e['c'],'implemented':True})
 groups={}
 for ob in f.get('furniture',[]):
  if ob.get('plaza'):groups.setdefault(ob['plaza'],[]).append(ob['geom'].centroid)
 for name,pts in groups.items():items.append({'id':name,'kind':'広場','geometry':[],'point':[sum(p.x for p in pts)/len(pts),sum(p.y for p in pts)/len(pts)],'implemented':True})
 for po in polys(f['void']):items.append({'id':'吹抜','kind':'吹抜','geometry':rings(po),'point':list(po.centroid.coords)[0],'implemented':True})
 for bed in f.get('landscape',[]):
  items.append({'id':bed['id'],'kind':'庭園','geometry':rings(bed['geom']),'point':list(bed['geom'].centroid.coords)[0],'implemented':True})
 if f.get('parking'):
  for q in f['parking']['stalls']:items.append({'id':q['id'],'kind':'駐車場','geometry':rings(q['polygon']),'point':list(q['polygon'].centroid.coords)[0],'implemented':True})
 if w=='A'and lev==0:
  for q in D['site']['old_A22']['stalls']:items.append({'id':q['id'],'kind':'駐車場','geometry':rings(q['polygon']),'point':list(q['polygon'].centroid.coords)[0],'implemented':True})
 if w=='B'and lev==3:
  support=next(q for q in read(P/'source/annex-v6.json')['support_reservations']if q['id']=='RF-SUPPORT-16');items.append({'id':'RF-SUPPORT-16 未承認','kind':'未承認構造','geometry':rings(support['polygon']),'point':list(support['polygon'].centroid.coords)[0],'implemented':False})
 out.append({'wing':w,'label':f['label'],'level':lev,'height':f['height'],'floor':rings(f['floor_plate']),'public':rings(f['public']),'items':items,'bounds':list(f['floor_plate'].bounds),'spawn':None})
for fac in D['parking']['facilities']:
 for f in fac['floors']:
  items=[{'id':s['id'],'kind':'駐車場','geometry':rings(s['polygon']),'point':list(s['polygon'].centroid.coords)[0],'implemented':True}for s in f['stalls']]
  for c in f['cores']:
   for key,kind in [('stair','階段'),('elevator','EV')]:
    if not c[key].is_empty:items.append({'id':c['id']+'-'+key,'kind':kind,'geometry':rings(c[key]),'point':list(c[key].centroid.coords)[0],'implemented':True})
  out.append({'wing':fac['id'],'label':f['label'],'level':f['level'],'height':f['height'],'floor':rings(f['floor_plate']),'public':rings(f['protected_pedestrian']),'items':items,'bounds':list(f['floor_plate'].bounds)})
for d in D['devices']:
 if not d.get('door'):continue
 door=d['door'];u=door['axis'];ctr=d['floors'][0]['cabin'].centroid;normal=[ctr.x-door['p'][0],ctr.y-door['p'][1]];ln=math.hypot(*normal);normal=[q/ln for q in normal];cab=d['floors'][0]['cabin'];corners=list(cab.exterior.coords)[:-1];xx=[(p[0]-ctr.x)*u[0]+(p[1]-ctr.y)*u[1]for p in corners];zz=[(p[0]-ctr.x)*normal[0]+(p[1]-ctr.y)*normal[1]for p in corners]
 dev.append({'id':d['id'],'wing':d['wing'],'center':local((ctr.x,ctr.y),0),'u':u,'inside':normal,'width':max(xx)-min(xx),'depth':max(zz)-min(zz),'door_xz':local(door['p'],0),'door_width':door['w'],'stops':[{'label':r['label'],'level':r['level'],'y':r['y']}for r in d['floors']],'speed':2.,'acceleration':1.2})
write(P/'source/map-data-v7.json',out);write(P/'source/elevators-v7.json',dev)
print('RUNTIME',len(out),'maps',len(dev),'EV')
