"""Exact float32 vertex deduplication. Not LOD, no triangle removal or topology changes."""
from pathlib import Path
import json,gzip,struct,numpy as np,hashlib,time
P=Path(__file__).resolve().parents[1];records=[]
for src in ['base-b-v8.pack.gz','base-site-v8.pack.gz','fitout-v8.pack.gz','art-v9.pack.gz']:
 t=time.monotonic();raw=gzip.decompress((P/'assets'/src).read_bytes());hn=struct.unpack_from('<I',raw,4)[0];g=json.loads(raw[8:8+hn]);start=8+hn;h={'surfaces':{},'colliders':{},'signs':g['signs'],'lights':g['lights']};chunks=[];off=0;before=after=0
 def buf(a):
  global off
  b=a.tobytes();r=[off,len(b)];off+=len(b);chunks.append(b);return r
 def load(slot):return np.frombuffer(raw,dtype='<f4',count=slot[1]//4,offset=start+slot[0])
 old_hash=hashlib.sha256();new_hash=hashlib.sha256()
 for k,d in g['surfaces'].items():
  arr=np.concatenate([load(d[f]).reshape(-1,n)for f,n in [('v',3),('n',3),('uv',2),('c',4)]],axis=1)
  _,first,idx=np.unique(arr.view('V48').ravel(),return_index=True,return_inverse=True);unique=arr[first];idx=idx.astype('<i4');assert unique[idx].tobytes()==arr.tobytes()
  before+=len(arr);after+=len(unique);old_hash.update(arr.tobytes());new_hash.update(unique[idx].tobytes());h['surfaces'][k]={}
  for f,a,b in [('v',0,3),('n',3,6),('uv',6,8),('c',8,12)]:h['surfaces'][k][f]=buf(unique[:,a:b].copy())
  h['surfaces'][k]['i']=buf(idx)
 for k,d in g['colliders'].items():h['colliders'][k]=buf(load(d).copy())
 js=json.dumps(h,separators=(',',':')).encode();dst=src.replace('.pack.gz','-indexed.pack.gz')
 with gzip.open(P/'assets'/dst,'wb',compresslevel=9)as z:z.write(b'FY9\0'+struct.pack('<I',len(js))+js+b''.join(chunks))
 records.append({'source':src,'target':dst,'vertices_before':before,'vertices_after':after,'triangle_attribute_hash_before':old_hash.hexdigest(),'triangle_attribute_hash_after':new_hash.hexdigest(),'triangles_identical':old_hash.hexdigest()==new_hash.hexdigest(),'collider_data_unchanged':True,'source_bytes':(P/'assets'/src).stat().st_size,'target_bytes':(P/'assets'/dst).stat().st_size});print(src,records[-1],round(time.monotonic()-t,1),flush=True)
(P/'evidence/v9/indexed-mesh-verification.json').write_text(json.dumps(records,indent=2))
