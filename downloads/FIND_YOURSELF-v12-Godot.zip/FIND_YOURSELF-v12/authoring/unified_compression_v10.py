"""Re-encode regenerated v10 gzip packs losslessly. Requires Python zstandard; not needed to play."""
from pathlib import Path
import gzip,hashlib,json,zstandard,struct
P=Path(__file__).resolve().parents[1];rows=[]
for p in sorted((P/'assets/v10').glob('*.pack.gz')):
 raw=gzip.decompress(p.read_bytes());out=p.with_suffix('.zst');out.write_bytes(b'FYZ1'+struct.pack('<I',len(raw))+zstandard.ZstdCompressor(level=19,threads=2).compress(raw))
 assert zstandard.ZstdDecompressor().decompress(out.read_bytes()[8:])==raw
 rows.append({'old':p.name,'new':out.name,'old_bytes':p.stat().st_size,'new_bytes':out.stat().st_size,'uncompressed_sha256':hashlib.sha256(raw).hexdigest(),'payload_byte_identical':True})
(P/'source/v10/unified-compression.json').write_text(json.dumps(rows,indent=2));print('Verified packs:',len(rows))
