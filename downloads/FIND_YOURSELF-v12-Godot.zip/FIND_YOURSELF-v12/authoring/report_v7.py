from pathlib import Path
import sys,math,json,collections
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
import fitz
P=Path(__file__).resolve().parents[1];D=read(P/'source/site-v7.json');doc=fitz.open();font=P/'assets/NotoSansCJKjp-Regular.otf';INK=(.1,.16,.19);GREEN=(.14,.40,.33)
def text(p,r,s,fs=11,col=INK):
 result=p.insert_textbox(fitz.Rect(r),str(s),fontname='JP',fontsize=fs,color=col,lineheight=1.35)
 if result<0:raise RuntimeError(('text overflow',str(s)[:80],result))
def page(title,sub='',w=1190,h=842):
 p=doc.new_page(width=w,height=h);p.insert_font(fontname='JP',fontfile=str(font));p.draw_rect(p.rect,fill=(.985,.987,.98),color=None);text(p,(32,20,w-32,65),title,21);text(p,(32,70,w-32,112),sub,10);text(p,(32,h-27,w-32,h-5),f'FIND YOURSELF | 敷地・構造検証 v7 | 2026-10-27 JST | 独立検証・未統合 | {len(doc)}',8);return p
def paragraph(title,sections):
 p=page(title,'図面検査・自動物理検査・実画面確認・人間による実操作を区別');y=135
 for heading,body in sections:
  text(p,(40,y,1150,y+35),heading,15,GREEN);y+=38;lines=math.ceil(len(body)/65)+body.count('\n');h=max(54,lines*19);text(p,(40,y,1150,y+h),body,11.5);y+=h+19
 return p
def transform(rect,bounds):
 r=fitz.Rect(rect);x0,z0,x1,z1=bounds;s=min((r.width-24)/(x1-x0),(r.height-24)/(z1-z0));ox=r.x0+(r.width-(x1-x0)*s)/2;oy=r.y0+(r.height-(z1-z0)*s)/2
 return lambda p:fitz.Point(ox+(p[0]-x0)*s,oy+(p[1]-z0)*s),s
def geom(p,g,pt,fill=None,color=INK,width=.4):
 if g.is_empty:return
 sh=p.new_shape()
 for po in polys(g):
  if po.area<1e-6:continue
  for ring in[po.exterior,*po.interiors]:sh.draw_polyline([pt(q)for q in ring.coords])
 sh.finish(fill=fill,color=color,width=width,even_odd=True,closePath=True);sh.commit()
def line(p,g,pt,col=INK,width=.4):
 for ln in lines(g):p.draw_polyline([pt(q)for q in ln.coords],color=col,width=width)
def table(title,heads,rows,widths=None,sub=''):
 widths=widths or[1110/len(heads)]*len(heads)
 for k in range(0,len(rows),23):
  p=page(title+f' {k+1}–{min(k+23,len(rows))}/{len(rows)}',sub);y=125
  for ri,row in enumerate([heads]+rows[k:k+23]):
   x=40;hh=26
   for val,ww in zip(row,widths):
    p.draw_rect(fitz.Rect(x,y,x+ww,y+hh),fill=(.12,.27,.26)if ri==0 else(.93,.95,.94)if ri%2 else(1,1,1),color=(.7,.75,.74),width=.3);text(p,(x+4,y+3,x+ww-4,y+hh-2),val,8,(1,1,1)if ri==0 else INK);x+=ww
   y+=hh
geo=read(P/'evidence/geometry-v7.json');physical=read(P/'evidence/final/physics-all.json')if(P/'evidence/final/physics-all.json').exists()else{'passed':0,'failed':'未集計'};ev=read(P/'evidence/final/physics-EV.json')if(P/'evidence/final/physics-EV.json').exists()else read(P/'evidence/iteration2/physics-EV.json');vehicle=read(P/'evidence/final/vehicle-clearance-v7.json')
paragraph('FIND YOURSELF｜3館・敷地構造検証 v7',[
 ('対象と保護範囲','B館v6の17店舗修正・198区画を維持。A・B・C館15層、駐車場6,699台の既存設計を独立したGodotシーンへ展開。ゲーム本体・承認済み原本は変更していません。店舗内装・仕上げの完成版ではありません。寸法はゲーム用設計値で、実施設の実測値ではありません。外構地盤・庭園は下地表示で、公共床面積へ加算していません。'),
 ('今回の実装','B1〜RFの階段、21基のEV、館間連絡橋の接続先、駐車場スロープ、敷地歩行者ルート。1920×1080初期表示、144 FPS上限・VSync要求ON、解像度/FPS設定の保存、Mキーの検証用マップ、480店舗のブランド設定枠。'),
 ('検査結果の範囲',f"独立図面検査 {geo['passed']}合格 / {geo['failed']}不合格。自動カプセル歩行 {physical['passed']}合格 / {physical['failed']}不合格。EV乗降 {ev['passed']}/{len(ev['checks'])}。24スロープの静的姿勢クリアランス（車高1.65m/2.10m各24件）は全件合格。これらは構造安全・運転・人間によるプレイの合格を意味しません。"),
 ('未承認・未完成','RF-SUPPORT-16は未承認。構造計算・基礎・防水・積載荷重は未検証。A/Cを含む店舗の本格内装・最終看板・設備能力・避難性能・全駐車操作・NPC負荷は未完了。FF15級の画質には到達していません。')])
paragraph('原因と修正した生成ルール',[
 ('開口の意味を分離','吹き抜け・階段・EV・屋外非建築領域を同じ「穴」として手すり生成していたため、屋上EV出口などが閉塞。設備室を除外し、接続先の実床を含めて手すり端部を判定します。'),
 ('接続した床でも設備開口を優先','敷地連絡橋の床が歩行者タワーの階段開口へ重なっていたため、階段の途中で天井に衝突。すべての橋床にも同じ昇降設備の開口を差し引き、描画と衝突へ同じ形を使います。'),
 ('検証範囲の閉鎖壁を撤去','v6のA/C着地点のプレビュー境界は実施設の壁ではありません。全館化に合わせてBの所有床とプレビュー床を区別し、接続先の共用床上に境界壁・偽天井を残さないようにしました。'),
 ('扉・床・実経路','C館の過大な旧階段開口を実寸の2フライトへ合わせ、折返しに手すりを追加。公共扉は壁面内で開口幅＋60mm退避し、斜め接触を防ぎます。経路は扉中心を通過。駐車場は3cmの開口余白で乗降床を削らず、床版へ含めます。設備側の同一床面を二重生成しません。B南西入口は実外郭へ2.750m補正。広場・店舗区画は維持します。')])
paragraph('操作・画面設定・マップ',[
 ('操作','WASD移動、マウス視点、Shift速歩、Fで扉/EV。EV前でFを押し行先を選択すると実際のかごが昇降します。別階のかごは現在階を選んで呼び出します。Mはマップ、F10は画面設定です。数字キー等の旧デバッグ移動は検査用で、歩行合格には使いません。'),
 ('設定','初期1920×1080、上限144 FPS、VSync要求ON。2560×1440・3840×2160、上限30/60/120/144/無制限。保存先は独立検証版のuser://site-v7-settings.cfg。GPU/画面の更新速度により実FPSは低くなります。検証用llvmpipeはVSync非対応のため、実モニターとの同期は未検証です。'),
 ('館内マップ','建築データから同時生成し、現在位置・向き、館/階切替、店舗・広場・トイレ・階段・EV・ES・駐車場を表示。切替は表示のみでワープしません。マップ中はプレイヤーとEV・ESを停止。RFの未承認構造は×印で区別。'),
 ('FPSの解釈','物理60Hzとdtに基づく移動を維持。上限5設定で120物理tickの距離が同じことを別fixtureで検査。NPCはこの独立プロジェクトに存在せず、NPCのFPS依存はここでは実測していません。ソフトウェアGPUの結果をRTX4060性能と見なしません。一部の旧自動撮影プロセスでは終了待ちが発生し、停止しました。Windows実機での終了・表示は未検証です。')])
# Whole site
p=page('敷地全体配置図','既存配置を維持。駐車場・車路・歩道・館間連絡・タワーを表示。構造計算図ではありません。',1684,1191);bounds=D['site']['site_boundary'].bounds;pt,sc=transform((35,115,1649,1120),bounds)
geom(p,D['site']['landscape_buffer'],pt,(.88,.92,.82),None)
for fac in D['parking']['facilities']:
 f=fac['floors'][0];geom(p,f['floor_plate'],pt,(.79,.82,.83),(.45,.48,.5));c=f['floor_plate'].centroid;q=pt((c.x,c.y));text(p,(q.x-60,q.y-10,q.x+100,q.y+28),fac['name'],9)
for q in D['site']['roads']:geom(p,q['polygon'],pt,(.47,.49,.49),None)
for q in D['site']['walks']+D['site']['bridges']+[D['site']['roof_car_bridge']]:geom(p,q['polygon'],pt,(.61,.81,.83),(.2,.4,.44))
for w,col in [('A',(.78,.87,.76)),('B',(.77,.83,.93)),('C',(.89,.81,.70))]:
 f=next(f for f in D['floors']if f['wing']==w and f['level']==0);geom(p,f['floor_plate'],pt,col,INK);c=f['floor_plate'].centroid;q=pt((c.x,c.y));text(p,(q.x-45,q.y-20,q.x+80,q.y+35),w+'館',20)
for t in D['site']['pedestrian_towers']:geom(p,t['outline'],pt,(.85,.69,.35),INK)
# Fifteen detailed levels
for f in D['floors']:
 p=page(f"{f['wing']}館 {f['label']}｜詳細平面",f"床標高 {f['height']:.3f}m / 床版 {f['floor_plate'].area:,.1f}㎡ / 店舗 {len(f['stores'])}区画 / X幅 {f['floor_plate'].bounds[2]-f['floor_plate'].bounds[0]:.1f}m・Z長 {f['floor_plate'].bounds[3]-f['floor_plate'].bounds[1]:.1f}m / World XZ / 原設計由来・独立検証版の修正のみ",1684,1191);pt,sc=transform((35,125,1649,1105),f['floor_plate'].bounds)
 geom(p,f['floor_plate'],pt,(.94,.93,.88),(.3,.38,.4));geom(p,f['public'],pt,(.82,.92,.94),None)
 for room in f.get('program',[]):geom(p,room['polygon'].intersection(f['floor_plate']),pt,(.85,.84,.80),(.5,.49,.44))
 for s in f['stores']:
  geom(p,s.get('sales',s['polygon']),pt,(.79,.88,.80),(.24,.39,.32));geom(p,s.get('backroom',Polygon()),pt,(.87,.79,.62),(.45,.39,.26));c=s['polygon'].representative_point();q=pt((c.x,c.y));text(p,(q.x-35,q.y-6,q.x+40,q.y+12),s['id'],6.5);e=s['entry'];u=s['u'];w=s.get('door_width_m',2.4);aa=[e[i]-u[i]*w/2 for i in range(2)];bb=[e[i]+u[i]*w/2 for i in range(2)];p.draw_line(pt(aa),pt(bb),color=(.85,.2,.15),width=1.8)
  if s.get('main_route'):line(p,LineString(s['main_route']),pt,(.25,.38,.41),.5)
 for d in[x for x in D['devices']if x['wing']==f['wing']]:
  row=next(r for r in d['floors']if r['level']==f['level']);geom(p,d['outline'],pt,None,(.25,.32,.4));geom(p,row['opening'],pt,(.5,.72,.84),(.15,.38,.5));geom(p,row['front'],pt,(.69,.83,.65),(.3,.4,.28));
  for fp in row['flights']:geom(p,fp,pt,(.86,.7,.4),(.6,.42,.18))
  c=d['outline'].centroid;q=pt((c.x,c.y));text(p,(q.x-30,q.y-5,q.x+50,q.y+12),d['id'],7)
 for e in f.get('escalators',[]):
  geom(p,e['shaft'],pt,(.90,.73,.42),(.6,.39,.15));geom(p,unary_union(e['landings']),pt,None,(.28,.5,.31),.6);cc=e['c'];u=e['u'];sg=1 if e['direction']=='UP'else-1;aa=[cc[i]-u[i]*sg*3.5 for i in [0,1]];bb=[cc[i]+u[i]*sg*3.5 for i in [0,1]];p.draw_line(pt(aa),pt(bb),color=(.45,.25,.12),width=.7);qq=pt(cc);text(p,(qq.x-37,qq.y-7,qq.x+58,qq.y+13),e['id'],6.5)
 if f.get('parking'):
  pk=f['parking'];geom(p,pk['vehicle_aisles'],pt,(.60,.62,.63),None);geom(p,pk['protected_pedestrian'],pt,(.75,.9,.92),None)
  for st in pk['stalls']:geom(p,st['polygon'],pt,None,(.35,.4,.42),.3)
 text(p,(45,1120,1600,1155),'灰：設備/裏方計画（詳細未施工） / 緑：売場 / 黄土：バックヤード / 水色：共用動線 / 赤：実入口 / 青：EV開口 / 橙：階段投影 / 細線：店舗内の原設計動線。什器・照明・全設備の完成図ではありません。',9)
# Parking plans
for fac in D['parking']['facilities']:
 if fac['kind']!='garage':continue
 for lev in [0,2,6]:
  f=fac['floors'][lev];p=page(fac['name']+' '+f['label']+'｜車両・歩行者動線',f"標高 {f['height']:.3f}m / {len(f['stalls'])}台 / 7層合計 {sum(len(q['stalls'])for q in fac['floors'])}台。車路曲線・駐車操作全件の合格ではありません。");pt,sc=transform((35,125,1155,760),f['floor_plate'].bounds);geom(p,f['floor_plate'],pt,(.88,.89,.88),INK);geom(p,f['vehicle_aisles'],pt,(.55,.59,.62),None);geom(p,f['protected_pedestrian'],pt,(.6,.83,.83),None)
  for st in f['stalls']:geom(p,st['polygon'],pt,None,(.3,.4,.4),.3)
  for c in f['cores']:geom(p,c['stair'],pt,(.87,.68,.34),INK);geom(p,c['elevator'],pt,(.4,.72,.84),INK)
  for r in fac['ramps']:
   if r['from_level']==lev or r['to_level']==lev:geom(p,r['shaft'],pt,(.75,.57,.46),(.6,.3,.2))
# Device detailed plan and section by type
for target in ['A-A-KW','B-K1','C-K-CW','P-A-E-K1','P-B-S-K1','TW-PAS']:
 d=next(q for q in D['devices']if q['id']==target);row=d['floors'][1];p=page(target+'｜階段・EV 詳細','実階高・2フライト・乗降場・EV昇降路を同じデータから生成。構造耐力や防火区画の認定図ではありません。');pt,sc=transform((35,125,620,760),d['outline'].bounds);geom(p,d['outline'],pt,(.94,.93,.89),INK);geom(p,d['rooms']['stair'],pt,None,INK);geom(p,row['opening'],pt,(.5,.75,.88),INK);geom(p,row['front'],pt,(.73,.87,.7),INK);geom(p,row['mid'],pt,(.8,.76,.62),INK)
 for fp in row['flights']:geom(p,fp,pt,(.90,.74,.43),INK)
 names={'women':'女性WC','men':'男性WC','accessible_wc':'多目的WC','front_lobby':'前室','lift_lobby':'EVロビー','lift_access':'EV前通路','accessible_access':'多目的WC前'}
 for name,g in d['rooms'].items():
  if name in ['stair','lift']:continue
  geom(p,g,pt,(.89,.85,.91)if name in ['women','men','accessible_wc']else None,(.46,.43,.48));cc=g.representative_point();pp=pt((cc.x,cc.y));text(p,(pp.x-38,pp.y-6,pp.x+65,pp.y+15),names.get(name,name),7)
 if d['wing']in'ABC':
  core=next(c for f in D['floors']if f['wing']==d['wing']and f['level']==0 for c in f['cores']if c['id']==d['core']);geom(p,core['room_wall_solids'],pt,(.3,.33,.34),None)
  for g in core.get('cubicle_wall_solids',[]):geom(p,g,pt,(.3,.33,.34),None)
  for cub in core.get('cubicles',[]):geom(p,cub['polygon'],pt,None,(.3,.33,.34))
  for ob in core.get('fixtures',[]):geom(p,ob['geom'],pt,(.62,.66,.68),(.32,.35,.37))
 for r in d['flights'][0]['ramps']:
  aa=r['a'];bb=r['b'];ll=math.dist(aa,bb);v=[(bb[i]-aa[i])/ll for i in [0,1]];lat=[-v[1],v[0]]
  for k in range(r['risers']+1):
   cc=[aa[i]+(bb[i]-aa[i])*k/r['risers']for i in [0,1]];p.draw_line(pt([cc[i]-lat[i] for i in [0,1]]),pt([cc[i]+lat[i]for i in [0,1]]),color=(.38,.31,.20),width=.35)
 for door in[d['stair_door'],d.get('door')]:
  if door:
   e=door['p'];u=door['axis'];ww=door['w'];p.draw_line(pt([e[i]-u[i]*ww/2 for i in range(2)]),pt([e[i]+u[i]*ww/2 for i in range(2)]),color=(.85,.18,.13),width=2)
 # Abstract unfolded stair section, dimensioned to actual flights; explicitly not rendered screenshot.
 flight=d['flights'][0];yy=flight['lower_y'];rise=flight['upper_y']-yy;scale=45;ox=675;oy=660;run=math.dist(flight['ramps'][0]['a'],flight['ramps'][0]['b'])
 pts=[(ox,oy),(ox+run*scale,oy-rise/2*scale),(ox+(run+1.8)*scale,oy-rise/2*scale),(ox+(run*2+1.8)*scale,oy-rise*scale)]
 p.draw_polyline(pts,color=(.15,.31,.4),width=3);text(p,(660,145,1150,215),'展開断面（設計図・Godot実画面ではありません）',13);text(p,(660,230,1150,450),f"階高：{rise:.3f}m\nEV開口：{row['opening'].area:.2f}㎡\nEVかご床：{row['cabin'].area:.2f}㎡\n片フライト走行長：{run:.2f}m\n踏段：片側{flight['ramps'][0]['risers']}段\n幅：2.00m\nEV：{len(d['floors'])}停止階\n実衝突：傾斜支持＋描画踏段\n最大22cmの衝突スイープ付き段差処理",12)
# Support16
ann=read(P/'source/annex-v6.json');support=next(q for q in ann['support_reservations']if q['id']=='RF-SUPPORT-16');p=page('RF-SUPPORT-16｜未承認のまま維持',f"張出し {support['area_m2']:.3f}㎡ / 最大突出 {support['maximum_overhang_depth_m']:.3f}m。今回、構造安全を実証していません。");rf=next(f for f in D['floors']if f['wing']=='B'and f['level']==3);bounds=support['polygon'].buffer(12).bounds;pt,sc=transform((40,130,750,755),bounds);clip=box(*bounds);geom(p,rf['floor_plate'].intersection(clip),pt,(.87,.9,.86),INK);geom(p,support['polygon'],pt,(.95,.5,.35),(.7,.2,.1));text(p,(790,145,1145,700),'支持方式の候補：\n・周辺躯体への伝達梁\n・局所張出しの縮小\n\nどちらも勝手に採用していません。\n通路・駐車区画・床開口を維持したうえで、荷重、たわみ、接合部、基礎・耐震の設計が必要です。\n\n歩行検査で床を通れても、安全な建築構造とは判断できません。',13)
# Summaries
rows=[]
for f in D['floors']:rows.append([f['wing'],f['label'],f"{f['height']:.3f}",f"{f['floor_plate'].area:,.1f}",str(len(f['stores'])),str(len(f['cores']))])
table('15層 寸法・区画台帳',['館','階','床Y m','床版㎡','店舗','共用設備核'],rows)
table('駐車台数台帳',['施設','層数','台数','備考'],[[q['name'],str(len(q['floors'])),str(sum(len(f['stalls'])for f in q['floors'])),'元の駐車区画ID・寸法を保持']for q in D['parking']['facilities']]+[['A既存小駐車場','1','22','既存維持'],['B地下駐車場','1','193','地下店舗と分離した元の車路'],['B屋上駐車場','1','115','RF-SUPPORT-16安全未確認'],['合計','—','6699','全車両経路・駐車操作の合格ではない']],widths=[310,100,100,600])
table('部材納まり・用途再確認｜完成扱いしない範囲',['館','階','既知用途外の差分㎡','0.5m内側の残存㎡','評価'],[[r['wing'],r['floor'],f"{r['source_named_role_uncovered_m2']:.3f}",f"{r['inner_area_after_half_metre_inset_m2']:.3f}",'細い接合帯と局所の役割を要確認']for r in geo['unresolved_programme_records']],widths=[65,80,190,190,585],sub='共用・店舗・設備核・既知の在庫/搬入/庭園/駐車場を引いた差分。差分全体を用途不明な客用床とは見なさず、壁・接合の詳細が未完了として台帳へ抽出。倉庫や壁で機械的に埋めていません。')
paragraph('敷地境界と部材納まりの留保',[
 ('敷地外への続き','W-OFFSITE-Aは計画範囲端で歩道が終わるため、0.36m縮小する経路計画器では端点の外側支持床を確認できません。元の敷地内経路の物理検査とは分けて、敷地外の接続は未検証です。'),
 ('差分の読み方','C地下などには細い壁際・店舗間の差分帯が残り、一部は0.5m内側へ縮めても残ります。承認済み原本の区画を保護し、これを新しい客用通路や任意の管理室として扱っていません。詳細納まり・役割の確認は未完了です。CSVに座標と面積を収録しています。'),
 ('見た目の品質判定','構造と移動が成立しても、A/Cの基本白壁・仮陳列・未仕上げの設備帯は残っています。自動検査件数を理由に、自然な商業施設としての最終品質や建築の完成を認定していません。')])
# Rendered screenshots, exact image bytes embedded. Each page includes proof filename and viewpoint.
shots=json.loads((P/'source/cameras-v7.json').read_text());active=P/'evidence/screenshots-final'
for shot in shots:
 path=active/(shot['id']+'.png')
 if not path.exists():continue
 p=page('Godot実画面｜'+shot['id'],'1920×1080 Viewport / GL Compatibility / llvmpipe / NPC 0 / 自動カメラ。人間によるプレイ操作ではありません。');p.insert_image(fitz.Rect(35,118,1155,748),filename=str(path));text(p,(38,758,1150,795),f"eye(local XYZ)={shot['eye']} / look={shot['look']} / file={path.name}",8)
# High res UI
for label in ['1440','2160']:
 for stem in ['22-map-B','23-settings']:
  path=P/'evidence'/('ui-'+label)/(stem+'.png')
  if path.exists():
   p=page(f'UI実画面｜{stem} / {label}p','固定1920×1080の論理UIをウィンドウ解像度へ拡大。原寸PNGはZIPに収録。');p.insert_image(fitz.Rect(35,120,1155,750),filename=str(path))
paragraph('残課題と統合の判断',[
 ('構造安全・敷地全体','RF-SUPPORT-16、全館の架構・基礎・耐震、地下防水、車両荷重、設備能力・排煙・避難性能は未検証。メッシュと歩行検査から建築安全は証明できません。'),
 ('内装・見た目','A/Cは既存区画に合わせた基本床・壁・ガラス・屋根・開口・設備核を実装した段階です。バックヤードの業種別運用、全店の什器・商品・本格看板・天井設備・照明・外観仕上げは未完了。白い箱・空疎な店舗が残るため、商業施設の最終品質とは評価していません。'),
 ('検査と性能','図面・自動物理カプセル・EV乗降・静的車体クリアランスはそれぞれ別検査。人間の実操作、Windowsの描画/入力、RTX4060性能、1000/5000NPC、全車路の旋回・駐車・交通流、全店舗奥の移動は未検証です。'),
 ('統合','この版は独立検証の提出物です。既存ゲーム本体のNPC・スキャン・AP・セーブには一切統合していません。図面と実画面の確認後、ユーザーの承認により統合可否を判断します。')])
out=P/'deliverables/FIND_YOURSELF-Site-Structural-Review-v7.pdf';doc.save(out,garbage=4,deflate=True);doc.close();print('REPORT',out,len(fitz.open(out)))
