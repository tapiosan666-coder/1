"""Original task-specific retail joinery. Author source included; no third party model added."""
from pathlib import Path
P=Path(__file__).resolve().parents[1];src=(P/'authoring/retail_models_v10.py').read_text();exec(src[:src.index('for var in range(3):bookcase')]);OUT=P/'assets/v12/models';OUT.mkdir(parents=True,exist_ok=True)
# Rounded cosmetics consultation bar with two mirrors, trays, actual tester groups.
mirror=material('Satin_mirror',(.65,.72,.71),.07,.98);screen=material('Original_ocean_screen',(.05,.20,.26),.24);leather=material('Cognac_upholstery',(.25,.105,.052),.7)
box('Fluted_consultation_plinth',(0,0,.46),(2.35,.68,.92),walnut,.02);box('Quartz_worktop',(0,0,.95),(2.45,.79,.06),stone,.025)
for x in [-.60,.60]:
 tube('Mirror_stalk',[(x,.13,.98),(x,.13,1.27)],.016,brass);lathe('Round_mirror_rim',[(0,0),(.235,0),(.245,.018),(.235,.035),(0,.035)],brass,steps=48)
 # Mirrors mounted upright, not lying on the counter.
 o=bpy.context.scene.objects.get('Round_mirror_rim');o.rotation_euler.x=math.pi/2;o.location=(x,.13,1.47)
 bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=12,location=(x,.105,1.47));o=bpy.context.object;o.name='Mirror_face';o.scale=(.221,.008,.221);o.data.materials.append(mirror)
 box('Tester_tray',(x,-.14,1.00),(.48,.22,.025),brass,.01)
 for j in range(4):lathe('Serum_tester',[(0,0),(.026,0),(.026,.12),(.015,.14),(0,.14)],ceramics[j%3],(x-.15+j*.10,-.15,1.02),20)
finish('beauty_consultation')
# Apparel folded-knit feature table: differing stacks, display accessories and softened wooden joinery.
box('Feature_table_top',(0,0,.79),(2.1,1.0,.075),wood,.025)
for x in [-.8,.8]:box('Feature_table_leg',(x,0,.39),(.08,.78,.78),walnut,.012)
for i in range(6):
 x=-.71+(i%3)*.70;y=-.24+(i//3)*.49
 for j in range(2+i%3):
  box('Folded_knit_body',(x,y,.855+j*.042),(.44,.34,.040),fabrics[(i+j)%5],.012);tube('Folded_collar',[(x-.045,y+.10,.88+j*.042),(x,y+.07,.885+j*.042),(x+.045,y+.10,.88+j*.042)],.008,fabrics[(i+j)%5])
finish('apparel_fold_table')
# Homeware vignette: full-sized dining table, chairs and table setting instead of a gondola grid.
box('Dining_oak_top',(0,0,.75),(1.85,.9,.065),wood,.032)
for x in [-.72,.72]:
 for y in [-.30,.30]:box('Dining_tapered_leg',(x,y,.36),(.065,.065,.72),walnut,.012)
for x in [-.55,.55]:
 for y in [-.79,.79]:
  box('Chair_seat',(x,y,.45),(.43,.43,.06),fabrics[1],.025)
  for xx in [-.17,.17]:
   for yy in [-.17,.17]:tube('Chair_leg',[(x+xx,y+yy,.02),(x+xx*.9,y+yy*.9,.43)],.015,wood)
  box('Chair_curved_back',(x,y+(.20 if y>0 else-.20),.70),(.44,.035,.41),wood,.025)
for x in [-.55,.55]:
 for y in [-.23,.23]:
  lathe('Glazed_dinner_plate',[(0,0),(.12,0),(.14,.012),(.14,.025),(.12,.025),(.10,.008),(0,.008)],ceramics[0],(x,y,.79),36)
lathe('Stoneware_vase',[(0,0),(.08,0),(.13,.18),(.07,.30),(.055,.33),(.047,.33),(.05,.28),(0,.015)],ceramics[1],(0,0,.79),32)
finish('home_dining_vignette')
# Appliance/TV wall has screen sizes, soundbars and continuous service cabinetry.
box('Media_wall',(0,.24,1.22),(3.4,.07,2.44),walnut,.02);box('AV_storage',(0,0,.32),(3.4,.58,.64),white,.02)
for x,w,h in [(-.91,1.34,.76),(.90,1.57,.88)]:
 box('Thin_OLED_frame',(x,-.015,1.52),(w,.075,h),metal,.015);box('Original_screen_graphic',(x,-.058,1.52),(w-.035,.004,h-.035),screen,.003);box('Soundbar',(x,-.12,.76),(w*.65,.10,.07),rubber,.018)
finish('electronics_media_wall')
# Display table for books, with stepped face-out presentations and stacks.
box('Curated_book_table',(0,0,.40),(2.1,1.05,.80),walnut,.025)
for k in range(8):
 x=-.78+(k%4)*.52;y=-.24+(k//4)*.47
 for j in range(2+k%3):box('Horizontal_book_block',(x,y,.82+j*.035),(.35,.28,.032),paper,.003);box('Original_dust_jacket',(x,y,.84+j*.035),(.354,.284,.006),bookmats[k%6],.002)
finish('book_curated_table')
# Accessible cafe booth: fixed seating, soft back cushions and independent central table.
for y in [-.83,.83]:
 box('Banquette_base',(0,y,.24),(1.4,.48,.48),walnut,.025);box('Banquette_cushion',(0,y,.49),(1.4,.50,.12),leather,.055);box('Banquette_back',(0,y+(.23 if y>0 else-.23),.76),(1.4,.13,.56),leather,.055)
box('Cafe_booth_table',(0,0,.74),(1.25,.66,.055),stone,.025);lathe('Table_pedestal',[(0,0),(.28,0),(.28,.03),(.05,.08),(.05,.72),(0,.72)],metal,steps=32)
finish('cafe_booth')
print('V12_MODELS_COMPLETE',flush=True)
# Proper double-faced browsing gondola. The inherited short shelf was single-faced and showed a blank back at the entrance.
for variant in range(2):
 before=set(bpy.context.scene.objects);bookcase(variant,short=True)
 for o in set(bpy.context.scene.objects)-before:o.location.y-=.20
 before=set(bpy.context.scene.objects);bookcase(variant+2,short=True)
 for o in set(bpy.context.scene.objects)-before:o.rotation_euler.z+=math.pi;o.location.y+=.20
 finish('book_double_gondola_'+str(variant))
