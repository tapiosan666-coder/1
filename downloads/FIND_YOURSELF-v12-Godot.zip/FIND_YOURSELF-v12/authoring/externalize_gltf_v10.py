"""Deduplicate identical PBR images across GLBs without altering the image pixels or mesh data."""
from pathlib import Path
import struct,json,hashlib
P=Path(__file__).resolve().parents[1];T=P/'assets/v10/textures';T.mkdir(exist_ok=True);rows=[]
for folder in ['models','retail']:
 for p in sorted((P/'assets/v10'/folder).glob('*.glb')):
  raw=p.read_bytes();n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);start=20+n;bn=struct.unpack_from('<I',raw,start)[0];binary=raw[start+8:start+8+bn];images={im['bufferView']:(i,im)for i,im in enumerate(g.get('images',[]))if'bufferView'in im};chunks=[];off=0
  for vi,bv in enumerate(g['bufferViews']):
   b=binary[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']]
   if vi in images:
    i,im=images[vi];ext='.jpg'if im.get('mimeType')=='image/jpeg'else'.png';name=hashlib.sha256(b).hexdigest()+ext;(T/name).write_bytes(b);g['images'][i]={'uri':'../textures/'+name};rows.append({'model':str(p.relative_to(P)),'texture':'assets/v10/textures/'+name,'sha256':hashlib.sha256(b).hexdigest()});b=b'\0'*4
   pad=(-off)%4
   if pad:chunks.append(b'\0'*pad);off+=pad
   bv['byteOffset']=off;bv['byteLength']=len(b);chunks.append(b);off+=len(b)
  binary=b''.join(chunks);binary+=b'\0'*((-len(binary))%4);g['buffers'][0]['byteLength']=len(binary);js=json.dumps(g,separators=(',',':')).encode();js+=b' '*((-len(js))%4);p.write_bytes(struct.pack('<III',0x46546c67,2,12+8+len(js)+8+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary)
(P/'source/v10/shared-textures.json').write_text(json.dumps(rows,indent=2));print('Shared texture references',len(rows),'unique',len({r['sha256']for r in rows}))
