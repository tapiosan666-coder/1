"""Original retail assets modelled in Blender. Curved profiles, garment surfaces, bevelled joinery.
Exported models are original project assets; CC0 wood image attribution retained separately.
"""
import bpy,math,random,json,sys
from mathutils import Vector,Matrix
import bmesh
from pathlib import Path
P=Path(__file__).resolve().parents[1];OUT=P/'assets/v10/retail';OUT.mkdir(exist_ok=True);rng=random.Random(10104)
bpy.ops.wm.read_factory_settings(use_empty=True)
def material(name,col,rough=.5,metal=0,texture=None):
 m=bpy.data.materials.new(name);m.use_nodes=True;s=m.node_tree.nodes.get('Principled BSDF');s.inputs['Base Color'].default_value=(*col,1);s.inputs['Roughness'].default_value=rough;s.inputs['Metallic'].default_value=metal
 if texture:
  im=bpy.data.images.load(str(P/texture),check_existing=True);tex=m.node_tree.nodes.new('ShaderNodeTexImage');tex.image=im;m.node_tree.links.new(tex.outputs['Color'],s.inputs['Base Color'])
 return m
wood=material('CC0_Oak_veneer',(.40,.25,.11),.43,texture='assets/v10/wood-oak.png');walnut=material('CC0_Smoked_walnut',(.23,.13,.07),.40,texture='assets/v10/wood-walnut.png');metal=material('Anodised_graphite',(.038,.043,.044),.30,.75);brass=material('Satin_champagne',(.49,.34,.15),.28,.76);stone=material('Honed_solid_surface',(.72,.70,.64),.31);white=material('Warm_white_coating',(.77,.75,.70),.6);paper=material('Paper_page_edges',(.79,.77,.69),.85);skin=material('Display_mannequin_porcelain',(.72,.70,.65),.48);rubber=material('Grip_rubber',(.012,.015,.014),.8)
fabrics=[material('Woven_'+str(i),c,.88)for i,c in enumerate([(.075,.11,.14),(.59,.54,.43),(.23,.30,.23),(.37,.14,.10),(.57,.59,.56)])]
bookmats=[material('Book_jacket_'+str(i),c,.63)for i,c in enumerate([(.06,.13,.15),(.35,.12,.07),(.58,.48,.30),(.13,.18,.25),(.28,.31,.23),(.56,.54,.47)])]
glass=material('Shop_display_glass',(.8,.88,.88),.06);gs=glass.node_tree.nodes.get('Principled BSDF');gs.inputs['Transmission Weight'].default_value=.85;gs.inputs['IOR'].default_value=1.46;gs.inputs['Alpha'].default_value=.18;glass.surface_render_method='DITHERED'
ceramics=[material('Glazed_ceramic_'+str(i),c,.24)for i,c in enumerate([(.73,.72,.65),(.13,.24,.19),(.42,.19,.09)])];pastry=material('Laminated_pastry',(.53,.25,.075),.64);steel=material('Brushed_stainless',(.49,.52,.54),.28,.9)
spine=material('Original_book_spine_atlas',(1,1,1),.75,texture='assets/v8/book-spines.png')
def box(name,loc,size,mat,b=.007):
 sx,sy,sz=[v/2 for v in size];vv=[(-sx,-sy,-sz),(sx,-sy,-sz),(sx,sy,-sz),(-sx,sy,-sz),(-sx,-sy,sz),(sx,-sy,sz),(sx,sy,sz),(-sx,sy,sz)];ff=[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
 me=bpy.data.meshes.new(name);me.from_pydata(vv,[],ff);me.update()
 if b:
  bm=bmesh.new();bm.from_mesh(me);bmesh.ops.bevel(bm,geom=list(bm.edges),offset=min(b,min(size)*.25),segments=2,affect='EDGES',clamp_overlap=True);bm.to_mesh(me);bm.free()
 o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);o.location=loc;me.materials.append(mat)
 uv=me.uv_layers.new(name='UVMap')
 for face in me.polygons:
  axis=max(range(3),key=lambda i:abs(face.normal[i]));axes=[i for i in range(3)if i!=axis]
  for li,vi in zip(face.loop_indices,face.vertices):uv.data[li].uv=(me.vertices[vi].co[axes[0]]+size[axes[0]]/2,me.vertices[vi].co[axes[1]]+size[axes[1]]/2)
 return o

def mesh(name,verts,faces,mat,uv=None):
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);o.data.materials.append(mat)
 for f in me.polygons:f.use_smooth=True
 if uv:
  layer=me.uv_layers.new(name='UVMap')
  for poly in me.polygons:
   for li,vi in zip(poly.loop_indices,poly.vertices):layer.data[li].uv=uv[vi]
 return o
def tube(name,points,r,mat):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=8;cu.bevel_depth=r;cu.bevel_resolution=3;cu.use_fill_caps=True;sp=cu.splines.new('BEZIER');sp.bezier_points.add(len(points)-1)
 for p,co in zip(sp.bezier_points,points):p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(o);o.data.materials.append(mat);return o
def lathe(name,profile,mat,loc=(0,0,0),steps=32):
 v=[];uv=[];f=[]
 for j,(r,z)in enumerate(profile):
  for i in range(steps):a=i*math.tau/steps;v.append((loc[0]+math.cos(a)*r,loc[1]+math.sin(a)*r,loc[2]+z));uv.append((i/steps,j/(len(profile)-1)))
 for j in range(len(profile)-1):
  for i in range(steps):k=j*steps+i;nx=j*steps+(i+1)%steps;f.append((k,nx,nx+steps,k+steps))
 return mesh(name,v,f,mat,uv)
def move_all(offset):
 for o in bpy.context.scene.objects:o.location+=Vector(offset)
def clear():
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def finish(name):
 # Convert curves and consolidate by material: complex merchandise does not create thousands of draw calls.
 bpy.ops.object.select_all(action='SELECT');bpy.context.view_layer.objects.active=next(iter(bpy.context.scene.objects));bpy.ops.object.convert(target='MESH');objects=list(bpy.context.scene.objects)
 for o in objects:
  if o.type!='MESH':continue
  bpy.context.view_layer.objects.active=o;o.select_set(True)
  if len(o.data.materials)>1:bpy.ops.mesh.separate(type='MATERIAL')
  o.select_set(False)
 groups={}
 for o in list(bpy.context.scene.objects):
  if o.type=='MESH'and len(o.data.vertices):groups.setdefault(o.data.materials[0].name if o.data.materials else'plain',[]).append(o)
 for key,group in groups.items():
  bpy.ops.object.select_all(action='DESELECT')
  for o in group:o.select_set(True)
  bpy.context.view_layer.objects.active=group[0];bpy.ops.object.join();group[0].name=name+'_'+key
 bpy.ops.object.select_all(action='SELECT');bpy.ops.export_scene.gltf(filepath=str(OUT/(name+'.glb')),export_format='GLB',use_selection=True,export_yup=True,export_apply=True,export_animations=False,export_cameras=False,export_lights=False,export_image_format='AUTO')
 print('RETAIL_ASSET',name,flush=True);clear()
def book(x,y,z,w,h,colour,index):
 box('Bound_pages',(x,y,z+h/2),(w*.88,.16,h*.96),paper,.001)
 for sg in[-1,1]:box('Book_hardcover',(x+sg*w*.49,y,z+h/2),(.0028,.17,h),colour,.001)
 box('Rounded_spine',(x,y-.084,z+h/2),(w,.012,h),colour,.003)
 # Legible original spine atlas, per-volume title choice.
 col=index%16;row=(index//16)%2;uu0=col/16;uu1=(col+1)/16;vv0=1-(row+1)/2;vv1=1-row/2
 mesh('Printed_spine',[(x-w*.46,y-.0904,z+.007),(x+w*.46,y-.0904,z+.007),(x+w*.46,y-.0904,z+h-.007),(x-w*.46,y-.0904,z+h-.007)],[(0,1,2,3)],spine,[(uu0,vv0),(uu1,vv0),(uu1,vv1),(uu0,vv1)])
def bookcase(variant,double=False,short=False):
 width=2.00;depth=.39;z0=.08;ht=1.52 if short else 2.24;levels=[.18,.58,.98,1.48]if short else[.18,.58,.98,1.38,1.78,2.20]
 for x in[-width/2,width/2]:box('Veneered_gable',(x,0,ht/2),(.045,depth,ht),wood)
 box('Recessed_back',(0,.18,ht/2),(width,.018,ht-.04),walnut,.002)
 box('Shadow_plinth',(0,0,.06),(width-.08,depth-.06,.12),metal)
 for j,zz in enumerate(levels):
  box('Shelf_with_lipped_edge',(0,0,zz),(width,depth,.032),wood)
  if j==len(levels)-1:continue
  xx=-.94;k=0
  while xx<.91:
   bw=rng.uniform(.028,.055);bh=rng.uniform(.22,.32);book(xx+bw/2,-.015,zz+.018,bw,bh,bookmats[(k+j+variant)%6],k+variant*7);xx+=bw+.006;k+=1
for var in range(3):bookcase(var);finish('book_wall_'+str(var))
for var in range(2):bookcase(var,short=True);finish('book_island_'+str(var))
for var in range(2):
 box('Display_table_rebated_plinth',(0,0,.07),(1.9,.70,.14),walnut,.015);box('Veneer_table_pedestal',(0,0,.39),(1.64,.52,.57),wood,.012);box('Stone_top_eased_edge',(0,0,.725),(2.02,.81,.065),stone,.014)
 for k in range(6):
  x=-.74+(k%3)*.74;y=-.20+(k//3)*.40;h=.035+.01*(k%3)
  for j in range(3):box('Featured_book_pages',(x,y,.78+j*h),(.26,.31,h-.004),paper,.001);box('Original_cover',(x,y,.78+j*h+h/2),(.265,.315,.004),bookmats[(k+var)%6],.001)
 finish('book_table_'+str(var))
def shirt(cx,cy,top,mat,variant=0):
 v=[];uv=[];f=[];rings=22;around=24
 for j in range(rings):
  t=j/(rings-1);zz=top-t*.68;width=.095+(min(t/.20,1))*.135;width*=1-.07*math.sin(t*math.pi);dep=.065+.018*math.sin(t*math.pi)
  for i in range(around):
   a=i*math.tau/around;fold=(.003+.006*t)*math.sin(a*7+t*2+variant);v.append((cx+math.cos(a)*(width+fold),cy+math.sin(a)*(dep+fold*.7),zz+.005*math.sin(a*4)*t));uv.append((i/around,t))
 for j in range(rings-1):
  for i in range(around):a=j*around+i;b=j*around+(i+1)%around;f.append((a,b,b+around,a+around))
 o=mesh('Tailored_woven_garment',v,f,mat,uv);sol=o.modifiers.new('Fabric_thickness','SOLIDIFY');sol.thickness=.0015;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=sol.name)
 for sg in[-1,1]:
  v=[];f=[]
  for j in range(10):
   t=j/9;center=(cx+sg*(.20+.10*t),cy,top-.12-.45*t);r=.09-.043*t
   for i in range(16):a=i*math.tau/16;v.append((center[0]+math.cos(a)*r*.65,center[1]+math.sin(a)*r,center[2]+math.cos(a)*r*.10))
  for j in range(9):
   for i in range(16):a=j*16+i;b=j*16+(i+1)%16;f.append((a,b,b+16,a+16))
  mesh('Draped_sleeve',v,f,mat)
 # Collar, lapel seam, buttons and hanger form real profile silhouettes.
 tube('Folded_collar',[(cx-.09,cy,top-.02),(cx-.07,cy-.07,top-.035),(cx,cy-.09,top-.11),(cx+.07,cy-.07,top-.035),(cx+.09,cy,top-.02)],.008,mat)
 for j in range(4):
  o=lathe('Shirt_button',[(0,0),(.008,0),(.009,.003),(0,.004)],brass,steps=12);o.location=(cx,cy-.073,top-.20-j*.11);o.rotation_euler.x=math.pi/2
 tube('Shoulder_hanger',[(cx-.21,cy,top-.14),(cx,cy,top+.025),(cx+.21,cy,top-.14),(cx-.21,cy,top-.14)],.007,wood)
 tube('Hanger_hook',[(cx,cy,top+.025),(cx,cy,top+.12),(cx+.035,cy,top+.15),(cx+.045,cy,top+.12)],.004,metal)
for var in range(3):
 for sg in[-1,1]:
  tube('Weighted_rail_foot',[(sg*.92,-.34,.025),(sg*.92,0,.04),(sg*.92,.34,.025)],.024,metal);tube('Rack_upright',[(sg*.92,0,.04),(sg*.92,0,1.72)],.024,metal)
 tube('Continuous_hanging_rail',[(-.92,0,1.72),(.92,0,1.72)],.023,brass)
 # Shirt faces lie perpendicular to the rail, as garments physically hang on a shopping rack.
 for i in range(9):
  before=set(bpy.context.scene.objects);shirt(0,0,1.58,fabrics[(i+var)%5],i)
  for o in set(bpy.context.scene.objects)-before:o.matrix_world=Matrix.Translation((-.76+i*.19,0,0))@Matrix.Rotation(math.pi/2,4,'Z')@o.matrix_world
 finish('garment_rack_'+str(var))
# A shop window mannequin: joined and remeshed anatomical blank figure, dressed with an actual garment surface.
for part,loc,scale in [('torso',(0,0,1.28),(.205,.105,.33)),('pelvis',(0,0,.91),(.17,.11,.15)),('neck',(0,0,1.61),(.055,.05,.08)),('head',(0,-.003,1.77),(.09,.08,.125)),('leftarm',(-.255,0,1.30),(.05,.065,.29)),('rightarm',(.255,0,1.30),(.05,.065,.29)),('leftleg',(-.09,0,.49),(.068,.075,.43)),('rightleg',(.09,0,.49),(.068,.075,.43))]:
 bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=12,location=loc);o=bpy.context.object;o.name=part;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
bpy.ops.object.select_all(action='SELECT');bpy.context.view_layer.objects.active=bpy.context.selected_objects[0];bpy.ops.object.join();o=bpy.context.object;mod=o.modifiers.new('Continuous_sculpted_surface','REMESH');mod.mode='VOXEL';mod.voxel_size=.022;bpy.ops.object.modifier_apply(modifier=mod.name);mod=o.modifiers.new('Sculpt_smoothing','SMOOTH');mod.factor=1.4;mod.iterations=4;bpy.ops.object.modifier_apply(modifier=mod.name);o.data.materials.append(skin)
for p in o.data.polygons:p.use_smooth=True
shirt(0,-.01,1.57,fabrics[0]);lathe('Mannequin_display_base',[(0,0),(.25,0),(.25,.025),(0,.025)],metal,steps=48);finish('dressed_mannequin')
# Profiled retail shelving for shoes / cosmetics / lifestyle items; merchandise is separate shared models.
for var in range(3):
 for sg in[-1,1]:tube('Extruded_shelf_upright',[(sg*.98,.22,.03),(sg*.98,.22,1.98)],.020,brass if var==0 else metal)
 box('Merchandise_back_panel',(0,.27,1.05),(2.05,.035,2.10),walnut if var==0 else white,.008)
 for hh in[.16,.68,1.20,1.72]:box('Eased_display_shelf',(0,0,hh),(2.02,.57,.034),wood if var!=2 else stone,.009)
 finish('product_bay_'+str(var))
# Curved bentwood cafe chair.
def cafe_chair(cx,cy,angle):
 before=set(bpy.context.scene.objects)
 for x in[-.19,.19]:
  for y in[-.18,.18]:tube('Splayed_tapered_leg',[(x*1.10,y*1.10,.02),(x,y,.45)],.018,wood)
 profile=[(0,.44),(.17,.44),(.235,.455),(.235,.475),(0,.475)];lathe('Upholstered_seat',profile,fabrics[2],steps=40)
 v=[];faces=[]
 for j in range(7):
  zz=.47+j*.055
  for i in range(17):a=-1.15+i*2.30/16;v.append((math.sin(a)*.25,math.cos(a)*.23,zz))
 for j in range(6):
  for i in range(16):a=j*17+i;faces.append((a,a+1,a+18,a+17))
 o=mesh('Bent_plywood_backrest',v,faces,wood);mod=o.modifiers.new('Plywood_laminate','SOLIDIFY');mod.thickness=.016;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
 for o in set(bpy.context.scene.objects)-before:o.rotation_euler.z+=angle;o.location+=Vector((cx,cy,0))
lathe('Stone_cafe_top',[(0,.735),(.49,.735),(.505,.747),(.505,.77),(0,.77)],stone,steps=48);lathe('Pedestal_base',[(0,0),(.28,0),(.29,.025),(.24,.055),(.045,.08),(.045,.735),(0,.735)],metal,steps=40)
cafe_chair(0,-.87,0);cafe_chair(0,.87,math.pi)
for x in[-.14,.14]:
 lathe('Porcelain_cup',[(0,0),(.045,0),(.049,.065),(.045,.075),(.040,.072),(.040,.008),(0,.008)],ceramics[0],(x,.03,.77),32);tube('Cup_handle',[(x+.042,.03,.829),(x+.073,.03,.827),(x+.076,.03,.799),(x+.045,.03,.787)],.006,ceramics[0]);lathe('Saucer',[(0,0),(.064,0),(.073,.009),(.057,.012),(0,.004)],ceramics[0],(x,.03,.772),32)
finish('cafe_table')
# Counter with actual espresso machine controls / steam wands / grinder and refrigerated pastry case.
box('Recessed_counter_plinth',(0,0,.06),(2.35,.78,.12),metal,.012);box('Veneer_counter_body',(0,0,.52),(2.40,.82,.92),wood,.012);box('Polished_counter_top',(0,0,1.01),(2.50,.94,.065),stone,.018)
box('Coffee_machine_cast_body',(-.35,.12,1.29),(.72,.43,.42),steel,.045);box('Machine_control_panel',(-.35,-.107,1.39),(.61,.018,.13),metal,.010)
for x in[-.55,-.30]:
 tube('Portafilter_handle',[(x,-.12,1.22),(x,-.29,1.22)],.022,rubber);lathe('Group_head',[(0,0),(.05,0),(.05,.035),(0,.035)],steel,(x,-.10,1.21),24)
 for k in range(3):box('Backlit_button',(x+k*.028-.02,-.120,1.41),(.014,.007,.014),white,.002)
tube('Steam_wand',[(-.67,-.1,1.34),(-.73,-.17,1.25),(-.72,-.20,1.15)],.008,steel);box('Drip_tray',(-.35,-.18,1.08),(.67,.24,.025),steel,.008)
lathe('Grinder_hopper',[(0,0),(.09,0),(.13,.15),(.13,.32),(.10,.34),(0,.34)],glass,(-.93,.08,1.25),40);box('Grinder_base',(-.93,.08,1.14),(.23,.24,.20),metal,.035)
box('Pastry_display_base',(.68,0,1.08),(.85,.74,.10),steel,.012)
for x in[.25,1.11]:box('Display_glass_side',(x,0,1.32),(.009,.68,.40),glass,.001)
box('Display_glass_front',(.68,-.34,1.32),(.86,.009,.40),glass,.001);box('Display_glass_lid',(.68,0,1.525),(.88,.70,.009),glass,.001)
for j in range(6):
 cx=.40+(j%3)*.26;cy=-.16+(j//3)*.30;v=[];faces=[]
 for a in range(25):
  t=a/24;ang=(t-.5)*2.5;cc=Vector((cx+math.sin(ang)*.10,cy+math.cos(ang)*.06,1.16));rr=.01+.035*math.sin(math.pi*t)**.6
  for k in range(12):q=k*math.tau/12;v.append(tuple(cc+Vector((math.cos(q)*rr,math.sin(q)*rr,.016*math.cos(q*2)))))
 for a in range(24):
  for k in range(12):i=a*12+k;n=a*12+(k+1)%12;faces.append((i,n,n+12,i+12))
 mesh('Laminated_croissant',v,faces,pastry)
finish('cafe_counter')
# Non-food register and product table with softened joinery.
box('Register_base',(0,0,.5),(2.4,.82,1.0),walnut,.02);box('Register_top',(0,0,1.03),(2.49,.92,.06),stone,.015);tube('Monitor_arm',[(.7,0,1.06),(.7,0,1.24)],.025,metal);o=box('Register_display',(.7,.02,1.34),(.34,.045,.23),metal,.015);o.rotation_euler.x=.2;finish('retail_counter')
for var in range(2):
 box('Merchandise_table_base',(0,0,.10),(1.8,.68,.20),metal,.02);box('Merchandise_table_body',(0,0,.43),(1.70,.60,.55),wood,.015);box('Merchandise_table_top',(0,0,.73),(2.0,.82,.06),stone,.012)
 for x in[-.65,0,.65]:
  for y in[-.19,.19]:lathe('Ceramic_display_vase',[(0,0),(.08,0),(.11,.09),(.10,.16),(.05,.22),(.045,.25),(.04,.25),(.04,.21),(0,.005)],ceramics[(int((x+.7)*7)+var)%3],(x,y,.76),32)
 finish('lifestyle_table_'+str(var))
# Electronics display: rounded devices, camera aperture, glass display, independent tilt stand.
box('Electronics_display_island',(0,0,.44),(1.9,.73,.88),white,.025);box('Oak_bullnose_top',(0,0,.90),(2.02,.83,.055),wood,.015)
for xx in[-.65,0,.65]:
 tube('Device_security_stand',[(xx,0,.93),(xx,.03,1.04)],.015,steel)
 o=box('Rounded_device_chassis',(xx,0,1.20),(.27,.020,.35),metal,.012);o.rotation_euler.x=-.15
 o=box('Glass_screen',(xx,-.013,1.20),(.245,.006,.31),glass,.008);o.rotation_euler.x=-.15
 tube('Coiled_security_tether',[(xx,0,1.02),(xx+.05,.05,.94),(xx+.10,.12,.94)],.004,white)
finish('electronics_table')
# Apothecary wall: different bottle forms, pumps and dropper tops, not steel water bottles.
box('Apothecary_back',(0,.25,1.05),(2.05,.035,2.10),white,.009)
for hh in[.16,.68,1.20,1.72]:
 box('Glass_product_shelf',(0,0,hh),(2.0,.56,.024),stone,.007)
 for j in range(7):
  x=-.83+j*.275;h=.14+.035*(j%3);r=.035+.006*(j%2)
  lathe('Serum_glass_bottle',[(0,0),(r,0),(r,h*.70),(r*.60,h*.86),(r*.40,h),(0,h)],ceramics[j%3],(x,0,hh+.015),24)
  lathe('Satin_dispenser_cap',[(0,0),(r*.45,0),(r*.45,.035),(0,.035)],brass,(x,0,hh+.015+h),20)
  if j%2:tube('Pump_nozzle',[(x,0,hh+h+.055),(x,-.025,hh+h+.055),(x,-.035,hh+h+.045)],.006,brass)
finish('cosmetic_bay')
box('Bakery_service_cabinet',(0,.21,1.04),(2.04,.08,2.08),wood,.014)
for hh in[.20,.72,1.24,1.76]:
 box('Cafe_wall_shelf',(0,0,hh),(2.0,.50,.035),walnut,.008)
 for j in range(6):
  x=-.78+j*.31
  lathe('Stacked_espresso_cups',[(0,0),(.048,0),(.055,.075),(.050,.080),(.044,.075),(.040,.010),(0,.010)],ceramics[j%3],(x,0,hh+.02),24)
  tube('Porcelain_handle',[(x+.047,0,hh+.08),(x+.080,0,hh+.078),(x+.080,0,hh+.04),(x+.043,0,hh+.035)],.006,ceramics[j%3])
finish('cafe_wall')
print('RETAIL_LIBRARY_COMPLETE',flush=True)
