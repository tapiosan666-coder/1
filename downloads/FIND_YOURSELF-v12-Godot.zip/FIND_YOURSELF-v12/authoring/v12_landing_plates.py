"""Restore visible, flush inspection plates on already-collidable outer landings. No new walking floor or physics changes."""
from pathlib import Path
P=Path(__file__).resolve().parents[1];src=(P/'authoring/v12_safety.py').read_text();exec(src[:src.index('for e in es:')]);M={};coll={};rows=[]
for e in es:
 u=np.array(e['u'],float);n=np.array([-u[1],u[0]]);c=np.array([e['c'][0],e['c'][2]]);half=e['run_m']/2
 for sg,lev in[(-1,e['levels'][0]),(1,e['levels'][1])]:
  y=HEIGHT[lev];cc=c+u*sg*(half+1.425);physical=floor_near(y,rect(c,u,e['run_m']+10,10));requested=rect(cc,u,.75,1.44);plate=requested.intersection(physical);render_group='V12-LANDING-'+e['id']+'-'+str(lev);surf(plate,y+.001,'v12_landing_plate',True,False)
  k='v12_landing_plate@@'+render_group
  if k in M:
   v=np.array(M[k]['v']).reshape(-1,3);xz=v[:,[0,2]]-c;M[k]['uv']=np.c_[xz@u*4,xz@n*4].ravel().tolist()
  rows.append({'bank':e['id'],'floor_y':y,'geometry':plate,'requested_m2':requested.area,'supported_m2':plate.area,'outside_actual_flat_collision_m2':plate.difference(physical).area,'visual_surface_offset_m':.001,'new_colliders':False})
save_zst(P/'assets/v12/es-landing-plates.pack.zst',{'surfaces':M,'colliders':{},'signs':[],'lights':[]});write(P/'source/v12/landing-plates.json',rows)
# Original procedural normal map: fine milled anti-slip texture, no photographic input.
from PIL import Image
q=np.arange(512)/512;xx,yy=np.meshgrid(q,q);h=.06*np.sin(xx*math.tau*24)+.015*np.sin(yy*math.tau*8);dx=np.gradient(h,axis=1)*3;dy=np.gradient(h,axis=0)*3;normal=np.dstack([-dx,-dy,np.ones_like(h)]);normal/=np.linalg.norm(normal,axis=2,keepdims=True);Image.fromarray(((normal*.5+.5)*255).astype('uint8')).save(P/'assets/v12/landing-normal.png');print('SUPPORTED_LANDING_PLATES',len(rows),'new physics faces',sum(len(x)for x in coll.values()),flush=True)
