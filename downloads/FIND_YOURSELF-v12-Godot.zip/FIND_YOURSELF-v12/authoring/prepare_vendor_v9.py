from pathlib import Path
import json,struct,io,hashlib
from PIL import Image
P=Path(__file__).resolve().parents[1];A=P/'assets/vendor';V=P/'assets/v9';V.mkdir(exist_ok=True)
for model in ['SheenChair','SheenWoodLeatherSofa']:
 p=A/(model+'.glb');raw=p.read_bytes();n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);start=20+n;bn=struct.unpack_from('<I',raw,start)[0];data=raw[start+8:start+8+bn];chunks=[];views=[]
 # Preserve all geometry and other buffer views; convert image buffers to standard PNG for Godot.
 image_views={im['bufferView']:i for i,im in enumerate(g['images'])};offset=0
 for vi,bv in enumerate(g['bufferViews']):
  blob=data[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']]
  if vi in image_views:
   ix=image_views[vi];im=Image.open(io.BytesIO(blob));im.thumbnail((2048,2048),Image.Resampling.LANCZOS);out=io.BytesIO();im.save(out,format='PNG',optimize=True);blob=out.getvalue();g['images'][ix]['mimeType']='image/png'
  pad=(-offset)%4
  if pad:chunks.append(b'\0'*pad);offset+=pad
  bv['byteOffset']=offset;bv['byteLength']=len(blob);chunks.append(blob);offset+=len(blob)
 for tex in g.get('textures',[]):
  if 'EXT_texture_webp'in tex.get('extensions',{}):tex['source']=tex['extensions'].pop('EXT_texture_webp')['source']
 for key in ['extensionsUsed','extensionsRequired']:
  if key in g:g[key]=[v for v in g[key]if v!='EXT_texture_webp']
 if model=='SheenChair':
  # Remove the manufacturer's underside label texture, preserving an unbranded material.
  for mat in g['materials']:
   if mat.get('name')=='label':mat['pbrMetallicRoughness']={'baseColorFactor':[.20,.16,.10,1],'metallicFactor':0,'roughnessFactor':.8}
 binary=b''.join(chunks);binary+=b'\0'*((-len(binary))%4);g['buffers'][0]['byteLength']=len(binary)
 js=json.dumps(g,separators=(',',':')).encode();js+=b' '*((-len(js))%4)
 dest=A/(model+'-v9.glb');dest.write_bytes(struct.pack('<III',0x46546c67,2,12+8+len(js)+8+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary)
 if model=='SheenChair':
  mat=next(m for m in g['materials']if m.get('name')=='wood Brown')
  for key,idx in [('wood-photo',mat['pbrMetallicRoughness']['baseColorTexture']['index']),('wood-orm',mat['pbrMetallicRoughness']['metallicRoughnessTexture']['index'])]:
   iv=g['images'][g['textures'][idx]['source']]['bufferView'];v=g['bufferViews'][iv];im=Image.open(io.BytesIO(binary[v['byteOffset']:v['byteOffset']+v['byteLength']]));im.save(V/(key+'.png'))
 print(dest.name,dest.stat().st_size)
(P/'licenses/vendor/MODIFICATIONS-v9.txt').write_text('SheenChair: CC0-1.0, Eric Chadwick / Wayfair LLC, 2020. Underside manufacturer label replaced by unbranded material. Embedded images limited to 2048 pixels. Wood maps also used on original architecture.\nSheenWoodLeatherSofa: CC0 original by Fran Calvente (2021), CC-BY-4.0 improvements by Eric Chadwick / Darmstadt Graphics Group GmbH (2024). Embedded images converted WEBP to PNG, maximum 2048px; geometry unchanged. Source and full attribution in adjacent README and metadata files.\nSource: https://github.com/KhronosGroup/glTF-Sample-Assets/tree/main/Models\n')
