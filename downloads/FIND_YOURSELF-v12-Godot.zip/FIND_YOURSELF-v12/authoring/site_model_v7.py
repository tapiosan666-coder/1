"""Whole site structural visualization. Geometry derives from existing named programme, not invented corridor fillers."""
from pathlib import Path
import sys,json,gzip,math,numpy as np
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
from shapely import constrained_delaunay_triangles
P=Path(__file__).resolve().parents[1];D=read(P/'source/site-v7.json');M={};coll={};render_group='SITE';lights=[];signs=[];doors=[];esc=[];brands=[];summary=[];routes=[]
def pos(x,y,z):return[round(x+429,5),round(y,5),round(z-46,5)]
exec((P/'authoring/mesh_primitives.py').read_text())
# A single triangulated polygon per surface; avoids thousands of artificial 3m grid seams on site-scale slabs.
def surf(g,y,mat,up=True,solid=False,shade=1):
 for po in polys(g):
  if po.area<1e-8:continue
  for t in constrained_delaunay_triangles(po).geoms:
   co=list(t.exterior.coords)[:3];tri(mat,[pos(x,y,z)for x,z in co],(0,1 if up else -1,0),[[x,z]for x,z in co],solid,shade)
def slab(g,y):
 holes=[]
 for d in D['devices']:
  for r in d['floors']:
   if abs(r['y']-y)<.02:
    holes.append(r['opening'])
    if r['level']>d['floors'][0]['level']:holes.extend([fp.buffer(.06,join_style=2)for fp in r['flights']])
 return g.difference(unary_union(holes))
def qsign(text,p,n=(0,-1),w=3,h=.5):
 # Runtime vector labels are provisional original name slots, not completed logo work.
 signs.append({'text':text,'p':p,'n':n,'w':w,'h':h})
def slope(a,b,y0,y1,width,mat='dark_stone',solid=True):
 v=np.array(b)-a;v=v/np.linalg.norm(v);lat=np.array([-v[1],v[0]])*width/2;a=np.array(a);b=np.array(b)
 quad(mat,[pos(*(a+lat)[:1],y0,0)]if False else[pos(a[0]+lat[0],y0,a[1]+lat[1]),pos(a[0]-lat[0],y0,a[1]-lat[1]),pos(b[0]-lat[0],y1,b[1]-lat[1]),pos(b[0]+lat[0],y1,b[1]+lat[1])],(0,1,0),solid=solid)
def publicdoor(id,p,y,u,w,label):doors.append({'id':id,'p':pos(p[0],y,p[1]),'u':u,'n':[-u[1],u[0]],'leaf_width_m':w-.02,'clear_width_m':w,'height_m':2.2,'hinge_side':-1,'mechanism':'sliding','slide_side':1,'room_label':label,'role':'public'})
for f in D['floors']:
 w=f['wing'];lev=f['level'];y=f['height'];render_group=w+'-'+f['label'];cores=unary_union([c['outline']for c in f['cores']]);coreclear=unary_union([c['rooms']['stair'].union(c['rooms']['lift'])for c in f['cores']]);bexisting=w=='B'and lev in [0,1,2]
 if not bexisting:
  extrude(f['floor_plate'],y-.38,.38,'stone',True)
  if w=='B'and lev==-1:extrude(f.get('above_basement_grade_cover',Polygon()),-.38,.38,'plaster',True)
  if lev<3:
   above=next(g for g in D['floors']if g['wing']==w and g['level']==lev+1);ceiling=above['floor_plate'].difference(coreclear)
   # C has roofs/decks only over its independent buildings; outdoor lanes retain sky.
   if w=='C':ceiling=ceiling.intersection(f['shell'])
   surf(ceiling,above['height']-.42,'plaster',False,False)
  env=f.get('building_envelope_v5',f['shell']);wall=env.boundary.buffer(.12).difference(f['public'].buffer(.25))
  if w=='C':wall=f.get('envelope_walls',wall)
  h=4.6 if lev<3 else 1.1
  # Shared frontage/party walls derive from one footprint; only declared customer-facing sales gets glass.
  store_union=unary_union([s['polygon']for s in f['stores']]);wall=wall.difference(store_union.buffer(.14)).difference(cores.buffer(.14))
  if lev==3:wall=wall.difference(unary_union([q['polygon'].buffer(.2)for q in D['site']['bridges']+[D['site']['roof_car_bridge']]if abs(q['height']-y)<.02]))
  extrude(wall,y,h,'plaster',True)
  for index,s in enumerate(f['stores']):
   render_group=s['id'];pol=s['polygon'];sales=s.get('sales',pol);stock=s.get('backroom',Polygon());entry=s['entry'];u=s['u'];dw=s.get('door_width_m',2.4);frontline=LineString(s['front'])if s.get('front')else pol.boundary.intersection(rect(entry,u,s.get('frontage_m',dw+2),.7));front=frontline.buffer(.14);outer=pol.boundary.buffer(.12).intersection(pol);part=stock.boundary.intersection(sales.buffer(.02)).buffer(.10).intersection(pol);walls=outer.union(part);cut=rect(entry,u,dw,.9)
   # A backrooms lack a recorded service door: choose the longest real sales/stock interface, report it as a generated proposal.
   back=s.get('back_door');bu=u
   if not stock.is_empty:
    boundary=stock.boundary.intersection(sales.buffer(.015));ls=lines(boundary)
    if back is None and ls:
     ln=max(ls,key=lambda g:g.length);c=ln.interpolate(.5,normalized=True);back=[c.x,c.y];aa,bb=ln.coords[0],ln.coords[-1];ll=math.dist(aa,bb);bu=[(bb[0]-aa[0])/ll,(bb[1]-aa[1])/ll]if ll>.01 else u
    if back is not None:cut=cut.union(rect(back,bu,1.5,.8));publicdoor(s['id']+'-STOCK',back,y,bu,1.5,'従業員用 / '+s['id']);doors[-1]['role']='staff'
   opaque=walls.difference(front).difference(cut);glass=walls.intersection(front).difference(stock.buffer(.02)).difference(cut)
   extrude(opaque,y,h,'wall_sand'if index%3==0 else'plaster',True);extrude(glass,y,.35,'dark_stone',True);extrude(glass,y+.35,2.7,'glass',True);extrude(glass,y+3.05,max(0,h-3.05),'plaster',True);extrude(walls.intersection(cut),y+2.8,max(0,h-2.8),'plaster',True)
   surf(sales,y+.008,'oak_floor'if'衣料'in s['category']else'retail_terrazzo',True,False)
   # Preserve designed store spine, restrained structural fixtures only. Detailed merchandising is explicitly unfinished.
   keep=s.get('aisles',Polygon()).buffer(.15).union(LineString(s.get('main_route',[entry,[entry[0]+s['n'][0]*2,entry[1]+s['n'][1]*2]])).buffer(1.0));safe=sales.buffer(-.5).difference(keep);count=0
   if not safe.is_empty:
    xx0,zz0,xx1,zz1=safe.bounds
    for xx in np.arange(xx0+1,xx1,6):
     for zz in np.arange(zz0+1,zz1,6):
      fp=rect((xx,zz),u,2.4,.7)
      if count<10 and safe.covers(fp):extrude(fp,y,.85,'oak',True);count+=1
   qsign(s['id']+'  '+s['category'],pos(entry[0],y+3.35,entry[1]),[-s['n'][0],-s['n'][1]],min(5,dw+1),.6)
  render_group=w+'-'+f['label']
  for ob in f.get('furniture',[]):
   g=ob.get('geom',ob.get('polygon'));kind=ob['kind'];c=g.centroid
   if 'bench'in kind:extrude(g,y+.42,.09,'oak',True)
   elif 'plant'in kind:extrude(g,y,.45,'dark_stone',True);cylinder((c.x,c.y),y+.45,.55,.6,'leaf',8,False)
  if lev>0:
   all_connected=unary_union([other['floor_plate']for other in D['floors']if other['level']==lev and other['wing']!=w])
   edges=f['void'].difference(cores.buffer(.5)).boundary.intersection(f['floor_plate'].buffer(.12)).difference(all_connected.buffer(-.06))
   for ln in lines(edges):extrude(ln.buffer(.045),y,1.1,'glass',True)
  # Explicit customer access/vestibule apertures stay open. Door animation can be added later; no false collision panel.
  for dd in f.get('doors_v3',[]):qsign('入口 '+dd['id'],pos(dd['center'][0],y+3.2,dd['center'][1]),dd['normal'],3,.5)
  if lev==3:
   edge=unary_union([LineString(po.exterior.coords)for po in polys(f['floor_plate'])]).difference(cores.buffer(.5))
   connected=unary_union([q['polygon']for q in D['site']['bridges']+[D['site']['roof_car_bridge']]if abs(q['height']-y)<.05]);edge=edge.difference(connected.buffer(.15));extrude(edge.buffer(.04),y,1.1,'glass',True)
  summary.append({'wing':w,'floor':f['label'],'floor_m2':f['floor_plate'].area,'stores':len(f['stores']),'detailed_retail_fitout_complete':False})
 # original brand registry covers every one of the 480 ID slots, B198 included.
 for s in f['stores']:
  name={'A':'風環','B':'時織','C':'庭音'}[w]+' '+s['id'];brands.append({'store_id':s['id'],'wing':w,'floor':f['label'],'category':s['category'],'name':name,'logo_asset':None,'sign_position':pos(s['entry'][0],y+3.35,s['entry'][1]),'normal':[-s['n'][0],-s['n'][1]],'max_width_m':min(6,s.get('frontage_m',s.get('door_width_m',3))+0.4),'status':'original provisional identifier; final brand design and trademark clearance pending','ownership':'original generated text; no third-party logo'})
# A roof glazing follows existing atrium openings; it is not walkable roof floor.
f=next(f for f in D['floors']if f['wing']=='A'and f['level']==2);render_group='A-SKYLIGHTS'
for po in polys(f['void']):
 surf(po,16.4,'roof_glass',True,False)
 x0,z0,x1,z1=po.bounds
 for xx in np.arange(x0,x1,8):
  for ln in lines(LineString([(xx,z0),(xx,z1)]).intersection(po)):bar(ln.coords[0],ln.coords[-1],.12,16.15,.25,'metal',False)
# Terrain is an exterior ground layer, not additional retail/public structural floor.
# Use the approved green buffer and the ground between existing outlet pavilions/paths; never add a route.
render_group='SITE-TERRAIN';terrain=[]
g=D['site']['landscape_buffer'];extrude(g,-.40,.38,'soil',True);surf(g,-.014,'leaf',True,False);terrain.append({'id':'SITE-GREEN-BUFFER','geometry':g,'area_m2':g.area,'role':'original site green buffer; landscape finish unfinished'})
f=next(f for f in D['floors']if f['wing']=='C'and f['level']==0);g=f['floor_plate'].convex_hull.difference(f['shell'].union(f['public']));extrude(g,-.40,.38,'soil',True);terrain.append({'id':'C-EXTERIOR-GROUND','geometry':g,'area_m2':g.area,'role':'ground between original independent pavilions and paths; not an added corridor or store','structural_roof_capacity_verified':False})
for f in D['floors']:
 if f['wing']!='C':continue
 for bed in f.get('landscape',[]):
  if f['level']==0:surf(bed['geom'].intersection(g),-.012,'leaf',True,False)
  elif f['level']==3:surf(bed['geom'].intersection(f['floor_plate']),f['height']+.012,'leaf',True,False)
write(P/'source/terrain-v7.json',{'layers':terrain,'is_public_floor_area':False,'finish_complete':False,'engineering_verified':False})
# Core interiors + real stair geometry. No stationary EV slab infill.
for d in D['devices']:
 render_group='CORE-'+d['id'];ispark=d['wing'].startswith(('P-','TW-'));room=d['rooms'];st=room['stair'];lift=room['lift'];cc=lift.centroid if not lift.is_empty else None
 for row in d['floors']:
  y=row['y'];h=2.3 if ispark else 3.3
  core=None
  if not ispark:core=next(c for f in D['floors']if f['wing']==d['wing']and f['level']==row['level']for c in f['cores']if c['id']==d['core'])
  if core:
   walls=core['room_wall_solids'];walls=walls.union(unary_union(core.get('cubicle_wall_solids',[])));outer=core['outline'].boundary.buffer(.12);portal=next(q for q in core['doors']if q['id']=='CORE');walls=walls.union(outer.difference(rect(core['entry'],portal['axis'],portal['w'],1.0)))
   for door in core['doors']:walls=walls.difference(rect(door['p'],door['axis'],door['w'],.8))
   for obj in core.get('fixtures',[]):
    g=obj.get('geom',obj.get('polygon'))
    if g is not None:extrude(g,y,.85,'ceramic_0',True)
   # C source defines cubicles separately from room-wall solids; materialize those authored partitions too.
   for ci,cub in enumerate(core.get('cubicles',[])):
    axis=core['u'];doorpoint=cub['door'];partition=cub['polygon'].boundary.buffer(.055,join_style=2).difference(rect(doorpoint,axis,cub['door_width_m'],.4));extrude(partition,y,2.1,'plaster',True)
    publicdoor(d['id']+'-'+row['label']+'-WC-'+str(ci),doorpoint,y,axis,cub['door_width_m'],'個室');doors[-1]['role_label']='トイレ';doors[-1]['height_m']=2.0
  else:
   walls=st.boundary.buffer(.10).union(lift.boundary.buffer(.10)if not lift.is_empty else Polygon());walls=walls.difference(rect(d['stair_door']['p'],d['stair_door']['axis'],d['stair_door']['w'],.7))
   if d.get('door'):walls=walls.difference(rect(d['door']['p'],d['door']['axis'],1.6,.7))
  extrude(walls,y,h,'plaster',True)
  if not ispark and row['level']<3:
   nextrow=next(q for q in d['floors']if q['level']==row['level']+1);tall=st.boundary.buffer(.10).union(lift.boundary.buffer(.10));extrude(tall,y+h,nextrow['y']-y-h,'plaster',True)
  # Each named landing is already part of its floor plate. Never duplicate coplanar collision faces.
  surf(row['sill'],y,'metal',True,True)
  ed=d['stair_door']
  if not d['wing'].startswith('TW-'):publicdoor(d['id']+'-'+row['label']+'-ST',ed['p'],y,ed['axis'],ed['w'],'階段 '+d['id'])
  qsign('階段・EV '+d['id']+' / '+row['label'],pos(d['entry'][0],y+2.3,d['entry'][1]),w=3)
 for flight in d['flights']:
  midy=flight['mid_y'];extrude(flight['mid'],midy-.18,.18,'stone',True)
  joins=unary_union([r['polygon'].buffer(.16,join_style=2)for r in flight['ramps']]);return_guard=flight['mid'].boundary.difference(joins)
  for ln in lines(return_guard):extrude(ln.buffer(.04),midy,1.05,'glass',True);extrude(ln.buffer(.045),midy+1.05,.04,'metal',False)
  for r in flight['ramps']:
   a=np.array(r['a']);b=np.array(r['b']);vec=b-a;normal=vec/np.linalg.norm(vec);lat=np.array([-normal[1],normal[0]]);run=np.linalg.norm(vec);n=r['risers'];rise=r['y1']-r['y0'];
   # Real visual tread/riser profile above a continuous collidable support, player controller uses same support rule as escalators.
   slope(a,b,r['y0'],r['y1'],r['width'],'step',True)
   for k in range(n):
    t=(k+.5)/n;foot=rect(a+vec*t,normal,run/n,r['width']);extrude(foot,r['y0']+rise*k/n-.06,.06,'metal',False)
   for sg in[-1,1]:
    aa=a+lat*sg*(r['width']/2+.015);bb=b+lat*sg*(r['width']/2+.015);quad('glass',[pos(aa[0],r['y0'],aa[1]),pos(bb[0],r['y1'],bb[1]),pos(bb[0],r['y1']+1.0,bb[1]),pos(aa[0],r['y0']+1.,aa[1])],(lat[0],0,lat[1]),solid=True)
# A/C escalators re-use the tested inclined support and animated tread class, retain all source locations.
es={e['id']:(e,f['wing'])for f in D['floors']if f['wing']in'AC'for e in f['escalators']}
for id,(e,w)in es.items():
 lo=HEIGHT[e['levels'][0]];hi=HEIGHT[e['levels'][1]];a=np.array(e['c'])-np.array(e['u'])*e['run_m']/2;b=np.array(e['c'])+np.array(e['u'])*e['run_m']/2;u=np.array(e['u']);lat=np.array([-u[1],u[0]]);render_group='ESC-'+id;slope(a,b,lo,hi,2.4,'step',True)
 for end,yy,sg in[(a,lo,-1),(b,hi,1)]:extrude(rect(end+u*sg*.75,u,1.5,2.4),yy-.2,.2,'step',True)
 for sg in[-1,1]:
  aa=a+lat*sg;bb=b+lat*sg;quad('glass',[pos(aa[0],lo+.12,aa[1]),pos(bb[0],hi+.12,bb[1]),pos(bb[0],hi+1.,bb[1]),pos(aa[0],lo+1.,aa[1])],(lat[0],0,lat[1]),solid=True)
 esc.append({'id':id,'levels':e['levels'],'direction':e['direction'],'wing':w,'c':pos(e['c'][0],lo,e['c'][1]),'u':list(u),'low_y':lo,'high_y':hi,'run_m':e['run_m'],'rise_m':hi-lo,'tread_width_m':1.32,'shaft_width_m':2.4,'test_start':pos(a[0]-u[0]*.8,lo,a[1]-u[1]*.8),'test_end':pos(b[0]+u[0]*.8,hi,b[1]+u[1]*.8)})
# Existing attached B parking and legacy A22, kept with their source IDs/categories.
for f in D['floors']:
 if not f.get('parking'):continue
 y=f['height'];pk=f['parking'];render_group='ATTACHED-'+f['label'];surf(pk['vehicle_aisles'],y+.012,'black',True,False);surf(pk['protected_pedestrian'],y+.016,'retail_terrazzo',True,False)
 for q in pk['stalls']:
  for ln in lines(q['polygon'].boundary):surf(ln.buffer(.025,cap_style=2),y+.02,'paper',True,False)
old=D['site']['old_A22'];render_group='P-A-OLD22';extrude(old['vehicle_aisles'].union(old['protected_pedestrian']).union(unary_union([s['polygon']for s in old['stalls']])),-.2,.2,'dark_stone',True)
for q in old['stalls']:
 for ln in lines(q['polygon'].boundary):surf(ln.buffer(.025,cap_style=2),.02,'paper',True,False)
for t in D['site']['pedestrian_towers']:
 render_group=t['id']
 for i,y in enumerate(t['levels']):
  deck=t['outline'].difference(t['lift_opening']).difference(t['stair_opening']if i else Polygon());extrude(deck,y-.25,.25,'stone',True)
  # Open bridge tower, glass outer guard; entrances remain aligned to adjoining named walks.
  connected=unary_union([q['polygon']for q in D['site']['walks']+D['site']['bridges']if abs(q['height']-y)<.05]);edge=t['outline'].boundary.difference(connected.buffer(.2));extrude(edge.buffer(.04),y,1.1,'glass',True)
# Parking decks, explicit access aisles, vehicle ramp profiles, real collars / rails.
for fac in D['parking']['facilities']:
 for f in fac['floors']:
  y=f['height'];render_group=fac['id']+'-'+f['label'];extrude(f['floor_plate'],y-.28,.28,'dark_stone',True);surf(f['vehicle_aisles'],y+.005,'black',True,False);surf(f['protected_pedestrian'],y+.01,'retail_terrazzo',True,False)
  for stl in f['stalls']:
   for ln in lines(stl['polygon'].boundary):surf(ln.buffer(.026,cap_style=2),y+.015,'paper',True,False)
  for key in ['edge_guard','ramp_side_barriers','ramp_terminal_barriers']:
   g=f.get(key,Polygon());g=unary_union(g)if isinstance(g,list)else g
   if hasattr(g,'is_empty')and not g.is_empty:extrude(g,y,1.1,'plaster',True)
  if fac['kind']=='garage':
   extrude(f.get('columns',Polygon()),y,2.35,'plaster',True)
   if f['level']<6:
    up=fac['floors'][f['level']+1];surf(up['floor_plate'],up['height']-.28,'plaster',False,False)
 for r in fac['ramps']:
  render_group='RAMP-'+r['id'];pts=r['profile_xyz'];
  for p,q in zip(pts,pts[1:]):slope((p[0],p[2]),(q[0],q[2]),p[1],q[1],r['width_m'],'black',True)
  # ramp side guards follow actual slope height, never a solid vertical barrier at the flat mouth.
  for p,q in zip(pts,pts[1:]):
   v=np.array([q[0]-p[0],q[2]-p[2]]);v=v/np.linalg.norm(v);lat=np.array([-v[1],v[0]])
   for sg in[-1,1]:
    a=np.array([p[0],p[2]])+lat*sg*(r['width_m']/2+.04);b=np.array([q[0],q[2]])+lat*sg*(r['width_m']/2+.04);quad('plaster',[pos(a[0],p[1],a[1]),pos(b[0],q[1],b[1]),pos(b[0],q[1]+.9,b[1]),pos(a[0],p[1]+.9,a[1])],(lat[0],0,lat[1]),solid=True)
# Explicit source exterior pedestrian and motor routes; no anonymous infill ground plane.
for q in D['site']['roads']:render_group='ROAD-'+q['id'];extrude(q['polygon'],-.18,.18,'black',True)
for q in D['site']['walks']:render_group='WALK-'+q['id'];extrude(slab(q['polygon'],q['height']),q['height']-.16,.18,'stone',True)
for q in [*D['site']['bridges'],D['site']['roof_car_bridge']]:
 render_group='BRIDGE-'+q['id'];y=q['height'];extrude(slab(q['polygon'],y),y-.30,.30,'dark_stone'if'car'in q.get('role','')else'stone',True)
 # omit guard at terminal so adjoining public floor is not sealed.
 ends=[Point(q['line'].coords[0]),Point(q['line'].coords[-1])]if q.get('line')is not None else[];edge=q['polygon'].boundary
 for p in ends:edge=edge.difference(p.buffer(q.get('width_m',4)+1))
 connected=[t['outline']for t in D['site']['pedestrian_towers']if any(abs(v-y)<.02 for v in t['levels'])]
 connected +=[f['floor_plate']for f in D['floors']if abs(f['height']-y)<.02]
 connected +=[f['floor_plate']for fac in D['parking']['facilities']for f in fac['floors']if abs(f['height']-y)<.02]
 edge=edge.difference(unary_union(connected).buffer(.1))
 extrude(edge.buffer(.045),y,1.1,'glass',True)
meta={'revision':'v7 whole site standalone','mesh_triangles':sum(len(v['v'])//9 for v in M.values()),'collision_triangles':sum(len(v)//9 for v in coll.values()),'shops_total':480,'new_interior_shops':282,'cores':len(D['devices']),'staff_doors':doors,'escalators':esc,'signs':signs,'structural_capacity_verified':False,'RF_SUPPORT_16':'UNAPPROVED','human_playtest':False,'summary':summary}
with gzip.open(P/'assets/site-v7.json.gz','wt',encoding='utf8',compresslevel=6)as f:json.dump({'surfaces':M,'colliders':coll,'signs':[],'lights':[]},f,separators=(',',':'),default=encode)
write(P/'source/site-manifest-v7.json',meta);write(P/'source/brands-v7.json',brands);print('SITE_MODEL',meta['mesh_triangles'],meta['collision_triangles'],len(doors),flush=True)
