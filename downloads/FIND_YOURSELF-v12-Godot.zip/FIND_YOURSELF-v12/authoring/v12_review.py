"""Native Viewport comparisons and scalable vector design sheets. Not a substitute renderer."""
from pathlib import Path
import sys,json,math,shutil,collections
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
import fitz
D=Path('/workspace/1/docs/visual-review-v12');D.mkdir(parents=True,exist_ok=True);OUT=Path('/workspace/1/downloads');F=read(P/'source/v11/floors-updated.json');C=read(P/'source/v12/C-outlet-proposal.json');R=read(P/'source/v12/retail-layouts.json');doc=fitz.open();W,H=1400,1000

def text(p,box,t,size=15,color=(.12,.18,.22)):
 result=p.insert_textbox(fitz.Rect(box),str(t),fontname='japan',fontsize=size,color=color)
 if result<0:raise RuntimeError('PDF text overflow '+str(t)[:100])
def page(title,sub=''):
 p=doc.new_page(width=W,height=H);p.draw_rect(p.rect,color=None,fill=(.97,.98,.98));text(p,(40,28,1360,80),title,28);text(p,(40,85,1360,132),sub,13);text(p,(40,969,1360,994),'FIND YOURSELF v12 / 2026-10-28 JST / 独立検証・ゲーム本体へ未統合 / '+str(len(doc)),11);return p

def image(p,path,rect):
 path=Path(path)
 if not path.exists():raise FileNotFoundError(path)
 p.insert_image(fitz.Rect(rect),filename=str(path),keep_proportion=True)

def draw(p,g,rect,bounds,fill=(.7,.78,.82),stroke=(.22,.32,.39),width=.5):
 x,z,xx,zz=bounds;sc=min((rect[2]-rect[0])/(xx-x),(rect[3]-rect[1])/(zz-z));ox=(rect[0]+rect[2])/2-(x+xx)/2*sc;oy=(rect[1]+rect[3])/2-(z+zz)/2*sc
 def pt(q):return fitz.Point(q[0]*sc+ox,q[1]*sc+oy)
 for poly in polys(g):
  for ring,ff in[(poly.exterior,fill)]+[(r,(.97,.98,.98))for r in poly.interiors]:
   sh=p.new_shape();sh.draw_polyline([pt(q)for q in ring.coords]);sh.finish(color=stroke,fill=ff,width=width,closePath=True);sh.commit()
 return pt,sc

def cf(p,f,new,rect):
 floor=new['proposed_floor']if new else f['floor_plate'];public=new['proposed_public']if new else f['public'];bounds=next(q for q in F if q['wing']=='C'and q['level']==0)['floor_plate'].bounds;pt,sc=draw(p,floor,rect,bounds,(.84,.87,.88));draw(p,public,rect,bounds,(.66,.85,.87))
 for s in f['stores']:
  draw(p,s['polygon'],rect,bounds,(.43,.63,.77));q=pt(s['polygon'].representative_point().coords[0]);text(p,(q.x-42,q.y-6,q.x+48,q.y+11),s['id'],7)
 for c in f['cores']:draw(p,c['outline'],rect,bounds,(.65,.57,.77))
 if new:
  for col in C['supports']:
   x,z=col['world_xz'];q=pt((x-429,z+46));p.draw_circle(q,1.4,color=(.65,.18,.12),fill=(.65,.18,.12))
  if f['level']in[1,2]:
   for con in C['gallery_connections']:
    points=[pt(q)for q in con['points']];p.draw_polyline(points,color=(.08,.48,.21),width=1.0)
 q=pt((bounds[0]+10,bounds[3]-8));p.draw_line(q,fitz.Point(q.x+20*sc,q.y),color=(.1,.1,.1),width=2);text(p,(q.x,q.y+5,q.x+110,q.y+28),'20 m',10)

p=page('v12｜修正・別案・未解決を分けて確認','提出対象：単体起動できるGodotプロジェクト、同一視点の実画面、図面・検査の記録。Windows EXEは作成しません。')
text(p,(50,155,1330,390),'修正：ES床端の見える安全柵・必要な床補完、既存柵に塞がれていた乗降口、店舗4区画の描画／衝突不一致。\n別案：C館の上階床を整理した支持・回廊案。B1〜RFを短く乗り継ぐ独立ESモジュール。各館へのES移設は未施工です。\n試行内装：アパレル、生活雑貨、美容、書店、家電、カフェの6店舗。全館への展開は未実施です。\n原本保護：v11と既存スキャンゲームは変更せず、独立したv12内で制作しています。RF-SUPPORT-16は未承認のままです。',20)
text(p,(50,420,1330,665),'Godot 4.6.3 Standardでproject.godotを開き、初回インポート後にF5。\nF4：原配置／C館構造別案を切替。F7：独立ES乗継ぎ検討。F8：代表6店舗へ移動。\nM：現在地付き館内マップ。F10：画面設定。初期1080p・144FPS上限・VSync ON。\n画像：実際のGodot Forward+ Viewport、1920×1080、4x MSAA。比較カメラの位置・向き・FOVは共通です。\n描画環境はLinux llvmpipeソフトウェアVulkanです。Windows GPUのFPS、人間の実操作、FF16級品質は確認していません。',18)
text(p,(50,715,1330,925),'参考写真から採用した構成：同じ吹抜け脇に連続する上下ES、乗降板の外までつながる客用床、開口端のガラス柵、閉じたトラス外装。\n写真はユーザー提供資料を目視参照しました。透かし入り写真をゲーム素材として使用・配布していません。\nこの資料の図面はゲーム用設計値です。実施設計・構造安全認定ではありません。',16)

p=page('ES｜落下と、乗降口を塞ぐ柵を別々に修正','斜面支持・プレイヤー処理・ベルト移動・視点補間のコードはv11と同一。移動を直すための位置補正や瞬間移動は追加していません。')
text(p,(45,145,1355,335),'原因1：傾いた機械側のガラスだけでは、上階の床開口の周囲や乗降板の横を守れませんでした。実際の床メッシュから床端を抽出し、腰壁・ガラス・笠木と同じ形の衝突を設けました。必要な低い側の余剰開口だけを補完しています。\n原因2：複数の生成層にある既存の水平ガラス柵が、乗降板の外端を横切っていました。従来の短い検査は乗降板の内側から始まるため見逃していました。各層で共通の乗降口を使い、三角形を正確に切り分けて開口しました。\n再発防止：実機ごとの外端ポータル80か所と、乗降板全体の通行包絡を共有。壁や柵の三角形全体を雑に消さず、描画と衝突へ同じ切断を適用します。',16)
e=next(r for r in read(P/'source/v12/es-openings.json')if r['id']=='E1-12-UP');bounds=e['upper_floor_before'].bounds
for rect,geom,lab in[((55,410,650,830),e['upper_floor_before'],'床端・修正前'),((750,410,1345,830),e['upper_floor_after'],'床端・修正後')]:
 text(p,(rect[0],365,rect[2],400),lab,18);draw(p,geom,rect,bounds,(.78,.83,.86))
 if '後'in lab:
  for r in e['guards']: 
   if abs(r['y']-e['floor_y'])<.1:draw(p,r['geometry'],rect,bounds,(.11,.56,.35))
text(p,(55,857,1340,940),'緑：追加柵の床占有。灰：実床。開口・斜面は別物として扱います。柵高1.15m、追加床下の有効高さ設計2.30m。\nB館B1/RFの12計画設備は利用可能表示を撤回。既存柵を保ち、不足する未施工開口の床端を可視の安全柵で補いました。',15)

p=page('ES乗継ぎ｜既存の距離と、独立モジュール案','旧配置の図面内経路推定と、新しい独立案の設計中心線は別の数値です。各館の移設後の実歩行距離として報告していません。')
rows=read(P/'source/v12/es-transfer-distances.json');text(p,(45,150,650,187),'旧：同じ館の次の上りESまで',18)
y=200
for r in rows:
 dist='経路未成立'if r['plan_path_m']is None else f"図面 {r['plan_path_m']:.1f}m"
 text(p,(50,y,680,y+32),f"{r['wing']}  {r['from']} → {r['to']}   {dist} / 直線 {r['straight_line_m']:.1f}m",11);y+=34
study=read(P/'source/v12/es-transfer-study.json');f=study['floors'][2];rect=(760,190,1340,720);bounds=(-12,-11,12,11);draw(p,f['floor'],rect,bounds,(.83,.87,.88))
for b in study['escalators']:
 if b['levels'][0]not in[0,1]:continue
 cc=[b['c'][0],b['c'][2]]
 from shapely.geometry import Polygon as PG
 u=b['u'];n=(-u[1],u[0]);po=PG([(cc[0]+a*u[0]+v*n[0],cc[1]+a*u[1]+v*n[1])for a,v in[(-7.4,-.94),(7.4,-.94),(7.4,.94),(-7.4,.94)]])
 pt,sc=draw(p,po,rect,bounds,(.29,.59,.40)if b['direction']=='UP'else(.82,.57,.26));q=pt(cc);text(p,(q.x-35,q.y-8,q.x+50,q.y+14),b['direction'],10)
# On this 2F plan both landing banks connect around the atrium end, not through an unassigned strip.
r=study['transfers'][1];pt,sc=draw(p,Polygon(),rect,bounds)
p.draw_polyline([pt((q[0],q[2]))for q in r['points']],color=(.75,.12,.16),width=2)
text(p,(745,750,1345,924),'独立案：24×22m、上下各1基×4組、B1〜RFの5層。\n中間階は上り・下りとも乗継ぎ設計8.4m。\n1.8mカプセルのW入力で昇降・乗継ぎ14経路を確認。\n各館の店舗・吹抜け・柱・避難との現地整合は未承認です。\nB館B1/RFとC館B1/RFの連続ESは本敷地へ未設置です。',15)

ground=next(f for f in F if f['wing']=='C'and f['level']==0)
plan_rows=[{'floor':'1F','level':0,'before_floor_m2':ground['floor_plate'].area,'proposed_floor_m2':ground['floor_plate'].area,'removed_m2':0.,'retail_area_lost_m2':0.,'proposed_floor':ground['floor_plate'],'proposed_public':ground['public']}]+C['floors']
for row in plan_rows:
 f=next(f for f in F if f['wing']=='C'and f['level']==row['level']);p=page('C館 '+f['label']+'｜原配置と未承認の構造別案','青：店舗、紫：昇降設備、淡青：共用床、緑線：隣接棟をつなぐ上階回廊、赤点：支持柱の検討位置。実在施設寸法ではありません。')
 text(p,(55,145,640,182),'v11 原配置',21);text(p,(745,145,1345,182),'v12 別案・未承認',21);cf(p,f,None,(50,200,650,820));cf(p,f,row,(750,200,1350,820));
 if row['level']in[1,2]:
  finish=next(q for q in read(P/'source/v12/C-supported-finish.json')if q['floor']==row['floor']);text(p,(55,820,1340,848),f"別層に残っていた浮遊舗装 {finish['floating_finish_removed_m2']:,.1f} m2を支持床へ切断。材質とUVを維持。",12)
 text(p,(55,850,1340,945),f"構造床：{row['before_floor_m2']:,.1f} → {row['proposed_floor_m2']:,.1f} m2、削減 {row['removed_m2']:,.1f} m2。店舗区画の面積損失 {row['retail_area_lost_m2']:.4f} m2（丸め差）。\n店舗・階段・EV・既存ES・館間接続を維持。不要な中央横断床を整理。柱の視覚的支持は設けましたが耐力・基礎・接合部は未検証です。",15)

p=page('代表店舗｜用途別の売場と通路','配置は入口展示、壁面、中央売場、レジを分けています。部屋を同じ棚で埋める方法から変えた試行施工で、全館完成ではありません。')
for idx,r in enumerate(R):
 f,s=next((f,s)for f in F for s in f['stores']if s['id']==r['id']);col=idx%3;row=idx//3;box0=(45+col*450,190+row*350,445+col*450,465+row*350);bounds=s['polygon'].buffer(1).bounds;draw(p,s['polygon'],box0,bounds,(.83,.86,.87));draw(p,s['sales'],box0,bounds,(.89,.91,.83));draw(p,s['backroom'],box0,bounds,(.61,.64,.68))
 for ob in r['fixtures']:draw(p,ob['footprint'],box0,bounds,(.34,.55,.71),width=.4)
 main=LineString(s.get('main_route',[s['entry'],s['entry']]));draw(p,main.buffer(1.05).intersection(s['sales']),box0,bounds,(.82,.59,.46),width=.3)
 text(p,(box0[0],box0[1]-43,box0[2],box0[1]-3),r['id']+' / '+r['industry'],14);text(p,(box0[0],box0[3]+8,box0[2],box0[3]+65),f"売場 {r['sales_m2']:.1f} m2 / 什器占有 {r['fixture_footprint_m2']:.1f} m2\nレジ {'配置済'if r['checkout_placed']else'未配置'} / 主通路設計2.1m",11)

# Native image comparisons. PNGs are embedded at their original pixel resolution; originals accompany this PDF.
shots=read(P/'source/v12/cameras.json')
for shot in shots:
 sid=shot['id'];before=P/'evidence/v12/before'/f'{sid}.png'
 if sid.startswith('01-ES'):after=P/'evidence/v12/ES-release-viewport'/f'{sid}.png'
 elif sid.startswith(('02-C','03-C')):after=P/'evidence/v12/C-release-viewports'/f'{sid}.png'
 elif 'shop-book'in sid:after=P/'evidence/v12/book-final-viewport'/f'{sid}.png'
 elif 'shop-cafe'in sid:after=P/'evidence/v12/cafe-final-viewport'/f'{sid}.png'
 elif 'shop-apparel'in sid:after=P/'evidence/v12/after-final-retail'/f'{sid}.png'
 else:after=P/'evidence/v12/after'/f'{sid}.png'
 p=page(sid+'｜同一視点のGodot実画面','左：保護したv11。右：v12（C館の構造変更は未承認別案）。画像補完やBlender代替レンダリングではありません。')
 text(p,(45,150,675,183),'v11',20);text(p,(725,150,1355,183),'v12 別案・未承認'if sid.startswith(('02-C','03-C'))else'v12',20);image(p,before,(40,210,685,575));image(p,after,(715,210,1360,575))
 note='店舗の内装と陳列を試行改修。売場の主通路は確保しましたが、商品造形・照明・接合詳細はFF16級に達していません。'
 if sid.startswith('01-ES'):note='既存柵の乗降口を切り直し、開口の側面を見える柵で保護。斜面・移動・カメラの処理はv11と同一です。'
 if sid.startswith(('02-C','03-C')):note='中庭・既存の店舗・3階への移動を維持し、余剰床を整理した別案。支持柱の配置は検討用で、構造安全の承認ではありません。'
 if 'shop-book'in sid:note='壁面の分類棚、両面陳列の中央書架、新刊台、レジを分離しました。天井端の取り合いと一部の照明均一性は残課題です。'
 text(p,(55,625,1345,730),note,18);text(p,(55,770,1345,910),'カメラ眼点 '+str(shot['eye'])+'\n注視点 '+str(shot['look'])+f" / FOV {shot['fov']}°\n1920×1080 / Forward+ / 4x MSAA / llvmpipe / 静止画像は描画FPSの実測ではありません。",14)

p=page('ES乗継ぎ別案｜実際のGodot Viewport','8.4mは独立モジュールの設計値。これを各館へ移設済みと解釈しないでください。')
image(p,P/'evidence/v12/transfer-final2-viewports/ES-study-1F.png',(40,160,685,525));image(p,P/'evidence/v12/transfer-final2-viewports/ES-study-transfer-2F.png',(715,160,1360,525));text(p,(55,585,940,930),'同じ吹抜け脇の2列に上下ESをまとめ、各階で折り返す構成です。離れた広場へ歩く乗継ぎはありません。\n共用通路から乗降板へ入り、反対側の共用通路へ出る14経路と、床端16方向の押し歩きを確認しています。\n店舗への接続、地下区画の分離、屋上への接続、構造・避難の検討は各館への配置設計で行う必要があります。\nこのモジュールは商業施設の完成内装を示すものではありません。F7で起動、F4で全館検証へ戻ります。',17)
# A developed section: adjacent-storey flights occupy different depth bands.
sc=11.5;ox=1150;oy=900
def section(x,y):return fitz.Point(ox+x*sc,oy-y*sc)
for f in study['floors']:
 y=f['height'];p.draw_line(section(-12,y),section(-7.4,y),color=(.2,.3,.35),width=4);p.draw_line(section(7.4,y),section(12,y),color=(.2,.3,.35),width=4);q=section(-12,y);text(p,(q.x-65,q.y-6,q.x-3,q.y+15),f['label'],9)
for b in study['escalators']:
 if b['direction']!='UP':continue
 u=b['u'][0];p.draw_line(section(-u*5.9,b['low_y']),section(u*5.9,b['high_y']),color=(.15,.4,.3),width=5)
p.draw_line(section(-11,21.16),section(11,21.16),color=(.30,.52,.65),width=2);text(p,(960,930,1360,960),'展開断面：上下階は別帯（奥行6.4m）',11)

p=page('検証結果と残課題｜合格の範囲を限定','幾何検査、実コントローラーの自動入力、ルート追従、人間の操作は別の検証です。人間による実操作は今回実施していません。')
text(p,(45,150,1355,460),'ES：修正前の側面押し歩きは322ケース中200件で落下を再現。修正後は同じケースを再検査。別に、乗降板の外から通り抜ける40経路を追加しました。\n店舗：480区画を点検。通常売場など458店舗の床上1.15m境界で、描画・衝突を照合。4店舗8測点の衝突不足を復元し、Godotの82,491測点でも照合しました。\n限界：0.5m間隔の境界検査は、全ての天井接合・細かな傷や建築美観の合格を意味しません。屋上22区画は屋外売場／未施工の区別を確定せず、通常店舗の境界合格から除外しています。\n残余帯：48領域を台帳化（保護動線2、狭隙候補10、C館の床役割確認36）。検出候補は全てが不具合と確定したものではありません。用途を未確認のまま倉庫などと命名して埋めていません。',17)
text(p,(45,500,1355,790),'未解決：外壁際の残余帯の用途・必要幅、店舗の天井取り合い、一部の照明と商品の高精細化、アパレルの試着室・飲食の厨房詳細、全館への内装展開。\n承認待ち：C館の上階構造案、ESの各館への移設・地下／屋上の追加、RF-SUPPORT-16。柱・梁は視覚的支持の検討で、耐力・基礎・耐震や避難性能は実証していません。\n性能：Windows GPU実測なし。144FPS達成とは報告しません。ソフトウェアVulkanで実画像を撮影しました。\n使用素材：既存CC0／CC-BYの素材と、専用Blenderモデル8種。出典・改変・商用利用条件はGodot ZIPのlicensesに収録。実在店ロゴやFF16の素材は使用していません。',17)
text(p,(45,830,1355,938),'検査の最新数値と実施条件は同梱のRESULTS.md・JSONをご覧ください。画像保存後の終了時に、ソフトウェアVulkan側のTexture RID解放警告が残る場合があります。画像取得・起動は確認していますが、Windowsでの再現性は未検証です。',14)
path=OUT/'FIND_YOURSELF-v12-Review.pdf';doc.save(path,garbage=4,deflate=True);doc.close();print('REVIEW_PDF',path.stat().st_size,'bytes',flush=True)
