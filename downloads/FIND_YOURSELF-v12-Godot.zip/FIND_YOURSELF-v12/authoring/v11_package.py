"""Single self-contained Godot archive. Prune caches, unused models and historical duplicate data, never active resources."""
from pathlib import Path
import zipfile,json,struct,hashlib,shutil,sys
P=Path(__file__).resolve().parents[1];D=P.parent/'downloads';D.mkdir(exist_ok=True)
large_old={'master-site-v3.json','parking-source-v3.json','design-v6.json','annex-v6.json','site-v7.json','design-v7.json'}
old_meta={'package-verification.json','unified-package-verification.json','export_presets.cfg','release-manifest-v11.json'}
art=json.loads((P/'source/v11/scene-art.json').read_text());models={str((P/'assets/v10'/(r['asset']+'.glb')).resolve().relative_to(P))for r in art['instances']}
files=[]
for f in sorted(P.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(P);r=str(rel)
 if any(part in ['.godot','evidence','__pycache__','.git']for part in rel.parts):continue
 if f.suffix in ['.uid','.translation','.pyc']:continue
 if f.suffix=='.import'and not f.name.endswith('.csv.import'):continue
 if len(rel.parts)==1 and f.name in old_meta:continue
 if rel.parts[0]=='source'and len(rel.parts)==2 and f.name in large_old:continue
 if r in ['source/v11/floors-baseline.json','source/v11/floors-updated.json']:continue
 if r.startswith('assets/v10/models/')or r.startswith('assets/v10/retail/')or r.startswith('assets/v11/models/'):
  if f.suffix=='.glb'and r not in models:continue
 if f.suffix in ['.exe','.pck','.7z','.cmd','.bat']:continue
 files.append((f,r))
manifest={'version':'v11 independent validation','single_archive':True,'main_game_integrated':False,'files':[{'path':r,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f,r in files]}
(P/'release-manifest-v11.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));files=[(f,r)for f,r in files if r!='release-manifest-v11.json'];files.append((P/'release-manifest-v11.json','release-manifest-v11.json'))
path=D/('FIND_YOURSELF-v11-Godot-TRIAL.zip'if'--trial'in sys.argv else'FIND_YOURSELF-v11-Godot.zip')
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f,r in files:z.write(f,'FIND_YOURSELF-v11/'+r)
print('PACKAGE',path.stat().st_size,'bytes',len(files),'files',len(models),'model types','limit 104857600')
assert path.stat().st_size<104857600,'Single artifact exceeds host limit; do not split or remove active assets.'
