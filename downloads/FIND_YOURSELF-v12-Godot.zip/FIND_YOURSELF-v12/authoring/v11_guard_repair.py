"""Restore missing B roof internal opening guards, not a new slab or structural approval."""
from pathlib import Path
import sys,math,numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import constrained_delaunay_triangles
rows=read(P/'source/v11/RF-guard-missing.json');f=next(f for f in read(P/'source/v11/floors-updated.json')if f['wing']=='B'and f['level']==3)
g=load_pack(P/'assets/v11/repairs.pack.zst');M={};coll={};render_group='V11-GUARD-RF-B-INTERNAL'
def pos(x,y,z):return[float(x+429),float(y),float(z-46)]
exec((P/'authoring/mesh_primitives.py').read_text())
# Preserve actual stair/ES/EV and bridge approaches. Restore only missing pieces along existing structural floor boundaries.
paths=read(P/'source/physical-routes-v11.json');protected=[]
for r in paths:
 pts=r['points']
 if any(abs(q[1]-16.4)<.1 for q in pts):
  protected.append(LineString([(p[0]-429,p[2]+46)for p in pts]).buffer(.65,cap_style=2))
# Landing apertures are protected by the real shaft doors, not a fixed guard across the EV doorway.
for ev in read(P/'source/elevators-v7.json'):
 if not any(abs(stop['y']-16.4)<.1 for stop in ev['stops']):continue
 n=np.array(ev['inside']);door=np.array([ev['door_xz'][0]-429,ev['door_xz'][2]+46]);centre=np.array([ev['center'][0]-429,ev['center'][2]+46]);protected.append(LineString([centre,door-n*1.5]).buffer(float(ev['door_width'])/2+.20,cap_style=2,join_style=2))
keep=unary_union(protected);candidate=unary_union([r['geometry']for r in rows if r['wing']=='B']);fixed=candidate.intersection(f['floor_plate'].boundary.buffer(.18,join_style=2)).difference(keep)
extrude(fixed,16.4,1.15,'v10_guard_glass',True)
for k in list(g['surfaces']):
 if k.endswith('@@'+render_group):del g['surfaces'][k]
g['surfaces'].update({k:{a:np.array(b,dtype=np.float32)for a,b in d.items()}for k,d in M.items()});g['colliders']['v10_guard_glass']=np.array(coll.get('v10_guard_glass',[]),dtype=np.float32)
r=save_zst(P/'assets/v11/repairs.pack.zst',g);write(P/'source/v11/roof-guard-repair.json',{'reason':'Roof guard generation used polygon exteriors and did not consistently guard internal openings; restore source guard footprint along actual floor boundary, preserving declared equipment/bridge access.','wing':'B','floor':'RF','geometry':fixed,'guard_footprint_m2':fixed.area,'height_m':1.15,'candidate_footprint_m2':candidate.area,'RF_SUPPORT_16':'UNAPPROVED; guard repair does not establish structural capacity','pack':r});print('RF_GUARD_REPAIR',fixed.area)
