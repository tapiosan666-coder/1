from pathlib import Path
import sys,copy,math
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
P=Path(__file__).resolve().parents[1];D=read(P/'source/design-v6.json');S=read(P/'source/master-site-v3.json');ann=read(P/'source/annex-v6.json');parks=read(P/'source/parking-source-v3.json');floors=[];devices=[];changes=[]
for f0 in S['floors']:
 w=f0['wing'];lev=f0['level'];f=copy.deepcopy(f0)
 if w=='B':
  if lev in [0,1,2]:
   f=copy.deepcopy(D['floors'][lev]);f['wing']='B';f['vertical_devices']=f0['vertical_devices'];f['core_free']=f0['core_free'];f['nav_free']=f['public'].union(f['core_free']);f['envelope_walls']=f0['envelope_walls'];f['doors_v3']=f0.get('doors_v3',[])
  elif lev==-1:f=copy.deepcopy(ann['basement'])
  else:f=copy.deepcopy(ann['roof'])
 f['wing']=w;f['level']=lev
 # Slab openings are sourced from the same vertical-device definitions as stairs/lifts.
 for v in f.get('vertical_devices',[]):
  old=f['floor_plate'];f['floor_plate']=old.difference(v['lift_opening']).difference(v['stair_opening']);changes.append({'kind':'align_actual_slab_to_v3_device','wing':w,'floor':f['label'],'core':v['core'],'removed_m2':old.difference(f['floor_plate']).area})
 floors.append(f)
# Actual A bridge vestibules follow the already-fixed B bridge, without consuming any shop.
for c in ann['connections']:
 if c['target']!='A':continue
 f=next(f for f in floors if f['wing']=='A'and f['level']==c['level']);patch=c['polygon'].intersection(f['floor_plate']);gain=patch.difference(f['public']);f['public']=f['public'].union(patch);f['core_free']=f['core_free'].union(patch);changes.append({'kind':'A_bridge_vestibule_floor_role','id':c['id'],'area_m2':gain.area,'store_area_removed_m2':sum(gain.intersection(st['polygon']).area for st in f['stores'])})
# Re-align old customer opening to the actual retained v6 facade, not to a stale v3 wall.
for f in floors:
 if f['wing']!='B' or f['level']!=0:continue
 env=f.get('building_envelope_v5',f['shell'])
 for door in f.get('doors_v3',[]):
  old=list(door['center']);n=door['normal'];line=LineString([(old[0]-n[0]*8,old[1]-n[1]*8),(old[0]+n[0]*8,old[1]+n[1]*8)]);cut=line.intersection(env.boundary);points=[]
  if cut.geom_type=='Point':points=[cut]
  elif cut.geom_type=='MultiPoint':points=list(cut.geoms)
  if points:
   center=min(points,key=lambda q:q.distance(Point(old)));door['center']=[center.x,center.y];door['aperture']=rect(door['center'],door['u'],door['frame_opening_width_m'],1.0);changes.append({'kind':'customer_door_to_actual_v6_facade','id':door['id'],'before_center':old,'new_center':door['center'],'shift_m':math.dist(old,door['center'])})
# one operational core record spans the real five storeys; C uses existing room geometry.
for w in 'ABC':
 ff=sorted([f for f in floors if f['wing']==w],key=lambda f:f['level'])
 for ci,c in enumerate(ff[1]['cores']):
  cd={'id':w+'-'+c['id'],'wing':w,'core':c['id'],'outline':c['outline'],'rooms':c['rooms'],'door':next(q for q in c['doors']if q['id']=='EV'),'stair_door':next(q for q in c['doors']if q['id']=='ST'),'entry':c['entry'],'floors':[],'flights':[]}
  for f in ff:
   room=c['rooms']['lift'];opening=room.buffer(-.10,join_style=2);cc=room.centroid;door=cd['door'];u=door['axis'];delta=[cc.x-door['p'][0],cc.y-door['p'][1]];ln=math.hypot(*delta);inside=[q/ln for q in delta];cabin=opening.buffer(-.10,join_style=2)
   if w in 'AB':
    v=next(q for q in f['vertical_devices']if q['core']==c['id']);cabin=v['cabin_floor_when_docked'];fl=[v['lower_flight_projection'],v['upper_flight_projection']];front=v['front_landing'];mid=v['mid_landing'];staircut=v['stair_opening']
   else:
    # Actual C shaft and landing preserved; two 2m lanes fit inside the existing long stair room.
    st=c['rooms']['stair'];ed=cd['stair_door'];sc=st.centroid;ax=[sc.x-ed['p'][0],sc.y-ed['p'][1]];al=math.hypot(*ax);ax=[q/al for q in ax];side=ed['axis'];start=[ed['p'][i]+ax[i]*3 for i in range(2)];fl=[]
    for sg in [-1,1]:fl.append(rect([start[i]+ax[i]*2.25+side[i]*sg*1.15 for i in range(2)],ax,4.5,2.0))
    front=rect([ed['p'][i]+ax[i]*1.6 for i in range(2)],ax,2.8,5.3).intersection(st.buffer(-.15));mid=rect([start[i]+ax[i]*8.4/1.0 for i in range(2)],ax,1.8,5.3)
    # mid begins at distance7.5 from door; front flight ends at7.5, use a slight physical overlap.
    mid=rect([start[i]+ax[i]*5.35 for i in range(2)],ax,1.8,5.3).intersection(st.buffer(-.15));staircut=unary_union(fl).buffer(.06,join_style=2)
    old=f['floor_plate'];oldshaft=c['shafts'];newshaft=opening.union(staircut if f['level']>-1 else Polygon());f['floor_plate']=old.union(oldshaft.intersection(c['outline'])).difference(newshaft);f['shafts']=f['shafts'].difference(oldshaft).union(newshaft);f['void']=f['void'].difference(oldshaft).union(newshaft);changes.append({'kind':'C_stair_opening_matches_actual_two_flights','floor':f['label'],'core':c['id'],'closed_unused_opening_m2':f['floor_plate'].difference(old).area,'new_opening_m2':newshaft.area,'original_source_modified':False})
    # Existing long opening needs an actual front landing slab; this is named equipment access, not a new room.
    f['floor_plate']=f['floor_plate'].union(front)
   row={'label':f['label'],'level':f['level'],'y':f['height'],'cabin':cabin,'opening':opening,'front':front,'mid':mid,'flights':fl,'sill':rect(door['p'],u,door['w'],.45),'public_entry':c['entry']};cd['floors'].append(row)
  for a,b in zip(cd['floors'],cd['floors'][1:]):
   front=a['front'];mid=a['mid'];pts=[]
   for j,fp in enumerate(a['flights']):
    # rectangle long axis from the front to return landing; evaluate its minimum rectangle edge midpoints
    co=list(fp.minimum_rotated_rectangle.exterior.coords)[:4];edges=[((co[k][0]+co[(k+1)%4][0])/2,(co[k][1]+co[(k+1)%4][1])/2)for k in range(4)];pairs=[(edges[0],edges[2]),(edges[1],edges[3])];p0,p1=max(pairs,key=lambda ab:math.dist(*ab));
    if Point(p0).distance(front)>Point(p1).distance(front):p0,p1=p1,p0
    if j==1:p0,p1=p1,p0
    y0=a['y'] if j==0 else(a['y']+b['y'])/2;y1=(a['y']+b['y'])/2 if j==0 else b['y'];pts.append({'polygon':fp,'a':p0,'b':p1,'y0':y0,'y1':y1,'width':2.,'risers':16})
   cd['flights'].append({'from':a['level'],'to':b['level'],'lower_y':a['y'],'upper_y':b['y'],'mid':mid,'mid_y':(a['y']+b['y'])/2,'ramps':pts})
  devices.append(cd)
# Parking cores: retained rooms, actual two flights each half-storey.
for fac in parks['facilities']:
 if fac['kind']!='garage':continue
 ff=fac['floors']
 for c in ff[0]['cores']:
  st=c['stair'];x0,z0,x1,z1=st.bounds;front=box(x1-1.5,z0,x1,z1);mid=box(x0,z0,x0+1.5,z1);run=(x1-x0)-3;fl=[box(x0+1.5,z0+.15,x1-1.5,z0+2.15),box(x0+1.5,z1-2.15,x1-1.5,z1-.15)];door=c['elevator_entry'];cd={'id':c['id'],'wing':fac['id'],'core':c['id'],'outline':c['outline'],'rooms':{'stair':st,'lift':c['elevator']},'entry':c['entry'],'stair_door':{'p':c['stair_entry'],'w':1.8,'axis':[0,1]},'floors':[],'flights':[]}
  if door:cd['door']={'p':door,'w':1.6,'axis':[1,0]}
  for f in ff:
   open0=c['elevator'].buffer(-.15,join_style=2)if door else Polygon();cab=open0.buffer(-.08,join_style=2);f['floor_plate']=f['floor_plate'].difference(unary_union(fl).buffer(.03)if f['level']>0 else Polygon()).union(front);row={'label':f['label'],'level':f['level'],'y':f['height'],'cabin':cab,'opening':open0,'front':front,'mid':mid,'flights':fl,'public_entry':c['entry'],'sill':rect(door,(1,0),1.6,.45)if door else Polygon()};cd['floors'].append(row)
  for a,b in zip(cd['floors'],cd['floors'][1:]):
   r=[]
   for j,fp in enumerate(fl):
    z=fp.centroid.y;p0=(x1-1.5,z)if j==0 else(x0+1.5,z);p1=(x0+1.5,z)if j==0 else(x1-1.5,z);r.append({'polygon':fp,'a':p0,'b':p1,'y0':a['y']if j==0 else(a['y']+b['y'])/2,'y1':(a['y']+b['y'])/2 if j==0 else b['y'],'width':2.,'risers':8})
   cd['flights'].append({'from':a['level'],'to':b['level'],'lower_y':a['y'],'upper_y':b['y'],'mid':mid,'mid_y':(a['y']+b['y'])/2,'ramps':r})
  devices.append(cd)
# Site bridge access towers: actual two-storey cores are also in the same device registry.
for t in S['site']['pedestrian_towers']:
 doorline=t['lift_door'];dp=doorline.interpolate(.5,normalized=True);aa,bb=doorline.coords[0],doorline.coords[-1];u=[(bb[0]-aa[0])/doorline.length,(bb[1]-aa[1])/doorline.length];st=t['stair'];fl=t['stair_flights'];front=t['landing'];mid=t['return_landing'];x0,z0,x1,z1=st.bounds;ed=Point((x0+x1)/2,z1)
 cd={'id':t['id'],'wing':t['id'],'core':t['id'],'outline':t['outline'],'rooms':{'stair':st,'lift':t['lift']},'entry':list(t['landing'].representative_point().coords)[0],'stair_door':{'p':[ed.x,ed.y],'w':4.6,'axis':u},'door':{'p':[dp.x,dp.y],'w':1.0,'axis':u},'floors':[],'flights':[]}
 # The shared landing includes the return underflight; it is a bridge interface, not an invented public corridor.
 for i,y in enumerate(t['levels']):cd['floors'].append({'label':'地上'if i==0 else'橋階','level':i,'y':y,'cabin':t['lift_opening'].buffer(-.08,join_style=2),'opening':t['lift_opening'],'front':front,'mid':mid,'flights':fl,'sill':rect((dp.x,dp.y),u,1.0,.4),'public_entry':cd['entry']})
 ramps=[]
 for j,fp in enumerate(fl):
  co=list(fp.minimum_rotated_rectangle.exterior.coords)[:4];e=[((co[k][0]+co[(k+1)%4][0])/2,(co[k][1]+co[(k+1)%4][1])/2)for k in range(4)];p0,p1=max([(e[0],e[2]),(e[1],e[3])],key=lambda ab:math.dist(*ab))
  if Point(p0).distance(mid)<Point(p1).distance(mid):p0,p1=p1,p0
  if j==1:p0,p1=p1,p0
  ramps.append({'polygon':fp,'a':p0,'b':p1,'y0':0 if j==0 else 2.7625,'y1':2.7625 if j==0 else 5.525,'width':2.,'risers':17})
 cd['flights'].append({'from':0,'to':1,'lower_y':0.,'upper_y':5.525,'mid':mid,'mid_y':2.7625,'ramps':ramps});devices.append(cd)
write(P/'source/site-v7.json',{'schema_notes':'v7 canonical floor=floors[].floor_plate; vertical devices=root devices; source-v3 nav_free, cores[].shafts, vertical_shafts and per-floor vertical_devices may be retained comparison references, not runtime geometry. Do not integrate legacy fields without migration.','revision':'v7 independent whole-site structural validation','floors':floors,'site':S['site'],'parking':parks,'devices':devices,'changes':changes,'RF_SUPPORT_16':{'status':'UNAPPROVED','capacity_verified':False,'reason':'No qualified structural calculation; not safe to claim from mesh or walk test'},'main_game_modified':False})
# B renderer uses identical retained retail records, only the source-defined device holes/ceilings change.
for i in range(3):D['floors'][i]=next(f for f in floors if f['wing']=='B'and f['level']==i)
write(P/'source/design-v7.json',D)
print('SITE_PREPARED',len(floors),len(devices),sum(len(f['stores'])for f in floors))
