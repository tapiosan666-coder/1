from pathlib import Path
import sys,json,math
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
P=Path(__file__).resolve().parents[1];D=read(P/'source/site-v7.json');geo=read(P/'evidence/geometry-v7.json');rows=[];stores=[]
for fac in D['parking']['facilities']:
 for f in fac['floors']:
  for s in f['stalls']:rows.append([s['id'],fac['id'],f['label'],f['height'],s.get('kind',s.get('category',s.get('type','standard'))),s['polygon'].area,*s['polygon'].centroid.coords[0]])
for f in D['floors']:
 for s in f.get('parking',{}).get('stalls',[]):rows.append([s['id'],f['wing']+'-'+f['label'],f['label'],f['height'],s.get('kind',s.get('category','standard')),s['polygon'].area,*s['polygon'].centroid.coords[0]])
for s in D['site']['old_A22']['stalls']:rows.append([s['id'],'P-A-OLD22','1F',0,s.get('kind',s.get('category','standard')),s['polygon'].area,*s['polygon'].centroid.coords[0]])
csvwrite(P/'deliverables/parking-6699-ledger-v7.csv',['ID','facility','floor','Y','source_use','area_m2','worldX','worldZ'],rows)
dev=[]
for d in D['devices']:
 for r in d['floors']:dev.append([d['id'],d['wing'],r['label'],r['y'],d['entry'][0],d['entry'][1],r['opening'].area,r['front'].area,2.,bool(d.get('door')),'implemented; engineering and human operation not approved'])
csvwrite(P/'deliverables/vertical-devices-v7.csv',['ID','wing','floor','Y','entryX','entryZ','EV_opening_m2','stair_front_landing_m2','stair_width_m','has_operating_lift','status'],dev)
res=[]
for r in geo['unresolved_programme_records']:
 for i,g in enumerate(polys(r['remaining_polygon']),1):
  if g.area<.01:continue
  res.append([r['wing'],r['floor'],i,g.area,*g.bounds,g.buffer(-.5).area,'thin construction/joint candidate - finish not verified'if g.buffer(-.5).area<.01 else'local purpose/joint review pending - do not mark complete'])
csvwrite(P/'deliverables/construction-joint-review-v7.csv',['wing','floor','component','area_m2','minX','minZ','maxX','maxZ','inner_after_0_5m_m2','status'],res)
brands=read(P/'source/brands-v7.json');csvwrite(P/'deliverables/brand-slots-480-v7.csv',['store_id','wing','floor','category','provisional_original_name','max_sign_width_m','logo_completed','trademark_cleared'],[[b['store_id'],b['wing'],b['floor'],b['category'],b['name'],b['max_width_m'],False,False]for b in brands])
print('LEDGERS',len(rows),'parking',len(brands),'brands',len(res),'joint review components')
