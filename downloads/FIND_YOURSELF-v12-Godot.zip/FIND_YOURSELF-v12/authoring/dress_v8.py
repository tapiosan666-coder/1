"""Original, deterministic retail fit-out for three review zones. No source footprint changes.
World-space geometry and fixture collisions, backed by source sales/aisle polygons.
"""
from pathlib import Path
import sys,json,math,gzip,random,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
sys.path.insert(0,str(Path(__file__).parent))
from site_v2_common import *
from shapely import constrained_delaunay_triangles
P=Path(__file__).resolve().parents[1];A=P/'assets/v8';A.mkdir(exist_ok=True)
D=read(P/'source/site-v7.json');B=read(P/'source/design-v7.json');canonical={q['id']:q for f in B['floors']for q in f['stores']}
for floor in D['floors']:
 if floor['wing']=='B'and floor['level']in [0,1,2]:
  for i,store in enumerate(floor['stores']):
   assert store['polygon'].symmetric_difference(canonical[store['id']]['polygon']).area<1e-7
   floor['stores'][i]=canonical[store['id']]
M={};coll={};render_group='';rng=random.Random(8821)
def pos(x,y,z):return [float(x+429),float(y),float(z-46)]
exec((P/'authoring/mesh_primitives.py').read_text())
def surf(g,y,mat,up=True,solid=False,shade=1):
 for po in polys(g):
  for t in constrained_delaunay_triangles(po).geoms:
   co=list(t.exterior.coords)[:3];tri(mat,[pos(x,y,z)for x,z in co],(0,1 if up else -1,0),[[x,z]for x,z in co],solid,shade)
def cub(c,u,w,d,y,h,m,solid=False):extrude(rect(c,u,w,d),y,h,m,solid)
def segments(g):return [LineString([a,b])for ln in lines(g)for a,b in zip(ln.coords, list(ln.coords)[1:])if math.dist(a,b)>.005]
def at(e,u,n,x,z):return(e[0]+u[0]*x+n[0]*z,e[1]+u[1]*x+n[1]*z)
def ball(c,y,r,h,m):
 # Ellipsoid with smooth normals, deterministic longitudinal topology.
 cx,cz=c;seg=12;rows=8
 for j in range(rows):
  for i in range(seg):
   pts=[];norms=[]
   for jj,ii in [(j,i),(j,i+1),(j+1,i+1),(j+1,i)]:
    th=math.pi*jj/rows;ph=math.tau*ii/seg
    pts.append(pos(cx+r*math.sin(th)*math.cos(ph),y+h*math.cos(th),cz+r*math.sin(th)*math.sin(ph)))
   center=np.mean(pts,axis=0);no=center-np.array(pos(cx,y,cz));no=no/max(np.linalg.norm(no),1e-9)
   quad(m,pts,no.tolist(),shade=.86+.14*j/rows)
def rod(a,b,r,m,segments=10):
 a=np.array(a);b=np.array(b);v=b-a;v=v/np.linalg.norm(v);u=np.cross(v,[0,1,0])
 if np.linalg.norm(u)<.01:u=np.cross(v,[1,0,0])
 u/=np.linalg.norm(u);n=np.cross(v,u)
 for i in range(segments):
  aa=u*math.cos(math.tau*i/segments)+n*math.sin(math.tau*i/segments);bb=u*math.cos(math.tau*(i+1)/segments)+n*math.sin(math.tau*(i+1)/segments)
  pp=[a+r*aa,a+r*bb,b+r*bb,b+r*aa]
  quad(m,[pos(x,y,z)for x,y,z in pp],((aa+bb)/2).tolist(),shade=.8+.2*max(0,aa[0]))
def localrod(c,u,n,a,b,r,m):
 p=at(c,u,n,a[0],a[2]);q=at(c,u,n,b[0],b[2]);rod((p[0],a[1],p[1]),(q[0],b[1],q[1]),r,m)
# Texture authoring, physical scale set in runtime. Original mathematical surfaces, no external photo sourcing.
rr=np.random.default_rng(87);N=768
for name,base,rough in [('limestone',(211,205,191),.36),('travertine',(188,169,138),.56),('pavers',(165,157,139),.75),('oak',(144,109,70),.45),('plaster',(222,218,207),.8),('slate',(66,74,72),.46),('brick',(160,120,94),.78)]:
 yy,xx=np.mgrid[:N,:N];noise=rr.normal(0,1,(N,N));grain=np.sin(xx/4+np.sin(yy/48)*2)*1.5
 if name=='oak':grain=np.sin(yy*.35+np.sin(xx*.011)*7)*8+np.sin(yy*.12+xx*.003)*6
 elif name=='travertine':grain=np.sin(yy*.045+np.sin(xx*.009))*3
 else:grain=grain*.25
 v=np.array(base)[None,None,:]+noise[:,:,None]*1.4+grain[:,:,None]
 if name=='limestone':
  for i in range(950):
   x,y=rr.integers(0,N,2);v[y:y+2,x:x+2]+=rr.uniform(-13,11)
 im=Image.fromarray(np.uint8(np.clip(v,0,255)));im.save(A/(name+'.png'))
# Brand kit: each ID has an original name, geometric mark, typography and variant palette.
fontpath=P/'assets/NotoSansCJKjp-Regular.otf';serif=str(P/'assets/v8/fonts/DejaVuSerif.ttf');sans=str(P/'assets/v8/fonts/DejaVuSans.ttf')
brands=read(P/'source/brands-v7.json');brand_by={x['store_id']:x for x in brands};all_signs=[]
roots=['VELORIA','NEMORA','ARVESS','LUMEVA','ORIENNE','CALMERA','TERRUNE','OVELIS','SORELI','FERNELL','MIREVA','RIVORA','SUVEL','NOLLIA','ALVENE','CERAVA','WENORA','LILVA','MERUNE','ELVORA']
suffix=['ATELIER','STUDIO','HOUSE','WORKS','ROOM','COLLECTIVE','GALLERY','STORE','LAB','MARKET','TOKYO','EDIT','DAYS','CLUB','PLACE','TERRACE','LIBRARY','CRAFT','FIELD','TABLE','COVE','LANE','MUSE','LINE']
palettes=[('#eee7d7','#293735','#b49c6c'),('#192e2d','#e7d5ad','#bc8f52'),('#efece4','#34312d','#a47655'),('#472d2a','#f1dfbf','#d1b16b'),('#1d2d40','#e4dec8','#ab987a'),('#d9d4c1','#373d33','#b28950'),('#cfc3b0','#4a342a','#a97e57'),('#f0eee5','#24483e','#759880')]
selected=[];zones={'A':((350,-32),85),'B':((0,8),76),'C':((-65,-240),128)}
for f in D['floors']:
 if f['level']!=0:continue
 center,r=zones[f['wing']]
 for s in f['stores']:
  ep=(s['entry'][0]+429,s['entry'][1]-46)
  if math.dist(ep,center)<r:selected.append((f,s))
selected_ids={s['id']for f,s in selected}
for i,b in enumerate(brands):
 cat=b['category'];sid=b['store_id'];name=roots[i%len(roots)]+' '+suffix[i//len(roots)%len(suffix)]
 override={'A1F-051':'ORIENNE BOOKS','A1F-003':'VELORIA LEATHER','A1F-005':'NEMORA LIVING','A1F-048':'ARVESS ATELIER','B1-022':'FERNELL COFFEE','B1-040':'TERRUNE BAKERY','B1-008':'OVELIS HOME','B1-043':'MIREVA STUDIO','C1F-CSW-3':'LUMEVA TABLE','C1F-CSW-2':'CALMERA HOUSE','C1F-CSW-1':'RIVORA GOODS','C1F-CW-3':'SORELI LEATHER'}
 name=override.get(sid,name)
 if sid not in override and name in set(override.values()):name+=' EDITIONS'
 bg,fg,accent=palettes[(i*7)%len(palettes)];im=Image.new('RGB',(1536,384),bg);dr=ImageDraw.Draw(im)
 style=i%6;ft=ImageFont.truetype(serif if style in[0,3] else sans,80 if len(name)<18 else 66);sm=ImageFont.truetype(str(fontpath),25)
 # Designed icon, not a copied trademark: four interleaving arcs, fan, geometry or inset monogram.
 cx,cy=140,176
 if style==0:
  for k in range(4):dr.arc((cx-60+k*10,cy-64+k*5,cx+64-k*7,cy+64-k*5),35,310,fill=accent,width=3)
 elif style==1:
  for k in range(7):dr.line((cx-68+k*19,cy+55,cx,cy-65),fill=accent,width=3)
 elif style==2:
  dr.regular_polygon((cx,cy,68),6,rotation=30,outline=accent,width=3);dr.regular_polygon((cx,cy,42),3,rotation=30,outline=accent,width=3)
 elif style==3:
  dr.ellipse((cx-66,cy-66,cx+66,cy+66),outline=accent,width=2);dr.text((cx,cy-5),name[0],font=ImageFont.truetype(serif,78),fill=fg,anchor='mm')
 elif style==4:
  for k in range(5):dr.arc((cx-70,cy-60+k*13,cx+70,cy+40+k*13),180,360,fill=accent,width=4)
 else:
  for k in range(3):dr.rectangle((cx-50+k*17,cy-60+k*15,cx+50+k*17,cy+38+k*15),outline=accent,width=2)
 dr.text((280,152),name,font=ft,fill=fg,anchor='lm',stroke_width=0)
 dr.line((282,220,1410,220),fill=accent,width=2)
 dr.text((284,252),cat+'  /  '+sid,font=sm,fill=fg)
 if style in [1,4]:dr.line((40,32,1496,32),fill=accent,width=2);dr.line((40,350,1496,350),fill=accent,width=2)
 file='brand-'+sid+'.png';im.save(A/file,optimize=True)
 b.update({'name':name,'logo_asset':'v8/'+file,'status':'original procedural brand artwork; trademark clearance not performed','review_area':sid in selected_ids,'style':style})
write(P/'source/brands-v8.json',brands)
# Display graphic atlas for editorial windows: actual merchandise textures, not faux photographic scene images.
for title,sub,file,col in [('THE QUIET EDIT','SPRING / MATERIAL / FORM','editorial',('#d1c8b9','#293b35')),('FRESHLY MADE','COFFEE  ·  BREAD  ·  EVERY DAY','menu',('#243b33','#e8ddbf'))]:
 im=Image.new('RGB',(768,1024),col[0]);dr=ImageDraw.Draw(im)
 if file=='editorial':
  dr.ellipse((190,140,590,540),fill='#b4a38b');dr.polygon([(280,300),(450,260),(570,710),(190,710)],fill='#53675d');dr.line((280,300,190,710),fill='#728379',width=8)
 else:
  dr.ellipse((180,150,588,558),outline=col[1],width=3);dr.ellipse((266,236,502,472),fill='#a48c66');dr.arc((310,80,440,250),0,190,fill=col[1],width=5)
 for j,line in enumerate(title.split()):dr.text((65,740+j*65),line,font=ImageFont.truetype(serif,52),fill=col[1])
 dr.text((65,940),sub,font=ImageFont.truetype(sans,16),fill=col[1]);im.save(A/(file+'.png'))
# Keep every recorded public route and main shop aisle free. World route coordinates -> source coordinates.
rs=read(P/'source/physical-routes-v7.json');route_lines=[]
for r in rs:
 pts=r['points']
 for a,b in zip(pts,pts[1:]):
  if abs(a[1])<.25 and abs(b[1])<.25 and math.dist(a,b)<150:route_lines.append(LineString([(a[0]-429,a[2]+46),(b[0]-429,b[2]+46)]).buffer(.46))
route_clear=unary_union(route_lines)
fixture_rows=[];light_rows=[];text_rows=[];selected_bounds={};removed=[];floor_surfaces=[]
# Fixture builders, dimensions in metres.
def books(c,u,n,y,width=2.1,short=False):
 height=1.30 if short else 2.10
 cub(c,u,width,.38,y,height,'v8_oak',True)
 # Front-facing dark recesses and each individual book spine with stamped stripe.
 for hh in ([.18,.59,1.0]if short else[.18,.59,1.0,1.41,1.82]):
  cub(at(c,u,n,0,.205),u,width-.13,.024,y+hh,.30,'v8_dark')
  x=-width/2+.10
  while x<width/2-.12:
   ww=rng.uniform(.035,.085);ht=rng.uniform(.22,.32);pp=at(c,u,n,x,.235);mat='v8_book'+str(rng.randrange(7))
   # Omit unseen back/bottom book faces; spine, paper top and both sides retain volume.
   aa=at(c,u,n,x-ww/2,.135);bb=at(c,u,n,x+ww/2,.135);cc=at(c,u,n,x+ww/2,.335);dd=at(c,u,n,x-ww/2,.335)
   quad('v8_paper',[pos(aa[0],y+hh+ht,aa[1]),pos(bb[0],y+hh+ht,bb[1]),pos(cc[0],y+hh+ht,cc[1]),pos(dd[0],y+hh+ht,dd[1])],(0,1,0))
   for a,b in [(aa,dd),(bb,cc)]:quad(mat,[pos(a[0],y+hh,a[1]),pos(b[0],y+hh,b[1]),pos(b[0],y+hh+ht,b[1]),pos(a[0],y+hh+ht,a[1])],(u[0],0,u[1]))
   q1=at(c,u,n,x-ww/2,.339);q2=at(c,u,n,x+ww/2,.339);tile=rng.randrange(32);tx=tile%16;ty=tile//16
   quad('v8_book_spines',[pos(q1[0],y+hh,q1[1]),pos(q2[0],y+hh,q2[1]),pos(q2[0],y+hh+ht,q2[1]),pos(q1[0],y+hh+ht,q1[1])],(n[0],0,n[1]),[[tx/16,(ty+1)/2],[(tx+1)/16,(ty+1)/2],[(tx+1)/16,ty/2],[tx/16,ty/2]])
   x+=ww+.012
 for xx in[-width/2,width/2]:cub(at(c,u,n,xx,0),u,.04,.45,y,height+.02,'v8_bronze')
def clothing(c,u,n,y,width=2.1):
 cub(c,u,width+.12,.76,y,.09,'v8_slate',True)
 for xx in[-width/2,width/2]:localrod(c,u,n,(xx,y+.08,0),(xx,y+1.64,0),.025,'v8_bronze')
 localrod(c,u,n,(-width/2,y+1.64,0),(width/2,y+1.64,0),.025,'v8_bronze')
 for i,xx in enumerate(np.arange(-width/2+.15,width/2,.20)):
  p=at(c,u,n,xx,0);ht=rng.uniform(.65,.96);m='v8_fabric'+str(rng.randrange(5))
  # Draped jacket silhouette, sleeves, collar and hanger triangle.
  outline=Polygon([(-.07,1.45),(-.19,1.40),(-.34,1.02),(-.25,.98),(-.15,1.20),(-.15,1.45-ht),(.15,1.45-ht),(.15,1.20),(.25,.98),(.34,1.02),(.19,1.40),(.07,1.45),(.035,1.38),(-.035,1.38)])
  for sg in [-1,1]:
   for t in constrained_delaunay_triangles(outline).geoms:
    co=list(t.exterior.coords)[:3];pts=[]
    for zz,yy in co:
     pp=at(p,u,n,sg*.033,zz);pts.append(pos(pp[0],y+yy,pp[1]))
    tri(m,pts,(sg*u[0],0,sg*u[1]),[[z*2,yy*2]for z,yy in co],shade=.88 if sg<0 else 1.0)
  for a,b in zip(list(outline.exterior.coords),list(outline.exterior.coords)[1:]):
   pts=[]
   for sg,zz,yy in[(-1,a[0],a[1]),(1,a[0],a[1]),(1,b[0],b[1]),(-1,b[0],b[1])]:
    pp=at(p,u,n,sg*.033,zz);pts.append(pos(pp[0],y+yy,pp[1]))
   quad(m,pts,(n[0],0,n[1]),shade=.85)
  localrod(p,u,n,(0,y+1.58,-.18),(0,y+1.43,0),.008,'v8_bronze');localrod(p,u,n,(0,y+1.43,0),(0,y+1.58,.18),.008,'v8_bronze')
def sofa(c,u,n,y):
 cub(c,u,1.90,.78,y+.12,.15,'v8_oak',True)
 for x in [-.82,.82]:
  for z in [-.27,.27]:cub(at(c,u,n,x,z),u,.06,.06,y,.15,'v8_bronze')
 for x in [-.46,.46]:
  pp=at(c,u,n,x,.02);extrude(rect(pp,u,.88,.65).buffer(.055),y+.27,.15,'v8_fabric2',False)
  extrude(rect(at(c,u,n,x,-.29),u,.88,.13).buffer(.05),y+.37,.42,'v8_fabric0',False)
 for sg in [-1,1]:extrude(rect(at(c,u,n,sg*.91,0),u,.13,.76).buffer(.04),y+.23,.40,'v8_fabric2',False)
def booktable(c,u,n,y):
 cub(c,u,1.95,.74,y,.12,'v8_oak',True);cub(c,u,1.75,.55,y+.12,.59,'v8_oak',True);cub(c,u,2.04,.80,y+.71,.065,'v8_travertine')
 for xx in [-.65,0,.65]:
  for z in [-.15,.15]:
   pp=at(c,u,n,xx,z);cub(pp,u,.25,.30,y+.775,.08,'v8_paper');cub(pp,u,.26,.31,y+.855,.008,'v8_book'+str(rng.randrange(7)))
def merchandise(c,u,n,y,cat,width=2.0):
 cub(c,u,width,.70,y,.12,'v8_slate',True)
 for xx in[-width/2+.04,width/2-.04]:cub(at(c,u,n,xx,0),u,.04,.58,y,1.65,'v8_bronze')
 for hh in [.18,.66,1.14,1.62]:
  cub(c,u,width,.68,y+hh,.035,'v8_oak')
  for xx in np.arange(-width/2+.18,width/2-.10,.32):
   pp=at(c,u,n,xx,.08)
   if any(k in cat for k in ['美容','ケア','雑貨','生活']):
    cylinder(pp,y+hh+.035,.08,.19,'v8_ceramic'+str(rng.randrange(3)),12)
    cylinder(pp,y+hh+.225,.035,.055,'v8_bronze',8)
   elif any(k in cat for k in ['靴','鞄']):
    cub(pp,u,.23,.38,y+hh+.035,.10,'v8_leather');ball(at(pp,u,n,0,.12),y+hh+.105,.10,.06,'v8_leather')
   elif '家電'in cat or 'モバイル'in cat:
    cub(pp,u,.21,.09,y+hh+.035,.32,'v8_dark');cub(at(pp,u,n,0,.05),u,.17,.005,y+hh+.08,.25,'v8_screen')
   else:cub(pp,u,.20,.23,y+hh+.035,rng.uniform(.15,.25),'v8_ceramic'+str(rng.randrange(3)))
def chair(c,u,n,y):
 ball(c,y+.47,.27,.055,'v8_fabric2')
 fp=rect(c,u,.46,.46)
 for po in polys(fp):
  co=list(po.exterior.coords)
  for a,b in zip(co,co[1:]):
   pts=[pos(a[0],y+.34,a[1]),pos(b[0],y+.34,b[1]),pos(b[0],y+.52,b[1]),pos(a[0],y+.52,a[1])]
   for inds in[(0,1,2),(0,2,3)]:coll.setdefault('v8_chair_seat',[]).extend(sum([pts[i]for i in inds],[]))
 for a in [-1,1]:
  for b in [-1,1]:localrod(c,u,n,(a*.18,y,b*.18),(a*.16,y+.45,b*.16),.018,'v8_bronze')
 cub(at(c,u,n,0,-.22),u,.48,.06,y+.45,.40,'v8_oak')
def dining(c,u,n,y):
 cylinder(c,y,.055,.73,'v8_bronze',12,True);cylinder(c,y+.73,.55,.055,'v8_travertine',32,True)
 for sg in [-1,1]:chair(at(c,u,n,0,sg*.9),u,(n[0]*sg,n[1]*sg),y)
 cylinder(at(c,u,n,.2,.1),y+.785,.075,.09,'v8_ceramic0',12);cylinder(at(c,u,n,-.15,.1),y+.785,.10,.012,'v8_paper',16)
 cylinder(c,y+.785,.035,.16,'v8_ceramic1',10)
def checkout(c,u,n,y,cat):
 cub(c,u,2.4,.85,y,1.0,'v8_oak',True);cub(c,u,2.48,.91,y+1,.065,'v8_travertine')
 for xx in np.arange(-1.1,1.2,.10):cub(at(c,u,n,xx,.43),u,.035,.035,y+.10,.80,'v8_bronze')
 cub(at(c,u,n,.65,0),u,.34,.22,y+1.065,.06,'v8_dark');cub(at(c,u,n,.65,0),u,.32,.07,y+1.12,.22,'v8_dark')
 if any(k in cat for k in ['カフェ','食品','ベーカリ']):
  cub(at(c,u,n,-.35,0),u,.7,.44,y+1.07,.40,'v8_chrome');cylinder(at(c,u,n,-.35,.24),y+1.09,.055,.12,'v8_ceramic0',12)
  for sg in[-.58,-.3]:localrod(c,u,n,(sg,y+1.3,.22),(sg,y+1.3,.34),.018,'v8_dark')
# Detailed fit-outs and facades in the 3 explicitly selected review regions only.
for f,s in selected:
 render_group=s['id'];sid=s['id'];w=f['wing'];u=s['u'];n=s['n'];e=s['entry'];y=0.;sales=s['sales'];dw=s.get('door_width_m',2.4);category=s['category']
 selected_bounds[sid]=mapping(sales);removed.append(sid)
 isbook=any(k in category for k in ['書店','書籍']);fashion=any(k in category for k in ['衣料','ファッション','服飾','スポーツ','アウトドア']);cafe=any(k in category for k in ['カフェ','飲食','レストラン','食品','ベーカリ'])
 mat='v8_oak'if isbook or cafe else'v8_limestone'if w=='A'else'v8_pavers'if w=='C'else'v8_travertine'
 surf(sales.buffer(-.13),.016,mat)
 # Per-store protected aperture, framed soffit and reveal. Canopy never encroaches below 3.18m.
 facewidth=min(14,max(dw+1,float(s.get('frontage_m',dw+3))))
 for side in[-1,1]:
  cub(at(e,u,n,side*(dw/2+.17),0),u,.22,.36,0,3.55,'v8_bronze'if w=='A'else'v8_oak',False)
 cub(at(e,u,n,0,-.12),u,facewidth,.62,3.20,.14,'v8_oak'if w=='B'else'v8_slate')
 cub(at(e,u,n,0,-.43),u,facewidth,.035,3.21,.025,'v8_led')
 # Trim whole real frontage, no fabricated walls or closed openings.
 fronts=[LineString(s['front'])]if s.get('front')else lines(sales.boundary.intersection(f['public'].buffer(.01)))
 front=unary_union(fronts)
 for ln in lines(front):
  if ln.length<1:continue
  bar(ln.coords[0],ln.coords[-1],.08,.07,.08,'v8_bronze')
  bar(ln.coords[0],ln.coords[-1],.09,3.08,.08,'v8_bronze')
  if w=='C':
   # Individual masonry piers and timber awning over the existing storefront edge.
   for t in [0,ln.length]:
    q=ln.interpolate(t);cub((q.x,q.y),u,.45,.42,0,4.60,'v8_brick')
   bar(ln.coords[0],ln.coords[-1],.65,3.76,.12,'v8_oak')
 # Brand signage, position faces out of the store; save actual dimensions.
 brand=brand_by[sid];brand=next(b for b in brands if b['store_id']==sid)
 all_signs.append({'file':'v8/brand-'+sid+'.png','p':pos(e[0]-n[0]*.46,3.67,e[1]-n[1]*.46),'n':[-n[0],-n[1]],'w':min(facewidth,7.4),'h':min(1.0,facewidth/4),'id':sid})
 brand['sign_position']=pos(e[0]-n[0]*.46,3.67,e[1]-n[1]*.46);brand['normal']=[-n[0],-n[1]];brand['max_width_m']=min(facewidth,7.4)
 # Non-identical layout follows sales geometry and protected circulation, not store bounds grid alone.
 aisle=s.get('aisles',Polygon());aisle=unary_union(aisle)if isinstance(aisle,list)else aisle
 if not hasattr(aisle,'geom_type'):aisle=Polygon()
 route=s.get('main_route',[]);keep=aisle.buffer(.20).union(route_clear)
 if len(route)>1:keep=keep.union(LineString(route).buffer(.65))
 keep=keep.union(rect(at(e,u,n,0,1.4),u,dw+.35,3.8))
 safe=sales.buffer(-.43).difference(keep);placed=[]
 # Register counter in an accessible front-side bay.
 for side in [-1,1]:
  c=at(e,u,n,side*(dw/2+1.5),3.1);fp=rect(c,u,2.6,1.0)
  if safe.covers(fp):checkout(c,u,n,0,category);placed.append(fp);fixture_rows.append({'store':sid,'kind':'checkout','geom':fp,'height':1.50});break
 if not any(r['store']==sid and r['kind']=='checkout'for r in fixture_rows):
  candidates=[]
  for po in polys(safe):
   candidates.extend([po.representative_point(),po.centroid])
  for pp in sorted(candidates,key=lambda q:math.dist((q.x,q.y),e)):
   c=(pp.x,pp.y);fp=rect(c,u,2.6,1.0)
   if safe.covers(fp):checkout(c,u,n,0,category);placed.append(fp);fixture_rows.append({'store':sid,'kind':'checkout','geom':fp,'height':1.50});break
 # Wall perimeter shelving: selected sufficiently straight edges, never across entry/backroom apertures.
 outer=sales.boundary.difference(s.get('backroom',Polygon()).buffer(.13)).difference(front.buffer(.55))
 wallcount=0
 for ln in lines(outer):
  if ln.length<2.3 or wallcount>14:continue
  for t in np.arange(1.25,ln.length-.65,2.5):
   q=ln.interpolate(t);qa=ln.interpolate(max(0,t-.05));qb=ln.interpolate(min(ln.length,t+.05));uv=np.array([qb.x-qa.x,qb.y-qa.y]);uv/=max(np.linalg.norm(uv),1e-9);nv=np.array([-uv[1],uv[0]])
   if not sales.covers(Point(q.x+nv[0]*.4,q.y+nv[1]*.4)):nv=-nv
   cc=(q.x+nv[0]*.38,q.y+nv[1]*.38);fp=rect(cc,uv,2.15,.65)
   if not sales.buffer(-.04).difference(keep).covers(fp)or any(fp.distance(p)<.5 for p in placed):continue
   if isbook:books(cc,uv,nv,0)
   elif fashion:clothing(cc,uv,nv,0)
   else:merchandise(cc,uv,nv,0,category)
   placed.append(fp);wallcount+=1;fixture_rows.append({'store':sid,'kind':'wall_display','geom':fp,'height':2.12})
 # Store-aligned candidate lattice follows the real frontage; no footprint or protected route changes.
 from shapely.ops import transform
 local=transform(lambda x,z,zz=None:((np.asarray(x)-e[0])*u[0]+(np.asarray(z)-e[1])*u[1],(np.asarray(x)-e[0])*n[0]+(np.asarray(z)-e[1])*n[1]),safe)
 x0,z0,x1,z1=local.bounds;count=0;limit=min(96 if isbook else 64,max(8,int(sales.area/(8 if cafe or isbook else 12))))
 for zz in np.arange(z0+.65,z1,1.2):
  for xx in np.arange(x0+.65,x1,1.2):
   if count>=limit:continue
   c=at(e,u,n,xx,zz);chosen=None
   for uu,nn in [(u,n),(n,u)]if cafe else[(u,n)]:
    fp=rect(c,uu,1.3 if cafe else 2.1,2.4 if cafe else .90)
    if safe.covers(fp)and all(fp.distance(p)>=1.15 for p in placed):chosen=(uu,nn,fp);break
   if chosen is None:continue
   uu,nn,fp=chosen
   if cafe:dining(c,uu,nn,0)
   elif isbook:
    if count%3==0:booktable(c,uu,nn,0)
    else:books(c,uu,nn,0,1.85,count%3==1);books(at(c,uu,nn,0,-.45),uu,[-nn[0],-nn[1]],0,1.85,count%3==1)
   elif any(k in category for k in ['家具','インテリア']):sofa(c,uu,nn,0)
   elif fashion:clothing(c,uu,nn,0)
   else:merchandise(c,uu,nn,0,category)
   placed.append(fp);count+=1;fixture_rows.append({'store':sid,'kind':'dining'if cafe else'book_table'if isbook and count%3==1 else'book_island'if isbook else'sofa_display'if any(k in category for k in ['家具','インテリア'])else'garment_rail'if fashion else'product_display','geom':fp,'height':.82 if cafe else 2.12})
 # Upper wall cladding follows real sales-wall runs and stays entirely above all staff door heads.
 for ln in segments(sales.boundary.difference(front.buffer(.35))):
  if ln.length<1.0:continue
  panel=ln.buffer(.15,cap_style=2).difference(ln.buffer(.10,cap_style=2)).intersection(sales)
  extrude(panel,2.35,1.85,'v8_oak'if isbook or cafe else'v8_plaster',False)
 # Category art on the wall nearest the rear point, using actual segment orientation.
 straight=[ln for ln in segments(outer) if ln.length>3.8]
 if straight:
  ln=max(straight,key=lambda q:q.length);pp=ln.interpolate(.5,normalized=True);a,b=ln.coords[0],ln.coords[-1];uu=np.array(b)-a;uu=uu/max(np.linalg.norm(uu),1e-8);nn=np.array([-uu[1],uu[0]])
  if not sales.covers(Point(pp.x+nn[0]*.1,pp.y+nn[1]*.1)):nn=-nn
  all_signs.append({'file':'v8/menu.png'if cafe else'v8/editorial.png','p':pos(pp.x+nn[0]*.18,3.25,pp.y+nn[1]*.18),'n':nn.tolist(),'w':1.35,'h':1.80,'id':sid+'-wall-art'})
 # Ceiling cassette lighting, brass spot housings and timber ceiling islands within the actual sales polygon.
 ceil=next(ff['height'] for ff in D['floors']if ff['wing']==w and ff['level']==1)-(.70 if w=='B'else .42)
 for xx in np.arange(sales.bounds[0]+2,sales.bounds[2],5):
  for zz in np.arange(sales.bounds[1]+2,sales.bounds[3],5):
   c=(xx,zz)
   if sales.buffer(-.7).covers(Point(c)):
    cub(c,u,1.3,.09,ceil-.10,.07,'v8_dark');cylinder(c,ceil-.21,.10,.12,'v8_bronze',12);cylinder(c,ceil-.215,.074,.01,'v8_led',12)
 for t in np.arange(-min(facewidth/2,5),min(facewidth/2,5),1.0):
  a=at(e,u,n,t,.3);b=at(e,u,n,t,5.0);ln=LineString([a,b]).intersection(sales.buffer(-.4))
  for l in lines(ln):bar(l.coords[0],l.coords[-1],.10,ceil-.13,.10,'v8_oak')
 lightpt=LineString(s['main_route']).interpolate(2.0)if len(s.get('main_route',[]))>1 else sales.representative_point()
 light_rows.append({'p':pos(lightpt.x,ceil-.3,lightpt.y),'range':10,'energy':3.8 if cafe else 3.0,'warm':cafe,'id':sid})
 # Decorative screen/print mounted inside storefront, without obscuring its open aperture.
 for side in [-1,1]:
  pp=at(e,u,n,side*(dw/2+1.0),1.6);fp=rect(pp,u,1.0,.35)
  if safe.covers(fp)and all(fp.distance(q)>.35 for q in placed):
   cub(pp,u,.85,.16,0,.14,'v8_slate',True)
   all_signs.append({'file':'v8/menu.png'if cafe else'v8/editorial.png','p':pos(pp[0],1.25,pp[1]),'n':[-n[0],-n[1]],'w':.8,'h':1.066,'id':sid+'-window'});break
 selected_bounds[sid]={'sales':mapping(sales),'wing':w,'remove_materials':['oak','walnut','wood','goods_cream','goods_green','goods_rust','goods_charcoal','fabric_sage','fabric_cream','fabric_navy','fabric_rust','metal','book_0','book_1','book_2','book_3','book_4','book_5','ceramic_0','ceramic_1','ceramic_2','paper','bread','quartz']}
# Trees: branch skeleton and individual curved leaf blades, no box/cone silhouettes.
def tree(c,y,h=3.2):
 cylinder(c,y,.58,.42,'v8_travertine',32,True);cylinder(c,y+.42,.51,.025,'v8_soil',24)
 rod((c[0],y+.44,c[1]),(c[0]+.08,y+h*.80,c[1]+.05),.045,'v8_bark')
 for j in range(9):
  ang=j*2.4;level=y+h*(.48+.045*j);tip=(c[0]+math.cos(ang)*.72,level+.35,c[1]+math.sin(ang)*.72)
  rod((c[0],level-.2,c[1]),tip,.019,'v8_bark',8)
  for k in range(65):
   theta=rng.random()*math.tau;rad=math.sqrt(rng.random())*.60
   x=tip[0]+math.cos(theta)*rad;z=tip[2]+math.sin(theta)*rad;yy=tip[1]+rng.uniform(-.26,.32);a=rng.random()*math.tau;l=rng.uniform(.10,.18);ww=l*.38
   ux,uz=math.cos(a)*l,math.sin(a)*l;vx,vz=-math.sin(a)*ww,math.cos(a)*ww
   pp=[pos(x-ux,yy-.02,z-uz),pos(x+vx,yy+.035,z+vz),pos(x+ux,yy,z+uz),pos(x-vx,yy+.035,z-vz)];no=(0,1,0)
   quad('v8_leaf'+str(j%3),pp,no,shade=rng.uniform(.65,1))
def bench(c,u,n,y,length=2.8):
 for side in [-1,1]:cub(at(c,u,n,side*(length/2-.18),0),u,.12,.64,y,.40,'v8_slate',True)
 for zz in np.arange(-.30,.31,.10):cub(at(c,u,n,0,zz),u,length,.075,y+.43,.055,'v8_oak')
 for yy in [.63,.75,.87]:cub(at(c,u,n,0,-.30),u,length,.05,y+yy,.08,'v8_oak')
 for xx in[-length/2+.12,length/2-.12]:cub(at(c,u,n,xx,0),u,.045,.66,y+.62,.04,'v8_bronze')
# Architectural finishes follow existing floor plates and openings, never bridge across atria.
for f in D['floors']:
 if f['level']not in [0,1,2]:continue
 w=f['wing'];y=f['height'];center,r=zones[w];zone=Point(center[0]-429,center[1]+46).buffer(r)
 render_group='FINISH-'+w+'-'+f['label']
 public=f['public'].intersection(f['floor_plate']).intersection(zone)
 surf(public,y+.018,'v8_limestone'if w=='A'else'v8_travertine'if w=='B'else'v8_pavers')
 # Thin paired contrasting floor borders at real store-front edges.
 stores=unary_union([s['polygon']for s in f['stores']]);border=stores.buffer(.66).difference(stores.buffer(.48)).intersection(public)
 surf(border,y+.021,'v8_slate'if w!='B'else'v8_oak')
 above=next(ff for ff in D['floors']if ff['wing']==w and ff['level']==f['level']+1)
 ceiling=above['floor_plate'].intersection(zone).difference(unary_union([c['outline']for c in f['cores']]))
 if w=='C':ceiling=ceiling.intersection(f['shell'])
 ceil_y=above['height']-(.70 if w=='B'else .42)
 # Perimeter ceiling coves and linear insets; openings remain exact.
 band=ceiling.boundary.buffer(.48).intersection(ceiling)
 extrude(band,ceil_y-.12,.10,'v8_oak'if w=='B'else'v8_plaster',False)
 led=ceiling.boundary.buffer(.075).intersection(ceiling)
 surf(led,ceil_y-.125,'v8_led',False)
 # Rhythm of recessed downlights with trim rings and segmented grilles.
 for xx in np.arange(math.floor(zone.bounds[0]/6)*6,zone.bounds[2],6):
  for zz in np.arange(math.floor(zone.bounds[1]/6)*6,zone.bounds[3],6):
   p=Point(xx,zz)
   if not public.buffer(-.8).covers(p)or not ceiling.buffer(-.6).covers(p):continue
   cylinder((xx,zz),ceil_y-.055,.145,.04,'v8_dark',16);cylinder((xx,zz),ceil_y-.060,.105,.01,'v8_led',16)
   # Narrow mechanical air grille, believable equipment scale rather than blank soffit.
   if int(xx+zz)%18==0:
    cub((xx+.65,zz),(1,0),.80,.16,ceil_y-.035,.02,'v8_dark')
    for t in np.arange(-.35,.36,.07):cub((xx+.65+t,zz),(1,0),.025,.18,ceil_y-.06,.02,'v8_bronze')
 # Existing furniture locations only; all additionally placed objects require source-safe public land.
 if f['level']==0:
  for ob in f['furniture']:
   g=ob['geom'];c=g.centroid
   if not zone.covers(c):continue
   render_group='PUBLIC-'+ob['id']
   # Old bench seat retained as its substrate, provide legs/back/slats on top.
   if 'bench'in ob['kind']:bench((c.x,c.y),(1,0),(0,1),0)
   elif 'plant'in ob['kind']:tree((c.x,c.y),.02,3.0 if w=='A'else 3.5)
  # Extra trees contained in genuine public bays, never in declared circulation paths.
  candidates=[]
  if w=='B':candidates=[(-7,7),(20,4),(-16,-8),(27,-12)]
  elif w=='A':candidates=[(339,-47),(351,-13),(365,-32)]
  else:candidates=[(-40,-220),(-60,-245),(-78,-264),(-25,-275),(-45,-300),(-90,-235),(-5,-235)]
  for k,(wx,wz)in enumerate(candidates):
   cc=(wx-429,wz+46);fp=Point(cc).buffer(.65)
   if not public.covers(fp)or route_clear.intersects(fp):continue
   render_group='TREE-'+w+str(k);tree(cc,0,3.4 if w!='C'else 4.5);fixture_rows.append({'store':'PUBLIC-'+w,'kind':'tree','geom':fp,'height':4.5 if w=='C'else 3.4})
# Floor edge fascia cladding at existing upper deck edges in C (actual thickness only, not re-layout).
for f in D['floors']:
 if f['wing']!='C'or f['level']not in[1,2]:continue
 center,r=zones['C'];zone=Point(center[0]-429,center[1]+46).buffer(r)
 render_group='FASCIA-C-'+f['label']
 edge=f['floor_plate'].boundary.intersection(zone)
 for ln in segments(edge):
  if ln.length<.5:continue
  bar(ln.coords[0],ln.coords[-1],.045,f['height']-.36,.30,'v8_slate')
# Registry/evidence: design coordinates remain unchanged; footprints saved for collision review.
write(P/'source/brands-v8.json',brands)
write(P/'source/fitout-v8.json',{'zones':zones,'stores':[{'id':s['id'],'wing':f['wing'],'category':s['category'],'area_m2':s['sales'].area}for f,s in selected],'replacement':selected_bounds,'fixtures':fixture_rows,'lights':light_rows,'signs':all_signs,'scope':'representative areas only, not complete mall','original_structure_changed':False})
raw={'surfaces':M,'colliders':coll,'signs':all_signs,'lights':light_rows}
with gzip.open(P/'assets/fitout-v8.json.gz','wb',compresslevel=5)as fp:fp.write(json.dumps(raw,separators=(',',':')).encode())
print('V8_FITOUT',len(selected),'stores',len(fixture_rows),'fixtures',sum(len(v['v'])//9 for v in M.values()),'triangles',len(M),'batches')
