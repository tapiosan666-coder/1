from pathlib import Path
P=Path(__file__).resolve().parents[1];src=(P/'authoring/retail_models_v10.py').read_text();exec(src[:src.index('for var in range(3):bookcase')]);OUT=P/'assets/v11/models'
for x in[-.98,.98]:box('Shoe_display_upright',(x,.16,.9),(.035,.45,1.8),white,.005)
for z in[.18,.70,1.22,1.74]:box('Illuminated_shoe_shelf',(0,0,z),(2.0,.50,.035),wood,.008)
finish('shoe_shelf')
