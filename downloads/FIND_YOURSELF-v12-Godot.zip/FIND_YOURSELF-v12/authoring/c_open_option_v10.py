"""Unapproved C-wing structural OPTION only. Approved site/v9 sources are read-only inputs.
Keep every shop plot, core, landing and original route centreline; reduce surplus gallery/deck floor.
"""
from pathlib import Path
import sys,math,json,numpy as np
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
from pack_tools_v10 import *
from shapely import contains_xy,constrained_delaunay_triangles
from shapely.ops import transform
P=Path(__file__).resolve().parents[1];D=read(P/'source/site-v7.json');routes=read(P/'source/physical-routes-v7.json');g=load_pack(P/'assets/v10/base-site.pack.gz');M={};coll={};render_group='';rows=[];masks=[]
def pos(x,y,z):return[round(float(x+429),5),round(float(y),5),round(float(z-46),5)]
exec((P/'authoring/mesh_primitives.py').read_text())
def world(poly):return transform(lambda x,z,zz=None:(np.asarray(x)+429,np.asarray(z)-46),poly)
def rings(geom):return[[[list(p)for p in po.exterior.coords],*[[list(p)for p in r.coords]for r in po.interiors]]for po in polys(geom)]
for f in D['floors']:
 if f['wing']!='C'or f['level']<1:continue
 y=f['height'];level=f['level'];old=f['floor_plate'];shops=unary_union([s['polygon'].buffer(.16,join_style=2)for s in f['stores']]);shops=shops.union(unary_union([s['polygon'].buffer(.16,join_style=2)for q in D['floors']if q['wing']=='C'and q['level']==2 for s in q['stores']]))if level==3 else shops;cores=unary_union([c['outline'].buffer(1.3,join_style=2)for c in f['cores']]);network=[]
 for r in routes:
  for a,b in zip(r['points'],r['points'][1:]):
   if abs(a[1]-y)<.06 and abs(b[1]-y)<.06 and math.dist(a,b)<250:
    ln=LineString([(a[0]-429,a[2]+46),(b[0]-429,b[2]+46)])
    if ln.intersects(old):network.append(ln.buffer(2.0,cap_style=2,join_style=2))
 # Existing store-front circulation bands provide a continuous four-metre gallery, not arbitrary new paths.
 front_bands=[]
 for s in f['stores']:
  e=np.array(s['entry']);u=np.array(s['u']);ln=s['sales'].boundary.intersection(f['public'].buffer(.045));front_bands.append(ln.buffer(4.0,cap_style=2,join_style=2))
 for e in f['escalators']:
  cc=e.get('c');uu=e.get('u')
  if cc and uu:
   run=e.get('run_m',12);front_bands.append(rect(cc,uu,run+8,7))
 keep=shops.union(cores).union(unary_union(network)).union(unary_union(front_bands));new=old.intersection(keep).buffer(0);delta=old.difference(new);new_public=f['public'].intersection(new)
 # Critical invariants: no plot changes, no newly invented floor, exact existing route centrelines retained.
 lost=sum(s['polygon'].intersection(old).difference(new).area for s in f['stores']);assert lost<1e-6,(f['label'],lost);assert new.difference(old).area<1e-7
 label='C-'+f['label'];prev=next(q for q in D['floors']if q['wing']=='C'and q['level']==level-1);oldw=world(old);neww=world(new);dw=world(delta);removed=0
 for key,data in list(g['surfaces'].items()):
  mat,_,group=key.partition('@@');face_xyz=triangles(data);ct=face_xyz.mean(axis=1);drop=np.zeros(len(ct),dtype=bool)
  if group==label:
   if mat=='stone':drop=(face_xyz[:,:,1].min(axis=1)>=y-.3801)&(face_xyz[:,:,1].max(axis=1)<=y+.0001)
   if mat=='glass':drop|=(ct[:,1]>=y)&(ct[:,1]<y+1.2)
   if mat=='plaster':drop|=contains_xy(dw.buffer(.20),ct[:,0],ct[:,2])&(ct[:,1]>y-.01)&(ct[:,1]<y+5.2)
  if group=='C-'+prev['label']and mat=='plaster':drop|=np.all(np.abs(face_xyz[:,:,1]-(y-.42))<.0001,axis=1)
  if drop.any():removed+=int(drop.sum());g['surfaces'][key]=retain(data,~drop)
 for mat,data in g['colliders'].items():
  if mat not in['stone','glass','plaster']:continue
  face_xyz=np.asarray(data).reshape(-1,3,3);ct=face_xyz.mean(axis=1);drop=np.zeros(len(ct),dtype=bool)
  if mat=='stone':drop=contains_xy(oldw.buffer(.03),ct[:,0],ct[:,2])&(face_xyz[:,:,1].min(axis=1)>=y-.3801)&(face_xyz[:,:,1].max(axis=1)<=y+.0001)
  elif mat=='glass':drop=contains_xy(oldw.buffer(.20).difference(world(shops).buffer(-.2)),ct[:,0],ct[:,2])&(ct[:,1]>=y)&(ct[:,1]<y+1.2)
  elif mat=='plaster':drop=contains_xy(dw.buffer(.20),ct[:,0],ct[:,2])&(ct[:,1]>y-.01)&(ct[:,1]<y+5.2)
  g['colliders'][mat]=face_xyz[~drop].ravel()
 render_group='C-OPTION-'+f['label'];extrude(new,y-.38,.38,'stone',True);surf(new.intersection(prev['shell']),y-.42,'plaster',False,False)
 # Rails follow the new deck edge. Never close a shop, core, bridge or named device opening.
 connected=unary_union([q['polygon'].buffer(.25)for q in D['site']['bridges']if abs(q['height']-y)<.05]);mouths=[]
 for rr in routes:
  for aa,bb in zip(rr['points'],rr['points'][1:]):
   if abs(aa[1]-y)<.06 and abs(bb[1]-y)<.06:
    line=LineString([(aa[0]-429,aa[2]+46),(bb[0]-429,bb[2]+46)]);crossings=line.intersection(new.boundary)
    for point in([crossings]if crossings.geom_type=='Point'else getattr(crossings,'geoms',[])):
     if point.geom_type=='Point':mouths.append(point.buffer(1.6))
 edges=new.boundary.difference(shops.buffer(.12)).difference(cores.buffer(.10)).difference(connected).difference(unary_union(mouths))
 for ln in lines(edges):
  if ln.length<.15:continue
  extrude(ln.buffer(.045,cap_style=2),y,.12,'v10_darkstone',True);extrude(ln.buffer(.018,cap_style=2),y+.12,.96,'v10_guard_glass',True);extrude(ln.buffer(.025,cap_style=2),y+1.08,.035,'v10_metal',False)
 row={'floor':f['label'],'level':level,'height':y,'original_floor_m2':old.area,'proposed_floor_m2':new.area,'removed_public_deck_m2':delta.area,'shop_area_lost_m2':lost,'original_store_ids':[s['id']for s in f['stores']],'proposed_floor':new,'proposed_public':new_public,'removed':delta,'new_floor_added_m2':0,'minimum_gallery_design_width_m':4.,'original_route_centreline_buffers_m':2.0,'structural_engineering_verified':False,'approval':'UNAPPROVED OPTION'};rows.append(row);masks.append({'level':level,'label':f['label'],'floor':new,'public':new_public})
 print('C_OPTION',f['label'],'deck removed',round(delta.area,2),'m2','shop loss',lost,'triangles replaced',removed,flush=True)
# Only a roof-form study, above the RF walking clearance; not certified structure or parking capacity.
rf=next(f for f in D['floors']if f['wing']=='C'and f['level']==3)
for i,pavilion in enumerate(rf['pavilions']):
 fp=pavilion['footprint'];rect=fp.minimum_rotated_rectangle;co=np.array(rect.exterior.coords)[:4];ed=[co[1]-co[0],co[2]-co[1]];u=max(ed,key=np.linalg.norm);L=np.linalg.norm(u);u=u/L;n=np.array([-u[1],u[0]]);W=min(np.linalg.norm(e)for e in ed);c=np.array(rect.centroid.coords[0]);render_group='C-OPTION-ROOF-'+pavilion['id'];base=19.15;rise=[1.65,1.1,1.45,1.0,1.3,.9][i]
 # Lightweight roof-frame study: supports stand only on retained RF floor outside protected walk lines.
 roof_floor=next(r['proposed_floor']for r in rows if r['level']==3);roof_routes=unary_union(network)
 for t in np.arange(-L/2+4,L/2-3,9):
  for side in[-1,1]:
   point=c+u*t+n*side*max(2,W/2-8)
   if roof_floor.buffer(-.20).contains(Point(point))and not roof_routes.buffer(.20).contains(Point(point)):
    extrude(Point(point).buffer(.085,quad_segs=4),16.4,base-16.4,'v10_metal',True)
 # Pitched profiles distinguish six independent pavilion volumes. No new walkable roof is claimed.
 for sg in[-1,1]:
  a=c-u*(L/2+.35)+n*sg*(W/2+.35);b=c+u*(L/2+.35)+n*sg*(W/2+.35);ra=c-u*(L/2+.35);rb=c+u*(L/2+.35)
  roof_pts=[pos(a[0],base,a[1]),pos(b[0],base,b[1]),pos(rb[0],base+rise,rb[1]),pos(ra[0],base+rise,ra[1])];roof_no=np.cross(np.array(roof_pts[1])-roof_pts[0],np.array(roof_pts[2])-roof_pts[0]);roof_no=roof_no/np.linalg.norm(roof_no);roof_no=roof_no if roof_no[1]>0 else-roof_no;quad('v10_roof',roof_pts,roof_no,solid=False)
  for t in np.arange(-L/2,L/2,.75):
   aa=c+u*t+n*sg*(W/2+.35);bb=c+u*t
   # Standing seam is a thin profile, not another floor or wall.
   dx=bb-aa;normal=np.array([n[0]*sg,.8,n[1]*sg]);points=[pos(aa[0],base+.02,aa[1]),pos(bb[0],base+rise+.02,bb[1]),pos(bb[0]+u[0]*.012,base+rise+.02,bb[1]+u[1]*.012),pos(aa[0]+u[0]*.012,base+.02,aa[1]+u[1]*.012)];quad('v10_metal',points,normal,solid=False)
# Merge authored additions into the option copy only.
g['surfaces'].update(M)
for k,d in coll.items():g['colliders'][k]=np.concatenate([g['colliders'].get(k,np.array([],dtype=np.float32)),np.asarray(d)])
print(write_pack(P/'assets/v10/base-site-C-option.pack.gz',g),flush=True)
write(P/'source/v10/C-deck-option.json',{'status':'UNAPPROVED STRUCTURAL OPTION','approved_source_modified':False,'RF_SUPPORT_16':'UNAPPROVED; B wing unchanged','floors':rows,'roof_forms':'Visual pavilion roof study at eaves 19.15m; no engineering, load, drainage or fire/egress certification','human_playtest':False})
mapdata=json.loads((P/'source/map-data-v7.json').read_text())
for q in mapdata:
 if q['wing']!='C':continue
 row=next((r for r in rows if r['level']==q['level']),None)
 if row is None:continue
 q['floor']=rings(row['proposed_floor']);q['public']=rings(row['proposed_public']);q['variant']='UNAPPROVED C DECK OPTION'
 for item in q['items']:
  if item['kind']in['広場','庭園']:
   geom=unary_union([Polygon(po[0],po[1:])for po in item['geometry']]);clipped=geom.intersection(row['proposed_floor']);item['geometry']=rings(clipped)
   if clipped.is_empty:item['implemented']=False;item['option_note']='Removed in unapproved deck option'
   else:item['point']=list(clipped.representative_point().coords[0])
(P/'source/v10/map-data-C-option.json').write_text(json.dumps(mapdata,separators=(',',':')))
