"""Loss-bounded float32 mesh transport, geometry buffers unchanged except rounding <0.1mm.
No scene simplification: same vertices, faces, surfaces and collider triangles.
"""
from pathlib import Path
import json,gzip,struct,numpy as np,hashlib,sys
P=Path(__file__).resolve().parents[1];rows=[]
pairs=[('base-b-v8.json.gz','base-b-v8.pack.gz'),('base-site-v8.json.gz','base-site-v8.pack.gz'),('fitout-v8.json.gz','fitout-v8.pack.gz')]
if '--fitout-only'in sys.argv:pairs=pairs[-1:]
for src,dest in pairs:
 g=json.loads(gzip.decompress((P/'assets'/src).read_bytes()));head={'surfaces':{},'colliders':{},'signs':g['signs'],'lights':g['lights']};chunks=[];offset=0;error=0.
 def buf(arr):
  global offset,error
  a=np.array(arr,dtype=np.float64);v=np.round(a,5).astype('<f4');error=max(error,float(np.max(np.abs(a-v)))if len(a)else 0.)
  raw=v.tobytes();out=[offset,len(raw)];offset+=len(raw);chunks.append(raw);return out
 for k,d in g['surfaces'].items():head['surfaces'][k]={f:buf(a)for f,a in d.items()}
 for k,d in g['colliders'].items():head['colliders'][k]=buf(d)
 header=json.dumps(head,separators=(',',':')).encode()
 with gzip.open(P/'assets'/dest,'wb',compresslevel=9)as z:
  z.write(b'FY8\0');z.write(struct.pack('<I',len(header)));z.write(header)
  for ch in chunks:z.write(ch)
 rows.append({'source':src,'target':dest,'surface_count':len(g['surfaces']),'max_float_error_m':error,'compressed_bytes':(P/'assets'/dest).stat().st_size,'triangles_not_removed':True});print(rows[-1],flush=True)
 del g,chunks
if '--fitout-only'in sys.argv:
 old=json.loads((P/'evidence/v8/mesh-packing.json').read_text());rows=[r for r in old if r['target']!='fitout-v8.pack.gz']+rows
(P/'evidence/v8/mesh-packing.json').write_text(json.dumps(rows,indent=2))
