"""Mount finish on actual guard panes, not stale conceptual railing lines. Render-only and variant-common."""
from pathlib import Path
import sys,math,numpy as np,hashlib
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import constrained_delaunay_triangles
levels=[0.,5.525,10.875,16.4];variants=[]
for variant in ['base-site','base-site-C-option']:
 sets={}
 for filename in ['assets/v10/base-b.pack.zst','assets/v10/'+variant+'.pack.zst','assets/v10/architecture.pack.zst','assets/v11/repairs.pack.zst']:
  g=load_pack(P/filename)
  for key,d in g['surfaces'].items():
   mat=key.split('@@')[0]
   if mat not in ['glass','v10_guard_glass']:continue
   a=triangles(d);low=a[:,:,1].min(1);high=a[:,:,1].max(1)
   for y in levels:
    selected=a[(abs(low-y)<.035)&(high-y>.85)&(high-y<1.25)]
    for ts in selected:
     pts=[(float(v[0])-429,float(v[2])+46)for v in ts];line=max([LineString([pts[i],pts[j]])for i,j in[(0,1),(1,2),(0,2)]],key=lambda l:l.length)
     if line.length>.08:sets.setdefault((y,round(float(ts[:,1].max()-y),3)),[]).append(line)
 variants.append(sets)
path=P/'assets/v11/repairs.pack.zst';g=load_pack(path);before={k:hashlib.sha256(np.asarray(v,dtype='<f4').tobytes()).hexdigest()for k,v in g['colliders'].items()}
for key in list(g['surfaces']):
 if key.startswith('v10_metal@@V11-GUARD-'):del g['surfaces'][key]
M={};coll={};render_group='';F=read(P/'source/v11/floors-updated.json')
def pos(x,y,z):return[float(x+429),float(y),float(z-46)]
exec((P/'authoring/mesh_primitives.py').read_text())
records=[]
for key in variants[0]:
 y,h=key
 normal=unary_union(variants[0][key]);option=unary_union(variants[1].get(key,[]));shared=normal.buffer(.06,join_style=2).intersection(option.buffer(.06,join_style=2));strip=shared.buffer(-.07,join_style=2)
 if strip.is_empty:strip=shared.buffer(-.035,join_style=2)
 render_group='V11-GUARD-ACTUAL-'+str(y)+'-'+str(h);extrude(strip,y+h,.035,'v10_metal',False)
 floor=unary_union([f['floor_plate']for f in F if abs(f['height']-y)<.02]);seen={};count=0
 for line in variants[0][key]:
  for s in np.linspace(0,line.length,max(2,math.ceil(line.length/2.5)+1)):
   p=line.interpolate(float(s));cell=(math.floor(p.x/.3),math.floor(p.y/.3))
   if shared.distance(p)>.025:continue
   if any(math.hypot(p.x-q[0],p.y-q[1])<.20 for a in[-1,0,1]for b in[-1,0,1]for q in seen.get((cell[0]+a,cell[1]+b),[])):continue
   footprint=rect((p.x,p.y),(1,0),.055,.055)
   if not floor.buffer(.12).covers(footprint):continue
   seen.setdefault(cell,[]).append((p.x,p.y));extrude(footprint,y+.01,h-.01,'v10_metal',False);count+=1
 records.append({'y':y,'pane_height':h,'actual_pane_segments':len(variants[0][key]),'shared_finish_footprint':strip,'posts':count,'note':'Only existing normal/option guard pane intersection receives finishes. Variant-specific edges retain their existing panes.'})
g['surfaces'].update({k:{a:np.array(v,dtype=np.float32)for a,v in d.items()}for k,d in M.items()});after={k:hashlib.sha256(np.asarray(v,dtype='<f4').tobytes()).hexdigest()for k,v in g['colliders'].items()};assert before==after
meta=save_zst(path,g);write(P/'source/v11/guard-finish-actual.json',{'rule':'Use actual 3D guard panes, not conceptual source guardrails. No new floor/guard collision is introduced.','normal_and_C_option_common_only':True,'all_collision_arrays_unchanged':before==after,'collision_hashes':after,'levels':records,'pack':meta});print('ACTUAL_GUARD_FINISH',sum(r['posts']for r in records),'posts; collision arrays unchanged')
