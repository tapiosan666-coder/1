"""Dress existing C landscaped beds only. No new public floor or path."""
from pathlib import Path
import sys,json,gzip,random,math,ast,numpy as np
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
from shapely import constrained_delaunay_triangles
P=Path(__file__).resolve().parents[1];D=read(P/'source/site-v7.json');rng=random.Random(9162);M={};coll={};render_group='';notes=[]
def pos(x,y,z):return [float(x+429),float(y),float(z-46)]
exec((P/'authoring/mesh_primitives.py').read_text())
# Reuse the same original botanical/mesh functions without executing the retail build.
module=ast.parse((P/'authoring/dress_v8.py').read_text());wanted={'surf','cub','at','ball','rod','tree'}
exec(compile(ast.Module(body=[n for n in module.body if isinstance(n,ast.FunctionDef)and n.name in wanted],type_ignores=[]),'<botanical-functions>','exec'))
f=next(f for f in D['floors']if f['wing']=='C'and f['level']==0);ground=f['floor_plate'].convex_hull.difference(f['shell'].union(f['public']));zone=Point(-65-429,-240+46).buffer(128)
for bed in f['landscape']:
 g=bed['geom'].intersection(ground).intersection(zone)
 if g.area<1:continue
 render_group='LANDSCAPE-'+bed['id'];surf(g,-.010,'v8_soil');edge=g.boundary.buffer(.08).intersection(g);extrude(edge,-.01,.055,'v8_travertine',False)
 safe=g.buffer(-1.4);placed=[]
 if not safe.is_empty:
  x0,z0,x1,z1=safe.bounds
  for x in np.arange(x0+2,x1,12):
   for z in np.arange(z0+2,z1,12):
    q=Point(x,z)
    if not safe.covers(q)or len(placed)>=6:continue
    render_group='GARDEN-TREE-'+bed['id']+'-'+str(len(placed));tree((x,z),-.42,4.8+rng.random()*1.3);placed.append([x+429,z-46])
 # Multi-scale underplanting. Ground has a declared landscape role, not a leftover-space assignment.
 x0,z0,x1,z1=g.bounds;grasses=0
 for i in range(min(1800,int(g.area*2.0))):
  x=rng.uniform(x0,x1);z=rng.uniform(z0,z1)
  if not g.buffer(-.2).covers(Point(x,z)):continue
  render_group='GRASS-'+str(math.floor(x/12))+'-'+str(math.floor(z/12))
  for j in range(3):
   a=rng.random()*math.tau;w=.028;h=rng.uniform(.10,.25);dx,dz=math.cos(a)*w,math.sin(a)*w
   tri('v8_leaf'+str(i%3),[pos(x-dx,-.005,z-dz),pos(x+dx,-.005,z+dz),pos(x+.04,h,z+.03)],(0,1,0),shade=rng.uniform(.8,1))
  grasses+=1
 # Low shrub clusters at existing bed interior positions, with no obstruction of public walking polygons.
 render_group='SHRUBS-'+bed['id']
 for i in range(min(30,int(g.area/18))):
  x=rng.uniform(x0,x1);z=rng.uniform(z0,z1)
  if g.buffer(-.8).covers(Point(x,z)):ball((x,z),.25,.48,.27,'v8_leaf'+str(i%3))
 notes.append({'id':bed['id'],'source_role':bed['kind'],'dressed_area_m2':g.area,'tree_centres_world':placed,'grass_clumps':grasses,'new_public_floor':False,'structure_load_verified':False})
raw=json.loads(gzip.decompress((P/'assets/fitout-v8.json.gz').read_bytes()));raw['surfaces'].update(M)
for mat,data in coll.items():raw['colliders'].setdefault(mat,[]).extend(data)
with gzip.open(P/'assets/fitout-v8.json.gz.tmp','wb',compresslevel=5)as z:z.write(json.dumps(raw,separators=(',',':')).encode())
(P/'assets/fitout-v8.json.gz.tmp').replace(P/'assets/fitout-v8.json.gz')
write(P/'source/landscape-v8.json',notes);print('LANDSCAPE',len(notes),'beds',sum(len(n['tree_centres_world'])for n in notes),'trees',sum(len(v['v'])//9 for v in M.values()),'triangles')
