from pathlib import Path
import json,struct,io,hashlib
from PIL import Image
P=Path(__file__).resolve().parents[1];R=Path('/workspace/scratch/v10-research');O=P/'assets/v10/models';O.mkdir(exist_ok=True);ledger=[]
inputs={k:R/(k+'.glb')for k in ['DiffuseTransmissionPlant','MaterialsVariantsShoe','WaterBottle','AnisotropyBarnLamp']};inputs['SheenWoodLeatherSofa']=Path('/workspace/scratch/v9-vendor-originals/SheenWoodLeatherSofa.glb');inputs['SheenChair']=Path('/workspace/scratch/v9-vendor-originals/SheenChair.glb')
for name,file in inputs.items():
 raw=file.read_bytes();n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);bstart=20+n+8;bn=struct.unpack_from('<I',raw,20+n)[0];data=raw[bstart:bstart+bn]
 # Keep the original node indices; unreachable firefly/camera/light nodes are not imported.
 if name=='DiffuseTransmissionPlant':
  drop={i for i,node in enumerate(g['nodes'])if 'firefly'in node.get('name','').lower()or'camera'in node or'KHR_lights_punctual'in node.get('extensions',{})}
  for sc in g['scenes']:sc['nodes']=[i for i in sc['nodes']if i not in drop]
  for node in g['nodes']:
   if'children'in node:node['children']=[i for i in node['children']if i not in drop]
  g.pop('animations',None);g.pop('cameras',None)
  for mat in g.get('materials',[]):mat.get('extensions',{}).pop('KHR_materials_diffuse_transmission',None)
 # Convert embedded images to ordinary PNGs; keep mesh/accessors/UVs unchanged.
 iv={im['bufferView']:i for i,im in enumerate(g.get('images',[]))};chunks=[];offset=0
 noncolor=set()
 for mat in g.get('materials',[]):
  for texref in [mat.get('normalTexture'),mat.get('occlusionTexture'),mat.get('pbrMetallicRoughness',{}).get('metallicRoughnessTexture')]:
   if texref:
    t=g['textures'][texref['index']];noncolor.add(t.get('source',t.get('extensions',{}).get('EXT_texture_webp',{}).get('source',-1)))
 for i,v in enumerate(g['bufferViews']):
  b=data[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]
  if i in iv:
   im=Image.open(io.BytesIO(b));im.thumbnail((1024,1024),Image.Resampling.LANCZOS);out=io.BytesIO()
   transparent=im.mode=='RGBA'and im.getchannel('A').getextrema()[0]<255
   if iv[i]not in noncolor and not transparent:
    im.convert('RGB').save(out,format='JPEG',quality=94,subsampling=0,optimize=True);mime='image/jpeg'
   else:
    if im.mode=='RGBA'and not transparent:im=im.convert('RGB')
    im.save(out,format='PNG',optimize=True);mime='image/png'
   b=out.getvalue()if name!='WaterBottle'else b'\0'*4;g['images'][iv[i]]['mimeType']=mime
  pad=(-offset)%4
  if pad:chunks.append(b'\0'*pad);offset+=pad
  v['byteOffset']=offset;v['byteLength']=len(b);chunks.append(b);offset+=len(b)
 for tex in g.get('textures',[]):
  if'EXT_texture_webp'in tex.get('extensions',{}):tex['source']=tex['extensions'].pop('EXT_texture_webp')['source']
 for key in ['extensionsUsed','extensionsRequired']:
  if key in g:g[key]=[x for x in g[key]if x not in['EXT_texture_webp','KHR_materials_diffuse_transmission','KHR_lights_punctual']]
 g.get('extensions',{}).pop('KHR_lights_punctual',None)
 for node in g.get('nodes',[]):node.get('extensions',{}).pop('KHR_lights_punctual',None)
 if name=='WaterBottle':
  # No manufacturer/organisation logos on the merchandise. Replace labelled bottle materials.
  for mat in g['materials']:
   mat['pbrMetallicRoughness']={'baseColorFactor':[.09,.19,.14,1],'metallicFactor':.65,'roughnessFactor':.28};mat.pop('emissiveTexture',None);mat['emissiveFactor']=[0,0,0];mat.pop('normalTexture',None);mat.pop('occlusionTexture',None)
 if name=='SheenChair':
  for mat in g['materials']:
   if mat.get('name')=='label':mat['pbrMetallicRoughness']={'baseColorFactor':[.20,.16,.10,1],'metallicFactor':0,'roughnessFactor':.8}
 if name=='WaterBottle':g.pop('images',None);g.pop('textures',None)
 binary=b''.join(chunks);binary+=b'\0'*((-len(binary))%4);g['buffers'][0]['byteLength']=len(binary);js=json.dumps(g,separators=(',',':')).encode();js+=b' '*((-len(js))%4);dest=O/(name+'.glb');dest.write_bytes(struct.pack('<III',0x46546c67,2,12+8+len(js)+8+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary)
 ledger.append({'asset':name,'file':str(dest.relative_to(P)),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'mesh_geometry_changed':False,'modifications':'Embedded images max 1024px PNG. Plant fireflies, lights, cameras and animation removed; unsupported diffuse transmission omitted. Bottle labels/materials replaced with unbranded metal. Chair underside label replaced.'});print(name,dest.stat().st_size,flush=True)
(P/'source/v10/imported-models.json').write_text(json.dumps(ledger,indent=2))
