from pathlib import Path
import json,gzip,struct,numpy as np
P=Path(__file__).resolve().parents[1];g=json.loads(gzip.decompress((P/'assets/art-v9.json.gz').read_bytes()));head={'surfaces':{},'colliders':{},'signs':g['signs'],'lights':g['lights']};chunks=[];offset=0
for field in ['surfaces','colliders']:
 for k,d in g[field].items():
  if field=='surfaces':head[field][k]={}
  for f,a in (d.items()if field=='surfaces'else [('v',d)]):
   raw=np.round(np.array(a),5).astype('<f4').tobytes();slot=[offset,len(raw)];offset+=len(raw);chunks.append(raw)
   if field=='surfaces':head[field][k][f]=slot
   else:head[field][k]=slot
header=json.dumps(head,separators=(',',':')).encode()
with gzip.open(P/'assets/art-v9.pack.gz','wb',compresslevel=9)as z:z.write(b'FY8\0'+struct.pack('<I',len(header))+header+b''.join(chunks))
print('ART_PACK', (P/'assets/art-v9.pack.gz').stat().st_size)
