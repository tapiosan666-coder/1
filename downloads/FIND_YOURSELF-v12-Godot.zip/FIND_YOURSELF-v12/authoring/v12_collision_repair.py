"""Restore missing physical faces directly from existing visible architecture. No extra blocking wall geometry."""
from pathlib import Path
import sys,numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
flags=read(P/'source/v12/boundary-flags.json');rows=[];coll={};packs=[load_pack(P/'assets/v10'/(n+'.pack.zst'))for n in ['base-b','base-site','fitout','art','architecture']]+[load_pack(P/'assets/v11/repairs.pack.zst')]
for r in flags:
 if r['floor']=='RF':continue
 pts=[q for q in r['issue_samples']if not q[4]];count=0
 for g in packs:
  for key,d in g['surfaces'].items():
   a=triangles(d);ct=a.mean(1);selected=np.zeros(len(a),bool)
   for x,y,z,v,c in pts:
    selected|=(a[:,:,1].min(1)<y)&(a[:,:,1].max(1)>y)&(a[:,:,0].min(1)<x+.35)&(a[:,:,0].max(1)>x-.35)&(a[:,:,2].min(1)<z+.35)&(a[:,:,2].max(1)>z-.35)
   if selected.any():coll.setdefault('v12_matched_visible_walls',[]).extend(a[selected].ravel().tolist());count+=int(selected.sum())
 rows.append({'id':r['id'],'missing_ray_samples':len(pts),'restored_visible_triangles':count,'locations':pts,'method':'Collision triangles copied from the existing visible wall faces, not new hidden walls.'})
save_zst(P/'assets/v12/boundary-physics.pack.zst',{'surfaces':{},'colliders':coll,'signs':[],'lights':[]});write(P/'source/v12/boundary-repairs.json',rows);print('MATCHED_VISIBLE_COLLIDERS',rows)
