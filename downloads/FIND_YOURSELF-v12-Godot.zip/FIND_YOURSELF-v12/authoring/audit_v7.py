from pathlib import Path
import sys,math,collections
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
P=Path(__file__).resolve().parents[1];D=read(P/'source/site-v7.json');B=read(P/'source/design-v6.json');checks=[];issues=[];rows=[]
def ck(id,ok,detail=None):checks.append({'id':id,'pass':bool(ok),'detail':detail})
ids=[]
for f in D['floors']:
 id=f['wing']+'-'+f['label'];stores=f['stores'];ids +=[s['id']for s in stores];ck(id+'/valid_slab',f['floor_plate'].is_valid)
 for s in stores:
  ck(s['id']+'/valid_polygon',s['polygon'].is_valid);ck(s['id']+'/door_on_shop_edge',s['polygon'].boundary.distance(Point(s['entry']))<.08,s['polygon'].boundary.distance(Point(s['entry'])));ck(s['id']+'/within_floor',s['polygon'].difference(f['floor_plate']).area<.05,s['polygon'].difference(f['floor_plate']).area)
  rows.append([f['wing'],f['label'],s['id'],s['category'],s['polygon'].area,s.get('sales',s['polygon']).area,s.get('backroom',Polygon()).area,s.get('frontage_m'),s.get('depth_m'),*s['entry']])
 for i,a in enumerate(stores):
  for b in stores[i+1:]:
   area=a['polygon'].intersection(b['polygon']).area
   if area>.00001:ck(a['id']+'/'+b['id']+'/store_overlap',area<.05,area)
 # Floor gap/role inspection must distinguish real named programme from full interior build completion.
 role_geometries=[f['public'],*[s['polygon']for s in stores],*[c['outline']for c in f['cores']],*[q['polygon']for q in f.get('program',[])],*[q['polygon']for q in f.get('service_zones',[])],*[q['polygon']for q in f.get('floor_roles',[])],*[q['geom']for q in f.get('landscape',[])],*[q['polygon']for q in f.get('gardens',[])]]
 for key in ['staff_corridor','staff_walk','outdoor_deck','outdoor_ground','indoor_public','core_free','construction_poche','loading_yard','enclosure']:
  q=f.get(key)
  if hasattr(q,'geom_type'):role_geometries.append(q)
 if f.get('parking'):
  pk=f['parking'];role_geometries.extend([pk['vehicle_aisles'],pk['protected_pedestrian'],*[s['polygon']for s in pk['stalls']]])
 roles=unary_union(role_geometries);leftover=f['floor_plate'].difference(roles)
 issues.append({'wing':f['wing'],'floor':f['label'],'source_named_role_uncovered_m2':leftover.area,'remaining_polygon':leftover,'inner_area_after_half_metre_inset_m2':leftover.buffer(-.5).area,'status':'not automatically a corridor; includes wall poche, decks and programme-specific parking. Physical visual review still needed','detailed_service_fitout_complete':False})
for lev in [0,1,2]:
 old=B['floors'][lev];new=next(f for f in D['floors']if f['wing']=='B'and f['level']==lev);newstores={s['id']:s for s in new['stores']}
 ck('B'+str(lev)+'/198_IDs_and_store_footprints_unchanged',all(s['id']in newstores and s['polygon'].symmetric_difference(newstores[s['id']]['polygon']).area<1e-7 for s in old['stores']))
for d in D['devices']:
 for row in d['floors']:
  if d['wing']not in 'ABC':continue
  f=next(f for f in D['floors']if f['wing']==d['wing']and f['level']==row['level']);ck(d['id']+'/'+row['label']+'/EV_opening',row['opening'].intersection(f['floor_plate']).area<1e-5,row['opening'].intersection(f['floor_plate']).area)
 for fl in d['flights']:
  for r in fl['ramps']:
   angle=math.degrees(math.atan2(r['y1']-r['y0'],math.dist(r['a'],r['b'])));ck(d['id']+f"/{fl['from']}/incline",angle<38,angle)
# Landings must already have a single structural floor owner before dropping redundant equipment collision faces.
for d in D['devices']:
 for r in d['floors']:
  if d['wing']in'ABC':owner=next(f['floor_plate']for f in D['floors']if f['wing']==d['wing']and f['level']==r['level'])
  elif d['wing'].startswith('P-'):owner=next(f['floor_plate']for fac in D['parking']['facilities']if fac['id']==d['wing']for f in fac['floors']if f['level']==r['level'])
  else:
   t=next(t for t in D['site']['pedestrian_towers']if t['id']==d['id']);owner=t['outline'].difference(t['lift_opening']).difference(t['stair_opening']if r['level'] else Polygon())
  missing=r['front'].difference(owner).area;ck(d['id']+'/'+r['label']+'/landing_has_structural_floor_owner',missing<1e-5,missing)
facilities=D['parking']['facilities'];capacity=sum(len(f['stalls'])for q in facilities for f in q['floors'])+len(D['site']['old_A22']['stalls'])+sum(len(f['parking']['stalls'])for f in D['floors']if f.get('parking'));ck('parking/6699_source_stalls',capacity==6699,capacity)
for fac in facilities:
 for r in fac['ramps']:
  pts=r['profile_xyz'];grade=max(abs((b[1]-a[1])/math.hypot(b[0]-a[0],b[2]-a[2]))for a,b in zip(pts,pts[1:]));ck(r['id']+'/profile_level_match',abs(pts[0][1]-r['lower_y'])<1e-8 and abs(pts[-1][1]-r['upper_y'])<1e-8);ck(r['id']+'/grade_matches_source',grade<.113,grade)
ck('IDs_unique',len(ids)==len(set(ids)),len(ids));protected=read(P/'source/protected-inputs-v7.json');bad=[p for p,v in protected.items()if not Path(p).is_file()or sha(p)!=v];ck('main_game_and_original_designs_unchanged',not bad,{'count':len(protected),'changed':bad})
report={'checks':checks,'passed':sum(c['pass']for c in checks),'failed':sum(not c['pass']for c in checks),'automatic_geometry_only':True,'human_playtest':False,'structural_engineering_verified':False,'RF_SUPPORT_16':'UNAPPROVED - no structural safety proof','capacity_stalls':capacity,'stores':len(ids),'unresolved_programme_records':issues,'changes':D['changes']}
write(P/'evidence/geometry-v7.json',report);csvwrite(P/'deliverables/store-ledger-v7.csv',['wing','floor','ID','category','total_m2','sales_m2','BOH_m2','frontage_m','depth_m','worldX','worldZ'],rows);print('AUDIT',report['passed'],report['failed']);print('FAILURES',[c for c in checks if not c['pass']])
