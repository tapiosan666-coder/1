"""Repair cadastral edges before generating walls. Keep baseline immutable. Entire scene evaluated from one revised inventory."""
from pathlib import Path
import sys,math,json,numpy as np,copy,os
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
from pack_tools_v11 import *
from shapely import contains_xy,constrained_delaunay_triangles
from shapely.ops import transform
P=Path(__file__).resolve().parents[1];BASE=Path(os.environ.get('FIND_YOURSELF_V10_BASELINE',str(P.parent/'FIND_YOURSELF-Site-v10-Unified')));floors=read(P/'source/v11/floors-updated.json');oldfloors=read(P/'source/v11/floors-baseline.json');changes=read(P/'source/v11/layout-changes.json');changed={r['id']for r in changes};scene=read(BASE/'source/v10/scene-art.json');oldscene=copy.deepcopy(scene);lookup={s['id']:(f,s)for f in floors for s in f['stores']};oldlookup={s['id']:(f,s)for f in oldfloors for s in f['stores']};F=read(P/'source/fitout-v8.json');M={};coll={};render_group='';rows=[];stock_glass=[]
def pos(x,y,z):return[round(float(x+429),5),round(float(y),5),round(float(z-46),5)]
exec((P/'authoring/mesh_primitives.py').read_text())
def toworld(g):return transform(lambda x,z,zz=None:(np.asarray(x)+429,np.asarray(z)-46),g)
def style(cat):
 if '靴'in cat:return'shoe'
 if any(x in cat for x in ['ファッション','服飾','衣料']):return'fashion'
 if '書'in cat:return'book'
 if any(x in cat for x in ['カフェ','食品','焼菓子']):return'cafe'
 return'homeware'
# Explicit representative shops, with dedicated uses; no partitioning/merging IDs for merchandising.
reps={'A1F-001':'grocery','A1F-003':'shoe','A1F-005':'homeware','B1-SW12':'travel','B1-SW32':'travel','B1-008':'homeware','B1-030':'beauty','B1-N03':'electronics'}
changed.update(reps)
oldMasks={};footMasks={}
for sid in changed:
 f,s=oldlookup[sid];poly=s['polygon'];stock=s.get('backroom',Polygon());oldMasks.setdefault(f['height'],[]).append(toworld(poly.boundary.buffer(.28,join_style=2).union(stock.boundary.buffer(.25,join_style=2))))
 if sid in reps:footMasks.setdefault(f['height'],[]).append(toworld(poly.buffer(.03)))
oldMasks={y:unary_union(g)for y,g in oldMasks.items()};footMasks={y:unary_union(g)for y,g in footMasks.items()}
front_by_id={r['id']:r for r in scene['frontages']};scene['frontages']=[r for r in scene['frontages']if r['id']not in changed];scene['signs']=[r for r in scene['signs']if r['store_id']not in changed];scene['hidden_sign_positions']=[]
all_doors=read(P/'source/scene-manifest.json')['staff_doors']+read(P/'source/site-manifest-v7.json')['staff_doors']
for sid in sorted(changed):
 f,s=lookup[sid];y=f['height'];pol=s['polygon'];stock=s.get('backroom',Polygon());stock=Polygon()if stock.is_empty else stock;sales=s.get('sales',pol);u=np.array(s['u']);n=np.array(s['n']);e=np.array(s['entry']);dw=float(s.get('door_width_m',2.4));st=reps.get(sid,style(s['category']));render_group='V11-WALL-'+sid
 # One canonical opaque boundary, with glass only on the customer frontage. All polygons have straight simplified edges.
 public=f['public'];segments=[]
 for ln in lines(pol.boundary.intersection(public.buffer(.055,join_style=2))):
  for a,b in zip(ln.coords, list(ln.coords)[1:]):
   a=np.array(a);b=np.array(b);v=b-a;l=np.linalg.norm(v)
   if l>.1 and abs(v.dot(u)/l)>.995:segments.append(LineString([a,b]))
 # Select the frontage at the actual entrance, not a rear edge with the same tangent.
 front=min(segments,key=lambda ln:ln.distance(Point(e)))if segments else LineString([e-u*dw/2,e+u*dw/2]);adj=[q for q in segments if q.distance(front)<.10];front=unary_union(adj)if adj else front
 t=[]
 for ln in lines(front):t.extend([(np.array(p)-e).dot(u)for p in ln.coords])
 lo=min(t)if t else-dw/2;hi=max(t)if t else dw/2
 opening=min(max(dw,(hi-lo)*.52),max(dw,(hi-lo)-.5),10.0)
 outer=pol.boundary.buffer(.12,join_style=2).intersection(pol);part=stock.boundary.intersection(sales.buffer(.02)).buffer(.10,join_style=2).intersection(pol);walls=outer.union(part);cuts=rect(e,u,opening,1.1)
 oldsign=oldlookup[sid][1]['entry'];scene['hidden_sign_positions'].append(pos(oldsign[0],y+3.35,oldsign[1]));scene['hidden_sign_positions'].append(pos(e[0],y+3.35,e[1]))
 # Preserve existing, authored staff door positions even where the record originated in runtime data.
 for d in all_doors:
  if sid in str(d['id'])and abs(d['p'][1]-y)<.1:cuts=cuts.union(rect((d['p'][0]-429,d['p'][2]+46),d['u'],float(d['leaf_width_m'])+.04,.9))
 glazing=walls.intersection(front.buffer(.14,join_style=2)).difference(stock.buffer(.025,join_style=2)).difference(cuts);opaque=walls.difference(glazing).difference(cuts);height=next(ff['height']for ff in floors if ff['wing']==f['wing']and ff['level']==f['level']+1)-y-(.70 if f['wing']=='B'else .42)
 extrude(opaque,y,height,'v10_chalk',True);extrude(glazing,y,.25,'v10_darkstone',True);extrude(glazing,y+.25,2.75,'glass',True);extrude(glazing,y+3.0,height-3.,'v10_chalk',True);extrude(walls.intersection(cuts),y+3.50,height-3.50,'v10_chalk',True)
 # Solid head/sides match the actual cutout, rather than floating boards in front of the old facade.
 for tt in [lo,hi]:extrude(rect(e+u*tt,u,.10,.28),y,3.5,'v10_metal',False)
 extrude(rect(e+u*(lo+hi)/2,u,hi-lo,.30),y+3.1,.40,'v10_oak'if st in['shoe','book','travel']else'v10_chalk',False)
 if sid in reps:surf(sales,y+.045,'v10_floor_A'if f['wing']=='A'else'v10_floor_B')
 scene['signs'].append({'store_id':sid,'p':pos(*(e-n*.20)[:1],0,0)if False else pos(e[0]-n[0]*.20,y+3.28,e[1]-n[1]*.20),'normal':(-n).tolist(),'width':max(1.,hi-lo-.4),'style':st})
 scene['frontages'].append({'id':sid,'wing':f['wing'],'category':s['category'],'style':st,'entry':s['entry'],'u':s['u'],'n':s['n'],'front':front,'frontage_m':hi-lo,'new_opening_m':opening,'original_plot_unchanged':sid not in{r['id']for r in changes}})
 rows.append({'id':sid,'gross_m2':pol.area,'sales_m2':sales.area,'backroom_m2':stock.area,'glazing_in_backroom_m2':glazing.intersection(stock).area,'entry':pos(e[0],y,e[1]),'opening_m':opening,'reason':'Canonical wall regenerated after plot allocation; sales/stock and customer/service faces distinct.'})
 stock_glass.append({'id':sid,'pass':glazing.intersection(stock).area<1e-6})
# Remove geometry owned by the old footprints before adding the new partition system.
wallmats={'plaster','wall_sand','wall_chalk','wall_sage','wall_taupe','wall_taupe','dark_stone','glass','v10_chalk','v10_metal','v10_oak','v10_darkstone','v10_clear_glass'}
pack_audit=[]
if '--overlay-only'in sys.argv:pack_audit=read(P/'source/v11/wall-audit.json')['input_output']
for name in ([]if '--overlay-only'in sys.argv else['base-b','base-site','base-site-C-option','fitout','art','architecture']):
 g=load_pack(BASE/'assets/v10'/(name+'.pack.zst'));removed=0
 for key,d in list(g['surfaces'].items()):
  mat,_,group=key.partition('@@');ts=triangles(d);ct=ts.mean(axis=1);drop=np.zeros(len(ct),bool)
  sid=next((x for x in changed if group==x or group.endswith('-'+x)),None)
  if sid:
   yy=lookup[sid][0]['height'];drop=(ct[:,1]>=yy-.01)&(ct[:,1]<yy+5.14)
   # Preserve structure/high ceiling; floor is visual only in these store-owned groups.
   drop&=((mat in wallmats)&(np.ptp(ts[:,:,1],axis=1)>.04))|((sid in reps)&(ct[:,1]<yy+2.8))|(group.startswith("V10-FRONT-"))
  # Delete luminaires only where the next structural slab is absent. No decorative cover wall is added.
  if mat in['light','v8_light','v9_light','v10_light','v8_led','v9_glow','v10_emitter']and not group.startswith(('V9-PARKLIGHT-','V10-FRONT-')):
   for ff in floors:
    if ff['level']not in[0,1,2]:continue
    above=next((x for x in floors if x['wing']==ff['wing']and x['level']==ff['level']+1),None)
    if above is None:continue
    mask=(ct[:,1]>ff['height']+2.5)&(ct[:,1]<above['height']-.05)&contains_xy(toworld(ff['public']),ct[:,0],ct[:,2])
    unsupported=~contains_xy(toworld(above['floor_plate'].buffer(.05)),ct[:,0],ct[:,2]);drop|=mask&unsupported
  if group.startswith('V10-BALUSTRADE-'):drop[:]=True
  if drop.any():g['surfaces'][key]=retain(d,~drop);removed+=int(drop.sum())
 for mat,data in g['colliders'].items():
  ts=np.asarray(data).reshape(-1,3,3);ct=ts.mean(axis=1);drop=np.zeros(len(ct),bool)
  if mat in wallmats:
   for yy,mask in oldMasks.items():drop|=(ct[:,1]>=yy-.02)&(ct[:,1]<yy+5.14)&(np.ptp(ts[:,:,1],axis=1)>.05)&contains_xy(mask,ct[:,0],ct[:,2])
  if mat not in ['stone','step']:
   for yy,mask in footMasks.items():drop|=(ct[:,1]>yy+.05)&(ct[:,1]<yy+2.8)&contains_xy(mask,ct[:,0],ct[:,2])
  g['colliders'][mat]=ts[~drop].ravel()
 pack_audit.append(dict(save_zst(P/'assets/v10'/(name+'.pack.zst'),g),removed_triangles=removed));print(name,removed,flush=True)
# Mutually shared walls are generated from the revised inventory, not boxed over the residual.
# Finish only existing guardrail footprints; no new walking surface or new hole is introduced.
for f in floors:
 if f['level']<=0:continue
 rails=f.get('guardrails',Polygon())
 if rails.is_empty:continue
 render_group='V11-GUARD-'+f['wing']+'-'+f['label'];skin=rails.buffer(-.025,join_style=2);rail_h=1.15 if f['wing']=='B'else 1.10
 if not skin.is_empty:extrude(skin,f['height']+rail_h,.035,'v10_metal',False)
 for po in polys(rails):
  ln=LineString(po.minimum_rotated_rectangle.exterior.coords);# mounting positions are derived from actual rail geometry
  points=list(po.exterior.coords)
  for i in range(0,len(points)-1,max(1,len(points)//8)):
   p=Point(points[i]);pad=rect((p.x,p.y),(1,0),.08,.08)
   if f['floor_plate'].buffer(.07).covers(pad):extrude(pad,f['height']+.02,rail_h-.02,'v10_metal',False)
for f in floors:
 for bay in f.get('forecourt_extensions',[]):
  render_group='V11-CORE-FORECOURT-'+f['label'];surf(bay['geometry'],f['height']+.041,'v10_floor_A'if f['level']==0 else'stone')
# Industry-specific variants replace the generic bottle fallback wherever the actual category is known.
instances=[]
for d in scene['instances']:
 sid=d['group'];cat=lookup[sid][1]['category']if sid in lookup else''
 if sid in reps:continue
 if d['asset']=='models/WaterBottle'and not any(x in cat for x in ['食品','カフェ','飲食']):continue
 if d['asset'].startswith('retail/product_bay'):
  if '靴'in cat:d['asset']='../v11/models/shoe_shelf'
  elif '旅行'in cat or 'アウトドア'in cat:d['asset']='../v11/models/travel_display'
  elif '美容'in cat or 'ケア'in cat:d['asset']='../v11/models/beauty_display'
  elif '家電'in cat or 'モバイル'in cat:d['asset']='retail/electronics_table'
  else:d['asset']='../v11/models/homeware_display'
 if d['group'].startswith('PUBLIC')and d['p'][2]<-130 and d['asset']in['models/SheenChair','models/SheenWoodLeatherSofa']:d['asset']='../v11/models/outdoor_chair'
 instances.append(d)
scene['instances']=instances
routes=read(P/'source/physical-routes-v11.json')
def add(asset,c,u,n,sid,dims,y=0):scene['instances'].append({'asset':asset,'p':pos(c[0],y,c[1]),'u':list(u),'front':list(n),'group':sid,'max_xz':list(dims),'target_height':None,'foliage_only':False})
for sid,kind in reps.items():
 render_group='V11-FIXTURE-'+sid
 f,s=lookup[sid];y=f['height'];e=np.array(s['entry']);u=np.array(s['u']);n=np.array(s['n']);keep=[LineString(s.get('main_route',[s['entry'],(e+n*3).tolist()])).buffer(1.15,cap_style=2,join_style=2)]
 for r in routes:
  if sid in r['id']:keep.append(LineString([(p[0]-429,p[2]+46)for p in r['points']]).buffer(.70,cap_style=2,join_style=2))
 safe=s['sales'].buffer(-.40,join_style=2).difference(unary_union(keep));placed=[];rstep=4.3 if kind=='grocery'else 3.3
 # Near entrance: low produce islands; wall and aisle merchandising further inside.
 minx,minz,maxx,maxz=safe.bounds;count=0
 cash_reservations=[rect(e+n*2.7+u*sg*(4.3 if kind=='grocery'else 2.1),u,*( (2.8,.8)if kind=='grocery'else(1.7,.75)))for sg in[-1,1]]
 wall_count=0
 for edge in lines(s['sales'].boundary):
  co=list(edge.coords)
  for aa,bb in zip(co,co[1:]):
   aa=np.array(aa);bb=np.array(bb);length=np.linalg.norm(bb-aa)
   if length<3:continue
   wu=(bb-aa)/length;wn=np.array([-wu[1],wu[0]])
   if not s['sales'].covers(Point((aa+bb)/2+wn*.3)):wn=-wn
   for tt in np.arange(1.2,length-1.0,2.5):
    c=aa+wu*tt+wn*.45;fp=rect(c,wu,2.,.60)
    if not s['sales'].buffer(-.10).covers(fp)or fp.intersects(unary_union(keep))or any(fp.distance(q)<.6 for q in cash_reservations+placed):continue
    if f['public'].distance(Point(aa+wu*tt))<.10:continue
    asset={'grocery':'refrigerated_case','shoe':'shoe_shelf','homeware':'homeware_display','travel':'travel_display','beauty':'beauty_display','electronics':'electronics_table'}[kind]
    add('retail/electronics_table'if kind=='electronics'else'../v11/models/'+asset,c,wu,wn,sid,(2.,.60),y);extrude(fp,y,.10,'v10_darkstone',True);extrude(fp,y,1.75 if kind not in['travel','electronics']else .95,'v11_fixture_proxy',True);placed.append(fp);wall_count+=1
    if kind=='shoe':
     for yy in[.19,.71,1.23]:
      for off in[-.65,0,.65]:add('models/MaterialsVariantsShoe',c+wu*off,wu,wn,sid,[.35,.4],y+yy);scene['instances'][-1]['target_height']=.17
    if wall_count>=(24 if kind=='grocery'else 8):break
   if wall_count>=(24 if kind=='grocery'else 8):break
  if wall_count>=(24 if kind=='grocery'else 8):break
 candidates=[(xx,zz)for xx in np.arange(minx+1.2,maxx,rstep)for zz in np.arange(minz+1.2,maxz,rstep)]
 for xx,zz in sorted(candidates,key=lambda p:(p[0]-e[0])**2+(p[1]-e[1])**2):
  c=np.array([xx,zz]);dims=(2.1,.96)if kind=='grocery'else(1.9,.65);fp=rect(c,u,*dims)
  if not safe.covers(fp)or any(fp.distance(q)<.7 for q in cash_reservations)or any(fp.distance(q)<1.1 for q in placed):continue
  depth=(c-e).dot(n);asset={'grocery':'grocery_gondola','shoe':'shoe_shelf','homeware':'homeware_display','travel':'travel_display','beauty':'beauty_display','electronics':'electronics_table'}[kind]
  if kind=='grocery'and depth<12:asset='produce_island'
  if kind=='grocery'and fp.distance(s['sales'].boundary)<1.7:asset='refrigerated_case'
  path='retail/electronics_table'if kind=='electronics'else'retail/lifestyle_table_'+str(count%2)if kind=='homeware'else'../v11/models/'+asset;add(path,c,u,-n,sid,dims,y);extrude(fp,y,.10,'v10_darkstone',True);extrude(fp,y,(.92 if kind=='grocery'and asset=='produce_island'else 1.72 if kind=='grocery'else 1.75 if kind=='shoe'else .95 if kind in['travel','electronics']else 1.95),'v11_fixture_proxy',True);placed.append(fp);count+=1
  if kind=='shoe':
   for z in[.19,.71,1.23]:
    for a in[-.65,0,.65]:
     q=c+u*a;add('models/MaterialsVariantsShoe',q,u,-n,sid,[.35,.40],y+z);scene['instances'][-1]['target_height']=.17
  if count>=(64 if kind=='grocery'else 18):break
 # Cash desks are beside the entrance, clear of the straight customer path and existing doors.
 for sg in[-1,1]:
  c=e+n*2.7+u*sg*(4.3 if kind=='grocery'else 2.1);dim=(2.8,.8)if kind=='grocery'else(1.7,.75);fp=rect(c,u,*dim)
  if safe.covers(fp)and all(fp.distance(p)>.3 for p in placed):
   add('../v11/models/checkout_lane'if kind=='grocery'else'retail/retail_counter',c,u,-n,sid,dim,y);extrude(fp,y,.82,'v10_oak',True)
 scene['lights']=[l for l in scene['lights']if l.get('store')!=sid]
 # Lights have a checked physical ceiling above them. Unlit voids are not "fixed" with floating fixtures.
 above=next(f2 for f2 in floors if f2['wing']==f['wing']and f2['level']==f['level']+1)
 for xx in np.arange(minx+2,maxx,7):
  for zz in np.arange(minz+2,maxz,7):
   if s['sales'].covers(Point(xx,zz))and above['floor_plate'].covers(Point(xx,zz)):
    scene['lights'].append({'p':pos(xx,above['height']-(.70 if f['wing']=='B'else .42)-.12,zz),'energy':1.0,'range':7,'color':[1,.94,.85],'shadow':False,'store':sid});render_group='V11-LIGHT-'+sid;extrude(rect((xx,zz),u,1.6,.12),above['height']-(.70 if f['wing']=='B'else .42)-.04,.04,'v10_light',False)
 print('REPRESENTATIVE',sid,kind,count,flush=True)
# New architecture includes the repaired, visible walls and matching physical colliders.
M={k:v for k,v in M.items()if not k.startswith('v11_fixture_proxy@@')}
extra=save_zst(P/'assets/v11/repairs.pack.zst',{'surfaces':M,'colliders':coll,'signs':[],'lights':[]});write(P/'source/v11/scene-art.json',scene);write(P/'source/v11/wall-audit.json',{'stores':rows,'backroom_glazing_checks':stock_glass,'input_output':pack_audit,'new_geometry':extra,'main_game_modified':False,'structural_engineering_verified':False})
# Authoritative current site for edit/review, without distributing duplicate historical snapshots.
site=read(P/'source/site-v7.json');site['floors']=floors;site['revision']='v11 local cadastral and safety repairs; original site baseline preserved externally';write(P/'source/site-v11.json',site)
print('ENVIRONMENT_COMPLETE',len(changed),len(scene['instances']),flush=True)
