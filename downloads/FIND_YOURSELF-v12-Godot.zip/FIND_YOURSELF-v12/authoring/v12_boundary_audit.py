"""All-store boundary coverage from rendered and collision triangles. Probe openings separately; never infer visual quality from topology."""
from pathlib import Path
import sys,math,numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely.strtree import STRtree
F=read(P/'source/v11/floors-updated.json');A=read(P/'source/v11/scene-art.json');front={q['id']:q for q in A['frontages']};doors=read(P/'source/scene-manifest.json')['staff_doors']+read(P/'source/site-manifest-v7.json')['staff_doors'];packs=[load_pack(P/'assets/v10'/(n+'.pack.zst'))for n in ['base-b','base-site','fitout','art','architecture']]+[load_pack(P/'assets/v11/repairs.pack.zst')];visible=np.concatenate([triangles(d)for g in packs for d in g['surfaces'].values()]);physics=np.concatenate([np.asarray(d).reshape(-1,3,3)for g in packs for d in g['colliders'].values()]);rows=[];flags=[]
def slice_tri(a,y):
 lo=a[:,:,1].min(1);hi=a[:,:,1].max(1);out=[]
 for t in a[(lo<y-1e-6)&(hi>y+1e-6)]:
  pts=[]
  for i,j in [(0,1),(1,2),(2,0)]:
   if(t[i,1]-y)*(t[j,1]-y)<0:
    p=t[i]+(t[j]-t[i])*(y-t[i,1])/(t[j,1]-t[i,1]);pts.append((p[0]-429,p[2]+46))
  if len(pts)==2 and math.dist(*pts)>.001:out.append(LineString(pts))
 return out
for level in [-1,0,1,2,3]:
 y=HEIGHT[level]+1.15;vl=slice_tri(visible,y);cl=slice_tri(physics,y);vt=STRtree(vl);ct=STRtree(cl)
 for f in [f for f in F if f['level']==level]:
  for s in f['stores']:
   sid=s['id'];e=np.array(s['entry']);u=np.array(s['u']);w=front.get(sid,{}).get('new_opening_m',s.get('door_width_m',2.4));fr=front.get(sid,{});oe=e+u*(fr.get('opening_t0',-w/2)+fr.get('opening_t1',w/2))/2;opening=rect(oe,u,w+.08,1.2);samples=[];miss=[]
   for d in doors:
    if sid in str(d['id'])and abs(d['p'][1]-f['height'])<.1:opening=opening.union(rect((d['p'][0]-429,d['p'][2]+46),d['u'],d['leaf_width_m']+.08,1.0))
   for ln in lines(s['polygon'].boundary):
    co=list(ln.coords)
    for a,b in zip(co,co[1:]):
     a=np.array(a);b=np.array(b);v=b-a;length=np.linalg.norm(v)
     if length<.08:continue
     v/=length;n=np.array([-v[1],v[0]])
     for t in np.linspace(.04,length-.04,max(2,math.ceil(length/.5))):
      q=a+v*t
      if opening.covers(Point(q)):continue
      ray=LineString([q-n*.32,q+n*.32]);vv=bool(len(vt.query(ray,predicate='intersects')));cc=bool(len(ct.query(ray,predicate='intersects')));samples.append([float(q[0]+429),f['height']+1.15,float(q[1]-46),vv,cc])
      if not vv or not cc:miss.append(samples[-1])
   row={'id':sid,'wing':f['wing'],'floor':f['label'],'boundary_samples':len(samples),'render_uncovered':sum(not q[3]for q in samples),'collision_uncovered':sum(not q[4]for q in samples),'samples':samples,'issue_samples':miss,'status':'REVIEW'if miss else'BOUNDARY_COVERED'};rows.append(row)
   if miss:flags.append({k:v for k,v in row.items()if k!='samples'})
 print('BOUNDARY_LEVEL',level,'stores',len(rows),'flagged',len(flags),flush=True)
write(P/'source/v12/boundary-audit.json',{'method':'Cross-section of actual mesh/collision at floor+1.15m, <=0.5m edge spacing, +/-0.32m ray; declared entrances/staff doors excluded. Not architectural approval.','stores':rows,'flagged_stores':len(flags),'human_playtest':False});write(P/'source/v12/boundary-flags.json',flags);print('BOUNDARY_COMPLETE',len(rows),len(flags),flush=True)
