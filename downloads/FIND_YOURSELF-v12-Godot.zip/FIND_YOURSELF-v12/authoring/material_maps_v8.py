"""Deterministic original PBR texture maps; metres and roughness in finish_v8.gd."""
from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter
P=Path(__file__).resolve().parents[1]/'assets/v8';N=768;rng=np.random.default_rng(5588);yy,xx=np.mgrid[:N,:N]
def fbm(seed):
 r=np.random.default_rng(seed);s=np.zeros((N,N),np.float32)
 for i,n in enumerate([6,12,24,48,96,192]):
  a=np.uint8(r.uniform(0,255,(n,n)));b=np.asarray(Image.fromarray(a).resize((N,N),Image.Resampling.BICUBIC),dtype=float)/255-.5;s+=b/(1.6**i)
 return s
noise=fbm(184);fine=fbm(991)
for name,base,rough in [('limestone',(211,208,198),.26),('travertine',(193,179,155),.39),('pavers',(164,155,138),.76),('oak',(140,111,78),.47),('plaster',(227,224,215),.84),('slate',(68,76,74),.42),('brick',(173,135,109),.78)]:
 if name=='oak':
  # Nested growth rings and streaks with irregular phase rather than regular stripes.
  warp=fbm(388)*70;phase=yy*.11+warp+np.sin(xx*.003)*3
  v=(np.sin(phase)*.15+np.sin(phase*2.3)*.06+noise*.5);height=v*.06
  colour=np.array(base)[None,None,:]+v[:,:,None]*28+fine[:,:,None]*4
 elif name=='travertine':
  v=np.sin(yy*.025+noise*3)*2+noise*9;colour=np.array(base)[None,None,:]+v[:,:,None];height=noise*.04
 elif name=='limestone':
  vein=np.exp(-np.abs(noise-.06)*70)*.035;v=noise*8-fine*3-vein*45
  colour=np.array(base)[None,None,:]+v[:,:,None];height=fine*.018
 else:
  v=noise*(10 if name!='plaster'else 4)+fine*3;colour=np.array(base)[None,None,:]+v[:,:,None];height=fine*.06
 if name=='pavers':height=noise*.10+fine*.045
 Image.fromarray(np.uint8(np.clip(colour,0,255))).save(P/(name+'.png'))
 gx=(np.roll(height,-1,axis=1)-np.roll(height,1,axis=1))*14;gy=(np.roll(height,-1,axis=0)-np.roll(height,1,axis=0))*14
 nn=np.stack([-gx,-gy,np.ones_like(gx)],axis=2);nn/=np.linalg.norm(nn,axis=2,keepdims=True)
 Image.fromarray(np.uint8((nn*.5+.5)*255)).save(P/(name+'-normal.png'))
 Image.fromarray(np.uint8(np.clip((rough+noise*.08)*255,0,255))).save(P/(name+'-rough.png'))
print('21 original albedo / normal / roughness maps')

from PIL import ImageDraw,ImageFont
im=Image.new('RGB',(1024,512));dr=ImageDraw.Draw(im);ft=ImageFont.truetype(str(P/'fonts/DejaVuSerif.ttf'),12);small=ImageFont.truetype(str(P/'fonts/DejaVuSans.ttf'),8)
names=['BOTANICA','STILL LIFE','THE CITY','OBJECTS','SLOW DAYS','LIGHT','ARCHIVE','ORIENNE','MATERIAL','COAST','FIELD NOTES','FORM','GARDENS','HOME','EDITION','NATURE']
cols=['#314941','#a5613d','#d3c5a5','#34445a','#666849','#a38c64','#aeaaa0','#6d3534']
for i in range(32):
 x=(i%16)*64;y=(i//16)*256;bg=cols[i%len(cols)];dr.rectangle((x,y,x+63,y+255),fill=bg)
 dr.line((x+2,y,x+2,y+255),fill='#c8c0ab',width=1)
 dr.rectangle((x+7,y+16,x+55,y+22),fill='#d9c99d');dr.text((x+9,y+43),str(1980+i),font=small,fill='#eee5cc')
 word=names[i%len(names)]
 for j,letter in enumerate(word[:13]):dr.text((x+24,y+62+j*11),letter,font=ft,fill='#f3e9d4')
 dr.text((x+7,y+233),'FV / '+str(i+1),font=small,fill='#e9dfc7')
im.save(P/'book-spines.png')
