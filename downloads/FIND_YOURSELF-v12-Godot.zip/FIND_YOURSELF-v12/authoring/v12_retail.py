"""Six industry-specific pilot stores; spatial roles, fixtures and clearances from actual sales polygons."""
from pathlib import Path
import sys,numpy as np,copy,math
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import contains_xy,constrained_delaunay_triangles
from shapely.ops import transform
F=read(P/'source/v11/floors-updated.json');lookup={s['id']:(f,s)for f in F for s in f['stores']};scene=read(P/'source/v11/scene-art.json');routes=read(P/'source/physical-routes-v11.json');reps={'C1F-CW-1':'apparel','A1F-005':'homeware','B1-030':'beauty','A1F-007':'book','B1-N03':'electronics','C1F-CSW-3':'cafe'};M={};coll={};render_group='';rows=[];paths=[]
def pos(x,y,z):return[float(x+429),float(y),float(z-46)]
exec((P/'authoring/mesh_primitives.py').read_text())
scene['instances']=[i for i in scene['instances']if i['group']not in reps]
def world(g):return transform(lambda x,z,zz=None:(np.asarray(x)+429,np.asarray(z)-46),g)
# Remove inherited fixture geometry and collision within pilot sales polygons. Keep boundary walls and stockrooms.
masks={}
for sid in reps:
 f,s=lookup[sid];masks.setdefault(f['height'],[]).append(world(s['sales'].buffer(-.32,join_style=2)))
masks={y:unary_union(v)for y,v in masks.items()}
for name,folder in ([] if '--layout-only' in sys.argv else [('base-b','v10'),('base-site','v10'),('C-outlet','v12'),('fitout','v10'),('art','v10'),('architecture','v10'),('repairs','v11'),('repairs-C','v12')]):
 path=P/'assets'/folder/(name+'.pack.zst');g=load_pack(path);removed=0
 for key,d in list(g['surfaces'].items()):
  mat,_,group=key.partition('@@');a=triangles(d);ct=a.mean(1);drop=np.zeros(len(a),bool)
  if any(group==sid or group in['V11-FIXTURE-'+sid,'V8-FITOUT-'+sid]for sid in reps):
   for y,mask in masks.items():drop|=(ct[:,1]>y+.07)&(ct[:,1]<y+2.85)&contains_xy(mask,ct[:,0],ct[:,2])
  # v11 fixture group includes deliberately invisible collision proxy; delete every old pilot proxy.
  if group.startswith('V11-FIXTURE-')and group[12:]in reps:drop[:]=True
  if drop.any():g['surfaces'][key]=retain(d,~drop);removed+=int(drop.sum())
 for mat,v in g['colliders'].items():
  a=np.asarray(v).reshape(-1,3,3);ct=a.mean(1);drop=np.zeros(len(a),bool)
  for y,mask in masks.items():drop|=(ct[:,1]>y+.07)&(ct[:,1]<y+2.85)&contains_xy(mask,ct[:,0],ct[:,2])
  g['colliders'][mat]=a[~drop].ravel()
 save_zst(path,g);print('RETAIL_REMOVE',name,removed,flush=True)
for sid,kind in reps.items():
 f,s=lookup[sid];y=f['height'];u=np.array(s['u']);n=np.array(s['n']);e=np.array(s['entry']);sales=s['sales'];render_group='V12-RETAIL-'+sid;placed=[];records=[]
 main=LineString(s.get('main_route',[e.tolist(),(e+n*5).tolist()]));keep=main.buffer(1.05,cap_style=2,join_style=2).union(rect(e,u,min(8,s.get('door_width_m',2.4)+1.2),3.0))
 for r in routes:
  if sid in r['id']:keep=keep.union(LineString([(p[0]-429,p[2]+46)for p in r['points']]).buffer(.72,cap_style=2,join_style=2))
 safe=sales.buffer(-.3,join_style=2).difference(keep);co=np.array(sales.exterior.coords)if sales.geom_type=='Polygon'else np.concatenate([np.array(p.exterior.coords)for p in polys(sales)]);T=(co-e)@u;D=(co-e)@n;depth=max(D);width=max(T)-min(T)
 def put(asset,c,uu,nn,dim,height,role,gap=.70):
  fp=rect(c,uu,*dim)
  if not safe.covers(fp)or any(fp.distance(p)<gap for p in placed):return False
  placed.append(fp);scene['instances'].append({'asset':asset,'p':pos(c[0],y,c[1]),'u':list(uu),'front':list(nn),'group':sid,'max_xz':list(dim),'target_height':None,'foliage_only':False});extrude(fp,y,height,'v12_fixture_proxy',True);records.append({'asset':asset,'world':pos(c[0],y,c[1]),'footprint':fp,'height':height,'role':role});return True
 # Wall merchandising varies by industry and only occupies opaque sides/rear, never the entrance glazing.
 wallasset={'apparel':'retail/garment_rack_1','homeware':'../v11/models/homeware_display','beauty':'retail/cosmetic_bay','book':'retail/book_wall_1','electronics':'../v12/models/electronics_media_wall','cafe':'retail/cafe_wall'}[kind];wall_dims=(3.4,.62)if kind=='electronics'else(1.4,2.2)if kind=='cafe'else(2.05,.65)
 if kind=='cafe':wallasset='../v12/models/cafe_booth'
 wall_count=0
 for ln in lines(sales.boundary):
  for aa,bb in zip(list(ln.coords),list(ln.coords)[1:]):
   aa=np.array(aa);bb=np.array(bb);L=np.linalg.norm(bb-aa)
   if L<3:continue
   wu=(bb-aa)/L;wn=np.array([-wu[1],wu[0]])
   if not sales.covers(Point((aa+bb)/2+wn*.4)):wn=-wn
   if f['public'].distance(Point((aa+bb)/2))<.15:continue
   for t in np.arange(wall_dims[0]/2+.35,L-wall_dims[0]/2,wall_dims[0]+.3):
    wa='retail/book_wall_'+str(wall_count%3)if kind=='book'else'retail/garment_rack_'+str(wall_count%3)if kind=='apparel'else wallasset
    if kind=='cafe'and wall_count>=8:continue
    if put(wa,aa+wu*t+wn*(1.55 if kind=='cafe'else .72),wu,wn,wall_dims,2.24 if kind=='book'else 1.05 if kind=='cafe'else 1.85,'wall banquette seating'if kind=='cafe'else'wall category display',.40 if kind=='cafe'else .15):wall_count+=1
 # Checkout near entrance but beside decompression/queue area. This is a service location, not a product island.
 checkout=False
 for d in [3.6,4.6,5.6,6.6]:
  for t in [3.2,-3.2,5,-5,6.5,-6.5]:
   if put('retail/cafe_counter'if kind=='cafe'else'retail/retail_counter',e+n*d+u*t,u,-n,(2.5,1.0),1.55 if kind=='cafe'else 1.15,'checkout/service counter',.8):checkout=True;break
  if checkout:break
 if kind in ['book','apparel']:
  featured=False
  for dd in [4.4,6.5,8.5]:
   for tt in [-3.3,3.3,-5.5,5.5]:
    if put('../v12/models/book_curated_table'if kind=='book'else'../v12/models/apparel_fold_table',e+n*dd+u*tt,u,n,(2.1,1.05),1.05,'new releases / folded knit entrance feature',.75):featured=True;break
   if featured:break
 # Sector-specific central programmes. Tables do not share a universal gondola layout.
 patterns={
 'apparel':[(d,t,'retail/garment_rack_'+str(i%3),(2.1,.78),1.65,'seasonal hanging collection')for i,(d,t)in enumerate([(6,-3),(6,3),(10,-3),(10,3),(14,-3),(14,3)])]+[(4.3,0,'../v12/models/apparel_fold_table',(2.1,1.),1.05,'entrance folded knit feature')],
 'homeware':[(d,t,'../v12/models/home_dining_vignette',(1.85,2.05),1.12,'dining room scene / tableware')for d,t in[(6,-3.6),(11,3.6),(16,-3.6)]]+[(d,t,'retail/lifestyle_table_1',(2.,.85),1.05,'seasonal ceramics')for d,t in[(6,3.6),(11,-3.6),(16,3.6)]],
 'beauty':[(d,t,'../v12/models/beauty_consultation',(2.5,.85),1.75,'consultation / tester mirrors')for d,t in[(5,3.2),(9,-3.2),(13,3.2)]]+[(d,t,'retail/cosmetic_bay',(2.05,.60),2.1,'skincare collection')for d,t in[(7,-3.8),(12,-3.8),(17,-3.8)]],
 'book':[(d,t,'retail/book_island_'+str(i%2),(2.05,.75),1.52,'browsing bookshelf / cross aisle')for i,(d,t)in enumerate([(6,-3),(6,3),(10,-3),(10,3),(14,-3),(14,3),(18,-3),(18,3)])]+[(4.2,0,'../v12/models/book_curated_table',(2.1,1.05),1.,'new release table')],
 'electronics':[(d,t,'retail/electronics_table',(2.05,.85),1.4,'secured hands-on device demonstration')for d,t in[(5,-3),(5,3),(9,-3),(9,3),(13,-3),(13,3),(17,-3),(17,3)]],
 'cafe':[(d,t,'../v12/models/cafe_booth',(1.4,2.2),1.05,'four seat upholstered booth')for d,t in[(7,-4),(12,-4),(17,-4)]]+[(d,t,'retail/cafe_table',(1.05,2.3),.9,'two seat table')for d,t in[(6,4),(10,4),(14,4),(18,4),(10,0),(15,0)]]}
 if kind=='cafe':
  patterns[kind]+=[(d,t,'retail/cafe_table',(1.05,2.3),.90,'two-seat dining zone / transverse aisle')for d in [5,9,13,17,21,25]for t in [-12,-8,-4,0,4,8,12]]
 if kind=='beauty':
  patterns[kind]+=[(d,t,'retail/cosmetic_bay',(2.05,.6),2.1,'makeup and skincare collection')for d in [6,10,14,18]for t in [-8,-4,4,8]]
 island_count=0
 for d,t,asset,dim,h,role in patterns[kind]:
  if kind=='book'and asset.startswith('retail/book_island_'):continue
  if put(asset,e+n*d+u*t,u,n,dim,h,role,1.1):island_count+=1
 if kind=='book':
  for dd in np.arange(6,max(8,depth-2),3.8):
   for tt in [-1.6,4.8]:
    if put('../v12/models/book_double_gondola_'+str(int(dd)%2),e+n*dd+u*tt,n,u,(2.05,.82),1.52,'double-faced browsing row / cross aisle',1.1):island_count+=1
 # Deep side bays: explicitly named programme extensions, aligned to the store axis; preserve cross aisles.
 if kind in['apparel','electronics']:
  for d in np.arange(7,max(8,depth-2),4.1):
   for t in np.arange(min(T)+2,max(T)-1,3.7):
    asset={'book':'retail/book_island_0','apparel':'retail/garment_rack_2','electronics':'retail/electronics_table'}[kind]
    if put(asset,e+n*d+u*t,u,n,(2.05,.8),1.52 if kind=='book'else 1.4,'category bay with cross aisle',1.1):island_count+=1
 # Clear route samples are independently tested in Godot, including mid-store and stock access.
 rr=[]
 customer_segments=lines(main.intersection(sales.buffer(-.55,join_style=2)))
 customer_segments=[ln for ln in customer_segments if ln.length>.2]
 for ln in customer_segments:
  for a,b in zip(ln.coords,list(ln.coords)[1:]):
   if math.dist(a,b)>.02:rr.append([pos(a[0],y,a[1]),pos(b[0],y,b[1])])
 for a,b in []:
  if math.dist(a,b)>.02:rr.append([pos(a[0],y,a[1]),pos(b[0],y,b[1])])
 paths.append({'id':sid,'kind':kind,'main_segments':rr});rows.append({'id':sid,'industry':kind,'gross_m2':s['polygon'].area,'sales_m2':sales.area,'wall_displays':wall_count,'central_fixtures':island_count,'checkout_placed':checkout,'fixtures':records,'fixture_footprint_m2':sum(p.area for p in placed),'reserved_primary_aisle_width_m':2.1,'policy':'entry decompression / wall categories / purpose-specific central programme / checkout; original stock and store IDs unchanged','human_playtest':False})
 print('RETAIL_PILOT',sid,kind,'wall',wall_count,'islands',island_count,'checkout',checkout,flush=True)
M={k:v for k,v in M.items()if not k.startswith('v12_fixture_proxy@@')}
save_zst(P/'assets/v12/retail.pack.zst',{'surfaces':M,'colliders':coll,'signs':[],'lights':[]});write(P/'source/v12/scene-art.json',scene);write(P/'source/v12/retail-layouts.json',rows);write(P/'source/v12/retail-paths.json',paths)
