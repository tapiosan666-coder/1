from pathlib import Path
import sys,json,gzip,numpy as np,hashlib
from shapely import contains_xy
from shapely.geometry import shape
from shapely.affinity import translate
from shapely.ops import unary_union
P=Path(__file__).resolve().parents[1];fit=json.loads((P/'source/fitout-v8.json').read_text());rep=fit['replacement'];polys={k:translate(shape(v['sales']).buffer(-.22),429,-46)for k,v in rep.items()};union=unary_union(list(polys.values()));materials=set(next(iter(rep.values()))['remove_materials']);stats=[]
for src,dest in [('geometry.json.gz','base-b-v8.json.gz'),('site-v7.json.gz','base-site-v8.json.gz')]:
 g=json.loads(gzip.decompress((P/'assets'/src).read_bytes()));count=0;cc=0
 for key,data in list(g['surfaces'].items()):
  mat,_,group=key.partition('@@')
  if mat=='leaf':
   v=np.array(data['v']).reshape((-1,3,3));cent=v.mean(axis=1);drop=np.zeros(len(cent),dtype=bool)
   for w,(c,r)in fit['zones'].items():drop|=((cent[:,0]-c[0])**2+(cent[:,2]-c[1])**2<r*r)&(cent[:,1]>.03)&(cent[:,1]<3.)
   keep=~drop
   for k,n in [('v',9),('n',9),('uv',6),('c',12)]:data[k]=np.array(data[k]).reshape((-1,n))[keep].flatten().tolist()
   count+=int(drop.sum())
   if not data['v']:del g['surfaces'][key]
   continue
  if group not in polys or mat not in materials:continue
  v=np.array(data['v']).reshape((-1,3,3));cent=v.mean(axis=1);drop=contains_xy(polys[group],cent[:,0],cent[:,2])&(cent[:,1]>.04)&(cent[:,1]<2.8)
  if not drop.any():continue
  keep=~drop;count+=int(drop.sum())
  for k,n in [('v',9),('n',9),('uv',6),('c',12)]:data[k]=np.array(data[k]).reshape((-1,n))[keep].flatten().tolist()
  if not data['v']:del g['surfaces'][key]
 for mat,data in list(g['colliders'].items()):
  if mat not in materials:continue
  v=np.array(data).reshape((-1,3,3));cent=v.mean(axis=1);drop=contains_xy(union,cent[:,0],cent[:,2])&(cent[:,1]>.04)&(cent[:,1]<2.8);cc+=int(drop.sum());g['colliders'][mat]=v[~drop].flatten().tolist()
 # v7 site walls used fixed 4.6m while slabs follow non-uniform floor heights.
 # Extend only existing opaque wall top vertices to the existing slab underside.
 # No new wall footprint, floor, shaft, door or route is created.
 repairs=[]
 if src=='site-v7.json.gz':
  targets=[(-.75,-.38), (4.6,5.145), (10.125,10.495), (15.475,16.02)]
  wall_mats={'plaster','wall_chalk','wall_sand','wall_sage','wall_taupe'}
  for old,new in targets:
   visual=0;physical=0
   for key,data in g['surfaces'].items():
    if key.split('@@')[0]not in wall_mats:continue
    a=np.array(data['v']).reshape((-1,3));mask=np.abs(a[:,1]-old)<.00002;visual+=int(mask.sum());a[mask,1]=new;data['v']=a.flatten().tolist()
   for mat,data in g['colliders'].items():
    if mat not in wall_mats:continue
    a=np.array(data).reshape((-1,3));mask=np.abs(a[:,1]-old)<.00002;physical+=int(mask.sum());a[mask,1]=new;g['colliders'][mat]=a.flatten().tolist()
   repairs.append({'old_wall_top_y_m':old,'slab_underside_y_m':new,'visual_vertex_occurrences':visual,'collision_vertex_occurrences':physical,'floor_and_openings_changed':False})
  (P/'evidence/v8/wall-top-connections.json').write_text(json.dumps(repairs,indent=2))
 with gzip.open(P/'assets'/dest,'wb',compresslevel=5)as fp:fp.write(json.dumps(g,separators=(',',':')).encode())
 stats.append({'source':src,'source_sha256':hashlib.sha256((P/'assets'/src).read_bytes()).hexdigest(),'destination':dest,'removed_old_fixture_visual_triangles':count,'removed_old_fixture_collision_triangles':cc,'wall_top_join_repairs':repairs,'floor_plan_and_openings_changed':False})
 print(src,count,cc,flush=True)
(P/'evidence/v8/base-filter.json').write_text(json.dumps(stats,indent=2))
