"""1F-only authored mall finishes and furnishings. All floor/store/device records stay v8."""
from pathlib import Path
import sys,json,math,random,gzip,ast,numpy as np
from PIL import Image,ImageDraw,ImageFont
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
from shapely import constrained_delaunay_triangles
P=Path(__file__).resolve().parents[1];A=P/'assets/v9';A.mkdir(exist_ok=True);D=read(P/'source/site-v7.json');F=read(P/'source/fitout-v8.json');rng=random.Random(90109);M={};coll={};render_group='';signs=[];vendors=[];lights=[];placed=[];notes=[]
def pos(x,y,z):return[round(float(x+429),5),round(float(y),5),round(float(z-46),5)]
exec((P/'authoring/mesh_primitives.py').read_text())
module=ast.parse((P/'authoring/dress_v8.py').read_text());wanted={'surf','cub','at','ball','rod','localrod','bench','tree'}
exec(compile(ast.Module(body=[n for n in module.body if isinstance(n,ast.FunctionDef)and n.name in wanted],type_ignores=[]),'<original-mesh-tools>','exec'))
def rounded(c,u,w,d,y,h,mat,solid=False,r=.08):extrude(rect(c,u,max(.01,w-2*r),max(.01,d-2*r)).buffer(r,quad_segs=4),y,h,mat,solid)
def label(text,c,n,w,h,style='dark'):
 digest=__import__('hashlib').sha256((text+style).encode()).hexdigest()[:14];file='v9/graphic-'+digest+'.png';im=Image.new('RGB',(1200,240),'#243d39'if style=='dark'else'#ede6d7');dr=ImageDraw.Draw(im);fg='#e5d7ad'if style=='dark'else'#293b37';font=ImageFont.truetype(str(P/'assets/NotoSansCJKjp-Regular.otf'),60);sz=dr.textbbox((0,0),text,font=font);scale=min(1,1050/max(1,sz[2]));font=ImageFont.truetype(str(P/'assets/NotoSansCJKjp-Regular.otf'),int(60*scale));dr.line((60,40,1140,40),fill=fg,width=2);dr.text((600,115),text,font=font,fill=fg,anchor='mm');dr.line((60,193,1140,193),fill=fg,width=2);im.save(P/'assets'/file);signs.append({'file':file,'p':pos(c[0],c[1],c[2]),'n':list(n),'w':w,'h':h})
# Protect existing case routes, exits, operating cores and existing furniture.
route=[]
for r in read(P/'source/physical-routes-v7.json'):
 for a,b in zip(r['points'],r['points'][1:]):
  if abs(a[1])<.25 and abs(b[1])<.25 and math.dist(a,b)<150:route.append(LineString([(a[0]-429,a[2]+46),(b[0]-429,b[2]+46)]).buffer(.70))
keep=unary_union(route);occupied=unary_union([x['geom'].buffer(.12)for x in F['fixtures']]);zones=F['zones']
def vendor(model,c,u,width,depth,color=None):
 fp=rect(c,u,width,depth)
 vendors.append({'asset':model,'p':pos(c[0],0,c[1]),'yaw':math.atan2(-u[1],u[0]),'color':color,'footprint':fp})
 # Whole body bounding proxy restricted to declared furnishing bay.
 extrude(fp,0,.72 if model=='SheenChair'else 1.05,'v9_collision_only',True)
 # Remove the proxy from rendering; it is only a collision boundary.
 for key in [k for k in M if k.startswith('v9_collision_only@@')]:del M[key]
 return fp
for wing in 'ABC':
 f=next(f for f in D['floors']if f['wing']==wing and f['level']==0);above=next(f for f in D['floors']if f['wing']==wing and f['level']==1);cxz,r=zones[wing];zone=Point(cxz[0]-429,cxz[1]+46).buffer(r);public=f['public'].intersection(f['floor_plate']).intersection(zone);ceiling=above['floor_plate'].difference(unary_union([c['outline']for c in f['cores']])).intersection(zone);ceil=above['height']-(.70 if wing=='B'else .42)
 if wing=='C':ceiling=ceiling.intersection(f['shell'])
 render_group='V9-FLOOR-'+wing
 # Finish-only surfaces: no slab or aperture is added, not even across upper-floor voids.
 surf(public,.032,'v9_marble'if wing=='A'else'v9_limestone'if wing=='B'else'v9_paving')
 storeunion=unary_union([s['polygon']for s in f['stores']]);ribbon=storeunion.buffer(1.10).difference(storeunion.buffer(.95)).intersection(public);surf(ribbon,.034,'v9_bronze'if wing=='A'else'v9_basalt')
 # Recessed acoustic/coffer ceiling system under the original 1F slab.
 render_group='V9-CEILING-'+wing
 if wing!='C':
  surf(ceiling,ceil-.018,'v9_ceiling',False)
  count=0
  for x in np.arange(math.floor(zone.bounds[0]/4.8)*4.8,zone.bounds[2],4.8):
   for z in np.arange(math.floor(zone.bounds[1]/4.8)*4.8,zone.bounds[3],4.8):
    bay=rect((x,z),(1,0),4.1,3.5)
    if not ceiling.buffer(-.2).covers(bay)or not public.buffer(.8).covers(Point(x,z)):continue
    if wing=='A':
     frame=bay.difference(bay.buffer(-.065));extrude(frame,ceil-.20,.16,'v9_bronze',False);inner=bay.buffer(-.20);surf(inner,ceil-.07,'v9_ceiling',False)
     for sg in[-1,1]:cub((x,z+sg*1.61),(1,0),3.75,.025,ceil-.18,.02,'v9_glow')
    else:
     # Wooden baffles over circulation, grouped into bays; not a single repeated flat ceiling.
     for k in range(10):cub((x-1.83+k*.40,z),(1,0),.055,3.5,ceil-.22,.18,'v9_photo_oak')
     cub((x,z),(1,0),.045,3.1,ceil-.24,.03,'v9_glow')
    if count%5==0:lights.append({'p':pos(x,ceil-.40,z),'energy':1.2,'range':8,'color':[1,.93,.80]})
    count+=1
  notes.append({'wing':wing,'ceiling_bays':count,'other_floors_changed':False})
 # Facade treatments: existing front edges only, above clear doors and outside window glass.
 for s in f['stores']:
  if s['id']not in F['replacement']:continue
  render_group='V9-FACADE-'+s['id'];e=s['entry'];u=s['u'];n=s['n'];dw=s.get('door_width_m',2.4);front=LineString(s['front'])if s.get('front')else None
  if front is None:continue
  length=front.length;co=list(front.coords);uu=(np.array(co[-1])-co[0]);uu=uu/max(np.linalg.norm(uu),1e-8);mid=front.interpolate(.5,normalized=True);clad='v9_photo_oak'if wing=='B'else'v9_marble'if wing=='A'else['v9_brick','v9_stucco','v9_sage'][sum(map(ord,s['id']))%3]
  # Category-specific fascia, retaining each original opening.
  variant=sum(map(ord,s['id']))%4
  if wing=='A':clad=['v9_marble','v9_photo_oak','v9_basalt','v9_marble'][variant]
  if wing=='B':clad=['v9_photo_oak','v9_stucco','v9_sage','v9_photo_oak'][variant]
  # New layered fascia at the true wall frontage; clearance 3.55m or greater.
  outer=at((mid.x,mid.y),u,n,0,-.17);cub(outer,uu,length,.20,3.55,.83,clad);cub(at(outer,uu,n,0,-.12),uu,length,.028,3.56,.025,'v9_glow')
  for t in [0,length]:
   pp=front.interpolate(t);cc=at((pp.x,pp.y),u,n,0,-.20);cub(cc,u,.25,.32,0,4.48,clad)
  if wing=='C':
   # A full shaded awning, alternating timber and metal finishes by real pavilion.
   aw=at((mid.x,mid.y),u,n,0,-.70);cub(aw,uu,length,1.35,3.28,.11,'v9_photo_oak')
   for t in np.arange(.3,length,.60):
    pp=front.interpolate(t);bar(at((pp.x,pp.y),u,n,0,-.10),at((pp.x,pp.y),u,n,0,-1.30),.045,3.12,.14,'v9_bronze')
  # Small projecting blade signs and threshold inlay, legible from a long street.
  side=at(e,u,n,dw/2+.65,-.6);cub(side,n,.72,.065,2.65,.68,'v9_basalt')
  word='CAFE'if any(t in s['category']for t in['カフェ','食品'])else'BOOKS'if'書'in s['category']else s['category'][:6]
  for sg in[-1,1]:
   label(word,(side[0]+u[0]*.038*sg,2.98,side[1]+u[1]*.038*sg),[u[0]*sg,u[1]*sg],.58,.26)
 # Comfortable seating bays, kept out of existing travel lines and core discharge areas.
 cores=unary_union([c['outline'].buffer(1.3)for c in f['cores']]);old=unary_union([o['geom'].buffer(.2)for o in f['furniture']]);free=public.difference(keep).difference(old).difference(occupied).difference(cores)
 targets={'A':[(340,-45),(359,-18),(315,-55)],'B':[(11,19),(22,-11),(-12,9)],'C':[(-35,-226),(-65,-245),(-92,-218)]}[wing]
 for index,(wx,wz)in enumerate(targets):
  target=Point(wx-429,wz+46);choices=[]
  for dx in range(-10,11,2):
   for dz in range(-10,11,2):
    c=(target.x+dx,target.y+dz);fp=rect(c,(1,0),4.3,3.4)
    if free.covers(fp):choices.append((dx*dx+dz*dz,c,fp))
  if not choices:continue
  _,c,fp=min(choices,key=lambda x:x[0]);render_group='V9-LOUNGE-'+wing+str(index);placed.append({'wing':wing,'id':'LOUNGE-'+wing+str(index),'geom':fp});free=free.difference(fp.buffer(.5))
  vendor('SheenChair',(c[0]-1.15,c[1]),(1,0),.86,.72,[.60,.44,.23,1]if wing=='A'else[.28,.45,.38,1]);vendor('SheenChair',(c[0]+1.15,c[1]),(-1,0),.86,.72,[.24,.36,.42,1])
  rounded(c,(1,0),1.05,.75,.38,.045,'v9_marble',True,r=.12);cylinder(c,0,.06,.38,'v9_bronze',12,False)
  label(wing+'館 / 1F',(c[0],1.15,c[1]-.12),(0,-1),.30,.12)
  # A planter with articulated rim, fern fronds and several broad leaves.
  pc=(c[0],c[1]+1.05);rounded(pc,(1,0),1.4,.55,0,.38,'v9_basalt',True,r=.12)
  for j in range(22):
   aa=j*2.4;length=rng.uniform(.30,.65);a=(pc[0],.4,pc[1]);b=(pc[0]+math.cos(aa)*length,.7+rng.random()*.5,pc[1]+math.sin(aa)*length)
   rod(a,b,.009,'v9_leaf',6)
   for t in [.4,.6,.8]:
    bx=a[0]+(b[0]-a[0])*t;bz=a[2]+(b[2]-a[2])*t;by=a[1]+(b[1]-a[1])*t
    for sg in[-1,1]:
     pts=[pos(bx,by,bz),pos(bx-sg*math.sin(aa)*.15,by+.055,bz+sg*math.cos(aa)*.15),pos(bx+math.cos(aa)*.10,by+.02,bz+math.sin(aa)*.10)];tri('v9_leaf',pts,(0,.8,.2))
 # Genuine source-data plan on a slim information kiosk in a safe open bay.
 info=free.buffer(-1.0)
 if not info.is_empty:
  want=Point(cxz[0]-429,cxz[1]+46);q=nearest_points(want,info)[1];c=(q.x,q.y);fp=rect(c,(1,0),1.0,.55);render_group='V9-INFO-'+wing;rounded(c,(1,0),1,.55,0,1.75,'v9_basalt',True,r=.045)
  im=Image.new('RGB',(768,1024),'#ece8de');dr=ImageDraw.Draw(im);ft=ImageFont.truetype(str(P/'assets/NotoSansCJKjp-Regular.otf'),32);dr.text((48,40),wing+'館 1F / FLOOR GUIDE',font=ft,fill='#263f39');dr.line((48,106,720,106),fill='#b9a274',width=3)
  bounds=f['floor_plate'].bounds;scale=min(640/(bounds[2]-bounds[0]),600/(bounds[3]-bounds[1]))
  def xy(x,z):return(60+(x-bounds[0])*scale,170+(z-bounds[1])*scale)
  for po in polys(f['public']):dr.polygon([xy(x,z)for x,z in po.exterior.coords],fill='#d6cbb8')
  for ss in f['stores']:
   for po in polys(ss['polygon']):dr.polygon([xy(x,z)for x,z in po.exterior.coords],fill='#658078',outline='#ece8de')
  xx,zz=xy(*c);dr.ellipse((xx-8,zz-8,xx+8,zz+8),fill='#c65a35');dr.text((48,850),'● 現在地 / Mキーで詳細マップ',font=ft,fill='#263f39');dr.text((48,914),'F：扉・EV / 案内は実装済み設備',font=ft,fill='#263f39');file='v9/guide-'+wing+'.png';im.save(P/'assets'/file);signs.append({'file':file,'p':pos(c[0],1.02,c[1]-.286),'n':[0,-1],'w':.84,'h':1.12});placed.append({'wing':wing,'id':'INFO-'+wing,'geom':fp})
# A bookstore: gallery-like long wall, indexed shelving, face-out volumes, display benches, reading lounge.
f=next(f for f in D['floors']if f['wing']=='A'and f['level']==0);s=next(s for s in f['stores']if s['id']=='A1F-051');u=s['u'];n=s['n'];e=s['entry'];render_group='V9-BOOKSTORE'
bookrows=[x for x in F['fixtures']if x['store']==s['id']and x['kind']in ['book_island','book_table']]
for i,ob in enumerate(bookrows):
 c=ob['geom'].centroid
 if i%7==0:
  label(['文学 / FICTION','旅と暮らし / LIFESTYLE','建築とデザイン / DESIGN'][i%3],(c.x,2.85,c.y),(0,1),2.5,.50)
  for xx in[-1.15,1.15]:cub((c.x+xx,c.y),(1,0),.012,.012,2.90,2.10,'v9_bronze')
 if i%3==1:
  # Hero editorial face-out books on slanted supports; natural, useful variation among spines.
  for j in[-1,0,1]:
   pc=(c.x+j*.47,c.y+.25);cub(pc,(1,0),.32,.10,.79,.46,'v9_basalt');label(['ATLAS','FORM','QUIET'][j+1],(pc[0],1.05,pc[1]+.056),(0,1),.26,.34,'light')
# Carefully placed reading sofas in existing safe sales bays; no shelving is added.
safe=s['sales'].buffer(-.6).difference(s['aisles'].buffer(.4)).difference(keep).difference(occupied.buffer(.25))
for po in sorted(polys(safe),key=lambda q:q.area,reverse=True):
 p=po.representative_point();fp=rect((p.x,p.y),u,3.1,1.5)
 if safe.covers(fp):
  render_group='V9-BOOK-LOUNGE';vendor('SheenWoodLeatherSofa',(p.x,p.y),u,2.85,1.0);placed.append({'wing':'A','id':'BOOK-LOUNGE','geom':fp});break
# C cafe exterior seating uses only the original public corridor, never a new slab.
f=next(f for f in D['floors']if f['wing']=='C'and f['level']==0);s=next(s for s in f['stores']if s['id']=='C1F-CSW-3');e=s['entry'];u=s['u'];n=s['n'];free=f['public'].intersection(f['floor_plate']).difference(keep).difference(occupied).difference(unary_union([x['geom'].buffer(.3)for x in placed]));outdoor=0
for offset in np.arange(-7,8,2.0):
 for distance in[2.2,4.0,5.6]:
  c=at(e,u,n,offset,-distance);fp=rect(c,u,1.5,2.5)
  if not free.covers(fp):continue
  render_group='V9-TERRACE-'+str(outdoor);cylinder(c,.73,.52,.045,'v9_marble',32,True);cylinder(c,0,.06,.73,'v9_bronze',12,True)
  for sg in[-1,1]:vendor('SheenChair',at(c,u,n,0,sg*.85),u if sg==1 else[-u[0],-u[1]],.86,.72,[.37,.49,.42,1])
  cylinder(c,.775,.07,.09,'v9_porcelain',16);placed.append({'wing':'C','id':'TERRACE-'+str(outdoor),'geom':fp});free=free.difference(fp.buffer(.4));outdoor+=1
  if outdoor>=4:break
 if outdoor>=4:break
notes.append({'wing':'C','outdoor_cafe_tables':outdoor})
# Street luminaires inside original landscape beds, not in the walking strip.
for bed in f['landscape']:
 g=bed['geom'];c=g.representative_point()
 if math.dist((c.x+429,c.y-46),zones['C'][0])>125:continue
 render_group='V9-PARKLIGHT-'+bed['id'];cylinder((c.x,c.y),0,.075,3.8,'v9_basalt',12,True);rounded((c.x,c.y),(1,0),.50,.50,3.78,.10,'v9_bronze',r=.07);rounded((c.x,c.y),(1,0),.40,.40,3.775,.015,'v9_glow',r=.05);lights.append({'p':pos(c.x,3.65,c.y),'energy':.6,'range':7,'color':[1,.88,.65]})
# Avoid unpublished primitive-only markers in the visible scene.
write(P/'source/art-v9.json',{'signs':signs,'vendors':vendors,'lights':lights,'placed':placed,'notes':notes,'floors_affected':['A1F','B1F','C1F'],'stores_added':0,'main_game_integrated':False,'RF_SUPPORT_16':'UNAPPROVED'})
raw={'surfaces':M,'colliders':coll,'lights':[],'signs':[]}
with gzip.open(P/'assets/art-v9.json.gz','wb',compresslevel=6)as z:z.write(json.dumps(raw,separators=(',',':')).encode())
print('V9_ART',sum(len(d['v'])//9 for d in M.values()),'triangles',len(M),'batches',len(vendors),'vendor instances',notes)
