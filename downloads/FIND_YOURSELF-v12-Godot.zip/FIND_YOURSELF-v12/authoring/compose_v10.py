"""V10: replace retail presentation and frontage system; preserve original layouts and device records.
This script writes new v10 assets only. The approved source JSON and v9 originals are inputs.
"""
from pathlib import Path
import sys,math,json,ast,random,numpy as np
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
from pack_tools_v10 import *
from shapely import contains_xy,intersects_xy
from shapely.ops import transform
from shapely import constrained_delaunay_triangles
P=Path(__file__).resolve().parents[1];D=read(P/'source/site-v7.json');BD=read(P/'source/design-v7.json');F=read(P/'source/fitout-v8.json');rng=random.Random(10110)
M={};coll={};render_group='';records=[];fronts=[];signs=[];lights=[];changes=[]
def pos(x,y,z):return[round(float(x+429),5),round(float(y),5),round(float(z-46),5)]
exec((P/'authoring/mesh_primitives.py').read_text())
def world(g):return transform(lambda x,z,zz=None:(np.asarray(x)+429,np.asarray(z)-46),g)
def vec(v):return[float(v[0]),float(v[1])]
S={};floors={}
for wing in 'ABC':
 f=next(f for f in D['floors']if f['wing']==wing and f['level']==0)
 if wing=='B':f=dict(f,**BD['floors'][0]);f['wing']='B';f['level']=0
 floors[wing]=f
 for s in f['stores']:
  if s['id']in F['replacement']or wing=='C':S[s['id']]=(f,s)
# Use customer-facing sales/public adjacency; an entry line is not a full storefront.
for sid,(f,s)in S.items():
 e=np.array(s['entry']);u=np.array(s['u']);n=np.array(s['n']);adj=s['sales'].boundary.intersection(f['public'].buffer(.045));intervals=[]
 for ln in lines(adj):
  co=list(ln.coords)
  for a,b in zip(co,co[1:]):
   a=np.array(a);b=np.array(b);v=b-a;length=np.linalg.norm(v)
   if length<.02 or abs(np.dot(v/length,u))<.985:continue
   if max(abs(np.dot(a-e,n)),abs(np.dot(b-e,n)))>.16:continue
   intervals.append(sorted([float(np.dot(a-e,u)),float(np.dot(b-e,u))]))
 intervals.sort();merged=[]
 for a,b in intervals:
  if merged and a-merged[-1][1]<.10:merged[-1][1]=max(merged[-1][1],b)
  else:merged.append([a,b])
 candidates=[ab for ab in merged if ab[0]-.25<=0<=ab[1]+.25]
 if not candidates:
  # Existing true frontage is accepted only after checking both ends on this plot boundary.
  if s.get('front')and LineString(s['front']).length>1:
   co=np.array(s['front']);candidates=[[float(np.dot(co[0]-e,u)),float(np.dot(co[-1]-e,u))]];candidates=[sorted(x)for x in candidates]
  else:raise ValueError('Unresolved true frontage '+sid)
 t0,t1=max(candidates,key=lambda x:x[1]-x[0]);length=t1-t0;old=s.get('door_width_m',2.4);dw=min(14.,max(old,length*.58));dw=min(dw,max(old,length-.50));start=max(t0+.13,min(t1-.13-dw,-dw/2));end=start+dw
 # Original entry coordinate stays inside the proposed wide shop opening.
 if not start+.04<=0<=end-.04:raise ValueError('entry lost '+sid)
 line=LineString([e+u*t0,e+u*t1]);mask=line.buffer(.38,cap_style=3);inside=s['sales'];style=('book'if'書'in s['category']else'cafe'if any(k in s['category']for k in['カフェ','食品','ベーカリ','フード'])else'fashion'if any(k in s['category']for k in['服飾','衣料','ファッション'])else'shoe'if'靴'in s['category']else'home')
 info={'id':sid,'wing':f['wing'],'category':s['category'],'style':style,'entry':vec(e),'u':vec(u),'n':vec(n),'front':line,'mask':mask,'t0':t0,'t1':t1,'opening_t0':start,'opening_t1':end,'old_opening_m':old,'new_opening_m':dw,'frontage_m':length};fronts.append(info)
 render_group='V10-FRONT-'+sid
 # Consistent real fascia profiles. These replace old faces; they do not mask residual gaps.
 finish={'book':'v10_oak','cafe':'v10_clay','fashion':'v10_charcoal','shoe':'v10_chalk','home':'v10_sage'}[style]
 def point(t,depth=0):return e+u*t+n*depth
 for aa,bb in [(t0,start),(end,t1)]:
  if bb-aa<.10:continue
  pa=point(aa);pb=point(bb);bar(pa,pb,.18,0,.12,'v10_darkstone',True)
  bar(pa,pb,.025,.12,3.30,'v10_glass',True)
  for t in np.arange(aa+.9,bb,.95):
   pp=point(t);extrude(rect(pp,u,.035,.055),.12,3.30,'v10_metal',False)
 # Raised side reveals and stepped header, not one identical glass box per shop.
 for t in[t0+.08,start-.06,end+.06,t1-.08]:extrude(rect(point(t),u,.15,.24),0,4.55,finish,True)
 actual_ceil=next(q['height']for q in D['floors']if q['wing']==f['wing']and q['level']==1)-(.70 if f['wing']=='B'else.42)
 bar(point(t0),point(t1),.26,4.58,max(0,actual_ceil-4.58),'v10_chalk',True)
 bar(point(t0),point(t1),.26,3.54,1.04,finish,True);bar(point(t0,-.14),point(t1,-.14),.055,3.51,.045,'v10_brass',False)
 bar(point(t0,.10),point(t1,.10),.030,3.51,.018,'v10_emitter',False)
 if f['wing']=='C':
  # Only the individual pavilion's store frontage receives a shallow awning.
  canopy=rect(point((t0+t1)/2,-.72),u,length,1.42);extrude(canopy,3.36,.10,'v10_oak',False)
  for t in np.arange(t0+.45,t1,.75):bar(point(t,-.10),point(t,-1.36),.035,3.30,.10,'v10_metal',False)
 centre=point((start+end)/2,-.154);signs.append({'store_id':sid,'style':style,'p':pos(centre[0],4.01,centre[1]),'normal':[-n[0],-n[1]],'width':min(10,max(2.4,length-.6)),'height':.50})
 for t in np.arange(t0+.7,t1,2.0):
  pp=point(t,1.3);lights.append({'p':pos(pp[0],4.22,pp[1]),'energy':2.2 if style=='cafe'else 1.8,'range':8.0,'color':[1,.86,.68]if style in['book','cafe']else[1,.94,.85],'shadow':False,'store':sid})
 changes.append({'id':sid,'old_opening_m':old,'new_opening_m':dw,'frontage_m':length,'original_entry_retained':True,'frontage_source':'current sales/public boundary; collinear with original entry tangent','original_plot_unchanged':True})
# Full-depth sales lighting follows the existing cassette fixture grid, not just the entry.
for sid,(f,s)in S.items():
 ceil=next(q['height']for q in D['floors']if q['wing']==f['wing']and q['level']==1)-(.70 if f['wing']=='B'else.42)
 warm=any(k in s['category']for k in ['カフェ','食品','ベーカリ','書'])
 for xx in np.arange(s['sales'].bounds[0]+2,s['sales'].bounds[2],5):
  for zz in np.arange(s['sales'].bounds[1]+2,s['sales'].bounds[3],5):
   if s['sales'].buffer(-.7).contains(Point(xx,zz)):lights.append({'p':pos(xx,ceil-.27,zz),'energy':2.1 if warm else 1.8,'range':7.5,'color':[1,.88,.73]if warm else[1,.96,.89],'shadow':False,'store':sid})
# A helper records a shared GLB, rather than baking repeated merchandise into giant vertex arrays.
def add(asset,centre,u,front,group,boxxz=None,height=None,y=0.,foliage=False):
 records.append({'asset':asset,'p':pos(centre[0],y,centre[1]),'u':vec(u),'front':vec(front),'group':group,'max_xz':boxxz,'target_height':height,'foliage_only':foliage})
# Retain existing fixture layouts and the protected routes. Replace their presentation with real models.
for i,fx in enumerate(F['fixtures']):
 if fx['kind']=='tree':continue
 f,s=S[fx['store']];kind=fx['kind'];fp=fx['geom'];co=list(fp.minimum_rotated_rectangle.exterior.coords);edges=[np.array(co[1])-co[0],np.array(co[2])-co[1]];u=max(edges,key=np.linalg.norm);u=u/np.linalg.norm(u);n=np.array([-u[1],u[0]]);c=np.array(fp.centroid.coords[0]);dest=np.array(s['entry'])if kind=='checkout'else np.array(s['sales'].centroid.coords[0])
 if np.dot(dest-c,n)<0:u=-u;n=-n
 cat=s['category'];book='書'in cat;cafe=any(k in cat for k in['カフェ','食品','ベーカリ','フード']);fashion=any(k in cat for k in['服飾','衣料','ファッション']);shoe='靴'in cat;dims=sorted([np.linalg.norm(v)for v in edges],reverse=True);asset=None
 if kind=='checkout':asset='retail/cafe_counter'if cafe else'retail/retail_counter'
 elif kind=='dining':
  # Dining's declared long axis is the two-chair direction, not the tabletop width.
  u,n=n,-u;dims=sorted(dims);asset='retail/cafe_table'
 elif kind=='book_table':asset='retail/book_table_'+str(i%2)
 elif kind=='book_island':
  for sg in[-1,1]:add('retail/book_island_'+str(i%2),c+n*sg*.22,u*sg,n*sg,fx['store'],[2.04,.42])
  continue
 elif kind=='garment_rail' or(kind=='wall_display'and fashion):asset='retail/garment_rack_'+str(i%3)
 elif kind=='sofa_display':asset='models/SheenWoodLeatherSofa'
 elif kind=='wall_display'and book:asset='retail/book_wall_'+str(i%3)
 elif cafe and kind=='wall_display':asset='retail/cafe_wall'
 elif any(k in cat for k in['美容','ケア']):asset='retail/cosmetic_bay'
 elif any(k in cat for k in['モバイル','家電'])and kind=='product_display':asset='retail/electronics_table'
 elif any(k in cat for k in['モバイル','家電'])and kind=='wall_display':asset='retail/electronics_table'
 elif kind=='product_display'and not shoe:asset='retail/lifestyle_table_'+str(i%2)
 else:asset='retail/product_bay_'+str(i%3)
 add(asset,c,u,n,fx['store'],[float(dims[0]),float(dims[1])])
 # Eye-level products use the real scanned/modelled product shape. Far displays use the fixture silhouette/LOD.
 if asset.startswith('retail/product_bay'):
  for row,yy in enumerate([.19,.71,1.23]):
   for j in range(3):
    cc=c+u*(-.65+j*.65)+n*.03
    if shoe:add('models/MaterialsVariantsShoe',cc,u,n,fx['store'],[.34,.40],height=.15,y=yy)
    elif row==1:add('models/WaterBottle',cc,u,n,fx['store'],[.19,.19],height=.22,y=yy)
# Original lounge seats stay at their original positions, using the same licensed chair mesh.
old=read(P/'source/art-v9.json')
for d in old['vendors']:
 c=[d['p'][0]-429,d['p'][2]+46];u=[math.cos(d['yaw']),-math.sin(d['yaw'])];n=[-u[1],u[0]];add('models/'+d['asset'],c,u,n,'PUBLIC-V9',[.86,.72])
for bay in old['placed']:
 if not bay['id'].startswith('LOUNGE'):continue
 cc=bay['geom'].centroid
 for xx in[-.40,0,.40]:add('models/DiffuseTransmissionPlant',(cc.x+xx,cc.y+1.05),(1,0),(0,1),'PUBLIC-PLANTS',[.54,.50],height=.85,y=.38,foliage=True)
# Replace planar v8 tree canopies with the actual plant model at the authored planter positions.
for fx in F['fixtures']:
 if fx['kind']!='tree':continue
 c=fx['geom'].centroid;add('models/DiffuseTransmissionPlant',(c.x,c.y),(1,0),(0,1),'PUBLIC-PLANTS',[1.30,1.30],height=2.0,y=.40,foliage=True)
for bed in floors['C']['landscape']:
 region=bed['geom'].buffer(-1)
 if region.is_empty:continue
 for x in np.arange(region.bounds[0]+.5,region.bounds[2],6):
  for z in np.arange(region.bounds[1]+.5,region.bounds[3],6):
   if region.contains(Point(x,z))and rng.random()<.55:
    a=rng.random()*math.tau;add('models/DiffuseTransmissionPlant',(x,z),(math.cos(a),math.sin(a)),(-math.sin(a),math.cos(a)),'C-GARDEN-'+bed['id'],[1.8,1.8],height=rng.uniform(1.2,2.2),y=.02,foliage=True)
# Groundcover belongs to the existing planting beds; it does not add a path or hard obstacle.
for index,bed in enumerate(floors['C']['landscape']):
 region=bed['geom'].buffer(-.65)
 if region.is_empty:continue
 for x in np.arange(region.bounds[0],region.bounds[2],1.35):
  for z in np.arange(region.bounds[1],region.bounds[3],1.35):
   c=(x+rng.uniform(-.18,.18),z+rng.uniform(-.18,.18))
   if not region.contains(Point(c)):continue
   a=rng.random()*math.tau;add('retail/groundcover_'+str(rng.randrange(3)),c,(math.cos(a),math.sin(a)),(-math.sin(a),math.cos(a)),'C-COVER-'+str(index),[1.3,1.3],y=.165)
# Show windows on real remaining frontage, subject to floor and route checks.
keep=[]
for route in read(P/'source/physical-routes-v7.json'):
 for a,b in zip(route['points'],route['points'][1:]):
  if abs(a[1])<.1 and abs(b[1])<.1:keep.append(LineString([(a[0]-429,a[2]+46),(b[0]-429,b[2]+46)]).buffer(.7))
keep=unary_union(keep);occupied=unary_union([f['geom'].buffer(.10)for f in F['fixtures']])
for info in fronts:
 if info['style']not in['fashion','shoe','book']:continue
 f,s=S[info['id']];u=np.array(info['u']);n=np.array(info['n']);e=np.array(info['entry'])
 for a,b in[(info['t0']+.3,info['opening_t0']-.3),(info['opening_t1']+.3,info['t1']-.3)]:
  if b-a<2.1:continue
  c=e+u*(a+b)/2+n*.85;fp=rect(c,u,1.4,1.05)
  if not s['sales'].buffer(-.06).covers(fp)or fp.intersects(keep)or fp.distance(occupied)<.15:continue
  render_group='V10-SHOWCASE-'+info['id'];extrude(fp,.01,.14,'v10_darkstone',True)
  if info['style']=='fashion':
   for xx in[-.35,.35]:add('retail/dressed_mannequin',c+u*xx,-u,-n,info['id'],[.60,.60],y=.15)
  elif info['style']=='shoe':
   for xx in[-.40,0,.40]:add('models/MaterialsVariantsShoe',c+u*xx,u,-n,info['id'],[.32,.40],height=.18,y=.15)
  else:add('retail/book_table_0',c,u,-n,info['id'],[1.4,1.05],y=.15)
  lights.append({'p':pos(c[0],3.25,c[1]),'energy':2.0,'range':5,'color':[1,.88,.73],'shadow':True,'store':info['id']});occupied=occupied.union(fp)
# New public floor finishes use exactly the old public/sales surfaces, no new floor area.
for wing,f in floors.items():
 cxz,r=F['zones'][wing];zone=Point(cxz[0]-429,cxz[1]+46).buffer(r);render_group='V10-PUBLIC-'+wing;surf(f['public'].intersection(f['floor_plate']).intersection(zone),.040,'v10_floor_'+wing)
# Finish the existing balustrade tops over the review areas; no opening or circulation change.
for ff in D['floors']:
 if ff['wing']not in 'AB'or ff['level']not in[1,2]:continue
 cxz,r=F['zones'][ff['wing']];region=Point(cxz[0]-429,cxz[1]+46).buffer(r)
 rails=ff['guardrails'].intersection(region);profile=rails.buffer(-.025)
 if profile.is_empty:continue
 render_group='V10-BALUSTRADE-'+ff['wing']+'-'+ff['label'];extrude(profile,ff['height']+(1.15 if ff['wing']=='B'else 1.10),.025,'v10_metal',False)
# Architecture pack has new storefront collisions; other physical features stay in the original packs.
architecture={'surfaces':M,'colliders':coll,'signs':[],'lights':[]};print(write_pack(P/'assets/v10/architecture.pack.gz',architecture),flush=True)
maskworld=world(unary_union([x['mask']for x in fronts]));masks={x['id']:world(x['mask'])for x in fronts};audit=[]
for src,dst in [('base-b-v8-indexed.pack.gz','base-b.pack.gz'),('base-site-v8-indexed.pack.gz','base-site.pack.gz'),('fitout-v8-indexed.pack.gz','fitout.pack.gz'),('art-v9-indexed.pack.gz','art.pack.gz')]:
 g=load_pack(P/'assets'/src);removed=0
 for key,d in list(g['surfaces'].items()):
  mat,_,group=key.partition('@@');triangles_xyz=triangles(d);cent=triangles_xyz.mean(axis=1);drop=np.zeros(len(cent),dtype=bool)
  if src.startswith('base')and group in masks and mat in['plaster','wall_sand','wall_chalk','wall_sage','wall_taupe','dark_stone','glass']:
   drop=contains_xy(masks[group],cent[:,0],cent[:,2])&(cent[:,1]>=0)&(triangles_xyz[:,:,1].max(axis=1)<5.15)
  elif src.startswith('fitout'):
   if group in S:
    # Entire low-level presentation is replaced; preserve the store floor and high wall/ceiling fixtures.
    drop=(cent[:,1]>.025)&(cent[:,1]<2.30)
    # Retire the old low canopy and strip trims at the original door to make one coherent frontage.
    drop|=contains_xy(masks[group].buffer(.5),cent[:,0],cent[:,2])&(cent[:,1]>0)&(cent[:,1]<4.65)
   if group.startswith(('TREE-','GARDEN-')):drop[:]=True
  elif src.startswith('art'):
   if group.startswith(('V9-CEILING-','V9-FACADE-','V9-BOOKSTORE','V9-FLOOR-')):drop[:]=True
   if group.startswith('V9-LOUNGE-')and mat=='v9_leaf':drop[:]=True
  if drop.any():removed+=int(drop.sum());g['surfaces'][key]=retain(d,~drop)
 for mat,data in g['colliders'].items():
  if not src.startswith('base')or mat not in['plaster','wall_sand','wall_chalk','wall_sage','wall_taupe','dark_stone','glass']:continue
  tri=np.asarray(data).reshape(-1,3,3);cent=tri.mean(axis=1);drop=contains_xy(maskworld,cent[:,0],cent[:,2])&(cent[:,1]>=0)&(tri[:,:,1].max(axis=1)<5.15);g['colliders'][mat]=tri[~drop].ravel()
 audit.append({'input':src,'output':dst,'removed_visual_triangles':removed,'source_modified':False,'reason':'Replace complete first-floor presentation/frontage system; retain structural floor, store plots and devices'});print(write_pack(P/'assets/v10'/dst,g),flush=True)
write(P/'source/v10/scene-art.json',{'instances':records,'frontages':fronts,'signs':signs,'lights':lights,'changes':changes,'original_store_ids_preserved':True,'stores_added':0,'geometry_changes':audit,'RF_SUPPORT_16':'UNAPPROVED','main_game_integrated':False})
print('V10_COMPOSED',len(fronts),'frontages',len(records),'shared model placements; not a quality score',flush=True)
