import bpy,random,math
from pathlib import Path
P=Path(__file__).resolve().parents[1];O=P/'assets/v10/retail';bpy.ops.wm.read_factory_settings(use_empty=True)
for var in range(3):
 rng=random.Random(1050+var);verts=[];faces=[]
 for j in range(100):
  cx=rng.uniform(-.6,.6);cy=rng.uniform(-.6,.6);angle=rng.random()*math.tau;L=rng.uniform(.15,.36);W=rng.uniform(.012,.036);height=rng.uniform(.10,.24);start=len(verts)
  for k in range(7):
   t=k/6;xx=cx+math.cos(angle)*L*t;yy=cy+math.sin(angle)*L*t;zz=.008+height*math.sin(t*math.pi*.8);w=W*math.sin(t*math.pi)*.5
   for sg in[-1,0,1]:verts.append((xx-sg*math.sin(angle)*w,yy+sg*math.cos(angle)*w,zz+(.012 if sg==0 else 0)*math.sin(t*math.pi)))
  for k in range(6):
   a=start+k*3;faces.extend([(a,a+1,a+4,a+3),(a+1,a+2,a+5,a+4)])
 me=bpy.data.meshes.new('Curved_groundcover_leaves');me.from_pydata(verts,[],faces);me.update();ob=bpy.data.objects.new('Original_planted_groundcover',me);bpy.context.collection.objects.link(ob)
 for f in me.polygons:f.use_smooth=True
 mat=bpy.data.materials.new('Original_foliage_'+str(var));mat.diffuse_color=[(.12,.23,.055,1),(.18,.29,.085,1),(.15,.25,.075,1)][var];mat.use_nodes=True;bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=mat.diffuse_color;bs.inputs['Roughness'].default_value=.86;mat.use_backface_culling=False;me.materials.append(mat);bpy.context.view_layer.objects.active=ob;ob.select_set(True)
 bpy.ops.export_scene.gltf(filepath=str(O/('groundcover_'+str(var)+'.glb')),export_format='GLB',use_selection=True,export_yup=True,export_animations=False)
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
print('GROUND_COVER_ASSETS_COMPLETE')
