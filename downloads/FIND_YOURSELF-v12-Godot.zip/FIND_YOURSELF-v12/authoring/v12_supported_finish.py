"""Structural slab and decorative finish use the same C support polygon. Variant-only, exact barycentric UV preservation."""
from pathlib import Path
import sys,numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import constrained_delaunay_triangles
from shapely.ops import transform
G=load_pack(P/'assets/v10/fitout.pack.zst');rows=read(P/'source/v12/C-outlet-proposal.json')['floors'];M={};audit=[]
for r in rows:
 if r['level']not in[1,2]:continue
 key='v8_pavers@@FINISH-C-'+r['floor'];d=G['surfaces'][key];ix=np.asarray(d['i']).reshape(-1,3);attrs=np.concatenate([np.asarray(d[k]).reshape(-1,n)[ix]for k,n in [('v',3),('n',3),('uv',2),('c',4)]],axis=2);floor=transform(lambda x,z,zz=None:(np.array(x)+429,np.array(z)-46),r['proposed_floor']);out=[];before=[];after=[]
 for a in attrs:
  old=Polygon(a[:,[0,2]]);before.append(old)
  if old.area<1e-8:continue
  if floor.covers(old):out.append(a);after.append(old);continue
  clipped=old.intersection(floor);basis=np.c_[a[:,[0,2]],np.ones(3)];inverse=np.linalg.inv(basis);orientation=np.cross(a[1,:3]-a[0,:3],a[2,:3]-a[0,:3])
  for po in polys(clipped):
   for cell in constrained_delaunay_triangles(po).geoms:
    q=np.array(list(cell.exterior.coords)[:3]);bary=np.c_[q,np.ones(3)]@inverse;v=bary@a
    if np.dot(np.cross(v[1,:3]-v[0,:3],v[2,:3]-v[0,:3]),orientation)<0:v=v[[0,2,1]]
    out.append(v);after.append(cell)
 out=np.array(out,dtype=np.float32);M[key]={k:out[:,:,i:j].ravel()for k,i,j in [('v',0,3),('n',3,6),('uv',6,8),('c',8,12)]};old=unary_union(before);new=unary_union(after);outside=new.difference(floor).area;expected=old.intersection(floor);diff=new.symmetric_difference(expected).area;assert outside<.002 and diff<.002
 audit.append({'floor':r['floor'],'key':key,'old_finish_m2':old.area,'supported_finish_m2':new.area,'floating_finish_removed_m2':old.difference(new).area,'outside_support_m2':outside,'clip_residual_m2':diff,'before_triangles':len(attrs),'after_triangles':len(out),'physical_floor_added':False,'UV_interpolation':'barycentric; no image resizing or material substitution'});print('SUPPORTED_FINISH',r['floor'],audit[-1],flush=True)
save_zst(P/'assets/v12/C-supported-finish.pack.zst',{'surfaces':M,'colliders':{},'signs':[],'lights':[]});write(P/'source/v12/C-supported-finish.json',audit)
