"""Vector review plans, never labelled Godot screenshots."""
from pathlib import Path
import os,sys,math,json,csv,collections,numpy as np
os.environ.setdefault('MPLCONFIGDIR','/tmp/v11-mpl')
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Polygon as Patch,Rectangle
from matplotlib import font_manager
fullfont=P.parent/'FIND_YOURSELF-Site-v10/assets/NotoSansCJKjp-Regular.otf';fullfont=fullfont if fullfont.exists()else P/'assets/NotoSansCJKjp-Regular.otf';font_manager.fontManager.addfont(str(fullfont));plt.rcParams.update({'font.family':font_manager.FontProperties(fname=fullfont).get_name(),'font.size':9,'axes.unicode_minus':False,'pdf.fonttype':3})
F=read(P/'source/v11/floors-updated.json');B=read(P/'source/v11/floors-baseline.json');gaps=read(P/'source/v11/gap-audit.json');changes=read(P/'source/v11/layout-changes.json');changed={r['id']for r in changes};R=P/'evidence/v11/plans';R.mkdir(parents=True,exist_ok=True)
def draw(ax,g,color,edge=None,alpha=1,lw=.4):
 for p in polys(g):
  ax.add_patch(Patch(np.asarray(p.exterior.coords)+[429,-46],facecolor=color,edgecolor=edge or color,alpha=alpha,lw=lw))
  for ring in p.interiors:ax.add_patch(Patch(np.asarray(ring.coords)+[429,-46],facecolor='white',edgecolor=edge or color,lw=lw))
def plan(ax,f,labels=True,zoom=None):
 draw(ax,f['floor_plate'],'#e3e6e8');draw(ax,f['public'],'#fff1cd')
 for s in f['stores']:
  draw(ax,s['polygon'],'#bcd9e5','#497486');draw(ax,s.get('backroom',Polygon()),'#85959d','#667982')
  if s['id']in changed:draw(ax,s['polygon'],'none','#207a4c',lw=.65)
  e=np.array(s['entry'])+[429,-46];ax.plot(*e,'o',color='#be413c',ms=1.6)
  if labels:ax.text(e[0],e[1],s['id'],fontsize=4.1,ha='center',va='bottom',clip_on=True)
 for z in f.get('program',[]):draw(ax,z.get('polygon',Polygon()),'#d5c7b4','#968b79',alpha=.6)
 draw(ax,f.get('guardrails',Polygon()),'#c05660')
 for c in f['cores']:draw(ax,c['outline'],'none','#7a4d9c')
 if zoom:ax.set_xlim(zoom[:2]);ax.set_ylim(zoom[2:])
 else:
  x,z,xx,zz=f['floor_plate'].bounds;ax.set_xlim(x+419,xx+439);ax.set_ylim(z-56,zz-36)
 ax.set_aspect('equal');ax.invert_yaxis();ax.grid(alpha=.15);ax.set_xlabel('world X [m]');ax.set_ylabel('world Z [m]');ax.set_title(f['wing']+'館 '+f['label']+' / y='+str(f['height'])+'m / '+str(len(f['stores']))+'店舗')
with PdfPages(R/'01-15層平面図.pdf')as pdf:
 for wing in 'ABC':
  fig,axes=plt.subplots(2,3,figsize=(16.54,11.69));fig.suptitle('v11 独立検証｜'+wing+'館 5層・店舗ID／入口／売場／裏方／共用床',fontsize=17)
  for ax,f in zip(axes.ravel(),[f for f in F if f['wing']==wing]):plan(ax,f)
  ax=axes.ravel()[-1];ax.axis('off');ax.text(.03,.8,'青：店舗　濃灰：バックヤード\n黄：共用床　茶：既存用途帯\n緑輪郭：局所修正店舗　赤点：入口\n紫：設備コア　赤線：設計手すり\n\n図面検査≠人間の実歩行≠構造安全の承認\nゲーム座標のX/Z。実在施設の寸法ではありません。\n店舗の詳細はCSV台帳・GeoJSONを参照。\nRF-SUPPORT-16：未承認',va='top',fontsize=12);fig.tight_layout(rect=[0,0,1,.95]);pdf.savefig(fig);plt.close(fig)
with PdfPages(R/'02-局所修正と昇降設備案.pdf')as pdf:
 fig,axes=plt.subplots(1,2,figsize=(16.54,9));
 for ax,data,title in zip(axes,[B,F],['v10 修正前','v11 修正後']):
  f=next(f for f in data if f['wing']=='A'and f['level']==0);plan(ax,f,True,(345,429,-89,-29));ax.set_title(title+'｜靴店A1F-003・隣接区画・境界')
 fig.suptitle('細長い入口を広い既存売場面へ移動／首部分はA1F-005へ連続配分');fig.text(.04,.025,'入口 world(364.559, -65.000)、旧間口3.90m→既存の広い正面20.88m。IDは維持。単なる壁による目隠しではありません。');pdf.savefig(fig);plt.close(fig)
 fig,axes=plt.subplots(1,2,figsize=(16.54,9))
 for ax,wing in zip(axes,['A','C']):
  f=next(f for f in F if f['wing']==wing and f['level']==0);plan(ax,f,False)
  for r in gaps:
   if r['wing']==wing and r['floor']=='1F':draw(ax,r['geometry'],'#ef6b3c',alpha=.9)
 fig.suptitle('隙間抽出例：各棟内の境界残余と、正式な経路を区別');fig.text(.04,.02,'全15層166領域：155再配分、11正式アクセス保護。幅1.3mまでの境界閉合による検出範囲。未抽出の全空間が良好という意味ではありません。');pdf.savefig(fig);plt.close(fig)
 data=read(P/'source/elevators-v7.json');d=data[0];fig,axes=plt.subplots(1,2,figsize=(16.54,9));ax=axes[0];w=d['width'];dep=d['depth'];door=d['door_width'];ax.add_patch(Rectangle((-w/2,-dep/2),w,dep,fc='#e2e7e9',ec='black'))
 for x in[-w/2-.16,w/2]:ax.add_patch(Rectangle((x,-dep/2),.16,dep,fc='#777777'))
 for x in[-door/2,0]:ax.add_patch(Rectangle((x,-dep/2-.05),door/2-.008,.08,fc='#a58c68'))
 ax.annotate('客用ロビー → 敷居 → かご',xy=(0,-dep/2),xytext=(0,-dep/2-1.5),ha='center',arrowprops={'arrowstyle':'->'});ax.set_xlim(-w, w);ax.set_ylim(-dep/2-2,dep/2+.6);ax.invert_yaxis();ax.set_aspect('equal');ax.set_title(d['id']+' 平面例／閉扉位置');ax.set_xlabel('扉接線方向 [m]');ax.set_ylabel('奥行方向 [m]')
 ax=axes[1]
 for stop in d['stops']:
  yy=stop['y'];ax.plot([-2,-.15],[yy,yy],color='#777777',lw=5);ax.add_patch(Rectangle((-.1,yy),.15,2.25,fc='#a58c68'));ax.text(-2.0,yy+.25,stop['label']+' '+str(yy)+'m')
 ax.add_patch(Rectangle((.1,d['stops'][1]['y']),2.3,2.35,fc='#e2e7e9',ec='black'));ax.plot([2.5,2.5],[d['stops'][0]['y']-.3,d['stops'][-1]['y']+2.7],color='#777777',lw=7);ax.set_xlim(-2.5,3);ax.set_ylim(d['stops'][0]['y']-.7,d['stops'][-1]['y']+3);ax.set_title('断面例：閉じたシャフト・各階扉・敷居');ax.set_aspect('equal');fig.suptitle('EV 安全構成｜全21基・98停止階。実際の形状・座標は elevators-v7.json を参照');fig.text(.04,.02,'扉高2.25m、シャフト側壁0.16m、敷居厚0.12m。かご不在時の全面安全ゲートは実扉と重なり、開閉中は各扉パネルの衝突が追従。');pdf.savefig(fig);plt.close(fig)
 es=read(P/'source/v11/escalator-transfer-proposals.json')
 for offset in range(0,len(es['records']),4):
  fig,axes=plt.subplots(2,2,figsize=(16.54,11.69));fig.suptitle('ES 乗り継ぎ変更案｜未施工・床開口／上下対／構造の確認前')
  for ax,r in zip(axes.ravel(),es['records'][offset:offset+4]):
   for e,col,style,label in[(r['existing_lower'],'#25738a','-','既存1→2F'),(r['existing_upper'],'#9d6b42','-','既存2→3F'),(r['proposed_upper'],'#a02a7d','--','未施工2→3F案')]:
    aa=np.array(e['test_start']);bb=np.array(e['test_end']);ax.plot([aa[0],bb[0]],[aa[2],bb[2]],style,color=col,lw=4,label=label);ax.annotate('',(bb[0],bb[2]),(aa[0],aa[2]),arrowprops={'arrowstyle':'->','color':col})
   ax.set_title(r['wing']+'館 '+r['from']+'\n直線 '+str(round(r['before_straight_line_m'],1))+'m →案 '+str(round(r['proposed_straight_line_m'],1))+'m');ax.set_aspect('equal');ax.invert_yaxis();ax.grid(alpha=.2);ax.legend(fontsize=8);ax.set_xlabel('world X [m]');ax.set_ylabel('world Z [m]')
  for ax in axes.ravel()[len(es['records'][offset:offset+4]):]:ax.axis('off')
  fig.text(.04,.02,'直線距離は実歩行距離ではありません。3F店舗区画との重複は0㎡ですが、床開口・踊り場・上り下り対・構造は未解決。C館は東側の上段新設候補。');fig.tight_layout(rect=[0,.04,1,.96]);pdf.savefig(fig);plt.close(fig)
 opt=read(P/'source/v10/C-deck-option.json');fig,axes=plt.subplots(1,2,figsize=(16.54,10));c=next(f for f in F if f['wing']=='C'and f['level']==1);o=next(f for f in opt['floors']if f['level']==1)
 for ax,g,title in zip(axes,[c['floor_plate'],o['proposed_floor']],['通常版（維持）','v10由来の縮小別案（未承認）']):
  draw(ax,g,'#e6e6e6','#777777');draw(ax,c['shell'],'#a8cbd8','#47778d');ax.set_aspect('equal');ax.autoscale_view();ax.invert_yaxis();ax.set_title(title);ax.set_xlabel('world X [m]');ax.set_ylabel('world Z [m]')
 fig.suptitle('C館2F比較｜v11では通常版デッキを変更していません');fig.text(.04,.02,'縮小案でも店舗・館間経路を残す必要があります。支持フレーム案は未施工・配置未確定。耐力・基礎・避難・車両離隔は未検証。');pdf.savefig(fig);plt.close(fig)
 fig,ax=plt.subplots(figsize=(12,7));ax.axis('off');ax.plot([1,9],[4,4],lw=12,color='#aaaaaa');ax.plot([1,9],[3.7,3.7],lw=7,color='#587280');ax.plot([1.3,1.3],[.7,3.7],lw=9,color='#587280');ax.plot([8.7,8.7],[.7,3.7],lw=9,color='#587280');ax.plot([1.1,1.5],[.6,.6],lw=15,color='#999999');ax.plot([8.5,8.9],[.6,.6],lw=15,color='#999999');ax.text(5,4.5,'床→梁→柱→基礎という連続荷重経路の検討',ha='center');ax.annotate('通行幅4mを侵さない柱位置が必要',xy=(1.3,2),xytext=(2.4,1.9),arrowprops={'arrowstyle':'->'});ax.text(5,5.25,'C館 支持フレームの考え方／未施工・寸法未確定',ha='center',fontsize=17);ax.text(5,-.15,'柱0.35m・梁0.55m・最大8mモジュールはゲーム用初期案。構造設計値ではありません。\n図は原理図で、Godotの施工画像・特定地点への配置図ではありません。',ha='center');ax.set_xlim(0,10);ax.set_ylim(-.5,6);pdf.savefig(fig);plt.close(fig)
# Trace table, retaining final polygons after multiple edits to one ID.
lookup={s['id']:(f,s)for f in F for s in f['stores']};old={s['id']:(f,s)for f in B for s in f['stores']};rows=[]
for sid in sorted(changed):
 f,s=lookup[sid];of,os=old[sid];rows.append([sid,f['wing'],f['label'],os['polygon'].area,s['polygon'].area,os['entry'][0]+429,os['entry'][1]-46,s['entry'][0]+429,s['entry'][1]-46,' / '.join(dict.fromkeys(r['reason']for r in changes if r['id']==sid))])
csvwrite(R/'変更座標・区画対応表.csv',['store_id','wing','floor','before_gross_m2','after_gross_m2','old_world_x','old_world_z','new_world_x','new_world_z','reason'],rows)
print('REVIEW_PLANS_COMPLETE',len(changed))
