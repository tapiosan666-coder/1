from pathlib import Path
import sys,math,heapq,numpy as np,shapely
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
from scipy.ndimage import distance_transform_edt
P=Path(__file__).resolve().parents[1];D=read(P/'source/site-v7.json');routes=[];fail=[]
def loc(p,y):return[p[0]+429,y,p[1]-46]
def add(id,kind,pts):routes.append({'id':id,'kind':kind,'points':pts})
# Local portals to representative sales aisle, preserves exact source shop entry instead of nearest-point success.
for f in D['floors']:
 if f['wing']=='B'and f['level']in[0,1,2]:continue
 for s in f['stores']:
  pts=s.get('main_route');e=s['entry'];n=s['n'];outside=[e[0]-n[0]*1.1,e[1]-n[1]*1.1];inside=[e[0]+n[0]*1.1,e[1]+n[1]*1.1]
  if not s['polygon'].buffer(.02).covers(Point(inside)):n=[-n[0],-n[1]];outside=[e[0]-n[0]*1.1,e[1]-n[1]*1.1];inside=[e[0]+n[0]*1.1,e[1]+n[1]*1.1]
  pts=[outside,e,inside]
  add(s['id']+'-ENTRY','actual source shop doorway', [loc(p,f['height'])for p in pts])
# Retain v6 B retail/stock and main walking checks, but drop old fake preview/roof markers.
old=read(P/'source/physical-routes.json')
for r in old:
 if r['id'].startswith(('B1-','B2-','B3-','PUBLIC-','SERVICE-')):routes.append(r)
# Straight and two-flight vertical travel at every storey; no floor debug teleport inside a route.
for d in D['devices']:
 for flight in d['flights']:
  a,b=flight['ramps'];front=next(r['front']for r in d['floors']if r['level']==flight['from']);fc=front.representative_point();mid=flight['mid'].centroid
  da=(np.array(a['b'])-a['a']);da=da/np.linalg.norm(da);db=(np.array(b['b'])-b['a']);db=db/np.linalg.norm(db)
  pts=[loc((fc.x,fc.y),flight['lower_y']),loc(np.array(a['a'])-da*.7,a['y0']),loc(a['a'],a['y0']),loc(a['b'],a['y1']),loc((mid.x,mid.y),flight['mid_y']),loc(b['a'],b['y0']),loc(b['b'],b['y1']),loc(np.array(b['b'])+db*.7,b['y1']),loc((fc.x,fc.y),flight['upper_y'])]
  add(d['id']+f"-STAIR-{flight['from']}-UP",'two-flight physical stair support',pts);add(d['id']+f"-STAIR-{flight['from']}-DOWN",'two-flight physical stair support',pts[::-1])
# Every ramp has actual source slope points/levels. Pedestrian capsule here is diagnostic only, not vehicle driving.
for fac in D['parking']['facilities']:
 for r in fac['ramps']:
  pts=[loc((p[0],p[2]),p[1])for p in r['profile_xyz']];add(r['id'],'parking ramp physical capsule (not driving)',pts)
# Raster graph only plans public-floor paths; actual physical validation remains separate.
class Planner:
 def __init__(self,g,step=.8):
  self.g=g.buffer(-.36).simplify(.015);self.step=step;self.x0,self.z0,x1,z1=self.g.bounds;self.nx=math.ceil((x1-self.x0)/step)+1;self.nz=math.ceil((z1-self.z0)/step)+1;xx=np.arange(self.nx)*step+self.x0;zz=np.arange(self.nz)*step+self.z0;self.mask=shapely.contains_xy(self.g,xx[None,:],zz[:,None]);self.prepared={}
 def cell(self,p):
  x=round((p[0]-self.x0)/self.step);z=round((p[1]-self.z0)/self.step);opts=[]
  for dz in range(-3,4):
   for dx in range(-3,4):
    xx=x+dx;zz=z+dz
    if 0<=xx<self.nx and 0<=zz<self.nz and self.mask[zz,xx]:
     q=(self.x0+xx*self.step,self.z0+zz*self.step)
     if self.g.buffer(.005).covers(LineString([p,q])):opts.append((math.dist(p,q),(xx,zz)))
  return min(opts)[1]if opts else None
 def path(self,a,b):
  if not self.g.buffer(.005).covers(Point(a))or not self.g.buffer(.005).covers(Point(b)):return None
  if self.g.buffer(.005).covers(LineString([a,b])):return[a,b]
  aa,bb=self.cell(a),self.cell(b)
  if aa is None or bb is None:return None
  pq=[(0,aa)];dist={aa:0};prev={}
  while pq:
   _,q=heapq.heappop(pq)
   if q==bb:break
   for dx,dz in[(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]:
    qq=(q[0]+dx,q[1]+dz)
    if not(0<=qq[0]<self.nx and 0<=qq[1]<self.nz)or not self.mask[qq[1],qq[0]]:continue
    if dx and dz and(not self.mask[q[1],qq[0]]or not self.mask[qq[1],q[0]]):continue
    dd=dist[q]+math.hypot(dx,dz)
    if dd<dist.get(qq,1e99):dist[qq]=dd;prev[qq]=q;heapq.heappush(pq,(dd+math.dist(qq,bb),qq))
  if bb not in dist:return None
  seq=[b];q=bb
  while q!=aa:seq.append((self.x0+q[0]*self.step,self.z0+q[1]*self.step));q=prev[q]
  seq+=[a];seq.reverse();simple=[seq[0]];i=0
  while i<len(seq)-1:
   j=len(seq)-1
   while j>i+1 and not self.g.buffer(.005).covers(LineString([seq[i],seq[j]])):j-=1
   simple.append(seq[j]);i=j
  return simple
planners={}
for f in D['floors']:
 w=f['wing'];lev=f['level'];obs=unary_union([o.get('geom',o.get('polygon'))for o in f.get('furniture',[])if o.get('geom',o.get('polygon'))is not None]);g=f['public'].union(f.get('core_free',Polygon())).difference(obs.buffer(.08));planners[w,lev]=Planner(g)
 # each core: source public edge -> EV landing and stair-door access
 for dev in[d for d in D['devices']if d['wing']==w]:
  row=next(r for r in dev['floors']if r['level']==lev);door=dev.get('door');entry=dev['entry'];point=row['front'].representative_point();endpoints=[('STAIR',[point.x,point.y])]
  if door:
   cc=row['cabin'].centroid;n=np.array([cc.x-door['p'][0],cc.y-door['p'][1]]);n=n/np.linalg.norm(n);endpoints.append(('EV',[door['p'][0]-n[0]*.9,door['p'][1]-n[1]*.9]))
  for kind,end in endpoints:
   if kind=='STAIR':
    ed=dev['stair_door']['p'];centre=dev['rooms']['stair'].centroid;n=np.array([centre.x-ed[0],centre.y-ed[1]]);n=n/np.linalg.norm(n);outer=(np.array(ed)-n*.8).tolist();inner=(np.array(ed)+n*.8).tolist();first=planners[w,lev].path(entry,outer);last=planners[w,lev].path(inner,end);path=first+[ed]+last if first and last else None
   else:path=planners[w,lev].path(entry,end)
   if path:add(dev['id']+'-'+f['label']+'-ACCESS-'+kind,'public to real vertical lobby',[loc(p,f['height'])for p in path])
   else:fail.append({'id':dev['id']+'-'+f['label']+'-ACCESS-'+kind,'start':entry,'end':end,'reason':'no exact-endpoint public/core-free path'})
# Interwing bridges continue into the destination retail street; choose existing shop doorway nearest bridge but at least8m beyond it.
for con in read(P/'source/annex-v6.json')['connections']:
 w=con['target'];lev=con['level'];other=next(f for f in D['floors']if f['wing']==w and f['level']==lev);ep=con['world_route'][-1];options=[]
 for s in other['stores']:
  e=s['entry'];n=s['n'];p=[e[0]-n[0]*1.2,e[1]-n[1]*1.2]
  if other['public'].buffer(-.36).covers(Point(p))and math.dist(p,ep)>8:options.append((math.dist(p,ep),s['id'],p))
 bridge_planner=Planner(other['public'].union(con['polygon']).union(other.get('core_free',Polygon())))
 for _,id,p in sorted(options):
  path=bridge_planner.path(ep,p)
  if path:
   add(con['id']+'-THROUGH-TO-'+id,'B bridge into actual A/C shop street',[loc(p,con['height'])for p in con['world_route'][:-1]+path]);break
 else:fail.append({'id':con['id'],'reason':'destination street path not solved'})
# Original named parking/site paths; no path invented to force a successful result.
for q in D['site']['walks']+D['site']['bridges']:
 neighborhood=q['line'].buffer(12,join_style=2)
 supports=[r['polygon']for r in D['site']['walks']+D['site']['bridges']if abs(r['height']-q['height'])<.02]
 supports +=[f['public'] for f in D['floors']if abs(f['height']-q['height'])<.02]
 supports +=[f['protected_pedestrian']for fac in D['parking']['facilities']for f in fac['floors']if abs(f['height']-q['height'])<.02]
 if abs(q['height'])<.02:supports.append(D['site']['old_A22']['protected_pedestrian'])
 free=unary_union(supports).intersection(neighborhood);obstacles=[]
 for t in D['site']['pedestrian_towers']:
  if abs(q['height'])<.02 or abs(q['height']-5.525)<.02:
   free=free.union(t['outline']);obstacles.extend([t['stair'].buffer(.13),t['lift'].buffer(.13)])
 planner=Planner(free.difference(unary_union(obstacles)),.4);pts0=list(q['line'].coords);path=planner.path(pts0[0],pts0[-1])
 if path:pts=[loc(p,q['height'])for p in path]
 else:
  pts=[loc(p,q['height'])for p in pts0];fail.append({'id':q['id'],'reason':'cannot route through existing tower landings without crossing equipment; source line retained as failing diagnostic'})
 add(q['id']+'-SITE-WALK','source site footpath with actual tower lobby route',pts);add(q['id']+'-SITE-WALK-REVERSE','source site footpath with actual tower lobby route',pts[::-1])
for fac in D['parking']['facilities']:
 for f in fac['floors']:
  free=f['protected_pedestrian'].union(unary_union([c['public_lobby'].union(c['stair'])for c in f['cores']])).difference(f.get('edge_guard',Polygon()));walls=[]
  for c in f['cores']:
   walls.append(c['stair'].boundary.buffer(.105).difference(rect(c['stair_entry'],(0,1),1.8,.7)))
   if not c['elevator'].is_empty:walls.append(c['elevator'].boundary.buffer(.105).difference(rect(c['elevator_entry'],(1,0),1.6,.7)))
  planner=Planner(free.difference(unary_union(walls)),.4)
  for c in f['cores']:
   dev=next((d for d in D['devices']if d['id']==c['id']),None)
   if dev is None:continue
   row=next(r for r in dev['floors']if r['level']==f['level']);ep=c['entry'];fc=row['front'].representative_point();end=[fc.x,fc.y];path=planner.path(ep,end)
   if path:add(c['id']+'-'+f['label']+'-PUBLIC-STAIR','parking protected pedestrian to actual stair lobby',[loc(p,f['height'])for p in path])
   else:fail.append({'id':c['id']+'-'+f['label']+'-PUBLIC-STAIR','reason':'exact parking stair access not planned'})
   if c.get('elevator_entry'):
    ep=c['elevator_entry'];cc=c['elevator'].centroid;v=np.array([cc.x-ep[0],cc.y-ep[1]]);v=v/np.linalg.norm(v);end=(np.array(ep)-v*.9).tolist();path=planner.path(c['entry'],end)
    if path:add(c['id']+'-'+f['label']+'-PUBLIC-EV','parking protected pedestrian to elevator landing',[loc(p,f['height'])for p in path])
    else:fail.append({'id':c['id']+'-'+f['label']+'-PUBLIC-EV','reason':'exact parking elevator access not planned'})
write(P/'source/physical-routes-v7.json',routes);write(P/'source/path-planning-v7.json',{'count':len(routes),'failures':fail,'not_a_physical_test':True});print('ROUTES',len(routes),'plan failures',len(fail),flush=True)
