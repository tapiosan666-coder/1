from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import numpy as np,random
P=Path(__file__).resolve().parents[1]/'assets/v10/materials';P.mkdir(exist_ok=True);N=1024;rng=np.random.default_rng(10012)
def noise(n):return np.asarray(Image.fromarray(np.uint8(rng.uniform(0,255,(n,n)))).resize((N,N),Image.Resampling.BICUBIC),dtype=float)/255-.5
cloud=noise(8);grain=noise(180);fine=noise(512)
for name,base,rough in [('limestone',(209,204,192),.28),('terrazzo',(193,185,167),.37),('plaster',(217,212,200),.83),('basalt',(53,57,55),.38),('paving',(169,133,103),.79)]:
 arr=np.array(base)[None,None,:]+cloud[:,:,None]*(6 if name!='plaster'else 3)+grain[:,:,None]*2+fine[:,:,None]
 height=grain*.00012+fine*.00005
 if name=='terrazzo':
  im=Image.fromarray(np.uint8(np.clip(arr,0,255)));dr=ImageDraw.Draw(im)
  rr=random.Random(1009)
  for i in range(18000):
   x=rr.randrange(N);y=rr.randrange(N);r=rr.choice([1,1,1,2,3]);c=rr.choice([(171,164,145),(207,200,185),(144,142,131),(222,216,204)]);dr.polygon([(x-r,y),(x,y-r),(x+r,y-r/2),(x+r/2,y+r)],fill=c)
  arr=np.array(im)
 if name=='paving':height=grain*.0008+fine*.00015
 Image.fromarray(np.uint8(np.clip(arr,0,255))).save(P/(name+'-albedo.png'))
 dx=np.gradient(height,axis=1)*N/1.2;dy=np.gradient(height,axis=0)*N/1.2;nn=np.stack([-dx,-dy,np.ones_like(dx)],axis=2);nn/=np.linalg.norm(nn,axis=2,keepdims=True);Image.fromarray(np.uint8((nn*.5+.5)*255)).save(P/(name+'-normal.png'));Image.fromarray(np.uint8(np.clip(rough+grain*.035,0,1)*255)).save(P/(name+'-roughness.png'))
print('V10 original physically sized material maps; roughness is authored, not measured.')
