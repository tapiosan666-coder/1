"""Unapproved C outlet variant. Six pavilions + perimeter links, explicit load paths. Does not alter normal or originals."""
from pathlib import Path
import sys,math,heapq,numpy as np,copy
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import contains_xy,constrained_delaunay_triangles,set_precision
from shapely.ops import transform
D=read(P/'source/site-v11.json');F=D['floors'];C=[f for f in F if f['wing']=='C'];base=load_pack(P/'assets/v10/base-site.pack.zst');repair=load_pack(P/'assets/v11/repairs.pack.zst');M={};coll={};render_group='';routes=read(P/'source/physical-routes-v11.json');centre=np.mean([np.array(p['footprint'].centroid.coords[0])for p in C[1]['pavilions']],axis=0);records=[];connections=[];protected=[];support_rows=[]
def pos(x,y,z):return[float(x+429),float(y),float(z-46)]
exec((P/'authoring/mesh_primitives.py').read_text())
def world(g):return transform(lambda x,z,zz=None:(np.array(x)+429,np.array(z)-46),g)
def astar(start,end,space):
 if space.covers(LineString([start,end])):return[start,end]
 step=1.0;x0,z0,x1,z1=space.bounds;origin=(math.floor(x0),math.floor(z0));node=lambda p:(round(p[0]-origin[0]),round(p[1]-origin[1]));point=lambda n:(origin[0]+n[0],origin[1]+n[1]);a=node(start);b=node(end);valid={}
 def okay(n):
  if n not in valid:valid[n]=space.covers(Point(point(n)))
  return valid[n]
 if not okay(a):a=min([(a[0]+i,a[1]+j)for i in range(-3,4)for j in range(-3,4)if okay((a[0]+i,a[1]+j))],key=lambda n:math.dist(point(n),start))
 if not okay(b):b=min([(b[0]+i,b[1]+j)for i in range(-3,4)for j in range(-3,4)if okay((b[0]+i,b[1]+j))],key=lambda n:math.dist(point(n),end))
 q=[(0,0,a)];cost={a:0};parent={}
 while q:
  _,v,n=heapq.heappop(q)
  if v>cost[n]+1e-7:continue
  if n==b:break
  for dx,dz in[(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]:
   nn=(n[0]+dx,n[1]+dz)
   if not okay(nn):continue
   pp=point(nn);penalty=1+10*max(0,1-math.dist(pp,centre)/95)**2;nv=v+math.hypot(dx,dz)*penalty
   if nv<cost.get(nn,1e20):cost[nn]=nv;parent[nn]=n;heapq.heappush(q,(nv+math.dist(pp,point(b)),nv,nn))
 else:raise RuntimeError('C gallery disconnected '+str(start)+str(end))
 path=[end,point(b)];n=b
 while n!=a:n=parent[n];path.append(point(n))
 path.append(start);path=path[::-1];out=[path[0]];i=0
 while i<len(path)-1:
  j=len(path)-1
  while j>i+1 and not space.covers(LineString([path[i],path[j]])):j-=1
  out.append(path[j]);i=j
 return out
# Same six upper link axes at 2F/3F: avoid a different unsupported web on every floor.
f2=next(f for f in C if f['level']==1);f3=next(f for f in C if f['level']==2);common=f2['public'].intersection(f3['public']).buffer(-1.15,join_style=2);pavs=sorted(f2['pavilions'],key=lambda p:math.atan2(p['footprint'].centroid.y-centre[1],p['footprint'].centroid.x-centre[0]));anchors={p['id']:list(p['front_corridor'].intersection(common).representative_point().coords[0])for p in pavs};network=[]
for a,b in zip(pavs,pavs[1:]+pavs[:1]):
 points=astar(anchors[a['id']],anchors[b['id']],common);line=LineString(points);network.append(line);connections.append({'id':'C-GALLERY-'+a['id']+'-'+b['id'],'from':a['id'],'to':b['id'],'points':points,'length_m':line.length,'purpose':'Neighbouring pavilion galleries; perimeter circulation, no central shortcut','clear_width_m':4.0});print('C_LINK',a['id'],b['id'],round(line.length,1),flush=True)
# Keep every ground-level protected route and doorway away from column footprints.
f0=next(f for f in C if f['level']==0);groundkeep=[]
for r in routes:
 for a,b in zip(r['points'],r['points'][1:]):
  if abs(a[1])<.05 and abs(b[1])<.05:groundkeep.append(LineString([(a[0]-429,a[2]+46),(b[0]-429,b[2]+46)]).buffer(.8,cap_style=2))
for s in f0['stores']:groundkeep.append(Point(s['entry']).buffer(1.8))
upperkeep=[ln.buffer(1.0,cap_style=2,join_style=2)for ln in network]
for r in routes:
 if r['id'].startswith(('BC-2','C-K-')):
  for a,b in zip(r['points'],r['points'][1:]):
   if abs(a[1]-b[1])<.05:upperkeep.append(LineString([(a[0]-429,a[2]+46),(b[0]-429,b[2]+46)]).buffer(1.0,cap_style=2,join_style=2))
protected=unary_union(groundkeep+upperkeep);shops0=unary_union([s['polygon']for s in f0['stores']]);device_keep=[]
for f in C:
 for e in f['escalators']:device_keep.append(rect(e['c'],e['u'],e['run_m']+8,6.0))
all_devices={e['id']:e for ff in C for e in ff['escalators']};devices_by_level={lev:unary_union([rect(e['c'],e['u'],e['run_m']+8,6.0)for e in all_devices.values()if lev in e['levels']])for lev in [1,2,3]};devices=unary_union(device_keep);normalfloors={f['level']:f['floor_plate']for f in C}
for f in C:
 if f['level']<1:continue
 y=f['height'];lev=f['level'];devices=devices_by_level[lev];old=f['floor_plate'];pavilion=unary_union([p['footprint']for p in f['pavilions']]);core=unary_union([c['outline'].buffer(1.0,join_style=2)for c in f['cores']]);link=unary_union([ln.buffer(2.0,cap_style=1,join_style=2)for ln in network])if lev<3 else Polygon();necessary=[]
 for r in routes:
  if not(r['id'].startswith('BC-2')or r['id'].startswith('BR-PCN')or r['id'].startswith('P-CN')):continue
  pts=r['points']
  for aa,bb in zip(pts,pts[1:]):
   if abs(aa[1]-y)<.05 and abs(bb[1]-y)<.05:necessary.append(LineString([(aa[0]-429,aa[2]+46),(bb[0]-429,bb[2]+46)]).buffer(2.0,cap_style=1,join_style=2))
 new=set_precision(old.intersection(pavilion.union(core).union(link).union(devices).union(unary_union(necessary))),.001);delta=old.difference(new);public=f['public'].intersection(new);shops=unary_union([s['polygon']for s in f['stores']]);lost=shops.difference(new).area;assert lost<.03,(f['label'],lost)
 # Replace the real structural slab and ceiling, not only its decorative surface.
 for key,d in list(base['surfaces'].items()):
  mat,_,group=key.partition('@@');a=triangles(d);ct=a.mean(1);drop=np.zeros(len(a),bool)
  if group=='C-'+f['label']and mat=='stone':drop=(a[:,:,1].min(1)>=y-.381)&(a[:,:,1].max(1)<=y+.001)
  if mat in['glass','v10_guard_glass']and group=='C-'+f['label']:drop|=(a[:,:,1].min(1)>=y-.01)&(a[:,:,1].max(1)<=y+1.25)&contains_xy(world(old.buffer(.2)),ct[:,0],ct[:,2])
  if group=='C-'+next(q for q in C if q['level']==lev-1)['label']and mat=='plaster':drop|=np.all(abs(a[:,:,1]-(y-.42))<.005,axis=1)
  if drop.any():base['surfaces'][key]=retain(d,~drop)
 for mat,v in base['colliders'].items():
  a=np.asarray(v).reshape(-1,3,3);ct=a.mean(1);drop=np.zeros(len(a),bool);inside=contains_xy(world(old.buffer(.25)),ct[:,0],ct[:,2])
  if mat=='stone':drop=inside&(a[:,:,1].min(1)>=y-.381)&(a[:,:,1].max(1)<=y+.001)
  if mat in['glass','v10_guard_glass']:
   protected_glazing=world(unary_union([ss['polygon'].buffer(.30,join_style=2)for ss in f['stores']]+[cc['outline'].buffer(.25,join_style=2)for cc in f['cores']]))
   drop|=inside&(a[:,:,1].min(1)>=y-.01)&(a[:,:,1].max(1)<=y+1.25)&(np.ptp(a[:,:,1],axis=1)>.5)&~contains_xy(protected_glazing,ct[:,0],ct[:,2])
  base['colliders'][mat]=a[~drop].ravel()
 # Variant-specific visible upper rail finishes must not float over deleted decks.
 for key,d in list(repair['surfaces'].items()):
  if 'V11-GUARD-'not in key:continue
  a=triangles(d);ct=a.mean(1);drop=(ct[:,1]>=y-.01)&(ct[:,1]<y+1.25)&contains_xy(world(old.buffer(.3)),ct[:,0],ct[:,2]);repair['surfaces'][key]=retain(d,~drop)
 # Restore new slab soffit and safe borders with explicit bridge/vertical-device mouths.
 render_group='V12-C-'+f['label'];extrude(new,y-.38,.38,'stone',True);surf(new,y-.385,'plaster',False)
 exclude=devices.buffer(.08).union(core.buffer(.1));exclude=exclude.union(shops.buffer(.2))if lev<3 else exclude;edge=new.boundary.difference(exclude);mouths=[]
 for r in routes:
  if not(r['id'].startswith('BC-2')or r['id'].startswith('BR-PCN')or r['id'].startswith('P-CN')):continue
  for aa,bb in zip(r['points'],r['points'][1:]):
   if abs(aa[1]-y)<.05 and abs(bb[1]-y)<.05:mouths.append(LineString([(aa[0]-429,aa[2]+46),(bb[0]-429,bb[2]+46)]).buffer(1.8,cap_style=1))
 edge=edge.difference(unary_union(mouths));rail=edge.buffer(.05,cap_style=2,join_style=2);extrude(rail,y,.14,'v10_darkstone',True);extrude(rail,y+.14,1.01,'v10_guard_glass',True);extrude(edge.buffer(.025,cap_style=2),y+1.15,.04,'v10_metal',False)
 # Main edge girders stay directly under the gallery slabs. They are visual load-path studies, not certified beams.
 deck=new.difference(pavilion.buffer(.1));beam=deck.boundary.buffer(.13,cap_style=2).intersection(new);extrude(beam,y-.95,.57,'v10_metal',False)
 records.append({'floor':f['label'],'level':lev,'height':y,'before_floor_m2':old.area,'proposed_floor_m2':new.area,'removed_m2':delta.area,'proposed_floor':new,'proposed_public':public,'retail_area_lost_m2':lost,'store_ids':[s['id']for s in f['stores']],'unapproved':True,'load_capacity_verified':False,'retained_device_ids':[e['id']for e in all_devices.values()if lev in e['levels']],'floor_components':len(polys(new))})
 print('C_FLOOR',f['label'],round(old.area),round(new.area),'removed',round(delta.area),flush=True)
# Portal supports on the outside edges of the shared 2F/3F galleries. Keep ground routes and shop entrances clear.
render_group='V12-C-CONTINUOUS-SUPPORTS';used=[]
for conn,line in zip(connections,network):
 samples=np.linspace(0,line.length,max(2,math.ceil(line.length/7.5)+1))
 for s in samples:
  p=np.array(line.interpolate(float(s)).coords[0]);a=np.array(line.interpolate(max(0,float(s)-.1)).coords[0]);b=np.array(line.interpolate(min(line.length,float(s)+.1)).coords[0]);u=b-a
  if np.linalg.norm(u)<.01:continue
  u/=np.linalg.norm(u);n=np.array([-u[1],u[0]])
  for side in[-1,1]:
   c=p+n*side*1.78;fp=rect(c,u,.28,.28)
   if fp.intersects(shops0.buffer(.12))or fp.intersects(protected)or any(np.linalg.norm(c-q)<.7 for q in used):continue
   used.append(c);extrude(fp,-.45,10.875-.38+.45,'v10_chalk',True);extrude(rect(c,u,.60,.60),-.35,.38,'v10_darkstone',True);support_rows.append({'connection':conn['id'],'world_xz':[c[0]+429,c[1]-46],'column_m':.28,'top_y':10.495,'status':'Visual and collision placement only; structural capacity NOT verified'})
  for y in[5.525,10.875]:extrude(rect(p,n,4.0,.28),y-.95,.57,'v10_metal',False)
# Roof decks are the existing pavilion roofs, not a new continuous canopy over the yard.
base['surfaces'].update({k:{a:np.asarray(v,dtype=np.float32)for a,v in d.items()}for k,d in M.items()})
for k,v in coll.items():base['colliders'][k]=np.concatenate([base['colliders'].get(k,np.array([],dtype=np.float32)),np.asarray(v,dtype=np.float32)])
print(save_zst(P/'assets/v12/C-outlet.pack.zst',base));print(save_zst(P/'assets/v12/repairs-C.pack.zst',repair));write(P/'source/v12/C-outlet-proposal.json',{'status':'UNAPPROVED independent C outlet structural variant','normal_geometry_unchanged':True,'RF_SUPPORT_16':'UNAPPROVED','floors':records,'gallery_connections':connections,'supports':support_rows,'support_design_limits':['Visual load paths only. No capacity, foundation, wind/seismic or fire/egress certification.','Support omissions near ground doors/routes require separate structural resolution.'],'pavilion_store_ids_preserved':True,'human_playtest':False})
print('C_PROPOSAL_COMPLETE',len(support_rows),'supports',flush=True)
