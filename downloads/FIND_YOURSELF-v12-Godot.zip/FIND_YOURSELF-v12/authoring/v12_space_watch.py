"""Residual geometry watch list. A label or successful ray test never certifies architectural necessity."""
from pathlib import Path
import sys,math
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
F=read(P/'source/v11/floors-updated.json');routes=read(P/'source/physical-routes-v11.json');out=[]
for f in F:
 U=unary_union([s['polygon']for s in f['stores']]);candidate=U.buffer(.65,join_style=2).buffer(-.65,join_style=2).difference(U).intersection(f['floor_plate']);protected=[]
 for r in routes:
  for a,b in zip(r['points'],r['points'][1:]):
   if abs(a[1]-f['height'])<.05 and abs(b[1]-f['height'])<.05:protected.append(LineString([(a[0]-429,a[2]+46),(b[0]-429,b[2]+46)]).buffer(.65,cap_style=1))
 protected+= [c['outline'].buffer(.15)for c in f['cores']]
 for k,g in enumerate(polys(candidate)):
  if g.area<.08:continue
  neighbors=[s['id']for s in f['stores']if s['polygon'].distance(g)<.025];p=g.representative_point();retained=g.intersection(unary_union(protected)).area>.02
  out.append({'id':f'{f["wing"]}{f["label"]}-NARROW-{k}','wing':f['wing'],'floor':f['label'],'area_m2':g.area,'world_x':p.x+429,'world_y':f['height'],'world_z':p.y-46,'store_ids':';'.join(neighbors),'kind':'morphological inter-tenant narrow-space candidate','status':'PRESERVE_REGISTERED_ACCESS'if retained else'REVIEW_OWNERSHIP_NOT_AUTOMATICALLY_A_DEFECT','reason':'Named entrance/core/route intersects'if retained else'No final use proven by the narrow-space detector. Do not seal, label as storage or claim fixed from a walk pass.','geometry':g,'action':'Keep access; visual review'if retained else'Compare canonical tenant/common/service ownership; issue local plan proposal before structural change.'})
 if f['wing']=='C':
  assigned=unary_union([f['public']]+[s['polygon']for s in f['stores']]+[c['outline']for c in f['cores']]);rem=f['floor_plate'].difference(assigned)
  for k,g in enumerate(polys(rem)):
   if g.area<.1:continue
   p=g.representative_point();near=sorted(f['stores'],key=lambda s:s['polygon'].distance(g))[:3]
   out.append({'id':f'C{f["label"]}-REAR-BAND-{k}','wing':'C','floor':f['label'],'area_m2':g.area,'world_x':p.x+429,'world_y':f['height'],'world_z':p.y-46,'store_ids':';'.join(s['id']for s in near),'kind':'floor area outside tenant/public/core ownership; may include wall/service/landscape','status':'UNRESOLVED_ACCOUNTING_AND_PURPOSE_REVIEW','reason':'Pavilion footprint is generated separately from inset tenant plots. Difference can survive as a thin rear perimeter strip. Area alone does not prove an accessible alley.','geometry':g,'action':'Proposal only: reconcile wall thickness and service requirements with tenant backroom boundaries. Do not shrink sales or invent a warehouse.'})
write(P/'source/v12/space-watch.json',{'items':out,'not_all_confirmed_defects':True,'human_playtest':False,'rule':'Each generated walkable face needs an owner and declared role; polygon validity and ray coverage are insufficient. Render wall and physical wall must share geometry; rear faces opaque; openings explicit; no leftover automatically becomes a corridor.'})
head=['id','wing','floor','area_m2','world_x','world_y','world_z','store_ids','kind','status','reason','action'];csvwrite(P/'source/v12/space-watch.csv',head,[[r[k]for k in head]for r in out]);print('SPACE_WATCH',len(out),'records',flush=True)
