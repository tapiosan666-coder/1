from pathlib import Path
import sys
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
rows=[];issues=[]
for f in read(P/'source/v11/floors-updated.json'):
 stores=f['stores'];r={'floor':f['wing']+f['label'],'stores':len(stores),'store_public_overlap_m2':0.,'store_outside_structural_floor_m2':0.,'sales_stock_overlap_m2':0.,'sales_stock_partition_residual_m2':0.,'entry_not_touching_public':[]}
 for s in stores:
  vals={'store_public_overlap_m2':s['polygon'].intersection(f['public']).area,'store_outside_structural_floor_m2':s['polygon'].difference(f['floor_plate']).area,'sales_stock_overlap_m2':s['sales'].intersection(s['backroom']).area,'sales_stock_partition_residual_m2':s['polygon'].symmetric_difference(s['sales'].union(s['backroom'])).area}
  for k,v in vals.items():
   r[k]+=v
   if v>1e-4:issues.append({'store_id':s['id'],'issue':k,'area_m2':v})
  if f['public'].distance(Point(s['entry']))>.03:r['entry_not_touching_public'].append(s['id']);issues.append({'store_id':s['id'],'issue':'entry_not_touching_public','distance_m':f['public'].distance(Point(s['entry']))})
 rows.append(r)
write(P/'source/v11/partition-check.json',{'floors':rows,'issues':issues,'tolerance_m2':.0001,'geometric_only':True,'human_playtest':False});print('PARTITION_CHECK',len(issues),'issues');print(issues[:12])
