"""Escalator openings: derive slabs and guards from actual collision floors, preserve the tested inclined support/controller."""
from pathlib import Path
import sys,math,numpy as np,hashlib
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import constrained_delaunay_triangles,set_precision
F=read(P/'source/site-v11.json')['floors'];es=read(P/'source/scene-manifest.json')['escalators']+read(P/'source/site-manifest-v7.json')['escalators'];levels=sorted(set(f['height']for f in F));inputs={n:load_pack(P/'assets/v10'/(n+'.pack.zst'))for n in ['base-b','base-site','fitout','art','architecture']};inputs['repairs']=load_pack(P/'assets/v11/repairs.pack.zst');alltri=np.concatenate([np.asarray(v).reshape(-1,3,3)for g in inputs.values()for v in g['colliders'].values()]);flat={y:alltri[(np.ptp(alltri[:,:,1],axis=1)<.003)&(abs(alltri[:,:,1].mean(1)-y)<.02)]for y in levels}
def floor_near(y,roi):
 a=flat[y];ct=a.mean(1);x,z,xx,zz=roi.bounds;bb=(a[:,:,0].min(1)<=xx)&(a[:,:,0].max(1)>=x)&(a[:,:,2].min(1)<=zz)&(a[:,:,2].max(1)>=z);out=[]
 for t in a[bb]:
  p=Polygon(t[:,[0,2]])
  if p.area>.0001:out.append(p.intersection(roi))
 return set_precision(unary_union(out),.001)
def blocker_lines(y,roi):
 a=alltri;plane=y+.7;lo=a[:,:,1].min(1);hi=a[:,:,1].max(1);x,z,xx,zz=roi.bounds;mask=(lo<plane)&(hi>plane)&(hi>y+.95)&(a[:,:,0].max(1)>=x)&(a[:,:,0].min(1)<=xx)&(a[:,:,2].max(1)>=z)&(a[:,:,2].min(1)<=zz);out=[]
 for t in a[mask]:
  pts=[]
  for i,j in[(0,1),(1,2),(2,0)]:
   if(t[i,1]-plane)*(t[j,1]-plane)<0:
    p=t[i]+(t[j]-t[i])*(plane-t[i,1])/(t[j,1]-t[i,1]);pts.append((p[0],p[2]))
  if len(pts)==2 and math.dist(*pts)>.01:out.append(LineString(pts))
 return unary_union(out).buffer(.08,join_style=2)
M={};coll={};render_group='';records=[];probes=[]
def pos(x,y,z):return[float(x),float(y),float(z)]
exec((P/'authoring/mesh_primitives.py').read_text())
for e in es:
 lo=e.get('low_y',levels[int(e['levels'][0])+1]);hi=e.get('high_y',levels[int(e['levels'][1])+1]);u=np.array(e['u'],float);n=np.array([-u[1],u[0]]);c=np.array([e['c'][0],e['c'][2]]);run=e['run_m'];half=run/2;wing=e.get('wing','B');big=rect(c,u,run+10,10);roi=rect(c,u,run+4,3.25);upper=floor_near(hi,big);lower=floor_near(lo,big);fill=[]
 # Close only unused low-shaft portions between two existing floor edges; retain >=2.30m clear headroom.
 limit=half-run*(2.30+.38)/(hi-lo)
 for s in np.arange(-half-1.5,limit-.1,.25):
  p=c+u*s
  if upper.covers(Point(*(p+n*1.38)))and upper.covers(Point(*(p-n*1.38))):fill.append(rect(p,u,.27,2.4).difference(upper))
 fill=unary_union(fill);upper_new=set_precision(upper.union(fill),.001);guards=[]
 render_group='V12-ES-'+e['id'];floor_mat='v10_floor_A'if wing=='A'else'v10_floor_B'if wing=='B'else'v10_floor_C'
 if not fill.is_empty:extrude(fill,hi-.38,.38,'stone',True);surf(fill,hi+.006,floor_mat);surf(fill,hi-.385,'plaster',False)
 for y,H,mouth,sg in[(lo,lower,c-u*half,-1),(hi,upper_new,c+u*half,1)]:
  edge=H.boundary.intersection(roi).difference(big.boundary.buffer(.05));opening=rect(mouth+u*sg*1.0,u,3.6,1.62);edge=edge.difference(opening).difference(blocker_lines(y,big));band=unary_union([ln.buffer(.055,cap_style=2,join_style=2)for ln in lines(edge)if ln.length>.10]);band=band.intersection(H.buffer(.015));guards.append({'y':y,'geometry':band})
  extrude(band,y,.16,'v10_darkstone',True);extrude(band,y+.16,.99,'v10_guard_glass',True);extrude(band,y+1.15,.04,'v10_metal',False)
  for ln in lines(edge):
   for s in np.linspace(0,ln.length,max(2,math.ceil(ln.length/1.8)+1)):
    p=ln.interpolate(float(s));pad=rect((p.x,p.y),(1,0),.07,.07).intersection(H.buffer(.025));extrude(pad,y+.01,1.14,'v10_metal',False)
 # Off-axis inputs: these deliberately avoid the designated upper mouth onto the moving flight.
 for s in[-half-1.7,-half*.6,0,half*.6,half+.75]:
  for side in[-1,1]:
   start=c+u*s+n*side*(.55 if s>half else 1.85);target=c+u*s+n*side*(2.3 if s>half else .25)
   if upper.buffer(-.31).covers(Point(*start)):
    probes.append({'id':e['id']+'-side-'+str(round(s,2))+'-'+str(side),'bank':e['id'],'floor_y':hi,'start':[start[0],hi,start[1]],'target':[target[0],hi,target[1]],'kind':'upper landing side or opening-side push, not normal escalator boarding'})
 records.append({'id':e['id'],'wing':wing,'floor_y':hi,'upper_floor_before':upper,'upper_floor_after':upper_new,'infill':fill,'infill_m2':fill.area,'guards':guards,'clear_headroom_m':2.30,'controller_changed':False,'ramp_changed':False});print('ES_SAFETY',e['id'],round(fill.area,2),sum(g['geometry'].area for g in guards),flush=True)
write(P/'source/v12/es-openings.json',records);write(P/'source/v12/es-probes.json',probes);extra=save_zst(P/'assets/v12/es-safety.pack.zst',{'surfaces':M,'colliders':coll,'signs':[],'lights':[]});print('SAFETY_GENERATED',len(records),'banks',len(probes),'probes',extra['bytes'])
