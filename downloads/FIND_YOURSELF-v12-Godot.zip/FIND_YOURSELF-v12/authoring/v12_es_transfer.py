"""Unapproved five-level stacked escalator architectural module; existing site placement unchanged."""
from pathlib import Path
import sys,math,numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import constrained_delaunay_triangles
M={};coll={};render_group='V12-TRANSFER-STUDY';banks=[];transfers=[];floors=[]
def pos(x,y,z):return[float(x),float(y),float(z)]
exec((P/'authoring/mesh_primitives.py').read_text())
# Two side-by-side up/down machines, alternating between two adjacent stacks. No crossing flights in the same volume.
for i,lev in enumerate([-1,0,1,2]):
 lo=HEIGHT[lev];hi=HEIGHT[lev+1];u=np.array([1.0 if i%2==0 else-1.0,0]);c0=np.array([0.,-3.2 if i%2==0 else 3.2]);n=np.array([-u[1],u[0]])
 for direction,offset in [('UP',1.1),('DOWN',-1.1)]:
  c=c0+np.array([0.,offset]);run=11.8;half=run/2;rise=hi-lo;a=c-u*half;b=c+u*half;side=np.array([-u[1],u[0]]);normal=np.array([-u[0]*rise/run,1.,-u[1]*rise/run]);normal/=np.linalg.norm(normal)
  # Same continuous slope collision used by the unchanged v11 player. Moving tread mesh sits above it.
  quad('step',[pos(*(a+side*.72)[:1],0,0)]if False else[pos(a[0]+side[0]*.72,lo,a[1]+side[1]*.72),pos(a[0]-side[0]*.72,lo,a[1]-side[1]*.72),pos(b[0]-side[0]*.72,hi,b[1]-side[1]*.72),pos(b[0]+side[0]*.72,hi,b[1]+side[1]*.72)],normal,solid=True)
  for sg,yy,ee in [(-1,lo,a),(1,hi,b)]:extrude(rect(ee+u*sg*.75,u,1.5,1.44),yy-.25,.25,'step',True)
  # Inclined glass safety balustrades plus solid skirt follow the real run.
  for sg in [-1,1]:
   aa=a+side*sg*.94;bb=b+side*sg*.94
   for y0,y1,mat in [(0,.15,'v10_metal'),(.15,.97,'v10_guard_glass')]:
    pp=[pos(aa[0],lo+y0,aa[1]),pos(bb[0],hi+y0,bb[1]),pos(bb[0],hi+y1,bb[1]),pos(aa[0],lo+y1,aa[1])];quad(mat,pp,(side[0]*sg,0,side[1]*sg),solid=True)
   for end,yy,ss in [(aa,lo,-1),(bb,hi,1)]:extrude(rect(end+u*ss*.75,u,1.5,.08),yy,.97,'v10_guard_glass',True)
  banks.append({'id':'STUDY-'+str(lev)+'-'+direction,'wing':'STUDY','levels':[lev,lev+1],'direction':direction,'c':pos(c[0],lo,c[1]),'u':u.tolist(),'low_y':lo,'high_y':hi,'run_m':run,'rise_m':rise,'test_start':pos(a[0]-u[0]*1.9,lo,a[1]-u[1]*1.9),'test_end':pos(b[0]+u[0]*1.9,hi,b[1]+u[1]*1.9)})
for i,lev in enumerate([-1,0,1,2]):
 lo=HEIGHT[lev];hi=HEIGHT[lev+1];u=np.array([1. if i%2==0 else -1.,0]);z=-3.2 if i%2==0 else 3.2;a=-u*7.35;b=u*7.35
 for sa,sb in zip([-7.35,-5.9,5.9],[-5.9,5.9,7.35]):
  aa=u*sa;bb=u*sb;ya=lo+(hi-lo)*max(0,min(1,(sa+5.9)/11.8))+.025;yb=lo+(hi-lo)*max(0,min(1,(sb+5.9)/11.8))+.025
  quad('v10_metal',[pos(aa[0],ya,z-.33),pos(bb[0],yb,z-.33),pos(bb[0],yb,z+.33),pos(aa[0],ya,z+.33)],(0,1,0),solid=True)
for lev in [-1,0,1,2,3]:
 y=HEIGHT[lev];outer=box(-12,-11,12,11);void=box(-7.4,-7.4,7.4,7.4)if lev>-1 else Polygon();floor=outer.difference(void);extrude(floor,y-.38,.38,'stone',True);surf(floor,y+.005,'v10_floor_A');surf(floor,y-.385,'plaster',False)
 rails=floor.boundary;mouths=[]
 for e in banks:
  for low,key in [(True,'test_start'),(False,'test_end')]:
   if abs(e[key][1]-y)<.01:
    c=np.array([e['c'][0],e['c'][2]]);u=np.array(e['u']);p=c+u*(-7.4 if low else 7.4);mouths.append(rect(p,u,1.2,2.45))
 rails=rails.difference(unary_union(mouths));extrude(rails.buffer(.04,cap_style=2),y,.16,'v10_chalk',True);extrude(rails.buffer(.025,cap_style=2),y+.16,.99,'v10_guard_glass',True);extrude(rails.buffer(.035,cap_style=2),y+1.15,.04,'v10_metal',False)
 floors.append({'label':LABEL[lev],'height':y,'floor':floor,'void':void})
for i in range(3):
 lower=next(e for e in banks if e['id']=='STUDY-'+str(i-1)+'-UP');upper=next(e for e in banks if e['id']=='STUDY-'+str(i)+'-UP');a=lower['test_end'];b=upper['test_start'];x=8.8 if a[0]>0 else-8.8;pts=[a,[x,a[1],a[2]],[x,a[1],b[2]],b];transfers.append({'from':lower['id'],'to':upper['id'],'points':pts,'centreline_length_m':sum(math.dist(a,b)for a,b in zip(pts,pts[1:])),'status':'Independent module only; not installed in A/B/C'})
# Four-column atrium frame; module proportions can be inspected without substituting an unproven site design.
for x in [-10.5,10.5]:
 for z in [-9.5,9.5]:extrude(Point(x,z).buffer(.27,quad_segs=8),-5.73,27.0,'v10_chalk',True)
for z in [-9.5,9.5]:extrude(rect((0,z),(1,0),21.5,.35),20.6,.5,'v10_chalk',False)
for x in np.arange(-10.5,10.6,3.5):extrude(rect((x,0),(0,1),19.4,.10),21.1,.10,'v10_metal',False)
surf(box(-11,-10,11,10),21.16,'roof_glass',True,False)
save_zst(P/'assets/v12/es-transfer-study.pack.zst',{'surfaces':M,'colliders':coll,'signs':[],'lights':[]});write(P/'source/v12/es-transfer-study.json',{'status':'UNAPPROVED independent five-level module / site NOT relocated','escalators':banks,'floors':floors,'transfers':transfers,'clear_mouth_width_m':2.45,'headroom_not_yet_verified':True,'RF_SUPPORT_16':'UNAPPROVED'})
# Audit original plan distances; these are horizontal straight lines, not invented walk measurements.
old=read(P/'source/scene-manifest.json')['escalators']+read(P/'source/site-manifest-v7.json')['escalators'];dist=[]
for e in old:
 if e['direction']!='UP':continue
 hi=HEIGHT[e['levels'][1]];u=np.array(e['u']);p=np.array([e['c'][0],e['c'][2]])+u*(e['run_m']/2+1.5);targets=[]
 for t in old:
  if t.get('wing','B')!=e.get('wing','B')or t['direction']!='UP'or t['levels'][0]!=e['levels'][1]:continue
  v=np.array(t['u']);q=np.array([t['c'][0],t['c'][2]])-v*(t['run_m']/2+1.5);targets.append((np.linalg.norm(q-p),t['id'],q.tolist()))
 if targets:
  d,tid,q=min(targets);dist.append({'wing':e.get('wing','B'),'from':e['id'],'to':tid,'floor_y':hi,'exit_world_xz':p.tolist(),'next_entry_world_xz':q,'straight_line_m':float(d),'walk_distance_measured':False})
write(P/'source/v12/es-transfer-existing.json',dist);print('TRANSFER_STUDY',len(banks),[round(x['centreline_length_m'],2)for x in transfers],flush=True)
