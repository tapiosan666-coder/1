"""Original industry-specific merchandising and weatherproof furniture. No new third-party assets."""
from pathlib import Path
P=Path(__file__).resolve().parents[1]
src=(P/'authoring/retail_models_v10.py').read_text();exec(src[:src.index('for var in range(3):bookcase')]);OUT=P/'assets/v11/models';OUT.mkdir(exist_ok=True,parents=True)
coated=material('Exterior_powder_coated_aluminium',(.13,.18,.17),.62,.65);outslat=material('Weatherproof_slatted_composite',(.34,.25,.15),.78);casecolors=[material('Luggage_shell_'+str(i),c,.48)for i,c in enumerate([(.16,.22,.25),(.33,.19,.12),(.46,.43,.35)])];produce=[material('Fruit_'+str(i),c,.50)for i,c in enumerate([(.49,.08,.03),(.72,.29,.03),(.18,.36,.08)])]
def outdoor_chair(x=0,y=0):
 for sx in[-.24,.24]:
  tube('Cast_aluminium_frame',[(x+sx,y+.27,.02),(x+sx,y+.21,.43),(x+sx,y-.22,.43),(x+sx,y-.27,.02)],.018,coated)
  tube('Sloped_back_frame',[(x+sx,y+.20,.43),(x+sx,y+.24,.82)],.018,coated)
 for i in range(6):box('Seat_slats',(x,y-.19+i*.074,.445),(.50,.055,.027),outslat,.007)
 for i in range(4):box('Back_slats',(x,y+.235,.52+i*.085),(.50,.028,.055),outslat,.007)
outdoor_chair();finish('outdoor_chair')
for sx in[-.65,.65]:
 tube('Bench_cast_leg',[(sx,.25,.02),(sx,.20,.44),(sx,-.20,.44),(sx,-.27,.02)],.027,coated);tube('Bench_back_support',[(sx,.22,.44),(sx,.30,.85)],.022,coated)
for i in range(6):box('Outdoor_bench_seat',(0,-.20+i*.08,.46),(1.65,.06,.035),outslat,.009)
for i in range(4):box('Outdoor_bench_back',(0,.27,.55+i*.09),(1.65,.035,.06),outslat,.009)
finish('outdoor_bench')
box('Outdoor_metal_table',(0,0,.735),(.64,.64,.035),coated,.03)
for x in[-.24,.24]:
 for y in[-.24,.24]:tube('Table_leg',[(x,y,.02),(x*.9,y*.9,.72)],.015,coated)
for yy,ang in[(-.69,0),(.69,math.pi)]:
 before=set(bpy.context.scene.objects);outdoor_chair(0,0)
 for ob in set(bpy.context.scene.objects)-before:ob.rotation_euler.z=ang;ob.location.y+=yy
finish('outdoor_cafe_set')
def suitcase(x,y,z,variant=0):
 box('Rounded_luggage_shell',(x,y,z+.31),(.36,.23,.58),casecolors[variant%3],.055)
 for zz in[-.16,-.08,0,.08,.16]:box('Shell_moulded_ribs',(x,y-.12,z+.31+zz),(.27,.008,.012),metal,.003)
 for xx in[-.11,.11]:
  lathe('Rubber_spinner_wheel',[(0,0),(.03,0),(.03,.035),(0,.035)],rubber,(x+xx,y,z),20)
  tube('Telescopic_rail',[(x+xx*.65,y+.02,z+.58),(x+xx*.65,y+.02,z+.83)],.009,steel)
 tube('Telescopic_grip',[(x-.08,y+.02,z+.83),(x+.08,y+.02,z+.83)],.018,rubber)
for sx in[-.72,0,.72]:
 suitcase(sx,0,.08,int((sx+1)*3));box('Display_podium',(sx,0,.045),(.61,.46,.09),stone,.015)
finish('travel_display')
for x in[-.88,.88]:box('Display_side',(x,.17,1.05),(.035,.44,2.1),wood,.009)
for k,z in enumerate([.15,.67,1.19,1.71]):
 box('Houseware_shelf',(0,.05,z),(1.8,.53,.035),wood,.009)
 for j in range(5):
  x=-.68+j*.34
  lathe('Ceramic_nested_bowl',[(0,0),(.07,0),(.12,.06),(.125,.075),(.112,.08),(.06,.018),(0,.018)],ceramics[(j+k)%3],(x,0,z+.02),24)
  for layer in range(3):box('Folded_cotton_towel',(x,.18,z+.025+layer*.027),(.24,.16,.025),fabrics[(j+layer)%len(fabrics)],.007)
finish('homeware_display')
for x in[-.85,.85]:box('Beauty_fixture_upright',(x,.16,1.05),(.035,.40,2.1),white,.006)
for k,z in enumerate([.15,.68,1.21,1.74]):
 box('Cosmetic_shelf',(0,0,z),(1.74,.45,.03),white,.005)
 for j in range(8):
  x=-.73+j*.205
  lathe('Lipstick_tester',[(0,0),(.022,0),(.022,.075),(.014,.08),(.014,.11),(0,.12)],casecolors[j%3],(x,-.06,z+.02),16)
  box('Makeup_palette',(x,.12,z+.07),(.13,.035,.10),ceramics[(j+k)%3],.012)
finish('beauty_display')
# Supermarket fixtures use distinct product silhouettes; no generic water-bottle shelf fallback.
packages=[material('Food_package_'+str(i),c,.72)for i,c in enumerate([(.55,.25,.06),(.22,.39,.19),(.56,.50,.31),(.17,.26,.41)])]
for side in[-1,1]:
 for z in[.17,.60,1.03,1.46]:
  box('Grocery_shelf',(0,side*.23,z),(2.0,.45,.025),white,.004)
  for i in range(9):
   x=-.85+i*.21;box('Food_carton',(x,side*.24,z+.14),(.15,.20,.25),packages[(i+int(z*7))%4],.006)
   box('Original_label_panel',(x,side*.347,z+.14),(.115,.002,.13),paper,.001)
box('Gondola_spine',(0,0,.86),(2.03,.035,1.65),metal,.004);box('Gondola_plinth',(0,0,.06),(2.1,.94,.12),metal,.012)
finish('grocery_gondola')
box('Produce_cabinet',(0,0,.34),(2.0,.95,.68),wood,.02)
for i in range(6):
 x=-.80+i*.32
 box('Angled_crate_divider',(x+.14,0,.76),(.024,.94,.18),walnut,.006)
 for j in range(4):
  yy=-.33+j*.22
  for k in range(2):lathe('Fresh_fruit',[(0,0),(.045,.008),(.062,.04),(.055,.09),(.028,.11),(0,.105)],produce[(i+j)%3],(x+(k-.5)*.10,yy,.69),16)
finish('produce_island')
box('Refrigerated_case_base',(0,0,.16),(2.1,.75,.32),steel,.02);box('Cold_case_back',(0,.34,1.1),(2.1,.05,1.9),white,.008)
for z in[.45,.93,1.41,1.89]:
 box('Cold_shelf',(0,.03,z),(2,.60,.028),white,.006)
 for i in range(8):box('Refrigerated_food_pack',(-.83+i*.235,.03,z+.13),(.19,.20,.23),packages[i%4],.008)
for x in[-.52,.52]:box('Refrigerator_glass_door',(x,-.35,1.15),(1.01,.012,1.65),glass,.004);tube('Cold_door_handle',[(x+.35,-.39,.94),(x+.35,-.39,1.34)],.012,steel)
finish('refrigerated_case')
box('Checkout_body',(0,0,.45),(2.8,.7,.90),white,.025);box('Conveyor_belt',(-.50,0,.92),(1.62,.61,.025),rubber,.008);box('Bagging_area',(1.02,0,.92),(.62,.64,.03),steel,.02)
box('Scanner',(0.32,0,1.04),(.25,.32,.19),metal,.025);box('POS_pedestal',(.64,.13,1.10),(.08,.08,.36),metal,.01);box('Touch_POS',(.64,.13,1.29),(.36,.08,.25),metal,.02)
finish('checkout_lane')
print('V11_MODELS_COMPLETE',flush=True)
