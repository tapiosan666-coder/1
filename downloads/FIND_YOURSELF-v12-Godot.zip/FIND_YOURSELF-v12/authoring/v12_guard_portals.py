"""All guard layers share real outer landing portals. Exact polygon clipping preserves the rest of each pane; no whole-triangle deletion."""
from pathlib import Path
import sys,numpy as np,math
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
E=read(P/'source/scene-manifest.json')['escalators']+read(P/'source/site-manifest-v7.json')['escalators'];masks=[];ledger=[]
for e in E:
 u=np.array([e['u'][0],0,e['u'][1]],float);n=np.array([-u[2],0,u[0]]);c=np.array(e['c'],float)
 for sign,lev in[(-1,e['levels'][0]),(1,e['levels'][1])]:
  y=HEIGHT[lev];cc=c+u*sign*(e['run_m']/2+1.5);cc[1]=y+.625;masks.append({'bank':e['id'],'c':cc,'u':u,'n':n,'bounds':rect([cc[0],cc[2]],e['u'],1.8,1.64).bounds,'planes':[(u,.9),( -u,.9),(n,.82),(-n,.82),(np.array([0,1,0]),.64),(np.array([0,-1,0]),.64)]})
def clip(poly,normal,center,limit,keep_inside):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  da=np.dot(a[:3]-center,normal)-limit;db=np.dot(b[:3]-center,normal)-limit;ia=da<=1e-7 if keep_inside else da>=-1e-7;ib=db<=1e-7 if keep_inside else db>=-1e-7
  if ia:out.append(a)
  if ia!=ib:
   t=da/(da-db);out.append(a+(b-a)*t)
 return out

def subtract(tri,m):
 inside=list(tri);out=[]
 for normal,limit in m['planes']:
  if len(inside)<3:break
  outside=clip(inside,normal,m['c'],limit,False)
  if len(outside)>2:out.extend([np.array([outside[0],outside[i],outside[i+1]])for i in range(1,len(outside)-1)])
  inside=clip(inside,normal,m['c'],limit,True)
 return out

def cut(arr,which):
 out=arr;modified=0
 for m in which:
  c=m['c'];vv=out[:,:,:3]-c;s=vv@m['u'];t=vv@m['n'];yy=vv[:,:,1];hit=(s.min(1)<.9)&(s.max(1)>-.9)&(t.min(1)<.82)&(t.max(1)>-.82)&(yy.min(1)<.64)&(yy.max(1)>-.64)
  if not hit.any():continue
  kept=[out[~hit]];new=[]
  for tr in out[hit]:new.extend(subtract(tr,m))
  if new:kept.append(np.array(new,dtype=np.float32))
  out=np.concatenate(kept);modified+=int(hit.sum())
 return out,modified
mats={'glass','v10_guard_glass','metal','v10_metal','v10_darkstone','dark_stone'}
for folder,name in [('v10','base-b'),('v10','base-site'),('v12','C-outlet'),('v11','repairs')]:
 if '--only-C'in sys.argv and name!='C-outlet':continue
 path=P/'assets'/folder/(name+'.pack.zst');g=load_pack(path);changed=0;cp=0
 for key,d in list(g['surfaces'].items()):
  if key.split('@@')[0]not in mats:continue
  a=triangles(d)
  if len(a)==0:continue
  bb=np.array([a[:,:,0].min(),a[:,:,2].min(),a[:,:,0].max(),a[:,:,2].max()]);lo=a[:,:,1].min();hi=a[:,:,1].max();which=[m for m in masks if hi>m['c'][1]-.64 and lo<m['c'][1]+.64 and not(bb[2]<m['bounds'][0]or bb[0]>m['bounds'][2]or bb[3]<m['bounds'][1]or bb[1]>m['bounds'][3])]
  if not which:continue
  if 'i'in d:ix=np.asarray(d['i']).reshape(-1,3);attrs=np.concatenate([np.asarray(d[k]).reshape(-1,num)[ix]for k,num in [('v',3),('n',3),('uv',2),('c',4)]],axis=2)
  else:attrs=np.concatenate([np.asarray(d[k]).reshape(-1,3,num)for k,num in [('v',3),('n',3),('uv',2),('c',4)]],axis=2)
  result,count=cut(attrs,which)
  if count:
   g['surfaces'][key]={k:result[:,:,a:b].ravel()for k,a,b in [('v',0,3),('n',3,6),('uv',6,8),('c',8,12)]};changed+=count
 for mat,v in g['colliders'].items():
  if mat not in mats:continue
  a=np.array(v).reshape(-1,3,3);res,count=cut(a,masks);g['colliders'][mat]=res.ravel();cp+=count
 if changed or cp:save_zst(path,g)
 ledger.append({'pack':str(path.relative_to(P)),'render_faces_clipped':changed,'physical_faces_clipped':cp,'method':'Exact 3D clipping by common outer-landing portal prisms, retaining UV/normal/colour and visible/collision correspondence','landing_clear_width_m':1.64});print('GUARD_PORTALS',name,changed,cp,flush=True)
write(P/'source/v12/guard-portal-repairs.json',ledger);write(P/'source/v12/guard-portals.json',[{'bank':m['bank'],'center_world':m['c'].tolist(),'u':m['u'].tolist(),'length_m':1.8,'clear_width_m':1.64,'vertical_m':1.28,'guard_exclusion_center_xz':(m['c'][[0,2]]-m['u'][[0,2]]*(1 if np.dot(m['c'][[0,2]]-np.array([next(e for e in E if e['id']==m['bank'])['c'][0],next(e for e in E if e['id']==m['bank'])['c'][2]]),m['u'][[0,2]])>0 else-1)*.5).tolist(),'guard_exclusion_length_m':3.6}for m in masks])
