"""Finite-radius hemisphere AO, original static scene geometry, representative 1F floors only.
Not a GI/lightmap bake. No untested claim about final GPU performance.
"""
from pathlib import Path
import json,gzip,struct,sys,numpy as np,trimesh,time
from PIL import Image,ImageFilter
P=Path(__file__).resolve().parents[1];triangles=[]
def unpack(p):
 raw=gzip.decompress(p.read_bytes());n=struct.unpack_from('<I',raw,4)[0];g=json.loads(raw[8:8+n]);start=8+n
 for key,d in g['surfaces'].items():
  if key.split('@@')[0]in['glass','roof_glass','light','v8_led','v9_glow']:continue
  off,sz=d['v'];a=np.frombuffer(raw,dtype='<f4',count=sz//4,offset=start+off).reshape(-1,3,3)
  a=a[(a[:,:,1].max(axis=1)>.09)&(a[:,:,1].min(axis=1)<4.5)]
  triangles.append(a.copy())
for file in ['base-b-v8.pack.gz','base-site-v8.pack.gz','fitout-v8.pack.gz','art-v9.pack.gz']:unpack(P/'assets'/file)
T=np.concatenate(triangles);del triangles
for wing,(center,radius)in json.loads((P/'source/fitout-v8.json').read_text())['zones'].items():
 t=time.monotonic();mn=np.array(center)-radius;mx=np.array(center)+radius
 sel=(T[:,:,0].min(axis=1)<mx[0])&(T[:,:,0].max(axis=1)>mn[0])&(T[:,:,2].min(axis=1)<mx[1])&(T[:,:,2].max(axis=1)>mn[1]);tri=T[sel];mesh=trimesh.Trimesh(vertices=tri.reshape(-1,3),faces=np.arange(tri.size//3).reshape(-1,3),process=False)
 from trimesh.ray.ray_pyembree import RayMeshIntersector
 caster=RayMeshIntersector(mesh);N=768
 x,z=np.meshgrid(np.linspace(mn[0],mx[0],N),np.linspace(mn[1],mx[1],N));orig=np.column_stack([x.ravel(),np.full(N*N,.072),z.ravel()]);occ=np.zeros(N*N,dtype=np.float32)
 # Hammersley hemisphere, deterministic. Distance fades the obstruction.
 for i in range(16):
  az=i*2.39996323;y=.12+.83*((i+.5)/16);r=np.sqrt(1-y*y);direction=np.array([np.cos(az)*r,y,np.sin(az)*r]);dirs=np.broadcast_to(direction,orig.shape).copy()
  locations,ids,_=caster.intersects_location(orig,dirs,multiple_hits=False)
  dist=np.linalg.norm(locations-orig[ids],axis=1);occ[ids]+=np.clip(1-dist/2.8,0,1)/16
 img=Image.fromarray(np.uint8(np.clip(1-occ*.82,0,1).reshape(N,N)*255)).filter(ImageFilter.GaussianBlur(.55));img.save(P/('assets/v9/contact-'+wing+'.png'))
 print(wing,'bake seconds',round(time.monotonic()-t,2),'triangles',len(tri),'meanAO',float(np.mean(occ)),flush=True)
