"""Local cadastral repairs: preserve IDs, named routes and service access. Inputs remain frozen."""
from pathlib import Path
import sys,copy,math,json,csv,numpy as np
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
P=Path(__file__).resolve().parents[1];F=read(P/'source/v11/floors-baseline.json');before=copy.deepcopy(F);routes=read(P/'source/physical-routes-v7.json');changes=[];gaps=[];ledger=[]
a=next(f for f in F if f['wing']=='A'and f['level']==0);s3=next(s for s in a['stores']if s['id']=='A1F-003');s5=next(s for s in a['stores']if s['id']=='A1F-005')
neck=s3['polygon'].intersection(box(-54,-19,100,100));old=s3['polygon'];s3['polygon']=old.difference(neck);s3['sales']=s3['sales'].intersection(s3['polygon']);s3['entry']=[(-74.88259646226393-54)/2,-19];s3['u']=[1.,0.];s3['n']=[0.,-1.];s3['front']=[[-74.88259646226393,-19],[-54,-19]];s3['frontage_m']=20.88259646226393;s3['door_width_m']=8.;s3['main_route']=[s3['entry'],[s3['entry'][0],-24],[s3['sales'].centroid.x,s3['sales'].centroid.y]];s3['aisles']=LineString(s3['main_route']).buffer(.8)
old5=s5['polygon'];expanded=unary_union([old5,neck]).buffer(.8,join_style=2).buffer(-.8,join_style=2);assert expanded.geom_type=='Polygon';s5['polygon']=expanded;s5['sales']=s5['sales'].union(expanded.difference(old5));s5['backroom']=s5.get('backroom',Polygon());s3['backroom']=s3.get('backroom',Polygon()).intersection(s3['polygon'])
a['public']=a['public'].difference(expanded.difference(old5)).union(neck.difference(expanded));changes.append({'id':'A1F-003','reason':'Move main entrance from a 3.9m-wide dogleg neck to the existing 20.88m-wide sales face. Neck reassigned to adjacent A1F-005; no store ID merged/deleted.','old_polygon':old,'new_polygon':s3['polygon'],'new_entry':s3['entry'],'old_frontage_m':3.90342213918,'new_frontage_m':20.88259646226393});changes.append({'id':'A1F-005','reason':'Absorb adjacent neck as continuous sales floor, not a sealed void. Backroom retained.','old_polygon':old5,'new_polygon':expanded})
# Identify sub-1.3m boundary strips. Treat separate C pavilions independently, but repair tenant gaps inside one pavilion.
for f in F:
 wing=f['wing'];lev=f['level'];stores=f['stores'];U=unary_union([s['polygon']for s in stores]);raw=U.buffer(.65,join_style=2).buffer(-.65,join_style=2).difference(U).intersection(f['floor_plate']);protected=[]
 for r in routes:
  if 'A1F-003'in r['id']:continue
  pts=r['points']
  for aa,bb in zip(pts,pts[1:]):
   if abs(aa[1]-f['height'])<.1 and abs(bb[1]-f['height'])<.1:protected.append(LineString([(aa[0]-429,aa[2]+46),(bb[0]-429,bb[2]+46)]).buffer(.65,cap_style=2,join_style=2))
 for s in stores:
  protected.append(rect(s['entry'],s['u'],s.get('door_width_m',2.4)+1.0,2.0))
  if s.get('back_door'):protected.append(rect(s['back_door'],s.get('back_door_u',s['u']),2.3,2.3))
 for c in f['cores']:protected.append(c['outline'].buffer(.25,join_style=2))
 for zone in f.get('service_zones',[])+f.get('program',[]):
  if hasattr(zone.get('polygon'),'geom_type'):
   # Old residual fragments were named equipment zones without usable width. A label is not access proof.
   protected.append(zone['polygon'].buffer(-.8,join_style=2).buffer(.8,join_style=2))
   rr=zone.get('main_route',[])
   if len(rr)>1 and zone['polygon'].buffer(.05).covers(LineString(rr)):protected.append(LineString(rr).buffer(.65,cap_style=2,join_style=2))
 protected=unary_union(protected)
 for k,g in enumerate(polys(raw.intersection(protected))):
  if g.area>.08:gaps.append({'id':f'{wing}-{f["label"]}-ACCESS-{k:03d}','wing':wing,'floor':f['label'],'world_center':[g.centroid.x+429,f['height'],g.centroid.y-46],'area_m2':g.area,'neighbors':[],'geometry':g,'status':'RETAINED / PROTECTED','reason':'Existing declared access route / entrance / service clearance. Automatic route existence is not architectural approval.'})
 for k,g in enumerate(polys(raw.difference(protected))):
  if g.area<.08:continue
  adjacent=[s for s in stores if s['polygon'].distance(g)<.01];record={'id':f'{wing}-{f["label"]}-GAP-{k:03d}','wing':wing,'floor':f['label'],'world_center':[g.centroid.x+429,f['height'],g.centroid.y-46],'area_m2':g.area,'neighbors':[s['id']for s in adjacent],'geometry':g}
  same_building=any(p.buffer(.02).covers(unary_union([q['polygon']for q in adjacent]+[g]))for p in polys(f.get('building_envelope_v5',f['shell'])))
  if not adjacent or not same_building:record.update(status='RETAINED / REVIEW',reason='Outside a single existing building envelope or no connected tenant owner; requires an explicit landscape/service design, not blind filling.')
  elif g.intersection(protected).area>.02:record.update(status='RETAINED / PROTECTED',reason='Named access route, entrance or service/core clearance intersects this candidate. Must not silently close it.')
  else:
   owners=sorted(adjacent,key=lambda s:(-s['polygon'].boundary.intersection(g.buffer(.00001,join_style=2)).length,s['polygon'].area));owner=owners[0]
   for candidate in owners:
    trial=candidate['polygon'].union(g).buffer(.0001,join_style=2).buffer(-.0001,join_style=2).simplify(.001,preserve_topology=True)
    if trial.geom_type=='Polygon':owner=candidate;break
   oldpol=owner['polygon'];newpol=oldpol.union(g).buffer(.0001,join_style=2).buffer(-.0001,join_style=2).simplify(.001,preserve_topology=True)
   if newpol.geom_type!='Polygon':record.update(status='UNRESOLVED',reason='Allocation would create a detached parcel; requires manual cadastral review.')
   else:
    owner['polygon']=newpol;added=newpol.difference(oldpol);oldstock=owner.get('backroom',Polygon());stock_extension=added.intersection(oldstock.buffer(1.3,join_style=2))if not oldstock.is_empty else Polygon();owner['backroom']=oldstock.union(stock_extension);owner['sales']=owner.get('sales',oldpol).union(added).difference(owner['backroom']);f['public']=f['public'].difference(g)
    for zz in f.get('program',[])+f.get('service_zones',[]):
     if hasattr(zz.get('polygon'),'geom_type'):zz['polygon']=zz['polygon'].difference(g)
    changes.append({'id':owner['id'],'reason':'Allocate unassigned inter-tenant strip into actual sales floor; regenerate the common boundary, not cap a hollow alley.','old_polygon':oldpol,'new_polygon':newpol});record.update(status='REALLOCATED',owner=owner['id'],reason='Whole strip allocated to a connected adjacent tenant, with the stock-facing portion assigned to its backroom. No hidden void remains.')
  gaps.append(record)
# Remove three inherited 4.82m2 detached tenant slivers at the same A-KW forecourt.
# They have no shop entrance, touch the existing public/core frontage and are not backrooms.
for f in F:
 for s in f['stores']:
  parts=polys(s['polygon'])
  if len(parts)<=1:continue
  primary=min(parts,key=lambda p:p.distance(Point(s['entry'])));other=unary_union([p for p in parts if p!=primary]);core=next((c for c in f['cores']if other.distance(c['outline'])<.01),None)
  if core and other.area<6 and other.intersection(s.get('backroom',Polygon())).area<1e-6 and other.boundary.intersection(f['public'].buffer(.01)).length>1:
   old=s['polygon'];s['polygon']=primary;s['sales']=s['sales'].intersection(primary);f['public']=f['public'].union(other);f.setdefault('forecourt_extensions',[]).append({'core':core['id'],'geometry':other,'area_m2':other.area,'role':'Existing stair/EV entrance forecourt; detached retail fragment removed. No new floor or corridor.'});changes.append({'id':s['id'],'reason':'Detached 4.82m2 retail island next to A-KW had no shop connection. Return it to the already adjoining common forecourt; primary shop and stockroom retained.','old_polygon':old,'new_polygon':primary})
 for z in f.get('program',[])+f.get('service_zones',[]):
  if hasattr(z.get('polygon'),'geom_type'):z['polygon']=z['polygon'].difference(unary_union([s['polygon']for s in f['stores']]))
# Area layers must remain polygonal. Set operations can leave zero-area line fragments; never turn these into walls.
for ff in F:
 for ss in ff['stores']:
  for key in ['polygon','sales','backroom']:
   pp=polys(ss.get(key,Polygon()));ss[key]=unary_union(pp)if pp else Polygon()
# The source inventory is audited for all floors, not just visible review shops.
for f in F:
 for s in f['stores']:
  pol=s['polygon'];r=pol.minimum_rotated_rectangle;co=list(r.exterior.coords);sides=[math.dist(co[i],co[i+1])for i in range(4)];w=min(sides);d=max(sides);sales=s.get('sales',pol);stock=s.get('backroom',Polygon());flags=[]
  if d/max(w,.01)>4:flags.append('aspect_over_4')
  if w<4:flags.append('minimum_enclosing_width_under_4m')
  if pol.minimum_clearance<.15:flags.append('short_edge_or_close_vertices')
  ledger.append({'id':s['id'],'wing':f['wing'],'floor':f['label'],'category':s['category'],'gross_m2':pol.area,'sales_m2':sales.area,'backroom_m2':stock.area,'backroom_percent':100*stock.area/max(pol.area,.01),'enclosing_width_m':w,'enclosing_depth_m':d,'entry_world_x':s['entry'][0]+429,'entry_world_z':s['entry'][1]-46,'public_entry_distance_m':f['public'].distance(Point(s['entry'])),'flags':';'.join(flags),'assessment':'Needs industry-specific design review'if flags else'No bounding-box shape flag; not a visual/architectural approval'})
# Keep the original route IDs and re-route only the relocated shoe-store access.
for r in routes:
 if 'A1F-003'in r['id']:
  e=s3['entry'];n=s3['n'];r['points']=[[e[0]+429-n[0]*1.1,0,e[1]-46-n[1]*1.1],[e[0]+429,0,e[1]-46],[e[0]+429+n[0]*1.1,0,e[1]-46+n[1]*1.1]];r['v11_reason']='Shoe-store main entrance relocated out of the dogleg neck; ID preserved.'
write(P/'source/v11/floors-updated.json',F);write(P/'source/v11/layout-changes.json',changes);write(P/'source/v11/gap-audit.json',gaps);write(P/'source/physical-routes-v11.json',routes)
csvwrite(P/'source/v11/store-ledger.csv',list(ledger[0]),[[r[k]for k in ledger[0]]for r in ledger])
# The map reads the same repaired store polygons and entry points.
def rings(g):return[[list(p.exterior.coords)]+[list(r.coords)for r in p.interiors]for p in polys(g)]
for src,dst in [('source/map-data-v7.json','source/map-data-v11.json'),('source/v10/map-data-C-option.json','source/v11/map-data-C-option.json')]:
 m=read(P/src)
 for f in F:
  ff=next((x for x in m if x['wing']==f['wing']and x['level']==f['level']),None)
  if ff is None:continue
  ff['public']=rings(f['public'])
  for item in ff['items']:
   s=next((s for s in f['stores']if s['id']==item['id']),None)
   if s:item['geometry']=rings(s['polygon']);item['point']=s['entry']
   zone=next((z for z in f.get('program',[])+f.get('service_zones',[])if z.get('id')==item['id']),None)
   if zone is not None:item['geometry']=rings(zone['polygon']);item['implemented']=not zone['polygon'].is_empty
 write(P/dst,m)
print('STORES',len(ledger),'changes',len(changes),'gaps',len(gaps),'allocated',sum(g['status']=='REALLOCATED'for g in gaps),'unresolved',sum(g['status']=='UNRESOLVED'for g in gaps),flush=True)
