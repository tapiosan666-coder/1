"""Keep variant maps, furnishings and planting supported by the same retained floor. No store ID removed."""
from pathlib import Path
import sys,copy,numpy as np,math
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *;from pack_tools_v11 import *
from shapely import contains_xy,constrained_delaunay_triangles
from shapely.ops import transform
F=read(P/'source/site-v11.json')['floors'];C=read(P/'source/v12/C-outlet-proposal.json')['floors'];by={r['level']:r for r in C};banks=read(P/'source/scene-manifest.json')['escalators']+read(P/'source/site-manifest-v7.json')['escalators'];actual={e['id']for e in banks}
def rings(g):return[[list(p.exterior.coords)]+[list(r.coords)for r in p.interiors]for p in polys(g)]
def world(g):return transform(lambda x,z,zz=None:(np.array(x)+429,np.array(z)-46),g)
m=read(P/'source/v12/map-data.json');changes=[]
for f in m:
 for i in f['items']:
  if i['kind']=='エスカレーター'and i['id']not in actual:
   if i['implemented']:changes.append(i['id'])
   i['implemented']=False;i['validation_note']='実機未施工。計画図の設備です。既存の階段・EVをご利用ください。'
write(P/'source/v12/map-data.json',m);option=copy.deepcopy(m)
for f in option:
 if f['wing']!='C'or f['level']not in by:continue
 row=by[f['level']];fills=unary_union([affinity.translate(r['infill'],-429,46)for r in read(P/'source/v12/es-openings.json')if r['wing']=='C'and abs(r['floor_y']-f['height'])<.01]);f['floor']=rings(row['proposed_floor'].union(fills));f['public']=rings(row['proposed_public'].union(fills));f['variant']='UNAPPROVED C OUTLET v12'
 for i in f['items']:
  if i['kind']in['広場','庭園']:
   geom=unary_union([Polygon(p[0],p[1:])for p in i['geometry']]).intersection(row['proposed_floor']);i['geometry']=rings(geom);i['implemented']=not geom.is_empty
   if not geom.is_empty:i['point']=list(geom.representative_point().coords[0])
write(P/'source/v12/map-data-C-option.json',option)
scene=read(P/'source/v12/scene-art.json');removed=[];kept=[]
for d in scene['instances']:
 p=d['p'];lev=min(by,key=lambda k:abs(by[k]['height']-p[1]));f=next(f for f in F if f['wing']=='C'and f['level']==lev);q=Point(p[0]-429,p[2]+46)
 if abs(p[1]-f['height'])<1.5 and f['floor_plate'].buffer(.3).covers(q)and not by[lev]['proposed_floor'].buffer(.08).covers(q.buffer(.15)):
  if any(s['id']==d['group']for ff in F for s in ff['stores']):raise RuntimeError('Retained store asset lost support '+d['group'])
  removed.append({'asset':d['asset'],'group':d['group'],'p':p,'reason':'Root outside retained variant slab. Removed only from unapproved variant; no store ID changed.'});continue
 kept.append(d)
scene['instances']=kept
lights=[]
for d in scene['lights']:
 p=d['p'];lev=min(by,key=lambda k:abs(by[k]['height']-.4-p[1]));row=by[lev];f=next(f for f in F if f['wing']=='C'and f['level']==lev);q=Point(p[0]-429,p[2]+46)
 if abs(row['height']-.4-p[1])<1.3 and f['floor_plate'].covers(q)and not row['proposed_floor'].covers(q):removed.append({'light':d,'reason':'Ceiling/slab removed in C structural option'});continue
 lights.append(d)
scene['lights']=lights;write(P/'source/v12/scene-art-C.json',scene)
g=load_pack(P/'assets/v12/C-outlet.pack.zst');M={};coll={};render_group='V12-C-SUPPORTED-ROOF-PLANTING'
def pos(x,y,z):return[float(x+429),float(y),float(z-46)]
exec((P/'authoring/mesh_primitives.py').read_text())
for lev,row in by.items():
 f=next(f for f in F if f['wing']=='C'and f['level']==lev);y=f['height'];bad=[o for o in f.get('furniture',[])if not row['proposed_floor'].buffer(.03).covers(o.get('geom',o.get('polygon')))];mask=unary_union([o.get('geom',o.get('polygon')).buffer(.15)for o in bad]);maskw=world(mask);count=0
 for key,d in list(g['surfaces'].items()):
  mat,_,group=key.partition('@@');a=triangles(d);ct=a.mean(1);drop=np.zeros(len(a),bool)
  if group=='C-'+f['label']and mat in ['oak','dark_stone','leaf']:drop=(ct[:,1]>=y-.01)&(ct[:,1]<y+1.6)&contains_xy(maskw,ct[:,0],ct[:,2])
  if lev==3 and mat=='leaf':drop|=(abs(ct[:,1]-(y+.012))<.03)&contains_xy(world(f['floor_plate'].buffer(.2)),ct[:,0],ct[:,2])
  if drop.any():g['surfaces'][key]=retain(d,~drop);count+=int(drop.sum())
 for mat,v in g['colliders'].items():
  if mat not in ['oak','dark_stone','leaf']:continue
  a=np.array(v).reshape(-1,3,3);ct=a.mean(1);drop=(ct[:,1]>=y-.01)&(ct[:,1]<y+1.6)&contains_xy(maskw,ct[:,0],ct[:,2]);g['colliders'][mat]=a[~drop].ravel()
 for o in bad:removed.append({'floor':f['label'],'furniture_id':o.get('id'),'reason':'Authored bench/planter footprint lacks retained structural support','geometry':o.get('geom',o.get('polygon'))})
 if lev==3:
  for bed in f.get('landscape',[]):surf(bed['geom'].intersection(row['proposed_floor']),y+.012,'leaf',True,False)
 print('C_DECOR',f['label'],len(bad),count,flush=True)
g['surfaces'].update({k:{a:np.array(v,dtype=np.float32)for a,v in d.items()}for k,d in M.items()});save_zst(P/'assets/v12/C-outlet.pack.zst',g);write(P/'source/v12/C-decor-support.json',{'removed_from_option_only':removed,'map_ES_wrong_implemented_flags_corrected':changes,'normal_scene_art_unchanged':True,'human_playtest':False});print('C_SUPPORTED_DECOR',len(removed),'MAP_UNBUILT_ES',len(changes),flush=True)
