"""2D shortest-grid estimates, deliberately not reported as real player walking measurements."""
from pathlib import Path
import sys,math,heapq
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'authoring'));from site_v2_common import *
F=read(P/'source/v11/floors-updated.json');rows=read(P/'source/v12/es-transfer-existing.json')
def route(a,b,space):
 if space.covers(LineString([a,b])):return[a,b]
 origin=(math.floor(space.bounds[0]),math.floor(space.bounds[1]));step=.75;node=lambda p:(round((p[0]-origin[0])/step),round((p[1]-origin[1])/step));point=lambda n:(origin[0]+n[0]*step,origin[1]+n[1]*step);valid={}
 def okay(n):
  if n not in valid:valid[n]=space.covers(Point(point(n)))
  return valid[n]
 def nearest(p):
  n=node(p);choices=[(n[0]+i,n[1]+j)for i in range(-4,5)for j in range(-4,5)if okay((n[0]+i,n[1]+j))]
  if not choices:return None
  return min(choices,key=lambda q:math.dist(point(q),p))
 aa=nearest(a);bb=nearest(b)
 if aa is None or bb is None:return None
 costs={aa:0};prev={};q=[(0,0,aa)]
 while q:
  _,v,n=heapq.heappop(q)
  if v>costs[n]+1e-8:continue
  if n==bb:break
  for dx,dz in[(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]:
   nn=(n[0]+dx,n[1]+dz)
   if not okay(nn)or dx*dz!=0 and(not okay((n[0]+dx,n[1]))or not okay((n[0],n[1]+dz))):continue
   nv=v+math.hypot(dx,dz)*step
   if nv<costs.get(nn,1e20):costs[nn]=nv;prev[nn]=n;heapq.heappush(q,(nv+math.dist(point(nn),point(bb)),nv,nn))
 else:return None
 p=[b,point(bb)];n=bb
 while n!=aa:n=prev[n];p.append(point(n))
 p.append(a);p=p[::-1];out=[p[0]];i=0
 while i<len(p)-1:
  j=len(p)-1
  while j>i+1 and not space.covers(LineString([p[i],p[j]])):j-=1
  out.append(p[j]);i=j
 return out
for r in rows:
 f=next(f for f in F if f['wing']==r['wing']and abs(f['height']-r['floor_y'])<.01);a=[r['exit_world_xz'][0]-429,r['exit_world_xz'][1]+46];b=[r['next_entry_world_xz'][0]-429,r['next_entry_world_xz'][1]+46];space=f['public'].buffer(-.35,join_style=2);path=route(a,b,space)
 r['plan_path_found']=path is not None;r['plan_only']=True;r['grid_resolution_m']=.75;r['actual_Godot_walk_distance_measured']=False;r['plan_path_m']=sum(math.dist(a,b)for a,b in zip(path,path[1:]))if path else None;r['path_source_xz']=path;r['candidate_module_transfer_m']=8.4;r['module_installed_in_this_wing']=False;print('PLAN_TRANSFER',r['from'],r['to'],r['plan_path_m'],flush=True)
write(P/'source/v12/es-transfer-distances.json',rows)
