"""Real visible guards around unbuilt B1/RF shafts. Never advertise a planned but absent machine as usable."""
from pathlib import Path
P=Path(__file__).resolve().parents[1];src=(P/'authoring/v12_safety.py').read_text();exec(src[:src.index('for e in es:')]);more=load_pack(P/'assets/v12/es-safety.pack.zst');alltri=np.concatenate([alltri]+[np.array(v).reshape(-1,3,3)for v in more['colliders'].values()]);flat={y:alltri[(np.ptp(alltri[:,:,1],axis=1)<.003)&(abs(alltri[:,:,1].mean(1)-y)<.02)]for y in levels};M={};coll={};records=[];probes=[];signs=[];portals=read(P/'source/v12/guard-portals.json');actualids={e['id']for e in es};future={e['id']:e for f in F if f['wing']=='B'for e in f['escalators']if e['id']not in actualids}
for e in future.values():
 u=np.array(e['u'],float);c=np.array(e['c'],float)+np.array([429,-46]);run=e['run_m'];big=rect(c,u,run+10,10);roi=rect(c,u,run+4,3.25);render_group='V12-UNBUILT-'+e['id'];bounds=[]
 for lev in e['levels']:
  y=HEIGHT[lev];H=floor_near(y,big);edge=H.boundary.intersection(roi).difference(big.boundary.buffer(.05)).difference(blocker_lines(y,big));mouths=[rect(p['guard_exclusion_center_xz'],[p['u'][0],p['u'][2]],p['guard_exclusion_length_m'],p['clear_width_m'])for p in portals if abs(p['center_world'][1]-.625-y)<.01];edge=edge.difference(unary_union(mouths));band=unary_union([ln.buffer(.055,cap_style=2,join_style=2)for ln in lines(edge)if ln.length>.1]).intersection(H.buffer(.015));extrude(band,y,.16,'v10_darkstone',True);extrude(band,y+.16,.99,'v10_guard_glass',True);extrude(band,y+1.15,.04,'v10_metal',False);bounds.append({'floor_y':y,'geometry':band,'guard_footprint_m2':band.area})
  for ln in lines(edge):
   if ln.length<.15:continue
   co=list(ln.coords);aa=np.array(co[0]);bb=np.array(co[-1]);v=bb-aa
   if np.linalg.norm(v)<.01:continue
   n=np.array([-v[1],v[0]])/np.linalg.norm(v)
   for t in np.linspace(.05,ln.length-.05,max(2,math.ceil(ln.length/1.5))):
    p=np.array(ln.interpolate(float(t)).coords[0]);normal=n if H.covers(Point(p+n*.6))else-n;start=p+normal*.8;target=p-normal*.6
    if H.buffer(-.31).covers(Point(start))and not H.buffer(.15).covers(Point(target)):
     probes.append({'id':e['id']+'-'+str(lev)+'-'+str(len(probes)),'bank':e['id'],'floor_y':y,'start':[start[0],y,start[1]],'target':[target[0],y,target[1]],'kind':'unbuilt shaft edge push; not a usable escalator'})
 records.append({'id':e['id'],'not_implemented':True,'guards':bounds});y=HEIGHT[-1]if e['levels'][0]==-1 else HEIGHT[3];p=c+u*(run/2+1.65);signs.append({'id':e['id'],'p':[p[0],y+1.5,p[1]],'n':u.tolist(),'text':'昇降設備 未施工\n階段・EVをご利用ください'});print('UNBUILT_GUARD',e['id'],sum(r['guard_footprint_m2']for r in bounds),flush=True)
save_zst(P/'assets/v12/es-unbuilt-safety.pack.zst',{'surfaces':M,'colliders':coll,'signs':[],'lights':[]});write(P/'source/v12/es-unbuilt-guards.json',records);write(P/'source/v12/es-unbuilt-probes.json',probes);write(P/'source/v12/es-unbuilt-signs.json',signs);print('UNBUILT_COMPLETE',len(records),'banks',len(probes),'probes',flush=True)
