"""Original deterministic honed-stone PBR maps. No copied image source."""
from pathlib import Path
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parents[1]/'assets/v9';N=1024;y,x=np.mgrid[:N,:N]/N
rng=np.random.default_rng(29109)
def noise(n):return np.asarray(Image.fromarray(np.uint8(rng.uniform(0,255,(n,n)))).resize((N,N),Image.Resampling.BICUBIC),dtype=float)/255-.5
n0=noise(5);n1=noise(18);n2=noise(72);fine=noise(256);phase=x*.9+y*1.4+n0*.28+n1*.07
vein=np.exp(-np.abs(np.sin(phase*12))*(22+n2*6));secondary=np.exp(-np.abs(np.sin(phase*31+n1*.8))*60)
shade=n0*4+n2*1.3+fine*.7-vein*13-secondary*2.5
colour=np.array([222,220,211])[None,None,:]+shade[:,:,None]
Image.fromarray(np.uint8(np.clip(colour,0,255))).save(P/'honed-marble.png')
h=n2*.001+fine*.0008-vein*.0003;dx=np.gradient(h,axis=1)*35;dy=np.gradient(h,axis=0)*35;v=np.stack([-dx,-dy,np.ones_like(dx)],axis=2);v/=np.linalg.norm(v,axis=2,keepdims=True)
Image.fromarray(np.uint8((v*.5+.5)*255)).save(P/'honed-marble-normal.png');Image.fromarray(np.uint8(np.clip(.31+n2*.025+fine*.018,0,1)*255)).save(P/'honed-marble-rough.png')
