from pathlib import Path
import json,hashlib,struct,gzip,sys,numpy as np
from shapely.geometry import shape,LineString
P=Path(__file__).resolve().parents[1];B=Path('/workspace/FIND_YOURSELF-Site-v8');E=P/'evidence/v9';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
protected=['player.gd','staff_doors.gd','escalator_v2.gd','elevators_v7.gd','ui_v7.gd','map_v7.gd','settings_v7.gd','project.godot','source/site-v7.json','source/design-v7.json','source/map-data-v7.json','source/scene-manifest.json','source/site-manifest-v7.json','source/elevators-v7.json','source/brands-v8.json','source/fitout-v8.json','assets/base-b-v8.pack.gz','assets/base-site-v8.pack.gz','assets/fitout-v8.pack.gz']
# Application title differs; numerical configuration stays identical.
protected=[x for x in protected if (B/x).exists()and x!='project.godot']
records=[{'path':x,'v8_sha256':sha(B/x),'v9_sha256':sha(P/x),'unchanged':sha(B/x)==sha(P/x)}for x in protected];assert all(x['unchanged']for x in records)
project=(P/'project.godot').read_text().replace('映像検証 v9','映像検証 v8');assert project==(B/'project.godot').read_text()
art=read(P/'source/art-v9.json');checks=[]
for row in art['placed']:
 fp=shape(row['geom']);wing=row['wing'];level=next(f for f in read(P/'source/site-v7.json')['floors']if f['wing']==wing and f['level']==0)
 # Lounge / cafe furnishings only on existing public floors; bookstore candidate is exempt sales area.
 if row['id']=='BOOK-LOUNGE':continue
 floor=shape(level['public']).intersection(shape(level['floor_plate']));checks.append({'id':row['id'],'existing_public_floor_contains_footprint':floor.buffer(.001).covers(fp),'footprint_m2':fp.area})
assert all(c['existing_public_floor_contains_footprint']for c in checks)
# Compare collider buffers independently, plus complete triangle attributes already checked by indexing script.
colliders=[]
for r in read(E/'indexed-mesh-verification.json'):
 def unpack(file):
  raw=gzip.decompress((P/'assets'/file).read_bytes());n=struct.unpack_from('<I',raw,4)[0];g=json.loads(raw[8:8+n]);return {k:raw[8+n+v[0]:8+n+v[0]+v[1]]for k,v in g['colliders'].items()}
 a=unpack(r['source']);b=unpack(r['target']);same=a==b;assert same;colliders.append({'file':r['target'],'same_float32_collision_buffers':same,'groups':len(a)})
# New finish geometry remains below the 1F ceiling, no added meshes on the other 12 levels.
raw=gzip.decompress((P/'assets/art-v9.pack.gz').read_bytes());n=struct.unpack_from('<I',raw,4)[0];g=json.loads(raw[8:8+n]);mx=-1;mn=999
for d in g['surfaces'].values():
 o,sz=d['v'];a=np.frombuffer(raw,dtype='<f4',count=sz//4,offset=8+n+o).reshape(-1,3);mn=min(mn,float(a[:,1].min()));mx=max(mx,float(a[:,1].max()))
assert mn>=0 and mx<5.106
r={'v8_inputs':records,'project_numerical_settings_unchanged':True,'additional_public_furnishings':checks,'indexed_colliders':colliders,'new_mesh_y_extent_m':[mn,mx],'new_store_count':0,'new_vendor_instances':len(art['vendors']),'main_game_modified':False,'RF_SUPPORT_16':'UNAPPROVED','human_playtest':False,'architectural_quality_certified':False,'note':'Geometry and floor inclusion tests do not establish aesthetic quality or human usability.'}
(E/'geometry-and-protection.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print('V9_AUDIT',len(records),'protected',len(checks),'public furnishing bays','PASS')
