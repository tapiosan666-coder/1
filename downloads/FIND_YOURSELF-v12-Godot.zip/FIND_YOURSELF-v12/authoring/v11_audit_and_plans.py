"""Independent whole-inventory checks and explicit, unbuilt vertical circulation proposals."""
from pathlib import Path
import sys,math,copy,json,csv,numpy as np
sys.path.insert(0,str(Path(__file__).parent));from site_v2_common import *
P=Path(__file__).resolve().parents[1];F=read(P/'source/v11/floors-updated.json');B=read(P/'source/v11/floors-baseline.json');lookup={s['id']:(f,s)for f in F for s in f['stores']};reps={'A1F-001','A1F-003','A1F-005','B1-SW12','B1-SW32','B1-008','B1-030','B1-N03'};audit=[];failures=[];oldids={s['id']for f in B for s in f['stores']};ids=set(lookup)
for f in F:
 stores=f['stores'];yy=f['height'];overlaps=[];old=next(x for x in B if x['wing']==f['wing']and x['level']==f['level'])
 for i,s in enumerate(stores):
  for other in stores[i+1:]:
   if s['polygon'].intersects(other['polygon']):
    area=s['polygon'].intersection(other['polygon']).area
    if area>1e-4:overlaps.append({'a':s['id'],'b':other['id'],'area_m2':area})
  r=s['polygon'].minimum_rotated_rectangle;co=list(r.exterior.coords);lengths=[math.dist(co[i],co[i+1])for i in range(4)];width=min(lengths);depth=max(lengths);stock=s.get('backroom',Polygon());sales=s.get('sales',s['polygon']);flags=[]
  if len(polys(s['polygon']))>1:flags.append('DISCONNECTED_PARCEL_COMPONENTS')
  if depth/max(width,.001)>4:flags.append('ELONGATED_ENCLOSING_BOX')
  meaningful_short=False
  for pp in polys(s['polygon']):
   cc=list(pp.exterior.coords)[:-1]
   for k in range(len(cc)):
    aa=np.array(cc[k])-np.array(cc[k-1]);bb=np.array(cc[(k+1)%len(cc)])-np.array(cc[k]);la=np.linalg.norm(aa);lb=np.linalg.norm(bb)
    if min(la,lb)<.03 and la>1e-7 and lb>1e-7 and abs(np.cross(aa/la,bb/lb))>.34:meaningful_short=True
  if meaningful_short:flags.append('SHORT_EDGE_WITH_MEANINGFUL_TURN')
  if stock.area/s['polygon'].area<.05 and s['polygon'].area>800:flags.append('LARGE_SHOP_BACKROOM_UNDERSIZED_OR_SHARED_LOGISTICS_UNSPECIFIED')
  audit.append({'id':s['id'],'wing':f['wing'],'floor':f['label'],'category':s['category'],'gross_m2':s['polygon'].area,'sales_m2':sales.area,'backroom_m2':stock.area,'backroom_percent':100*stock.area/s['polygon'].area,'enclosing_width_m':width,'enclosing_depth_m':depth,'components':len(polys(s['polygon'])),'valid_polygon':s['polygon'].is_valid,'entry_to_public_m':f['public'].distance(Point(s['entry'])),'flags':';'.join(flags),'fitout_status':'v11 representative layout'if s['id']in reps else'v10 representative retained'if s['id']in{q['id']for q in read(P/'source/fitout-v8.json')['stores']}else'NOT detailed furnished'})
  if not s['polygon'].is_valid:failures.append({'id':s['id'],'failure':'invalid_polygon'})
 for pair in overlaps:failures.append({'floor':f['wing']+f['label'],'failure':'store_overlap',**pair})
 # Programme labels are not proof of a usable or connected room. Report remaining authored roles accurately.
 for z in f.get('program',[]):
  z['v11_validation']='Role retained only where not reassigned; working dimensions, door location and real access remain a separate design check.'
 f['navigation_status']='Runtime physics and named test paths; independent prototype has no baked NPC NavMesh.'
# Map clipping is variant-aware: do not show removed C decks as public floor.
opt=read(P/'source/v10/C-deck-option.json');m=read(P/'source/v11/map-data-C-option.json')
def rings(g):return[[list(p.exterior.coords)]+[list(r.coords)for r in p.interiors]for p in polys(g)]
for f in m:
 if f['wing']=='C'and f['level']>0:
  proposed=next(x for x in opt['floors']if x['level']==f['level']);ff=next(x for x in F if x['wing']=='C'and x['level']==f['level']);f['public']=rings(ff['public'].intersection(proposed['proposed_floor']))
write(P/'source/v11/map-data-C-option.json',m)
# Keep historical fit-out input for authoring, but stop displaying moved shops' old art and old light positions.
fit=read(P/'source/fitout-v8.json');fit['lights']=[l for l in fit['lights']if l.get('id')not in reps];fit['signs']=[s for s in fit['signs']if not any(str(s['id']).startswith(id+'-')for id in reps)];fit['fixtures']=[r for r in fit['fixtures']if r.get('store')not in reps]
for s in fit['stores']:
 if s['id']in lookup:s['area_m2']=lookup[s['id']][1]['sales'].area
write(P/'source/fitout-v11.json',fit)
csvwrite(P/'source/v11/store-ledger.csv',list(audit[0]),[[r[k]for k in audit[0]]for r in audit]);write(P/'source/v11/inventory-audit.json',{'floors':len(F),'stores':len(audit),'original_store_IDs_preserved':ids==oldids,'geometry_failures':failures,'flagged_stores':[r for r in audit if r['flags']],'not_an_architectural_quality_approval':True})
# Every bank is inventoried; relocation stays a proposal until floor/opening/structure are resolved.
es=read(P/'source/scene-manifest.json')['escalators']+read(P/'source/site-manifest-v7.json')['escalators'];transfers=[]
for e in es:
 if e['direction']!='UP'or e['levels'][0]!=0:continue
 opts=[q for q in es if q.get('wing','B')==e.get('wing','B')and q['direction']=='UP'and q['levels'][0]==1]
 q=min(opts,key=lambda q:math.dist(e['test_end'],q['test_start']))
 proposal=copy.deepcopy(q);proposal['c']=list(e['c']);proposal['c'][1]=q.get('low_y',5.525);proposal['u']=[-x for x in e['u']];proposal['c'][0]+=-e['u'][1]*4.0;proposal['c'][2]+=e['u'][0]*4.0
 if e.get('wing','B')=='C':proposal['id']='CE23-NEW-UP-PROPOSAL'
 u=np.array(proposal['u']);center=np.array([proposal['c'][0],proposal['c'][2]]);start=center-u*float(q['run_m'])*.5-u*.8;end=center+u*float(q['run_m'])*.5+u*.8
 proposal['test_start']=[float(start[0]),q.get('low_y',5.525),float(start[1])];proposal['test_end']=[float(end[0]),q.get('high_y',10.875),float(end[1])]
 wing=e.get('wing','B');upper=next(f for f in F if f['wing']==wing and f['level']==2);foot=rect((center[0]-429,center[1]+46),u,q['run_m']+3.2,q['shaft_width_m']);retail=unary_union([s['polygon']for s in upper['stores']]);hit=foot.intersection(retail).area
 transfers.append({'wing':wing,'from':e['id'],'to':q['id'],'existing_lower':e,'existing_upper':q,'proposed_upper':proposal,'before_straight_line_m':math.dist(e['test_end'],q['test_start']),'proposed_straight_line_m':math.dist(e['test_end'],proposal['test_start']),'proposal_3F_retail_overlap_m2':hit,'proposal_floor_opening_change_m2':foot.intersection(upper['floor_plate']).area,'after_walking_distance_measured':False,'landing_review_required':True,'up_down_pair_redesign_required':True,'status':'UNBUILT PROPOSAL; no existing bank moved','reason':'Stack the next flight in reverse direction beside the same court; a floor opening/landing and structural review is required. C requires a new east 2F-3F bank rather than moving the only north bank.'})
write(P/'source/v11/escalator-transfer-proposals.json',{'bank_count':len(es),'records':transfers,'existing_positions_changed':False,'straight_line_is_not_walking_distance':True,'C_changes_unapproved':True})
# Explicit C support survey/proposal: distinguish slab visibility from structural engineering.
c=next(f for f in F if f['wing']=='C'and f['level']==0);point=Point(-134.5-429,-235.7+46);supports=[]
for level in[1,2,3]:
 ff=next(f for f in F if f['wing']=='C'and f['level']==level);pp=next(p for p in opt['floors']if p['level']==level);supports.append({'floor':ff['label'],'normal_deck_m2':ff['floor_plate'].area,'v10_option_deck_m2':pp['proposed_floor'].area,'above_reported_point_normal':ff['floor_plate'].covers(point),'above_reported_point_option':pp['proposed_floor'].covers(point),'structural_capacity_verified':False})
write(P/'source/v11/C-support-proposal.json',{'status':'UNAPPROVED / UNBUILT v11 support proposal','review_point_world':[-134.5,0,-235.7],'floors':supports,'proposal':['Retain pavilion-side galleries and the B/C bridge route; use the existing v10 reduction option only for visual comparison.','Arrange portal frames along each necessary bridge axis: conceptual 8m maximum module, columns at both edges of the deck outside protected walking lines, girders directly under the slab.','Anchor gallery ends to pavilion frames; reduce redundant cross-courtyard deck branches only after confirming every 2F/3F/RF store and EV/stair route.','Do not add isolated decorative columns without a continuous slab-girder-column-foundation load path.'],'conceptual_dimensions_m':{'gallery_clear_width':4.0,'portal_module_maximum_for_review':8.0,'candidate_column_width':.35,'candidate_girder_depth':.55},'dimension_status':'Game-space initial study; not engineered sections or verified spans. Exact placement is not approved.','not_verified':['loads','foundations','lateral stability','wind/seismic forces','fire/egress','vehicle clearances','column placement collision sweep'],'normal_geometry_changed':False,'RF_SUPPORT_16':'UNAPPROVED'})
# Current authoritative site contains the amended store inventory, not a second misleading old nav field.
site=read(P/'source/site-v7.json');site['floors']=F;site['revision']='v11 independent prototype; partial fit-out; structural proposals unapproved';write(P/'source/site-v11.json',site)
print('AUDIT',len(audit),'geometry_failures',len(failures),'flagged',sum(bool(r['flags'])for r in audit),'ES',len(es),'transfers',len(transfers),flush=True)
