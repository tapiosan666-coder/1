@echo off
cd /d "%~dp0"
call START-v10.cmd --rendering-method gl_compatibility
