@echo off
cd /d "%~dp0"
call START-v10.cmd -- --c-open-proposal
