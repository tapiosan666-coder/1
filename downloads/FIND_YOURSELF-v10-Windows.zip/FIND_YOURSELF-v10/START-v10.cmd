@echo off
cd /d "%~dp0"
if exist "FIND_YOURSELF_v10.exe" goto run
if not exist "runtime.001" goto missing
if not exist "runtime.002" goto missing
copy /b "runtime.001"+"runtime.002" "FIND_YOURSELF_v10.exe" >nul
if errorlevel 1 exit /b 2
:run
start "" "FIND_YOURSELF_v10.exe" %*
exit /b
:missing
echo Extract both Windows ZIP files into the same FIND_YOURSELF-v10 folder.
pause
exit /b 2
