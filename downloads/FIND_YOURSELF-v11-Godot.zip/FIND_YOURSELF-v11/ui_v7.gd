extends CanvasLayer
var game
var map:Control
var settings_panel:PanelContainer
var lift_panel:PanelContainer
var lift_buttons:VBoxContainer
var settings
var resolution:OptionButton
var caps:OptionButton
var vsync:CheckButton
var overlay:String=""
var lift_index:int=-1
func setup(g)->void:
 game=g;settings=load("res://settings_v7.gd").new();settings.restore()
 var theme=Theme.new();theme.default_font=g.font;theme.default_font_size=22
 var root=Control.new();root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);root.mouse_filter=Control.MOUSE_FILTER_IGNORE;root.theme=theme;add_child(root)
 map=load("res://map_v7.gd").new();root.add_child(map);map.setup(g.read_json("res://source/v11/map-data-C-option.json"if g.c_open_proposal else"res://source/map-data-v11.json"),g.player,g.font);map.visible=false
 settings_panel=PanelContainer.new();settings_panel.position=Vector2(555,235);settings_panel.size=Vector2(810,600);root.add_child(settings_panel);var style=StyleBoxFlat.new();style.bg_color=Color(.045,.065,.08,.98);style.content_margin_left=24;style.content_margin_right=24;style.content_margin_top=24;style.content_margin_bottom=24;style.corner_radius_top_left=12;style.corner_radius_top_right=12;style.corner_radius_bottom_left=12;style.corner_radius_bottom_right=12;settings_panel.add_theme_stylebox_override("panel",style)
 var v=VBoxContainer.new();v.add_theme_constant_override("separation",18);settings_panel.add_child(v)
 var title=Label.new();title.text="画面設定 / F10で閉じる";v.add_child(title)
 resolution=OptionButton.new()
 for text in ["1920 × 1080","2560 × 1440","3840 × 2160"]:resolution.add_item(text)
 resolution.select(settings.resolution_index);v.add_child(resolution)
 caps=OptionButton.new()
 for text in ["30 FPS","60 FPS","120 FPS","144 FPS","無制限"]:caps.add_item(text)
 caps.select(settings.LIMITS.find(settings.fps_limit));v.add_child(caps)
 vsync=CheckButton.new();vsync.text="VSync";vsync.button_pressed=settings.vsync;v.add_child(vsync)
 var apply=Button.new();apply.text="適用して保存";apply.pressed.connect(func():settings.resolution_index=resolution.selected;settings.fps_limit=settings.LIMITS[caps.selected];settings.vsync=vsync.button_pressed;settings.apply();close());v.add_child(apply)
 var note=Label.new();note.text="設定は独立検証版に保存します。\nVSync ON時は、画面の更新速度が実際の上限にもなります。\n物理更新は60 Hz、描画FPSとは分離しています。";note.add_theme_font_size_override("font_size",18);v.add_child(note);settings_panel.visible=false
 lift_panel=PanelContainer.new();lift_panel.position=Vector2(710,180);lift_panel.size=Vector2(500,650);root.add_child(lift_panel);lift_buttons=VBoxContainer.new();lift_buttons.add_theme_constant_override("separation",12);lift_panel.add_child(lift_buttons);lift_panel.visible=false
func pause_player(value:bool)->void:
 game.player.input_enabled=not value;game.player.velocity=Vector3.ZERO;game.player.set_physics_process(not value);game.elevators.set_physics_process(not value);game.animator.paused=value
 Input.mouse_mode=Input.MOUSE_MODE_VISIBLE if value else Input.MOUSE_MODE_CAPTURED
func close()->void:
 overlay="";map.visible=false;settings_panel.visible=false;lift_panel.visible=false;pause_player(false)
func show_map()->void:
 if overlay=="map":close();return
 close();overlay="map";map.follow_current_floor();map.visible=true;pause_player(true)
func show_settings()->void:
 if overlay=="settings":close();return
 close();overlay="settings";settings_panel.visible=true;pause_player(true)
func show_lift(index:int)->void:
 close();lift_index=index;overlay="lift";pause_player(true)
 for child in lift_buttons.get_children():child.queue_free()
 var r:Dictionary=game.elevators.records[index];var title=Label.new();title.text=r.data.id+" / 行先を選択";lift_buttons.add_child(title)
 for stop in range(r.data.stops.size()):
  var b=Button.new();b.text=r.data.stops[stop].label;b.pressed.connect(func():close();game.elevators.request(index,stop));lift_buttons.add_child(b)
 var cancel=Button.new();cancel.text="閉じる";cancel.pressed.connect(close);lift_buttons.add_child(cancel);lift_panel.visible=true
