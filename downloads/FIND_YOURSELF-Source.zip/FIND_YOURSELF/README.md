# FIND YOURSELF

**巨大モールにいる、自分と同じ顔の5,000人。その中の「本当の自分」を見つけるPCゲーム。**

Godot 4.6.3 / GDScript。現在は **0.17・A館上階の店舗と1階トイレを更新した日本語開発版**です。Steam販売版は開発中です。

2階は服飾・コスメ・住まい、3階はキッズ・文具・楽器・ホビーを中心に各12店舗へ。1階トイレは入口の目隠し、男女別区画、洗面12台、個室9、多機能/ベビー室を作り直しました。個室・試着室など13枚の扉は近づいて狙い、Fで開閉します。扉を狙っていないときのFは従来のソナーです。[実画面・変更内容・検証](docs/MALL_PHASE2.md)。

全68専門店の看板を、42の架空ブランドのロゴ・配色・図形・文字組みを持つデザインへ変更しました。[看板一覧](assets/retail/store_signs.png)。人物モデル自体は0.16を継続しています。

モール全体は[構造解析と15フロア案](docs/MALL_REDESIGN_PROPOSAL.md)、[寸法図・吹き抜け断面・第1工程](docs/MALL_PHASE1.md)をもとに段階改修中。B館の新外形や不足フロアはまだ実装していません。300人・訪問済み18地点と、初期スキャナーだけで本物を確定する仕様を維持しています。

以下は0.16以前の制作記録です。以前の個数・比較画像を含みます。

髪は22の立体的な束を前髪・側面・後頭部へ配置し、髪の流れに沿う陰影へ変更。細かい束の輪郭線が過剰に出るのを抑えました。服は肩を首から外へ傾斜させ、肘の折れと丸首の襟を調整。目の輪郭を固定したまま黒目とハイライトが動き、会話中は口元の線と眉も動きます。

[0.15からの近接比較とゲーム画面](docs/CHARACTER_POLISH.md)。全員が同じ基礎の顔を共有する仕様、12関節の衣服変形、300人・距離LODを維持します。『ペルソナ5』と同じ商用品質を完成した段階ではありません。

フードコートは丸みのあるテーブル9台、背もたれのある椅子36脚、料理10組、店舗カウンター4か所のPOS・受取口・トレー・調味料を作り直しました。座る位置をテーブルに寄せ、座面・膝・料理の高さも揃えています。建物や通路を増やす更新ではありません。

0.14の店舗仕上げ、フードコート入口の待合・手洗い給水・返却口、館内案内ラウンジと事前生成の陰影も保持しています。[前回の内装比較](docs/REALISM_COMPARISON.md)。

A館36・B館24・C館8の計68店舗に、新しい商品・小物モデル2,775点と、ポスター136枚・商品札201枚を配置。カップ・器・ボトル・靴・鞄・畳んだ衣類・ヘッドホン・タブレット・ランプ・植物などを業種に合わせて使い、従来の箱状の商品も一部置き換えました。個数は小物モデルの配置数で、旧版からの純増数ではありません。小物は店舗ごとにまとめ、標準40m・軽量28m・高画質55mの距離で描画します。

猫が経路の終点手前で止まる条件と、プレイヤー自身が解析を遮る条件を修正。近い階やその場で届く相手を選び、HUDに対象番号と残り時間を表示します。猫の経路探索を1更新につき最大2回、歩行NPCの経路要求を最大1回に抑え、まとめて計算する山を分散。これは実GPUのFPS保証とは区別します。

初期スキャナーの高速化をスキル画面へ追加。2→1.5→1→0.6秒、60/120/180 AP、銃の購入は不要。射程6mと単体の連続スキャンは維持します。NPCの判定半径を32→44cmに拡張し、壁越しの誤判定を防ぐ見通しの再確認を加えました。

![0.16のゲーム内の人物](https://github.com/tapiosan666-coder/1/raw/refs/heads/codex/mall-phase2-interiors/docs/screenshots/people16-game-face.png)

[0.12との店舗比較・新しいスキル画面](docs/STORE_COMPARISON.md)。[0.12の内装比較](docs/INTERIOR_COMPARISON.md)、[人物比較](docs/CHARACTER_COMPARISON.md)も保持。『8番出口』のような現実感は目標であり、同等品質へ到達した扱いにはしません。衣服の細かなシワ、表情と手指、施設全域の造形・照明・反射は制作途中です。

300人、定位置267・歩行33、A館5階層・B館1〜3階・C館1階、訪問済み18地点を維持。0.9の猫の自動スキャン修正、2・3階の回廊拡張、4系統のスキル画面も利用できます。0.8以降のLOD・区画描画・事前生成と画質設定を維持しています。[性能の条件と限界](docs/PERFORMANCE.md)。Windows実機のFPSは未測定です。

過去の変更は [更新内容](docs/CHANGELOG.md)、確定した仕様と仮設定の区別は [開発仕様](docs/DESIGN.md) を参照してください。

## すぐに遊ぶ

Smart App ControlでEXEがブロックされる場合は、[ソース版ZIP](https://github.com/tapiosan666-coder/1/raw/refs/heads/codex/mall-phase2-interiors/downloads/FIND_YOURSELF-Source.zip)と[Godotからの起動手順](docs/GODOT起動手順.md)を使用できます。公式Godot側の起動可否は端末のポリシーによります。

[Windows版ZIPをダウンロード](https://github.com/tapiosan666-coder/1/raw/refs/heads/codex/mall-phase2-interiors/downloads/FIND_YOURSELF-Windows.zip) → ZIPを右クリックして「すべて展開」→ 展開先の `FIND_YOURSELF.exe` を開いてください。


Windows用配布ビルドは `builds/FIND_YOURSELF-Windows.zip`、Linux用は `builds/FIND_YOURSELF-Linux.zip`。ZIPをすべて展開し、Windowsでは `FIND_YOURSELF.exe` をダブルクリックしてください。Linuxでは `./FIND_YOURSELF.x86_64` で起動します。PCKファイルを実行ファイルと同じフォルダーに置いてください。

Windowsバイナリはクロスビルド済みですが、このクラウド環境ではWindowsでの実行確認はできていません。Linuxでは描画・ゲーム動作・配布ビルド起動を検証しています。配布物は開発版です。Steamへの公開はしていません。

ソースから起動する場合：

1. [Godot 4.6.3 Standard版](https://godotengine.org/download/archive/4.6.3-stable/)をインストールします。.NET版は不要です。
2. Godotの「インポート」で、このフォルダーの `project.godot` を選びます。
3. **F6ではなくF5**でプロジェクトを実行します。
4. タイトル画面で肌・髪・顔幅を設定して **「探索をはじめる」** を押します。

ゲームにPython、Node.js、外部APIキーは不要です。UIは日本語です。日本語フォントを同梱しているため、追加インストールは不要です。写真からの顔生成は未実装です。

## 操作

| 操作 | キー |
| --- | --- |
| 移動 / 視点 | WASD / マウス |
| 初期スキャナー / 照準 | 左クリックを同じ1人へ2秒長押し / 右クリック |
| 装備切替 | 1：初期スキャナー / 2：購入済みスキャン銃 |
| リロード / ジャンプ / ダッシュ | R / Space / Shift |
| AP強化パネル | Tab |
| 瞬間ソナー / 範囲スキャン | F / Q（APで解放）|
| 連鎖スキャン / 二段ジャンプ | E / 空中でSpace（APで解放）|
| 案内図 / 訪問済み地点へ移動 | M（移動は100 APで解放後、目的地をクリック）|
| 宝箱を開ける / バッグ / 選択アイテムを使用 | G（近づいて） / I / X |
| 一時停止・再開 | Esc |

初期装備は手持ちの初期スキャナーです。6m以内の同じNPCを2秒間捉えながら左クリックを長押ししてください。対象変更・ボタンを離す・遮蔽・範囲外で途中進捗はリセットされます。偽物は床に落下し10 AP。Tabの「スキャン銃」を1,000 APで購入（300人版の仮設定）すると、2キーで銃を使えます。銃の強化は銃購入後に解放されます。銃・猫・範囲スキャンで本物を見つけてもクリアしません。必ず1キーで最初のスキャナーに戻し、本物を2秒間調べて確定します。

貫通スキャンは150 AP（銃購入が前提）、1発が最大3人に命中し壁で停止。連鎖スキャンは180 AP、照準した相手から5m以内・壁に遮られない近隣へ最大8人、再使用20秒。二段ジャンプは80 AP、着地で空中ジャンプが1回復活します。価格と人数は開発用の仮設定です。

ファストトラベルは100 AP。A館の従来10地点と、A・B連絡通路・B館東入口・B館2階ラウンジ・B館3階シネマ・B館家電売場・B・C連絡通路・C館屋外広場・C館テラスの案内ポイントから2m以内に近づくと訪問を記録します。Mのマップで訪問済みの地点だけを選択できます。新しいプレイでは訪問記録もリセットされます。

## 現在遊べる範囲

- 架空のA館の開発用区画を地下・1〜3階・屋上へ接続。西側階段で5階層を歩いて往復でき、1階から西駐車場へ通じる。地下に7つの食品カウンターと食品棚、屋上に植栽・ベンチ、西駐車場に40台の静止車両と歩行者通路。
- 既存の1〜3階。約180mの湾曲する主通路と3層の吹き抜け、各階12専門店、橋、2本のエスカレーター。1階には大型食品スーパー、回遊通路、フードコート、お手洗い、読書コーナー、バックヤード。
- B館は1〜3階の長大通路、各階8専門店と西側の大型売場、2本のエスカレーター。3階の映画館には18人の着席客。A館2階から連絡通路へ進むか、西駐車場の歩行路からB館1階へ入る。
- C館1階は、空が見える広場と周囲の8店舗、植栽・ベンチ・喫茶の席。B館1階の西端付近にある北側の入口から、54mの屋根付き連絡通路で接続する。
- 300人は全員同じ顔。定位置の267人（店員・買い物・読書・着席・会話・お手洗い・休憩）と歩行33人。近くの相手には日本語の吹き出し。表示を簡略化してもID・位置・スキャン判定を保持する。
- FPS移動・ダッシュ・ジャンプ・ADS。初期は単体・2秒・6mのスキャナー。途中で購入する銃は30m・5発・30発弾倉・1秒リロード・無限予備弾。
- 固定・等確率の本物、偽物だけの落下、AP、コンボ、合成サウンド、勝利・再プレイ。
- 4系統15種類の強化。ソナーは15→30→50→80→120m、4秒間の静止スナップショット。壁を透過するが本物は判別しない。
- 猫1匹（接近して見通しがある間に20→12→6秒のスキャン）、範囲スキャン（8→12→16m）。銃・猫・宝箱アイテムも本物は通知のみで、初期スキャナーだけが確定できる。
- 毎プレイ10宝箱（通常6・レア3・伝説1）、到達可能な経路点からランダム配置。人間磁石・超連鎖弾・時間停止時計・ブラックホール・全域ソナーチップ・スーパーカート・天井レーザー・ディスコフィーバー。数値は仮設定（詳細はDESIGN.md）。
- ポーズ、画質設定、スキル、バッグ、5階層を切り替える案内図、訪問済み18地点のみのファストトラベル。B館地下・屋上、C館の残る階層と連絡通路は今後追加する。

**5,000人の識別ロジックは自動テスト済みですが、5,000人の描画・15フロア・平均3時間のゲームプレイを完成したという意味ではありません。** 全体の確定仕様・実装状況は [DESIGN.md](docs/DESIGN.md) に記録しています。

## 開発・検証

```bash
# リポジトリのルートで実行
godot --headless --editor --import --quit
godot --headless --script res://tests/test_game.gd
godot --headless --script res://tests/test_mall_layout.gd
godot --headless --script res://tests/test_upper_and_restrooms.gd
godot --headless --script res://tests/test_store_signs.gd
godot --headless --script res://tests/test_expansion.gd
godot --headless --script res://tests/test_annex.gd
godot --headless --script res://tests/test_wing_b.gd
godot --headless --script res://tests/test_wing_c.gd
godot --headless --script res://tests/test_cat_and_skills.gd
godot --headless --script res://tests/test_scan_and_paths.gd
godot --headless --script res://tests/test_retail_detail.gd
godot --headless --script res://tests/test_dining_layout.gd
godot --headless --script res://tests/test_visual_access.gd
# 次は実際の描画環境が必要。--headlessを付けない
godot --script res://tests/test_character_motion.gd
godot --script res://tests/test_render_materials.gd
godot --script res://tests/test_world_art.gd
godot --path .

# 設計シミュレーションのみPythonが必要
python3 -m venv .venv  # ローカルで任意。クラウドでは以下のsetup_cloud.shを使う
.venv/bin/pip install -r tools/requirements.txt
.venv/bin/python tools/simulate_balance.py --trials 100000 --seed 20261023
```

建物・什器・群衆経路を変更した場合、[マップの事前生成手順](docs/WORLD_BAKING.md) で事前生成データを更新してください。配布ZIP作成時には入力スクリプトのハッシュ一致を検査します。

クラウドでの再セットアップは `bash tools/setup_cloud.sh`。現在のチェックアウトをそのまま使います。公開用にソースをZIP化する際、`.godot/`、`.git/`、`builds/`、仮想環境を含めないでください。

公式の同バージョンのexport templatesをGodotに導入すると、`godot --headless --export-release Windows` / `godot --headless --export-release Linux` でネイティブ実行ファイルを生成できます。クラウド設定ではテンプレートは `/workspace/.local/share/godot/export_templates/4.6.3.stable` に保存し、`XDG_DATA_HOME=/workspace/.local/share` を指定しています。

## 試算と次の段階

[10万回の結果と仮定](docs/BALANCE.md)は、未実装の完成版を想定した集約モデルです。実測のプレイ時間ではありません。0.2時点の集約モデルの仮定では平均210.6分、中央値205.8分です。180分の目標への調整と、長時間化する裾の改善が必要です。旧版の90.8分は現在の仕様の結果ではありません。本物の確率操作や配置変更で時間を引き延ばすことはしません。

次は髪と服の造形、より精細な素材と表情、作り込み区画の内装・照明の仕上げ、実プレイ計測を進めます。B館の地下・屋上、C館の残る階層、完成版の残りの区画、5,000人での描画とAI性能検証は今後の工程です。写真顔生成、セーブ／ロード、キー割り当て・音量設定、その他の言語対応、Steam連携・ストア素材・対象PCでのQAも販売前に必要です。

Godotと配布ランタイムに関する表示は [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) を参照してください。

人物アセットの再生成は任意です。通常のプレイとソースのインポートにはBlenderは不要です。制作手順と現状の限界は [美術・間取りの制作記録](docs/ART_AND_LAYOUT.md) を参照してください。
