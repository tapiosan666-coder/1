class_name FindHUD
extends Control

signal play_pressed
signal resume_pressed
signal restart_pressed
signal travel_pressed(key: String)
signal skill_pressed(key: String)
signal exit_pressed
var mode := "title"
var run: IdentityRun
var ammo := 30
var reload_progress := -1.0
var elapsed := 0.0
var target_id := -1
var notice := ""
var notice_time := 0.0
var hit_time := 0.0
var combo := 0
var sonar_cooldown := 0.0
var chain_cooldown := 0.0
var pulse_cooldown := 0.0
var target_distance := 0.0
var player_position := Vector3.ZERO
var location_name := "A館1階 / ショッピングモール"
var using_gun := false
var scan_progress := 0.0
var buttons: Control
var face_slider: HSlider
var skin_select: OptionButton
var hair_select: OptionButton
var font: Font
var ink := Color("eeecdf")
var muted := Color("8da4a6")
var lime := Color("b6f39b")
var orange := Color("f2b184")

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	font = preload("res://assets/fonts/NotoSansCJKjp-Regular.otf")
	theme = preload("res://assets/ui_theme.tres")
	buttons = Control.new()
	buttons.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	buttons.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(buttons)
	show_mode("title")

func _process(delta: float) -> void:
	notice_time = maxf(0, notice_time - delta)
	hit_time = maxf(0, hit_time - delta)
	queue_redraw()

func message(text: String) -> void:
	notice = text
	notice_time = 4.0

func _text(text: String, at: Vector2, size: int = 18, color: Color = ink) -> void:
	draw_string(font, at, text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func _line(a: Vector2, b: Vector2, color: Color = Color("405456")) -> void:
	draw_line(a, b, color, 1, true)

func _draw() -> void:
	if font == null:
		return
	if mode == "title":
		draw_rect(Rect2(0, 0, 690, 900), Color(0.035, 0.07, 0.085, 0.96))
		draw_rect(Rect2(690, 0, 750, 900), Color(0.02, 0.04, 0.05, 0.12))
		_text("自分を探す、奇妙なショッピングモール", Vector2(80, 78), 16, lime)
		_line(Vector2(80, 105), Vector2(610, 105))
		_text("FIND", Vector2(74, 230), 106)
		_text("YOURSELF", Vector2(74, 329), 106)
		_text("全員が同じ顔。本当の自分は、たった1人。", Vector2(82, 380), 18, lime)
		_text("静かなモールに、あなたと同じ顔の人々。", Vector2(82, 433), 21)
		_text("偽物をスキャンし、本当の自分を探そう。", Vector2(82, 465), 21)
		_text("全員に共通する、あなたの顔", Vector2(82, 524), 14, muted)
		_text("肌の色", Vector2(82, 558), 13, muted)
		_text("髪の色", Vector2(258, 558), 13, muted)
		_text("顔の幅", Vector2(434, 558), 13, muted)
		_text("WASD：移動　マウス：視点　Shift：ダッシュ", Vector2(82, 730), 16, muted)
		_text("左クリック長押し：2秒スキャン　右クリック：照準", Vector2(82, 758), 16, muted)
		_text("1：初期スキャナー　2：購入済みの銃　Esc：一時停止", Vector2(82, 786), 16, muted)
		_line(Vector2(82, 831), Vector2(610, 831))
		_text("日本語開発版 0.5 ／ A館1階 ／ 120人", Vector2(82, 860), 13, muted)
		_text("A館 / 中央通路", Vector2(1000, 790), 30)
		_text("店舗・フードコート・お手洗い", Vector2(1000, 820), 14, lime)
		return
	if run == null:
		return
	# Quiet header and large counters leave the center of the screen clear.
	draw_rect(Rect2(30, 25, 1380, 87), Color(0.035, 0.07, 0.085, 0.87))
	draw_rect(Rect2(30, 25, 4, 87), lime)
	_text("FIND YOURSELF", Vector2(55, 62), 24)
	_text(location_name, Vector2(55, 90), 14, muted)
	_text("残りの人数", Vector2(550, 51), 13, muted)
	_text("%03d" % (run.population - run.cleared), Vector2(550, 91), 35)
	_text("/ %03d" % run.population, Vector2(630, 88), 18, muted)
	_text("アビリティポイント", Vector2(855, 51), 13, muted)
	_text("%04d AP" % run.ap, Vector2(855, 91), 35, lime)
	_text("経過時間", Vector2(1210, 51), 13, muted)
	_text("%02d:%02d" % [int(elapsed) / 60, int(elapsed) % 60], Vector2(1210, 89), 30)
	if mode == "play":
		var center := Vector2(720, 450)
		var c := lime if target_id >= 0 else ink
		if hit_time > 0:
			for offset in [Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]:
				draw_line(center + offset * 9, center + offset * 16, lime, 2, true)
		else:
			draw_circle(center, 2.0, c)
			for dir in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
				draw_line(center + dir * 9, center + dir * 14, c, 1, true)
		if target_id >= 0:
			_text("対象 / %04d" % (target_id + 1), Vector2(765, 443), 13, muted)
			if using_gun:
				var count := mini(run.hits[target_id], run.required_hits())
				for i in run.required_hits():
					draw_rect(Rect2(765 + i * 19, 455, 14, 4), lime if i < count else Color("52686a"))
			else:
				_text("左クリック長押し / 残り %.1f秒" % (2.0 * (1 - scan_progress)), Vector2(765, 467), 14, lime)
		if not using_gun and scan_progress > 0:
			draw_arc(center, 25, -PI / 2, -PI / 2 + TAU * scan_progress, 64, lime, 3, true)
		if run.located:
			draw_rect(Rect2(498, 131, 444, 45), Color(0.08, 0.18, 0.17, 0.95))
			_text("本物を発見 / %.0fm / マーカーへ向かおう" % target_distance, Vector2(515, 159), 15, lime)
		if notice_time > 0:
			draw_rect(Rect2(420, 679, 650, 55), Color(0.035, 0.07, 0.085, 0.92))
			var notice_size := 16
			while font.get_string_size(notice, HORIZONTAL_ALIGNMENT_LEFT, -1, notice_size).x > 610 and notice_size > 12:
				notice_size -= 1
			_text(notice, Vector2(438, 712), notice_size, lime)
		if combo > 1 and notice_time > 0:
			_text("%02d 連続スキャン" % combo, Vector2(1060, 665), 32, orange)
		_draw_minimap()
		draw_rect(Rect2(1130, 753, 280, 112), Color(0.035, 0.07, 0.085, 0.9))
		if using_gun:
			_text("[2] スキャン銃", Vector2(1152, 779), 14, lime)
			_text("%02d" % ammo, Vector2(1150, 831), 45)
			_text("/ %02d　予備弾∞" % run.magazine_size(), Vector2(1226, 828), 15, muted)
			if reload_progress >= 0:
				draw_rect(Rect2(1152, 846, 236 * reload_progress, 3), lime)
		else:
			_text("[1] 初期スキャナー", Vector2(1152, 779), 14, lime)
			_text("%03d%%" % int(scan_progress * 100), Vector2(1150, 825), 35)
			_text("単体 / 2秒 / 射程6m", Vector2(1152, 850), 13, muted)
		draw_rect(Rect2(310, 818, 780, 70), Color(0.035, 0.07, 0.085, 0.9))
		_text("Tab / スキル購入", Vector2(325, 846), 14, muted)
		_text("F / ソナー " + ("未解放" if run.upgrades.sonar == 0 else ("使用可能" if sonar_cooldown <= 0 else "%d秒" % ceili(sonar_cooldown))), Vector2(535, 846), 14, lime if run.upgrades.sonar > 0 else muted)
		_text("E / 連鎖スキャン " + ("未解放" if run.upgrades.chain == 0 else ("使用可能" if chain_cooldown <= 0 else "%d秒" % ceili(chain_cooldown))), Vector2(800, 870), 14, lime if run.upgrades.chain > 0 else muted)
		_text("Q / 範囲スキャン " + ("未解放" if run.upgrades.pulse == 0 else ("使用可能" if pulse_cooldown <= 0 else "%d秒" % ceili(pulse_cooldown))), Vector2(800, 846), 14, lime if run.upgrades.pulse > 0 else muted)
		return
	draw_rect(Rect2(0, 0, 1440, 900), Color(0.025, 0.055, 0.065, 0.95))
	if mode == "skills":
		_text("探索する力を、手に入れよう。", Vector2(70, 90), 36)
		_text("スキル購入・強化　／　所持 %d AP" % run.ap, Vector2(72, 130), 19, lime)
		_text("購入した能力は今回のプレイ中ずっと有効です。この画面ではゲームが一時停止します。", Vector2(72, 163), 16, muted)
	elif mode == "pause":
		_text("ひと休みしましょう。", Vector2(460, 325), 52)
		_text("準備ができたら、探索を再開できます。", Vector2(463, 370), 20, muted)
	elif mode == "win":
		_text("本当の自分を見つけた。", Vector2(330, 300), 62, lime)
		_text("同じ顔の人々の中に、あなたは確かにいた。", Vector2(398, 354), 22)
		_text("処理 %d人　／　%02d:%02d　／　残り %d AP" % [run.cleared, int(elapsed) / 60, int(elapsed) % 60, run.ap], Vector2(452, 425), 20, muted)
		_text("ほかの人々は、モールに残っています。", Vector2(479, 466), 18, muted)
	elif mode == "map":
		_text("A館1階 / フロアマップ", Vector2(100, 160), 40)
		_text("訪問した案内ポイントのみ移動できます ／ Tabでファストトラベルを購入", Vector2(102, 201), 16, lime)
		var frame := Rect2(200, 250, 1040, 450)
		_draw_plan(frame)
		_text("フードコート", _map_point(Vector2(49, -47), frame), 16)
		_text("食品スーパー", _map_point(Vector2(7,36),frame),16)
		_text("お手洗い", _map_point(Vector2(-87, 42), frame), 16)
		_text("中央通路", _map_point(Vector2(-5, 3), frame), 16)
		draw_circle(_map_point(Vector2(player_position.x, player_position.z), frame), 6, lime)
		for key in Mall.HUBS:
			var p: Vector3 = Mall.HUBS[key]
			draw_circle(_map_point(Vector2(p.x,p.z),frame),5,lime if run.visited.has(key) else muted)
		_text("A館1階のみ探索可能 ／ 上階の回廊は現在、景観用です。",Vector2(430,716),15,muted)

func _draw_minimap() -> void:
	draw_rect(Rect2(30, 712, 250, 153), Color(0.035, 0.07, 0.085, 0.9))
	_text("現在地 / A館1階", Vector2(48, 738), 13, lime)
	var frame := Rect2(49, 751, 212, 86)
	_draw_plan(frame)
	var here := _map_point(Vector2(player_position.x, player_position.z), frame)
	draw_circle(here, 4, lime)
	_text("M / フロアマップ", Vector2(48, 854), 12, muted)

func _map_point(p: Vector2, frame: Rect2) -> Vector2:
	var bounds := Rect2(-96, -68, 194, 130)
	var scale_factor := minf(frame.size.x / bounds.size.x, frame.size.y / bounds.size.y)
	return frame.position + (frame.size - bounds.size * scale_factor) / 2 + (p - bounds.position) * scale_factor

func _draw_plan(frame: Rect2) -> void:
	draw_rect(frame, Color("14272d"))
	for region in Mall.floor_regions:
		var start := _map_point(region.position, frame)
		var end := _map_point(region.end, frame)
		draw_rect(Rect2(start, end - start), Color("42535a"))
	for area in [Mall.MAIN, Mall.PROMENADE, Mall.FOOD, Mall.RESTROOM, Mall.MARKET]:
		var start := _map_point(area.position, frame)
		var end := _map_point(area.end, frame)
		var color := Color("677d70") if area in [Mall.FOOD,Mall.MARKET] else Color("486e82") if area == Mall.RESTROOM else Color("899387")
		draw_rect(Rect2(start, end - start), color)
	for side in [-1, 1]:
		for x in Mall.SHOP_CENTERS:
			if not Mall.has_shop(x, side):
				continue
			var start := _map_point(Vector2(x - 9, -24 if side < 0 else 8), frame)
			var end := _map_point(Vector2(x + 9, -8 if side < 0 else 24), frame)
			var rect := Rect2(start, end - start)
			draw_rect(rect, Color("394f58"))
			draw_rect(rect, Color("839796"), false, 1)
			if frame.size.x > 400:
				_text(Mall.CATEGORIES[Mall.SHOP_CENTERS.find(x)], rect.position + Vector2(5, 26), 10)

func show_mode(next: String) -> void:
	mode = next
	for child in buttons.get_children():
		buttons.remove_child(child)
		child.queue_free()
	match mode:
		"title":
			skin_select = _option(Vector2(82, 570), ["明るい肌", "濃い肌", "赤みのある肌"])
			hair_select = _option(Vector2(258, 570), ["黒", "茶", "銀"])
			face_slider = HSlider.new()
			face_slider.position = Vector2(434, 570)
			face_slider.size = Vector2(160, 36)
			face_slider.min_value = 0.85
			face_slider.max_value = 1.15
			face_slider.step = 0.01
			face_slider.value = 1.0
			buttons.add_child(face_slider)
			_button("探索をはじめる　→", Rect2(82, 638, 400, 58), func(): play_pressed.emit(), true)
		"pause":
			_button("探索を再開", Rect2(460, 420, 520, 58), func(): resume_pressed.emit(), true)
			_button("最初からやり直す", Rect2(460, 498, 520, 54), func(): restart_pressed.emit())
			_button("ゲームを終了", Rect2(460, 572, 520, 54), func(): exit_pressed.emit())
		"skills":
			var i := 0
			for key in IdentityRun.SKILLS:
				var skill: Dictionary = IdentityRun.SKILLS[key]
				var col := i % 4
				var row := i / 4
				var maxed: bool = run.upgrades[key] >= skill.max
				var text := "%s\n%s  [%d/%d]\n%s\n%s" % [skill.branch, skill.name, run.upgrades[key], skill.max, skill.detail, "最大レベル" if maxed else "%d AP" % run.price(key)]
				var button := _button(text, Rect2(70 + col * 330, 192 + row * 137, 312, 126), func(): skill_pressed.emit(key))
				button.add_theme_font_size_override("font_size", 14)
				button.disabled = maxed or run.ap < run.price(key) or (key == "cat_speed" and run.upgrades.cat == 0) or (key in ["focus", "magazine", "reload", "range", "pierce"] and run.upgrades.gun == 0)
				i += 1
			_button("探索に戻る / Tab", Rect2(70, 772, 420, 56), func(): resume_pressed.emit(), true)
		"win":
			_button("もう一度探す", Rect2(460, 530, 520, 62), func(): restart_pressed.emit(), true)
			_button("ゲームを終了", Rect2(460, 612, 520, 54), func(): exit_pressed.emit())
		"map":
			var index := 0
			for key in Mall.HUBS:
				var label: String = key + (" / 移動" if run.can_travel(key) else " / 要スキル" if run.visited.has(key) else " / 未訪問")
				var button := _button(label,Rect2(100+index*250,742,238,45),func(): travel_pressed.emit(key))
				button.add_theme_font_size_override("font_size",15)
				button.disabled = not run.can_travel(key)
				index += 1
			_button("探索に戻る / M", Rect2(510, 806, 420, 55), func(): resume_pressed.emit(), true)
	queue_redraw()

func _option(at: Vector2, options: Array) -> OptionButton:
	var option := OptionButton.new()
	option.position = at
	option.size = Vector2(160, 36)
	for text in options:
		option.add_item(text)
	buttons.add_child(option)
	return option

func _button(text: String, rect: Rect2, callback: Callable, primary: bool = false) -> Button:
	var button := Button.new()
	button.text = text
	button.position = rect.position
	button.size = rect.size
	button.add_theme_font_size_override("font_size", 19)
	var style := StyleBoxFlat.new()
	style.bg_color = lime if primary else Color("1c343c")
	style.border_color = Color("4e686b")
	style.set_border_width_all(1)
	style.set_corner_radius_all(3)
	button.add_theme_stylebox_override("normal", style)
	var hover := style.duplicate() as StyleBoxFlat
	if primary:
		hover.bg_color = Color("d6ffc1")
	else:
		hover.bg_color = Color("34545b")
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("pressed", hover)
	button.add_theme_stylebox_override("disabled", style)
	button.add_theme_color_override("font_disabled_color", Color("9ca9a8"))
	button.add_theme_color_override("font_color", Color("152b30") if primary else ink)
	button.add_theme_color_override("font_hover_color", Color("152b30") if primary else ink)
	button.add_theme_color_override("font_pressed_color", Color("152b30") if primary else ink)
	button.pressed.connect(callback)
	buttons.add_child(button)
	return button
